<?php require 'layout.php'; top('Billing', 'b', 'Bills, payments, checks and customer balances'); ?>
<div class="tabs2" id="tabs" style="margin-bottom:1rem">
  <button type="button" data-t="ready" class="on">Ready for billing <span class="badge p" id="nReady">0</span></button>
  <button type="button" data-t="balances">Unpaid balances</button>
  <button type="button" data-t="checks">Checks <span class="badge p" id="nChecks">0</span></button>
  <button type="button" data-t="history">All bills</button>
</div>
<div id="pane"></div>
<script>
const SP = new URLSearchParams(location.search);
let tab = ['ready', 'balances', 'checks', 'history'].includes(SP.get('tab')) ? SP.get('tab') : 'ready', page = 1, timer, age = '', hiClient = +SP.get('client') || 0;
const billStatus = s => `<span class="badge ${s === 'Paid' || s === 'Transferred' ? 'g' : s === 'Partially paid' ? 'p' : 'x'}"${window.UI14 && UI14.stOf(s) ? ` data-st="${UI14.stOf(s)}"` : ''}>${E(s)}</span>`;
const ageTag = d => `<span class="agep ${d <= 30 ? 'a1' : d <= 60 ? 'a2' : 'a3'}">${d} day${d === 1 ? '' : 's'}</span>`;

function setTab(t) { tab = t; page = 1; age = ''; $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.t === t)); try { history.replaceState(null, '', 'bills.php?tab=' + t); } catch (e) {} draw(); }
$$('#tabs button').forEach(b => b.onclick = () => setTab(b.dataset.t));

async function draw() {
  try {
    if (tab === 'ready' || tab === 'history') await drawBills();
    else if (tab === 'balances') await drawBalances();
    else await drawChecks();
  } catch (x) { $('#pane').innerHTML = `<p class="err">${E(x.message)}</p>`; }
}

async function drawBills() {
  const ready = tab === 'ready';
  if (!$('#bq')) $('#pane').innerHTML = `<div class="toolbar"><input id="bq" placeholder="Search owner, pet or bill number..." style="flex:1">${ready ? '' : '<label class="chk"><input type="checkbox" id="ball"> Both branches</label>'}</div>
    <div class="card"><h2>${ready ? 'Waiting for payment' : 'All bills'}</h2><p class="muted" style="margin-top:0">${ready ? 'Oldest first. A bill appears here when the vet presses Done (or from a desk sale). Open it to review the charges, then take payment.' : 'Every bill that was sent to the front desk, newest first.'}</p>
    <table><thead><tr><th>Bill</th><th>Owner / pet</th><th>Items</th><th class="r">Total</th><th class="r">Paid</th><th>Status</th><th></th></tr></thead><tbody id="rows"></tbody></table>
    <div class="pager"><span id="info"></span><div id="pages"></div></div></div>`;
  else if (ready !== !!$('#bq').dataset.ready) { $('#pane').innerHTML = ''; return drawBills(); }
  $('#bq').dataset.ready = ready ? '1' : '';
  const r = await api(`/api/bills?tab=${tab}&q=${encodeURIComponent($('#bq').value)}&page=${page}${!ready && $('#ball')?.checked ? '&all=1' : ''}`);
  $('#nReady').textContent = r.ready; $('#nChecks').textContent = r.checks;
  $('#rows').innerHTML = r.rows.length ? r.rows.map(b => `<tr>
    <td><b>#${b.id}</b><br><small class="muted">${fmtDate(b.sale_date)}${ready ? '' : ' &middot; ' + E(b.branch || '')}</small></td>
    <td><div class="pn">${b.pet ? pav(b.pet, b.species, null, 'sm') : ''}<div>${E(b.client || 'Walk-in customer')}${+b.client_owes > 0 && +b.client_owes > (+b.total - +b.paid) + 0.004 ? ` <span class="owes" title="Total owed across all unpaid bills">Owes ${peso(b.client_owes)}</span>` : ''}<br><small class="muted">${E(b.pet || '')}${b.service ? ' &middot; ' + E(b.service) : ''}${b.prepared_by ? ' &middot; by ' + E(b.prepared_by) : ''}</small></div></div></td>
    <td><small>${E(b.items || '')}</small>${+b.desk_changed ? ' <span class="badge g">changed by front desk</span>' : ''}</td>
    <td class="r"><b>${peso(b.total)}</b></td><td class="r">${peso(b.paid)}</td><td>${billStatus(b.status)}</td>
    <td class="nowrap">${['Unpaid', 'Partially paid'].includes(b.status) ? `<a class="btn sm" href="pay.php?id=${b.id}">Take payment</a>` : `<a class="btn ghost sm" href="receipt.php?id=${b.id}">Statement</a>`}
      ${b.appt_id ? `<a class="btn plain sm" href="charge.php?appt=${b.appt_id}">View sheet</a>` : ''}</td></tr>`).join('')
    : `<tr><td colspan="7" class="empty">${ready ? 'Nothing is waiting for payment. New bills show up here (with a chime) when a vet presses Done.' : 'No bills found.'}</td></tr>`;
  pager(r, page, n => { page = n; drawBills(); }, $('#info'), $('#pages'));
  $('#bq').oninput = () => { clearTimeout(timer); timer = setTimeout(() => { page = 1; drawBills(); }, 250); };
  if ($('#ball')) $('#ball').onchange = () => { page = 1; drawBills(); };
}

async function drawBalances() {
  if (!$('#cq')) $('#pane').innerHTML = `<div id="bk"></div><div class="toolbar"><input id="cq" placeholder="Search owner name or phone..." style="flex:1"><button type="button" class="btn ghost" id="csv">Download CSV</button></div>
    <div class="card"><h2>Who owes the clinic</h2><p class="muted" style="margin-top:0">Unpaid bills of both branches, oldest first. Service is never blocked because of a balance: this list is for gentle reminders and collection.</p>
    <table><thead><tr><th>Owner</th><th>Phone</th><th class="r">Bills</th><th>Oldest</th><th class="r">Owes</th><th></th></tr></thead><tbody id="rows"></tbody></table></div>`;
  const r = await api(`/api/balances?q=${encodeURIComponent($('#cq').value)}&age=${age}`), b = r.buckets;
  $('#bk').innerHTML = `<div class="kpis"><button type="button" class="card kp ${age === '' ? '' : ''}" data-a="" style="text-align:left;cursor:pointer"><h2>Total owed</h2><div class="big">${peso(b.a + b.b + b.c)}</div><span class="muted">All unpaid bills</span></button>
    <button type="button" class="card kp" data-a="a" style="text-align:left;cursor:pointer"><h2>0 to 30 days</h2><div class="big">${peso(b.a)}</div><span class="muted">${age === 'a' ? 'Showing these' : 'Tap to filter'}</span></button>
    <button type="button" class="card kp ${b.b > 0 ? 'hot' : ''}" data-a="b" style="text-align:left;cursor:pointer"><h2>31 to 60 days</h2><div class="big">${peso(b.b)}</div><span class="muted">${age === 'b' ? 'Showing these' : 'Tap to filter'}</span></button>
    <button type="button" class="card kp ${b.c > 0 ? 'owe' : ''}" data-a="c" style="text-align:left;cursor:pointer"><h2>Over 60 days</h2><div class="big">${peso(b.c)}</div><span class="muted">${age === 'c' ? 'Showing these' : 'Tap to filter'}</span></button></div>`;
  $$('#bk [data-a]').forEach(x => x.onclick = () => { age = x.dataset.a; drawBalances(); });
  $('#rows').innerHTML = r.rows.length ? r.rows.map(c => `<tr id="c${c.id}" ${+c.id === hiClient ? 'style="background:#fff9e6"' : ''}><td><b>${E(c.name)}</b></td><td>${E(c.phone || '-')}</td><td class="r">${c.bills}</td><td>${fmtDate(c.oldest)} ${ageTag(+c.age)}</td>
    <td class="r"><span class="owes">${peso(c.owed)}</span></td><td class="nowrap"><a class="btn ghost sm" href="statement.php?client=${c.id}">Statement</a> <a class="btn sm" href="pay.php?client=${c.id}">Take payment</a></td></tr>`).join('')
    : '<tr><td colspan="6" class="empty">Nobody owes anything here. </td></tr>';
  $('#cq').oninput = () => { clearTimeout(timer); timer = setTimeout(drawBalances, 250); };
  $('#csv').onclick = () => {
    const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"', rows = [['Owner', 'Phone', 'Unpaid bills', 'Oldest bill', 'Days old', 'Owes'], ...r.rows.map(c => [c.name, c.phone, c.bills, c.oldest, c.age, (+c.owed).toFixed(2)])];
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([rows.map(x => x.map(q).join(',')).join('\r\n')], { type: 'text/csv' })); a.download = 'greenland-balances-' + new Date().toISOString().slice(0, 10) + '.csv'; a.click();
  };
  if (hiClient && $('#c' + hiClient)) { $('#c' + hiClient).scrollIntoView({ block: 'center' }); hiClient = 0; }
}

async function drawChecks() {
  $('#pane').innerHTML = `<div class="toolbar"><select id="cs" style="width:14rem"><option value="Pending clearing">Pending clearing</option><option value="">All checks</option><option value="Cleared">Cleared</option><option value="Bounced">Bounced</option></select></div>
    <div class="card"><h2>Check payments</h2><p class="muted" style="margin-top:0">A check counts as money only after it clears. Until then the bill still shows what was promised as "Pending clearing". If a check bounces the amount goes back onto the customer's balance and the staff are alerted.</p>
    <table><thead><tr><th>Bill</th><th>Owner</th><th>Bank / check no.</th><th>Check date</th><th class="r">Amount</th><th>Status</th><th></th></tr></thead><tbody id="rows"></tbody></table></div>`;
  const load = async () => {
    const rows = await api('/api/bills/checks?status=' + encodeURIComponent($('#cs').value));
    $('#rows').innerHTML = rows.length ? rows.map(c => `<tr><td><a class="link" href="receipt.php?id=${c.sale_id}">#${c.sale_id}</a><br><small class="muted">${E(c.branch || '')}</small></td><td>${E(c.client || '-')}</td><td>${E(c.bank || '')}<br><small class="muted">No. ${E(c.check_no || '')}</small></td>
      <td>${c.check_date ? fmtDate(c.check_date) : '-'}</td><td class="r"><b>${peso(c.amount)}</b></td><td><span class="badge ${c.check_status === 'Cleared' ? '' : c.check_status === 'Bounced' ? 'x' : 'p'}">${E(c.check_status)}</span></td>
      <td class="nowrap">${c.check_status === 'Pending clearing' ? `<button type="button" class="btn sm" data-c="${c.id}" data-s="Cleared">Mark cleared</button> <button type="button" class="btn danger sm" data-c="${c.id}" data-s="Bounced">Bounced</button>` : ''}</td></tr>`).join('')
      : '<tr><td colspan="7" class="empty">No checks here.</td></tr>';
    $$('#rows [data-c]').forEach(b => b.onclick = async () => {
      if (b.dataset.s === 'Bounced' && !confirm('Mark this check as bounced? The amount goes back onto the customer balance.')) return;
      try { await api('/api/bills/check/' + b.dataset.c, { status: b.dataset.s }); load(); } catch (x) { alert(x.message); }
    });
  };
  $('#cs').onchange = load; await load();
}

api('/api/bills?tab=ready&page=1').then(r => { $('#nReady').textContent = r.ready; $('#nChecks').textContent = r.checks; }).catch(() => {});
setTab(tab);
</script>
<?php bottom(); ?>

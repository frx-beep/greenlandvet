<?php require 'layout.php'; top('Sales', 'l', 'Sales and money'); require 'sales_view.php'; bottom(); ?>

<?php require 'layout.php'; top('Dashboard', 'd'); ?>
<div class="kpis" id="kp"></div>
<?php if (ui_ns()): ?><div class="card nscard" id="nsCard"><p class="muted">Loading the queue...</p></div><?php endif; ?>
<div class="row2">
  <div class="card"><h2 id="cTitle">Appointments Today</h2><div class="big" id="count">0</div><span class="muted" id="split"></span></div>
  <div class="card"><h2>Quick Actions</h2>
    <div class="btns"><a class="btn" href="client_new.php">+ New Client</a><a class="btn ghost" href="pet_new.php">+ Add Pet</a><a class="btn ghost" href="appt_new.php">+ New Appointment</a><a class="btn ghost" href="checkin.php">Queue / check in (scan QR)</a></div>
    <span class="muted">Register a client, add a pet under an existing client, or book a visit.</span></div>
</div>
<div class="row3">
  <div class="card"><div class="hd"><h2 id="month"></h2><div class="nav2"><button id="prev" aria-label="Previous month">&lsaquo;</button><button id="next" aria-label="Next month">&rsaquo;</button></div></div><div class="cal" id="cal"></div><div class="callegend" id="callegend"></div></div>
  <div class="card"><div class="hd"><h2 id="dayTitle"></h2><a class="btn plain" href="appointments.php">View all</a></div>
    <table><thead><tr><th>Time</th><th>Client</th><th>Pet</th><th>Service</th><th>Status</th></tr></thead><tbody id="rows"></tbody></table></div>
</div>
<div class="card"><h2>Search &amp; View Clients</h2>
  <form class="searchrow" id="sf"><input id="q" placeholder="Search by client name, pet name, or contact number..."><button class="btn">Search</button></form>
  <div class="cards3" id="found"></div></div>
<script>
const ymd = d => d.toLocaleDateString('en-CA');
const todayK = ymd(new Date());
let sel = todayK, view = new Date(); view.setDate(1);
let dayRows = [];
$('#crumb').textContent = new Date().toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });

async function drawCal() {
  const y = view.getFullYear(), m = view.getMonth();
  $('#month').textContent = view.toLocaleDateString('en', { month: 'long', year: 'numeric' });
  const mon = `${y}-${String(m + 1).padStart(2, '0')}`;
  const counts = await api(`/api/appointments/counts?month=${mon}`);
  const mix = window.UI14 ? await api(`/api/appointments/mix?month=${mon}`).catch(() => null) : null;   // coloured dots per service (Update 15)
  const SV = { Vaccination: 'v', 'Check-Up': 'c', Confinement: 'f', Surgery: 's' };
  const dots = k => mix && mix[k] ? '<span class="dts">' + Object.keys(SV).filter(n => mix[k][n]).map(n => `<em class="${SV[n]}" title="${n}: ${mix[k][n]}"></em>`).join('') + '</span>' : counts[k] ? '<i></i>' : '';
  let h = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => `<span class="dow">${d}</span>`).join('') + '<span></span>'.repeat(new Date(y, m, 1).getDay());
  for (let d = 1; d <= new Date(y, m + 1, 0).getDate(); d++) {
    const k = ymd(new Date(y, m, d));
    h += `<button class="day ${k === sel ? 'sel' : ''}${window.UI14 && k === todayK ? ' today' : ''}" data-d="${k}">${d}${dots(k)}</button>`;
  }
  $('#cal').innerHTML = h;
  if (window.UI14) $('#callegend').innerHTML = [['Vaccination', 'var(--sv-vac)'], ['Check-Up', 'var(--sv-chk)'], ['Confinement', 'var(--sv-conf)'], ['Surgery', 'var(--sv-surg)']].map(([n, c]) => `<span style="--lc:${c}">${n}</span>`).join('');
  $$('.day').forEach(b => b.onclick = () => { sel = b.dataset.d; drawCal(); drawDay(); });
}
async function drawDay() {
  const rows = dayRows = await api('/api/appointments/day?date=' + sel);
  const nice = new Date(sel + 'T00:00').toLocaleDateString('en', { weekday: 'short', month: 'short', day: 'numeric' });
  const live = rows.filter(r => r.status !== 'Cancelled'), conf = rows.filter(r => r.status === 'Confirmed').length, pend = rows.filter(r => r.status === 'Pending').length, done = rows.filter(r => r.status === 'Completed').length, gone = rows.length - live.length;
  $('#cTitle').textContent = sel === todayK ? 'Appointments Today' : 'Appointments on ' + nice;
  $('#dayTitle').textContent = 'Daily Appointments: ' + nice;
  $('#count').textContent = live.length;
  $('#split').textContent = `scheduled, ${conf} confirmed, ${pend} pending` + (done ? `, ${done} done` : '') + (gone ? `, ${gone} cancelled` : '');
  $('#rows').innerHTML = rows.length ? rows.map((a, i) => `<tr class="click" data-i="${i}" title="Click for details"><td>${+a.is_queue ? 'Any time' : fmtTime(a.time)}</td><td><a class="link" href="client.php?id=${a.client_id}">${esc(a.client)}</a></td><td><span class="pn">${pav(a.pet, a.species, null, 'sm')}${esc(a.pet)}</span></td><td>${esc(a.service)}</td>
    <td>${badge(a.status)}${a.source === 'Online' ? ' <span class="badge g">Online</span>' : ''}${a.checked_in_at ? ' <span class="badge">Arrived' + (a.room ? ', ' + E(a.room) : '') + '</span>' : ''}</td></tr>`).join('') : '<tr><td colspan="5" class="empty">No appointments for this day.</td></tr>';
  $$('#rows tr[data-i]').forEach(tr => tr.onclick = e => { if (!e.target.closest('a')) manageAppt(dayRows[tr.dataset.i], sel, () => { drawDay(); drawCal(); }); });
}
async function find(q = '') {
  const r = await api(`/api/clients?per=6&q=${encodeURIComponent(q)}`);
  $('#found').innerHTML = r.rows.length ? r.rows.map(c => `<a class="cl" href="client.php?id=${c.id}">${pavs(c.pet_pairs)} <b>${esc(c.name)}</b><br><small>${c.npets} pet${c.npets == 1 ? '' : 's'}, ${esc(c.phone)}</small></a>`).join('')
    : '<p class="muted">No clients found. Try "+ New Client".</p>';
}
$('#prev').onclick = () => { view.setMonth(view.getMonth() - 1); drawCal(); };
$('#next').onclick = () => { view.setMonth(view.getMonth() + 1); drawCal(); };
$('#sf').onsubmit = e => { e.preventDefault(); find($('#q').value.trim()); };
$('#q').oninput = () => find($('#q').value.trim());
async function kpis() {
  try { const k = await api('/api/dash'), t = k.trend || {}, W = t.weekday ? 'last ' + t.weekday : 'last week';
    const card = (href, cls, title, big, sub, ic, extra) => `<a class="card kp ${cls}" href="${href}">${uic(ic)}<h2>${title}</h2><div class="big">${big}</div><span class="muted">${sub}</span>${extra || ''}</a>`;
    const have = t.patients_7 !== undefined;
    $('#kp').innerHTML =
      (window.UI14 && have ? card('appointments.php', '', 'Patients today', t.patients, 'booked or walked in', 'calendar', trendHTML(t.patients, t.patients_lw, W) + spark(t.patients_7)) : '') +
      card('checkin.php', '', 'In the queue', k.waiting, `${k.in_room} being seen &middot; ${k.on_duty} vet${k.on_duty === 1 ? '' : 's'} on duty${k.queue_open ? '' : ' &middot; check-ups closed'}`, 'users') +
      card('confined.php', '', 'Confined', k.confined, (k.surgery || []).map(r => r.free ? 'Surgery room free' : 'Surgery room in use').join('') || 'patients staying with us', 'bed') +
      card('general.php', k.pending_records ? 'hot' : '', 'Records to finish', k.pending_records, `visit${k.pending_records === 1 ? '' : 's'} waiting for records`, 'box'); } catch (x) {}
}
drawCal(); drawDay(); find(); kpis(); setInterval(kpis, 20000);
</script>
<?php bottom(); ?>

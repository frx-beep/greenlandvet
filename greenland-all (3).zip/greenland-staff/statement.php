<?php require 'layout.php'; top('Statement of Account', 'b', 'Billing > Customer balances > Statement'); ?>
<div class="receipt card wide" id="st"><p class="muted">Loading...</p></div>
<div class="btns noprint" style="justify-content:center"><button class="btn" onclick="window.print()">Print statement</button><a class="btn ghost" id="pay" href="#">Take payment</a><a class="btn plain" href="bills.php?tab=balances">Back</a></div>
<script>
(async () => {
  const id = param('client'); $('#pay').href = 'pay.php?client=' + id;
  try {
    const r = await api('/api/balances/' + id), c = r.client;
    $('#st').innerHTML = `<div class="center"><h2 style="margin:0">Greenland Veterinary Clinic</h2><h3 style="margin:.6rem 0 0">STATEMENT OF ACCOUNT</h3><p class="muted" style="margin:.2rem 0">As of ${E(r.printed)}</p></div>
      <dl class="rdl"><dt>Client</dt><dd>${E(c.name)}</dd>${c.phone ? `<dt>Phone</dt><dd>${E(c.phone)}</dd>` : ''}${c.address ? `<dt>Address</dt><dd>${E(c.address)}</dd>` : ''}</dl>
      <h4 style="margin:1rem 0 .3rem">Unpaid bills</h4>
      <table><thead><tr><th>Bill</th><th>Date</th><th>For</th><th class="r">Total</th><th class="r">Paid</th><th class="r">Balance</th><th class="r">Age</th></tr></thead><tbody>${r.bills.map(b => `<tr><td>#${b.id}</td><td>${fmtDate(b.sale_date)}</td><td>${E(b.pet || '')} ${clip(b.items, 40)}</td><td class="r">${peso(b.total)}</td><td class="r">${peso(b.paid)}</td><td class="r">${peso(b.total - b.paid)}</td><td class="r">${b.age} d</td></tr>`).join('') || '<tr><td colspan="7" class="empty">No unpaid bills.</td></tr>'}</tbody></table>
      <div class="total"><b>TOTAL AMOUNT DUE</b><b>${peso(r.balance)}</b></div>
      ${r.payments.length ? `<h4 style="margin:1rem 0 .3rem">Recent payments</h4><table><tbody>${r.payments.map(p => `<tr><td>${fmtDate(p.created_at.slice(0, 10))}</td><td>${E(p.method)}${p.check_status ? ' (' + E(p.check_status) + ')' : ''}</td><td>bill #${p.sale_id}</td><td class="r">${peso(p.amount)}</td></tr>`).join('')}</tbody></table>` : ''}
      <p class="center muted" style="margin-top:1rem">Please settle the balance at your next visit. Thank you!</p>
      <p class="center notofficial"><b>This is not an official receipt.</b></p>`;
  } catch (x) { $('#st').innerHTML = `<p class="err">${E(x.message)}</p>`; }
})();
</script>
<?php bottom(); ?>

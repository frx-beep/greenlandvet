<?php require 'layout.php'; top('Pet Profile', 'c', 'Clients'); ?>
<a class="btn plain" id="back" href="clients.php" style="margin-bottom:1rem">&larr; Back</a>
<div class="card petbar"><div class="ph">Pet photo</div>
  <div><h2 id="pn"></h2><p class="muted" id="pl" style="margin:.2rem 0 .5rem"></p><a class="pill" id="own"></a> <span class="badge g" id="conf"></span></div>
  <button class="btn ghost" id="edit">Edit Pet</button></div>
<div class="svcrow"><b>Actions:</b><span id="quick"></span></div>
<div class="stackc" id="g"></div>
<script>
const id = param('id'); let pet;
async function load() {
  try { pet = await api('/api/pets/' + id); } catch (x) { return $('#pn').textContent = x.message; }
  $('#crumb').textContent = `Clients > ${pet.client} > ${pet.name}`;
  $('#pn').textContent = pet.name;
  if (pet.photo) { const ph = $('.ph'); ph.style.backgroundImage = `url(${pet.photo})`; ph.textContent = ''; }
  else if (window.UI14) { const ph = $('.ph'); ph.innerHTML = pav(pet.name, pet.species, null, 'xl'); ph.style.background = 'none'; ph.style.border = '0'; }
  $('#pl').textContent = [pet.species, pet.breed, pet.sex, pet.birthdate ? 'Born ' + fmtDate(pet.birthdate) : ''].filter(Boolean).join(' \u00B7 ');
  $('#own').textContent = 'Owner: ' + pet.client + ' \u203A'; $('#own').href = 'client.php?id=' + pet.client_id;
  $('#back').href = 'client.php?id=' + pet.client_id; $('#back').innerHTML = '&larr; ' + E(pet.client);
  $('#conf').textContent = pet.confined ? 'Currently confined' : 'Not confined'; $('#conf').className = 'badge ' + (pet.confined ? '' : 'g');
  $('#quick').innerHTML = (ROLE === 'vet' ? Object.entries(SVC).map(([t, s]) => `<a class="btn ghost sm" href="service_form.php?type=${t}&pet_id=${id}">+ ${s.name}</a>`).join(' ') + ' ' : '') + `<a class="btn ghost sm" href="general.php?pet=${id}">Timeline</a> <button type="button" class="btn ghost sm" id="surg">Schedule surgery</button>`;
  $('#surg').onclick = () => surgeryDialog({ pet_id: id, label: `${pet.name} (${pet.client})`, branch: ME_BRANCH });
  $('#g').innerHTML = Object.entries(SVC).map(([t, s]) => `<div class="card"><div class="hd"><h2>${s.card}</h2>${ROLE === 'vet' ? `<a class="btn plain sm" href="service_form.php?type=${t}&pet_id=${id}">+ Add</a>` : ''}</div><div id="t-${t}"></div></div>`).join('');
  const pr = await api(`/api/pets/${id}/profile`), miss = missingOf(pet);
  $('#g').insertAdjacentHTML('afterbegin', `<div class="card"><div class="hd"><h2>Documents</h2><button type="button" class="btn plain sm" id="pp">Open profile popup</button></div>
    ${miss.length ? `<p class="devnote">Details incomplete (${miss.join(', ')}). Use the popup to complete them.</p>` : ''}
    ${pr.documents.length ? `<ul class="doclist">${pr.documents.map(x => `<li><span><b>${E(x.doc_type)}</b> <small>${E(x.name)} &middot; ${D(x.created_at.slice(0, 10))}</small></span><button type="button" class="btn ghost sm" data-doc="${x.id}">View</button></li>`).join('')}</ul>` : '<p class="muted" style="margin:0">No documents uploaded yet (birth certificate, vaccination card...).</p>'}</div>`);
  $('#pp').onclick = () => petProfileDialog(id, { onClose: load });
  $$('#g [data-doc]').forEach(b => b.onclick = () => openDoc(id, b.dataset.doc).catch(x => alert(x.message)));
  Object.entries(SVC).forEach(([t, s]) => loadTable($('#t-' + t), s.all, `/api/records/${t}?pet_id=${id}`, t, r => ROLE === 'vet' && CAN_EDIT_REC ? `<a class="link" href="service_form.php?type=${t}&id=${r.id}">Edit</a>` : ''));
}
$('#edit').onclick = () => dialog(`<h3>Edit pet</h3><label>Pet's Name<input name="name" value="${E(pet.name)}" required></label>
  <div class="fr"><label>Species<select name="species">${['Dog', 'Cat', 'Bird', 'Rabbit', 'Other'].map(x => `<option ${x === pet.species ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
  <label>Breed<input name="breed" value="${E(pet.breed)}"></label></div>
  <div class="fr"><label>Birthdate<input type="date" name="birthdate" value="${E(pet.birthdate)}"></label>
  <label>Sex<select name="sex">${['Male', 'Female'].map(x => `<option ${x === pet.sex ? 'selected' : ''}>${x}</option>`).join('')}</select></label></div>`,
  async f => { await api('/api/pets/' + id, f); load(); });
load();
</script>
<?php bottom(); ?>

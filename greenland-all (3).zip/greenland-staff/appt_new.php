<?php require 'layout.php'; top('New Appointment', 'a', 'Appointments > New Appointment'); ?>
<div class="split">
  <div class="card"><h2>Appointment Details</h2>
    <form id="f" class="form" novalidate>
      <label>Client<div id="owner"></div></label>
      <div class="field"><span class="lbl">Pets and services (book several in one go). Check-ups and vaccinations are first come, first served on the day (no time); confinement and surgery get a booked time</span><div id="items" class="form"></div>
        <div class="btns" style="margin:.5rem 0 0"><button type="button" class="btn ghost sm" id="addItem">+ Add another pet or service</button></div></div>
      <div class="fr"><label>Branch<select name="branch" id="branch2"><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select></label>
        <label id="vetL"><span id="vetLbl">Veterinarian</span><select name="vet" id="vet"></select></label></div>
      <label>Date<input type="date" name="date" id="date" required><small class="ferr" data-f="date"></small></label>
      <div class="field" id="timeBox"><span class="lbl">Available times <span id="mins"></span></span><div class="slots" id="slots"></div><small class="ferr" data-f="time"></small></div>
      <p class="devnote" id="qnote" hidden></p>
      <label class="chk late" id="ovL" hidden><input type="checkbox" id="ov"> Allow a check-up today even though new check-ups closed (walk-in decided by the front desk)</label>
      <input type="hidden" name="time" id="time">
      <label>Notes<textarea name="reason" placeholder="Optional notes"></textarea></label>
      <div class="sugbox" id="sugs" hidden></div>
      <p class="err"></p>
      <div class="actions"><button class="btn">Save Appointment</button><a class="btn plain" href="appointments.php">Cancel</a></div>
    </form></div>
  <div class="card"><h2 id="bookedT"></h2><table><thead><tr><th>Time</th><th>Client / Pet</th><th>Service</th><th>Vet</th></tr></thead><tbody id="booked"></tbody></table></div>
</div>
<script>
const MAXITEMS = <?= (int)MAX_BOOKING_ITEMS ?>;
let cb, pets = [], items = [], busy = false;
const newItem = () => ({ pet: pets.length === 1 ? String(pets[0].id) : '', svc: 'Check-Up' });
const LAST = <?= json_encode(QUEUE_LAST_ARRIVAL) ?>, isQ = s => QUEUE_SERVICES.includes(s), allQ = () => items.length && items.every(i => isQ(i.svc)), anyQ = () => items.some(i => isQ(i.svc));
$('#date').value = today(); $('#date').min = today();
api('/api/auth/me').then(m => { if (m.branch) { $('#branch2').value = m.branch; fillVets(); refresh(); } });
cb = clientCombo($('#owner'), async c => { pets = c ? (await api('/api/clients/' + c.id)).pets : []; items = [newItem()]; renderItems(); refresh(); });
items = [newItem()];

function renderItems() {
  $('#items').innerHTML = items.map((it, i) => `<div class="item"><div class="fr"><label>Pet<select data-k="pet" data-i="${i}"><option value="">${pets.length ? 'Select pet' : 'Choose a client first'}</option>${pets.map(p => `<option value="${p.id}" ${String(p.id) === it.pet ? 'selected' : ''}>${E(p.name)} (${E(p.species || '')})</option>`).join('')}</select></label>
      <label>Service<select data-k="svc" data-i="${i}">${SERVICES.filter(s => s !== 'Confinement').map(s => `<option ${s === it.svc ? 'selected' : ''}>${E(s)}</option>`).join('')}</select></label>
      ${items.length > 1 ? `<button type="button" class="btn plain sm rm" data-rm="${i}">Remove</button>` : ''}</div></div>`).join('');
  $('#addItem').disabled = items.length >= MAXITEMS; $('#vetL').hidden = items.length > 1 && !allQ();
  $('#vetLbl').textContent = allQ() ? 'Preferred veterinarian (optional)' : 'Veterinarian';
  $('#timeBox').hidden = allQ();
  const d = $('#date').value, closed = d === today() && anyQ() && (() => { const n = new Date(); return n.getHours() * 60 + n.getMinutes() >= +LAST.slice(0, 2) * 60 + +LAST.slice(3); })();
  $('#qnote').hidden = !anyQ(); $('#qnote').innerHTML = anyQ() ? (closed ? `New check-ups and vaccinations for today closed at ${fmtTime(LAST)}.` : `Check-ups and vaccinations have <b>no set time</b>: the owner comes any time that day (until ${fmtTime(LAST)}) and is seen first come, first served. The queue number is given at check-in.`) + (allQ() ? '' : ' Confinement and surgery keep a booked time.') : '';
  $('#ovL').hidden = !closed;
  $$('#items [data-k]').forEach(el => el.onchange = () => { items[+el.dataset.i][el.dataset.k] = el.value; renderItems(); fillVets(); refresh(); });
  $$('#items [data-rm]').forEach(b => b.onclick = () => { items.splice(+b.dataset.rm, 1); renderItems(); fillVets(); refresh(); });
}
$('#addItem').onclick = () => { if (!cb.id) return alert('Search and choose a client first.'); items.push(newItem()); renderItems(); refresh(); };
const itemsJson = () => JSON.stringify(items.filter(i => !isQ(i.svc)).map(i => ({ svc: i.svc })));

function fillVets() {   // vets at this branch (every vet does every service)
  const br = $('#branch2').value, cur = $('#vet').value, list = VETINFO.filter(v => v.branch === br);
  $('#vet').innerHTML = `<option value="">${allQ() ? 'Any vet who is free' : 'Automatic: best available vet'}</option>` + list.map(v => `<option value="${E(v.name)}">${E(v.name)}</option>`).join('');
  if (list.some(v => v.name === cur)) $('#vet').value = cur;
}
async function loadSlots() {
  $('#time').value = ''; $('#sugs').hidden = true;
  const d = $('#date').value;
  if (allQ()) return;
  if (!d) return $('#slots').innerHTML = '<span class="muted">Choose a date first.</span>';
  const r = await api(`/api/schedule/slots?date=${d}&branch=${$('#branch2').value}&items=${encodeURIComponent(itemsJson())}&vet=${encodeURIComponent(items.length > 1 ? '' : $('#vet').value)}`);
  $('#mins').textContent = `(${r.minutes} minutes in total, shown with the vet who would be assigned)`;
  drawSlots($('#slots'), r, t => $('#time').value = t, true);
}
async function booked() {
  const d = $('#date').value, rows = d ? await api(`/api/appointments/day?date=${d}&branch=${$('#branch2').value}`) : [];
  $('#bookedT').textContent = 'Already booked: ' + (d ? fmtDate(d) : '-');
  $('#booked').innerHTML = rows.length ? rows.map(a => `<tr${a.status === 'Cancelled' ? ' style="opacity:.5"' : ''}><td>${+a.is_queue ? 'Any time' + (a.queue_no ? ' #' + a.queue_no : '') : fmtTime(a.time)}</td><td>${E(a.client)}<br><small class="muted">${E(a.pet)}</small></td><td>${E(a.service)}${a.status === 'Cancelled' ? ' <span class="badge x">Cancelled</span>' : ''}</td><td>${E(a.vet || '-')}</td></tr>`).join('') : '<tr><td colspan="4" class="empty">Nothing booked yet.</td></tr>';
}
const refresh = () => Promise.all([loadSlots(), booked()]);
['vet', 'date'].forEach(id => $('#' + id).onchange = () => { renderItems(); refresh(); });
$('#branch2').onchange = () => { renderItems(); fillVets(); refresh(); };
bindForm('#f', async d => {
  if (!cb?.id) throw new Error('Search and choose a client first.');
  if (items.some(i => !i.pet)) throw new Error('Choose a pet for every service.');
  if (!allQ() && !d.time) throw new Error('Pick one of the available times.');
  const body = { items: items.map(i => ({ pet_id: i.pet, service: i.svc })), date: d.date, time: allQ() ? '' : d.time, branch: d.branch, vet: items.length > 1 && !allQ() ? '' : d.vet, reason: d.reason, override: $('#ov') && $('#ov').checked ? 1 : 0 };
  try { await api('/api/appointments', body); }
  catch (x) { if (x.data && x.data.suggestions) { await refresh(); showSuggestions($('#sugs'), x.data.suggestions, async (dt, t) => { $('#date').value = dt; await refresh(); const b = $(`#slots .slot[data-t="${t}"]`); if (b && !b.disabled) b.click(); }); } throw x; }
  location = 'appointments.php?date=' + d.date;
});
(async () => {   // opened from a client or pet page: pre-select them
  const cid = param('client_id'), pid = param('pet_id');
  if (cid || pid) {
    const c = cid || (await api('/api/pets/' + pid)).client_id;
    cb.pick(await api('/api/clients/' + c));
    setTimeout(() => { if (pid) { items[0].pet = pid; renderItems(); } }, 300);
  }
})();
fillVets(); renderItems(); refresh();
</script>
<?php bottom(); ?>

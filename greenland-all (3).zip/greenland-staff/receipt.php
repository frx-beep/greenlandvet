<?php require 'layout.php'; top('Billing Statement', 'b', 'Billing > Billing statement'); ?>
<div class="receipt card" id="rc"><p class="muted">Loading...</p></div>
<div class="btns noprint" style="justify-content:center"><button class="btn" onclick="window.print()">Print billing statement</button><a class="btn plain" href="bills.php">Back to Billing</a><a class="btn ghost" href="sale_new.php">+ New sale</a></div>
<script>
const INFO = <?= json_encode(BRANCH_INFO) ?>;
const detail = p => p.method === 'Cash' ? (p.received && +p.received > +p.amount ? ` <small>(received ${peso(p.received)}, change ${peso(p.received - p.amount)})</small>` : '')
  : p.method === 'GCash' || p.method === 'Card' ? ` <small>(ref ${E(p.ref || '-')})</small>`
  : p.method === 'Check' ? ` <small>(${E(p.bank || '')} #${E(p.check_no || '')}, dated ${fmtDate(p.check_date)}${p.check_status === 'Bounced' ? ', BOUNCED' : p.check_status === 'Cleared' ? ', cleared' : ', pending clearing'})</small>` : '';
(async () => {
  const g = param('group'), id = param('id');
  try {
    const r = await api('/api/receipt?' + (g ? 'group=' + encodeURIComponent(g) : 'id=' + encodeURIComponent(id)));
    const bl = r.bills, b0 = INFO[r.branch] || {}, d = new Date((r.at || bl[0].ready_at || bl[0].sale_date + ' 00:00:00').replace(' ', 'T'));
    const when = d.toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' }) + (r.at ? ', ' + d.toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' }) : '');
    const paidNow = r.payments.reduce((s, p) => s + +p.amount, 0), left = bl.reduce((s, x) => s + +x.balance, 0), allPaid = left < 0.005;
    const pend = r.payments.some(p => p.method === 'Check' && p.check_status === 'Pending clearing');
    $('#rc').innerHTML = `<div class="center"><h2 style="margin:0">Greenland Veterinary Clinic</h2><b>${E(r.branch || '')} Branch</b><p class="muted" style="margin:.2rem 0">${E(b0.address || '')}<br>${E(b0.phone || '')}</p></div>
      <h3 class="center" style="margin:1rem 0">BILLING STATEMENT</h3>
      <dl class="rdl"><dt>Bill no.</dt><dd>${bl.map(x => '#' + x.id).join(', ')}</dd><dt>Date</dt><dd>${E(when)}</dd><dt>Client</dt><dd>${E(bl[0].client || 'Walk-in customer')}</dd>${bl[0].pet ? `<dt>Pet</dt><dd>${E(bl[0].pet)}</dd>` : ''}${r.taken_by ? `<dt>Payment taken by</dt><dd>${E(r.taken_by)}</dd>` : ''}</dl>
      ${bl.map(x => `<h4 style="margin:1rem 0 .3rem">Bill #${x.id} &middot; ${fmtDate(x.sale_date)}${x.service ? ' &middot; ' + E(x.service) : ''}</h4>
        <table><thead><tr><th>Item</th><th class="r">Qty</th><th class="r">Price</th><th class="r">Amount</th></tr></thead><tbody>${x.items.map(i => `<tr><td>${E(i.item)}</td><td class="r">${i.qty}</td><td class="r">${peso(i.price)}</td><td class="r">${peso(i.qty * i.price)}</td></tr>`).join('')}</tbody></table>
        <div class="total"><span>Bill total</span><b>${peso(x.total)}</b></div>${+x.balance > 0.004 ? `<div class="total"><span>Balance of this bill</span><span>${peso(x.balance)}</span></div>` : ''}`).join('')}
      <h4 style="margin:1rem 0 .3rem">Payment</h4>
      <table><tbody>${r.payments.map(p => `<tr><td>${E(p.method)}${detail(p)}</td><td class="r">${peso(p.amount)}</td></tr>`).join('') || '<tr><td colspan="2" class="muted">No payment yet.</td></tr>'}</tbody></table>
      <div class="total"><b>TOTAL PAID</b><b>${peso(paidNow)}</b></div>
      ${allPaid ? '<p class="okmsg center">Paid in full</p>' : `<p class="devnote center"><b>Remaining balance: ${peso(left)}</b></p>`}
      ${+r.client_balance > 0.004 ? `<p class="center muted">Total outstanding balance of ${E(bl[0].client)}: <b>${peso(r.client_balance)}</b></p>` : ''}
      ${pend ? '<p class="center muted"><small>Payments by check count only after the check clears.</small></p>' : ''}
      <p class="center muted">Thank you for trusting Greenland Veterinary Clinic!</p>
      <p class="center notofficial"><b>This is not an official receipt.</b></p>`;
  } catch (x) { $('#rc').innerHTML = `<p class="err">${E(x.message)}</p>`; }
})();
</script>
<?php bottom(); ?>

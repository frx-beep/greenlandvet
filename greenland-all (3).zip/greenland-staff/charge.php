<?php require 'layout.php'; top('Charge Sheet', isset($_GET['conf']) ? 'f' : (APP_ROLE === 'staff' ? 'k' : 'd'), isset($_GET['conf']) ? 'Confined patients > Running charge sheet' : 'What was done and used for this patient'); ?>
<div id="cs"><p class="muted">Loading...</p></div>
<script>
const APPT = param('appt'), CONF = param('conf'), STAFF = ROLE === 'staff', API = CONF ? '/api/charge/conf/' + CONF : '/api/charge/' + APPT, BACK = CONF ? 'confined.php' : (STAFF ? 'checkin.php' : 'index.php');
const MAIN = <?= json_encode(MAIN_BRANCH) ?>, SURG_MIN = <?= (int)SERVICE_MINUTES['Surgery'] ?>;
let S = null, items = [], saving = Promise.resolve(), tmr = null, dirty = false;
const lineTotal = i => (+i.qty || 0) * (+i.price || 0), total = () => items.reduce((s, i) => s + lineTotal(i), 0);

async function load() {
  if (!APPT && !CONF) { $('#cs').innerHTML = '<p class="err">No patient was chosen. Open this from My Patients or the queue.</p>'; return; }
  try { S = await api(API); } catch (x) { $('#cs').innerHTML = `<p class="err">${E(x.message)}</p>`; return; }
  items = S.items.map(i => ({ ...i })); draw();
  if (!CONF && !STAFF && S.appt.called_at && !S.appt.started_at && S.appt.status !== 'Completed') api(`/api/appointments/${APPT}/start`, {}).catch(() => {});   // opening the sheet = the patient is with the vet
}
function draw() {
  const a = S.appt, sale = S.sale, status = sale ? sale.status : null, locked = S.locked, done = a.status === 'Completed';
  const head = `<div class="card cs-head"><div class="cs-who"><h2 style="margin:0">${E(a.pet)} <span class="tag">${E(a.species || '')}</span></h2>
      <p class="muted" style="margin:.15rem 0 0">${E(a.client)}${a.phone ? ' &middot; ' + E(a.phone) : ''}</p></div>
      <div class="cs-meta"><span class="badge">${E(a.service)}</span>${a.room ? `<span class="badge g">${E(a.room)}</span>` : ''}${a.vet ? `<span class="badge g">${E(a.vet)}</span>` : ''}${a.severity ? `<span class="sevc ${E(a.severity.toLowerCase())}">${E(a.severity)}</span>` : ''}
      ${status ? `<span class="badge ${status === 'Paid' || status === 'Transferred' ? 'g' : status === 'Draft' ? 'p' : 'x'}">${status === 'Draft' ? 'Not sent yet' : E(status)}</span>` : ''}</div></div>
    ${S.conf ? confStrip() : ''}${+S.owes > 0 ? `<p class="owes-b"><b>This owner owes ${peso(S.owes)}</b> from earlier visits (for your information; service is never refused). The front desk will collect it.</p>` : ''}`;
  const isRate = i => S.conf && +i.id && +i.id === +S.conf.rate_item_id && S.conf.status === 'Admitted';
  const row = (i, k) => `<tr><td class="cs-name"><b>${E(i.item)}</b>${isRate(i) ? '<small>days are counted by calendar day</small>' : ''}</td>
      <td><div class="qty big"><button type="button" data-m="${k}" ${locked || isRate(i) ? 'disabled' : ''} aria-label="Less">&minus;</button><b>${+i.qty}</b><button type="button" data-p="${k}" ${locked || isRate(i) ? 'disabled' : ''} aria-label="More">+</button></div></td>
      <td class="r"><input class="pin" type="number" min="0" step="0.01" value="${(+i.price).toFixed(2)}" data-pr="${k}" ${locked || i.product_id ? 'readonly' : ''} aria-label="Price"></td>
      <td class="r"><b>${peso(lineTotal(i))}</b></td><td>${locked || isRate(i) ? '' : `<button type="button" class="x" data-rm="${k}" aria-label="Remove">&times;</button>`}</td></tr>`;
  const body = `<div class="card"><table class="cs"><thead><tr><th>Item</th><th>Qty</th><th class="r">Price</th><th class="r">Amount</th><th></th></tr></thead><tbody>${items.map(row).join('') || '<tr><td colspan="5" class="empty">Nothing on the sheet yet.</td></tr>'}</tbody></table>
    ${locked ? '' : '<div class="btns"><button type="button" class="btn ghost" id="addp">+ Medicine / product</button><button type="button" class="btn ghost" id="adds">+ Service / other charge</button></div>'}
    <div class="cs-total"><span>Total</span><b id="tot">${peso(total())}</b></div><p class="savestate muted" id="ss">${locked ? '' : 'Changes are saved automatically.'}</p></div>`;
  let notes = '';
  if (locked && !STAFF && status && status !== 'Draft') notes = `<p class="devnote">This charge sheet was sent to the front desk${sale.prepared_by ? ' by ' + E(sale.prepared_by) : ''}. To change it, ask the front desk.</p>`;
  if (status === 'Transferred') notes = `<p class="devnote">These charges were added to another bill${sale.transferred_to ? ' (#' + sale.transferred_to + ')' : ''}, so there is nothing to collect here.</p>`;
  else if (STAFF && status && status !== 'Draft' && status !== 'Paid') notes = '<p class="devnote">The vet prepared this charge sheet. If you change it, the change is marked "changed by front desk", logged, and the vet is told.</p>';
  if (sale && +sale.desk_changed) notes += '<p class="devnote">This bill was changed by the front desk after the vet sent it.</p>';
  const acts = [];
  if (S.conf && S.conf.status === 'Admitted' && !STAFF && !(S.conf.referred_from && !S.conf.arrived)) acts.push(`<button type="button" class="btn bigdone" id="discharge">Discharge ${E(a.pet)}</button>`);
  if (S.conf && !STAFF) acts.push(`<a class="btn" href="service_form.php?type=confinement&id=${S.conf.id}">Daily notes / record</a>`);
  if (S.can_done) acts.push(`<button type="button" class="btn bigdone" id="done">${STAFF ? 'Mark done (the vet could not)' : 'Done'}</button>`);
  if (!STAFF && done && !+a.record_done) acts.push(`<a class="btn" href="service_form.php?type=${APPT_TYPE[a.service]}&pet_id=${a.pet_id}&appt=${a.id}">Write the record now</a>`);
  if (STAFF && sale && ['Unpaid', 'Partially paid'].includes(status)) acts.push(`<a class="btn bigdone" href="pay.php?id=${sale.id}">Take payment</a>`);
  if (STAFF && sale && status === 'Paid') acts.push(`<a class="btn" href="receipt.php?id=${sale.id}">View billing statement</a>`);
  $('#cs').innerHTML = `${head}${body}${notes}<div class="cs-actions"><button type="button" class="btn ghost big" id="show">Show customer</button><span style="flex:1"></span><a class="btn plain big" href="${BACK}">Back</a>${acts.join('')}</div>`;
  wire();
}
function wire() {
  $$('#cs [data-p]').forEach(b => b.onclick = () => { items[b.dataset.p].qty = Math.min(999, +items[b.dataset.p].qty + 1); changed(); });
  $$('#cs [data-m]').forEach(b => b.onclick = () => { const i = items[b.dataset.m]; if (+i.qty > 1) { i.qty = +i.qty - 1; changed(); } });
  $$('#cs [data-rm]').forEach(b => b.onclick = () => { items.splice(+b.dataset.rm, 1); changed(); });
  $$('#cs [data-pr]').forEach(inp => inp.onchange = () => { items[inp.dataset.pr].price = Math.max(0, +inp.value || 0); changed(); });
  if ($('#addp')) $('#addp').onclick = () => productPicker(p => { const ex = items.find(i => i.product_id && +i.product_id === +p.product_id); if (ex) ex.qty = +ex.qty + p.qty; else items.push({ id: 0, item: p.item, qty: p.qty, price: p.price, product_id: p.product_id }); }, changed);
  if ($('#adds')) $('#adds').onclick = () => dialog(`<h3>Add a service or other charge</h3><label>Description<input name="item" maxlength="150" placeholder="e.g. Nail trimming, IV fluids, Laboratory test" required></label>
      <div class="fr"><label>Price (&#8369;)<input name="price" type="number" min="0" step="0.01" required></label><label>Quantity<input name="qty" type="number" min="1" value="1"></label></div>`,
      async f => { if (!f.item.trim()) throw new Error('Type what the charge is for.'); items.push({ id: 0, item: f.item.trim(), qty: Math.max(1, +f.qty || 1), price: Math.max(0, +f.price || 0), product_id: null }); changed(); }, 'Add');
  if ($('#show')) $('#show').onclick = showCustomer;
  if ($('#done')) $('#done').onclick = confirmDone;
  if ($('#discharge')) $('#discharge').onclick = confirmDischarge;
  if ($('#chdays')) $('#chdays').onclick = changeDays;
}
function changed() { draw(); dirty = true; $('#ss') && ($('#ss').textContent = 'Saving...'); clearTimeout(tmr); tmr = setTimeout(save, 500); }
function save() {
  if (!dirty) return saving; dirty = false;
  const body = { items: items.map(i => ({ id: i.id || 0, item: i.item, qty: i.qty, price: i.price, product_id: i.product_id || null })) };
  saving = saving.then(async () => {
    try {
      if (!body.items.length) throw new Error('Keep at least one item on the sheet.');
      const r = await api(API, body);
      (r.items || []).forEach((n, k) => { if (items[k]) { items[k].id = n.id; } });
      if ($('#ss')) $('#ss').textContent = 'Saved.';
    } catch (x) { dirty = true; if ($('#ss')) $('#ss').innerHTML = `<span class="err">${E(x.message)}</span>`; }
  });
  return saving;
}
function lines() { return items.map(i => `<tr><td>${E(i.item)}</td><td class="r">&times;${+i.qty}</td><td class="r">${peso(lineTotal(i))}</td></tr>`).join(''); }
function showCustomer() {   // a clean, large view the vet can turn toward the owner
  const d = document.createElement('dialog'); d.className = 'cust';
  d.innerHTML = `<h2>${E(S.appt.pet)}'s bill</h2><p class="muted">${E(S.appt.client)} &middot; ${E(S.appt.service)} &middot; ${E(fmtDay(S.appt.appt_date))}</p>
    <table class="custt"><tbody>${lines()}</tbody></table><div class="cust-total"><span>Total</span><b>${peso(total())}</b></div>
    ${+S.owes > 0 ? `<p class="cust-prev">Earlier balance: ${peso(S.owes)}</p>` : ''}<p class="muted">Please see the front desk to pay. Thank you!</p>
    <div class="actions"><button type="button" class="btn big" data-x>Close</button></div>`;
  document.body.append(d); d.showModal(); d.onclose = () => d.remove(); $('[data-x]', d).onclick = () => d.close();
}
const rateOf = () => { const i = items.find(x => +x.id === +S.conf.rate_item_id); return i ? +i.price : 0; };
function confStrip() {
  const c = S.conf, adm = c.status === 'Admitted';
  return `<div class="card cs-conf"><div class="cs-confrow"><div><span class="lbl">Admitted</span><b>${E(fmtDay(c.admitted))}</b></div>
    <div><span class="lbl">${adm ? 'Days so far' : 'Days'}</span><b>${c.days}</b>${c.override ? ' <span class="tag">typed in</span>' : ''}</div>
    <div><span class="lbl">Daily rate</span><b>${peso(rateOf())}</b></div>
    ${c.referred_from ? `<div><span class="tag">Referred from ${E(c.referred_from)}</span>${c.arrived ? '' : ' <span class="badge x">not arrived yet</span>'}</div>` : ''}
    <span style="flex:1"></span>${adm ? '<button type="button" class="btn ghost" id="chdays">Change days</button>' : ''}</div>
    <p class="muted" style="margin:.5rem 0 0">${adm ? 'The pet is staying with us. Add medicines and other charges as they are used; payment is taken at discharge. Days are counted by calendar day (the admission day counts).' : 'Discharged ' + E(fmtDay(c.discharged)) + '.'}</p></div>`;
}
function changeDays() {
  dialog(`<h3>Change the number of days</h3><p class="muted" style="margin:0">Counted automatically: <b>${S.conf.auto}</b> day${S.conf.auto === 1 ? '' : 's'}. Type a number to overwrite it, or leave it empty to count automatically. Every change is logged.</p>
    <label>Days<input name="days" type="number" min="1" max="365" value="${S.conf.override ? S.conf.days : ''}" placeholder="automatic (${S.conf.auto})"></label>`,
    async f => { await api(`/api/confined/${CONF}/days`, { days: f.days === '' ? null : +f.days }); await load(); }, 'Save');
}
async function confirmDischarge() {
  clearTimeout(tmr); await save();
  const a = S.appt, c = S.conf, d = document.createElement('dialog'); d.className = 'cust';
  d.innerHTML = `<h2>Discharge ${E(a.pet)}?</h2><p class="muted">${E(a.client)} &middot; ${c.days} day${c.days === 1 ? '' : 's'} (${E(fmtDay(c.admitted))} to today)</p>
    <table class="custt"><tbody>${lines()}</tbody></table><div class="cust-total"><span>Total</span><b>${peso(total())}</b></div>
    <label class="lbl">Outcome<select id="oc"><option value="">Choose...</option><option>Survived</option><option>Died</option></select></label>
    <label class="lbl" id="fuw">Follow-up check-up (optional)<input type="date" id="fu" min="${today()}"></label>
    <ul class="donelist"><li>The bill goes to the front desk for payment and the owner is told ${E(a.pet)} can go home.</li><li>You can still write or edit the daily notes afterwards.</li></ul>
    <p class="err" id="derr"></p><div class="actions"><button type="button" class="btn plain big" data-x>Go back</button><button type="button" class="btn bigdone" id="go">Confirm discharge</button></div>`;
  document.body.append(d); d.showModal(); d.onclose = () => d.remove(); $('[data-x]', d).onclick = () => d.close();
  $('#oc', d).onchange = () => { $('#fuw', d).hidden = $('#oc', d).value === 'Died'; };
  $('#go', d).onclick = async () => {
    if (!$('#oc', d).value) { $('#derr', d).textContent = 'Choose whether ' + a.pet + ' survived or died.'; return; }
    $('#go', d).disabled = true;
    try {
      const r = await api(`/api/confined/${CONF}/discharge`, { followup_date: $('#fu', d).value || null, outcome: $('#oc', d).value }); d.close();
      $('#cs').innerHTML = `<div class="card cs-ok"><div class="verified"><span class="ok">&#10003;</span><div><b>${E(a.pet)} ${r.outcome === 'Died' ? 'is closed after ' : 'is discharged after '}${r.days} day${r.days === 1 ? '' : 's'}${r.outcome === 'Died' ? ' (died)' : ''}</b><p>The front desk has been told the bill (${peso(r.total)}) is ready.${r.followup ? ' Follow-up check-up: ' + E(fmtDay(r.followup)) + '.' : ''}</p></div></div>
        <div class="cs-actions"><a class="btn big" href="service_form.php?type=confinement&id=${CONF}">Write the discharge notes</a><span style="flex:1"></span><a class="btn plain big" href="confined.php">Back to confined patients</a></div></div>`;
    } catch (x) { $('#derr', d).textContent = x.message; $('#go', d).disabled = false; }
  };
}
const NEXT_SVC = ['Check-Up', 'Surgery'];
async function confirmDone() {
  clearTimeout(tmr); await save();
  if (!items.length) { alert('Add at least the service fee before pressing Done.'); return; }
  const a = S.appt, askNext = NEXT_SVC.includes(a.service), atMain = a.branch === MAIN;
  let opt = null;
  if (a.service === 'Check-Up') { try { opt = await api('/api/surgery/options?appt_id=' + a.id); } catch (x) { opt = null; } }
  const nowOk = !!(opt && opt.now_ok); let pick = null;
  const d = document.createElement('dialog'); d.className = 'cust nx';
  d.innerHTML = `<h2>Finish ${E(a.pet)}'s visit?</h2><p class="muted">${E(a.client)} &middot; ${E(a.service)}</p>
    <table class="custt"><tbody>${lines()}</tbody></table><div class="cust-total"><span>Total</span><b>${peso(total())}</b></div>
    ${askNext ? `<h3 class="nx-h">What happens next?</h3>
    <div class="nx-opts">
      <label class="nx-o"><input type="radio" name="nx" value="home" checked><span><b>Goes home</b><small>The visit ends here.</small></span></label>
      <label class="nx-o"><input type="radio" name="nx" value="confine"><span><b>Confine now</b><small>${atMain ? 'Stays at the clinic. The room is freed for the next patient.' : 'Confinement is done at the ' + E(MAIN) + ' branch. ' + E(a.pet) + ' is referred there.'}</small></span></label>
      ${a.service === 'Check-Up' && !atMain && REFERRAL_REASONS.length ? `<label class="nx-o"><input type="radio" name="nx" value="refer"><span><b>Refer to ${E(MAIN)} for tests</b><small>X-ray, ultrasound or lab tests are done at the ${E(MAIN)} branch.</small></span></label>` : ''}
      ${a.service === 'Check-Up' ? `<label class="nx-o"><input type="radio" name="nx" value="surgery"><span><b>Surgery</b><small>${atMain ? 'Right now, or on another day.' : 'Done at the ' + E(MAIN) + ' branch, on a day and time you choose.'}</small></span></label>` : ''}
    </div>
    <div id="nx-home"><div class="fr"><label class="lbl">Follow-up check-up (optional)<input type="date" id="nx-fu" min="${today()}"></label><label class="lbl">Purpose of follow-up<input id="nx-fp" maxlength="150" placeholder="e.g. Recheck wound"></label></div></div>
    <div id="nx-ref" hidden>
      <div class="fr"><label class="lbl">Referred for<select id="nx-test">${REFERRAL_REASONS.map(x => `<option>${E(x)}</option>`).join('')}</select></label><label class="lbl">Date at ${E(MAIN)}<input type="date" id="nx-rd" min="${today()}" value="${today()}"></label></div>
      <label class="lbl">Note (optional)<input id="nx-rn" maxlength="150" placeholder="e.g. suspected fracture, left hind leg"></label>
      <small class="muted" style="display:block;margin:.3rem 0 0">The check-up bill is paid here as usual. The owner and the ${E(MAIN)} front desk are told, and ${E(a.pet)} is put on the ${E(MAIN)} list for that day.</small>
    </div>
    <div id="nx-more" hidden>
      <label class="lbl">Reason or procedure (optional)<input id="nx-reason" maxlength="150" placeholder="e.g. Parvo treatment, fracture repair"></label>
      <div id="nx-surg" hidden>
        ${nowOk ? `<label class="nx-o"><input type="radio" name="sm" value="now" checked><span><b>Start now</b><small>${E(opt.room)} is free. Surgery takes about ${SURG_MIN} minutes.</small></span></label>
          <label class="lbl" id="nx-vetw">Surgeon<select id="nx-vet">${opt.free_vets.map(v => `<option>${E(v)}</option>`).join('')}</select></label>`
        : `<p class="devnote strip">${E(atMain ? ((opt && opt.why) || 'The surgery room or a vet is not free right now.') : 'Surgery is done at the ' + MAIN + ' branch. ' + a.pet + ' is referred there.')}</p>`}
        <label class="nx-o"><input type="radio" name="sm" value="later" ${nowOk ? '' : 'checked'}><span><b>Another day or time</b><small id="nx-when">Not chosen yet</small></span></label>
        <div id="nx-pickw"><button type="button" class="btn ghost" id="nx-pick">Choose date and time</button></div>
      </div>
      <div class="nx-bill"><span class="lbl">The ${E(a.service.toLowerCase())} bill</span>
        <label class="nx-o"><input type="radio" name="nb" value="now" checked><span><b>Pay it now</b><small>It goes to the front desk as usual.</small></span></label>
        <label class="nx-o"><input type="radio" name="nb" value="carry"><span><b>Add it to the <span id="nx-tobill">confinement</span> bill</b><small>One payment at the end. ${atMain ? '' : 'This bill is closed here as transferred and logged.'}</small></span></label>
      </div>
    </div>` : ''}
    <ul class="donelist"><li>The room${a.room ? ' (' + E(a.room) + ')' : ''} and the vet are freed, so the next patient is called.</li><li>The bill goes to the front desk for payment${STAFF ? '' : ' and the owner is told'}.</li><li>This visit shows as <b>Pending record</b> until the findings are typed.</li></ul>
    <p class="err" id="derr"></p><div class="actions"><button type="button" class="btn plain big" data-x>Go back</button><button type="button" class="btn bigdone" id="go">Confirm Done</button></div>`;
  document.body.append(d); d.showModal(); d.onclose = () => d.remove(); $('[data-x]', d).onclick = () => d.close();
  const sel = () => askNext ? $('[name=nx]:checked', d).value : 'home';
  const sync = () => {
    if (!askNext) return;
    const t = sel(), m = $('[name=sm]:checked', d)?.value;
    $('#nx-home', d).hidden = t !== 'home'; $('#nx-more', d).hidden = t === 'home' || t === 'refer'; $('#nx-surg', d).hidden = t !== 'surgery'; if ($('#nx-ref', d)) $('#nx-ref', d).hidden = t !== 'refer';
    $('#nx-tobill', d).textContent = t === 'surgery' ? 'surgery' : 'confinement';
    if ($('#nx-vetw', d)) $('#nx-vetw', d).hidden = m !== 'now';
    $('#nx-pickw', d).hidden = m === 'now';
  };
  $$('[name=nx],[name=sm]', d).forEach(r => r.onchange = sync); sync();
  if ($('#nx-pick', d)) $('#nx-pick', d).onclick = () => surgeryDialog({ pet_id: a.pet_id, label: `${a.pet} (${a.client})`, branch: MAIN, lockBranch: true, reason: $('#nx-reason', d).value, vet: a.branch === MAIN ? a.vet : '', skipLabel: 'Back',
    collect: v => { pick = v; $('#nx-when', d).textContent = `${fmtDay(v.date)} at ${fmtTime(v.time)}${v.vet ? ' with ' + v.vet : ''}`; if (v.reason && !$('#nx-reason', d).value) $('#nx-reason', d).value = v.reason; } });
  $('#go', d).onclick = async () => {
    const err = $('#derr', d); err.textContent = '';
    const t = sel(); let next = null;
    if (askNext) {
      if (t === 'home') next = { type: 'home', followup_date: $('#nx-fu', d).value || null, followup_purpose: $('#nx-fp', d).value.trim() };
      else if (t === 'refer') next = { type: 'refer', test: $('#nx-test', d).value, date: $('#nx-rd', d).value, reason: $('#nx-rn', d).value.trim() };
      else {
        next = { type: t, bill: $('[name=nb]:checked', d).value, reason: $('#nx-reason', d).value.trim() };
        if (t === 'surgery') {
          if (($('[name=sm]:checked', d)?.value || 'later') === 'now') Object.assign(next, { mode: 'now', vet: $('#nx-vet', d).value });
          else { if (!pick) { err.textContent = 'Choose the surgery date and time first.'; return; } Object.assign(next, { mode: 'later', date: pick.date, time: pick.time, vet: pick.vet }); }
        }
      }
    }
    $('#go', d).disabled = true;
    try {
      const r = await api(`/api/appointments/${a.id}/done`, next ? { next } : {}); d.close(); doneCard(r, a);
    } catch (x) { err.textContent = x.message; $('#go', d).disabled = false; }
  };
}
function doneCard(r, a) {
  const n = r.next || {}, base = r.carried ? '' : 'The front desk has been told the bill is ready.';
  let head = r.already ? 'Already marked done' + (r.by ? ' by ' + E(r.by) : '') : E(a.pet) + ' is done', msg = r.already ? '' : base, links = '';
  if (!r.already && n.type === 'home') msg = (n.followup ? 'Goes home. Follow-up check-up on ' + E(fmtDay(n.followup)) + '. ' : 'Goes home. ') + base;
  if (!r.already && n.type === 'refer') msg = 'Referred to ' + E(MAIN) + ' for ' + E(n.test || 'tests') + (n.referral_date ? ' on ' + E(fmtDay(n.referral_date)) : '') + '. The owner and ' + E(MAIN) + ' were told. ' + base;
  if (!r.already && n.type === 'confine') { msg = (a.branch === MAIN ? 'Confined now. ' : 'Referred to ' + E(MAIN) + ' for confinement; the owner and ' + E(MAIN) + ' were told. ') + (r.carried ? 'The check-up charges were added to the confinement bill.' : base); links = `<a class="btn big" href="charge.php?conf=${n.conf_id}">Open the confinement sheet</a>`; }
  if (!r.already && n.type === 'surgery') { msg = E(n.summary || 'Surgery planned') + '. ' + (r.carried ? 'The check-up charges were added to the surgery bill.' : base); links = n.surgery_appt_id ? `<a class="btn big" href="charge.php?appt=${n.surgery_appt_id}">Open the surgery sheet</a>` : ''; }
  $('#cs').innerHTML = `<div class="card cs-ok"><div class="verified"><span class="ok">&#10003;</span><div><b>${head}</b><p>${msg}</p></div></div>
    <div class="cs-actions">${STAFF ? '' : `<a class="btn big" href="service_form.php?type=${APPT_TYPE[a.service]}&pet_id=${a.pet_id}&appt=${a.id}">Write the record now</a>`}${links}${STAFF && r.sale_id && !r.carried ? `<a class="btn bigdone" href="pay.php?id=${r.sale_id}">Take payment</a>` : ''}<span style="flex:1"></span><a class="btn plain big" href="${STAFF ? 'checkin.php' : 'index.php'}">${STAFF ? 'Back to the queue' : 'Back to my patients'}</a></div></div>`;
}
window.addEventListener('beforeunload', () => { if (dirty) { clearTimeout(tmr); save(); } });
load();
</script>
<?php bottom(); ?>

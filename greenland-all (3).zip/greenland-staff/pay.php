<?php require 'layout.php'; top('Take Payment', 'b', 'Billing > Payment'); ?>
<div id="pg"><p class="muted">Loading...</p></div>
<script>
const ID = param('id'), CL = param('client'), ALL = param('all') === '1';
let bill = null, others = [], picked = new Set(), lines = [];
const r2 = n => Math.round((+n || 0) * 100) / 100;
const owedOf = b => r2(b.total - b.paid);
const due = () => r2(owedOf(bill) + others.filter(o => picked.has(+o.id)).reduce((s, o) => s + r2(o.balance), 0));
const paidIn = () => r2(lines.reduce((s, l) => s + (+l.amount || 0), 0));
const hint = { Cash: 'Enter the amount received to see the change.', GCash: 'Type the GCash reference number.', Card: 'Type the last 4 digits or the approval code.', Check: 'Bank, check number and the date on the check.' };

async function load() {
  if (!ID && CL) { try { const s = await api('/api/balances/' + CL); if (s.bills.length) location.replace(`pay.php?id=${s.bills[0].id}&all=1`); else $('#pg').innerHTML = '<p class="muted">This client has no unpaid bills.</p>'; } catch (x) { $('#pg').innerHTML = `<p class="err">${E(x.message)}</p>`; } return; }
  try { bill = await api('/api/bills/' + ID); } catch (x) { $('#pg').innerHTML = `<p class="err">${E(x.message)}</p>`; return; }
  others = bill.others || []; if (ALL) others.forEach(o => picked.add(+o.id));
  if (!['Unpaid', 'Partially paid'].includes(bill.status)) { $('#pg').innerHTML = `<div class="card"><p>${bill.status === 'Paid' ? 'This bill is already paid.' : 'This bill is not ready for payment yet.'}</p><a class="btn" href="receipt.php?id=${bill.id}">View receipt</a> <a class="btn plain" href="bills.php">Back to Billing</a></div>`; return; }
  lines = [{ method: 'Cash', amount: owedOf(bill).toFixed(2), received: '' }]; draw();
}
function draw() {
  const b = bill, bal = owedOf(b);
  const items = b.items.map(i => `<tr><td>${E(i.item)}</td><td class="r">&times;${+i.qty}</td><td class="r">${peso(i.qty * i.price)}</td></tr>`).join('');
  const old = others.length ? `<div class="card"><h2>Earlier unpaid bills of ${E(b.client)}</h2><p class="muted" style="margin:0 0 .5rem">The customer may also pay old balances now. Tick the bills to include (oldest first).</p>
      ${others.map(o => `<label class="chk oldb"><input type="checkbox" data-o="${o.id}" ${picked.has(+o.id) ? 'checked' : ''}> <span><b>#${o.id}</b> &middot; ${fmtDate(o.sale_date)} &middot; ${E(o.items || '')}</span><b>${peso(o.balance)}</b></label>`).join('')}
      <div class="btns"><button type="button" class="btn ghost sm" id="pall">Include all old balances</button><button type="button" class="btn plain sm" id="pnone">None</button></div></div>` : '';
  $('#pg').innerHTML = `<div class="split" style="grid-template-columns:1.3fr 1fr;align-items:start"><div class="stackc">
    <div class="card"><div class="hd"><h2>Bill #${b.id}</h2><span class="badge ${b.status === 'Unpaid' ? 'x' : 'p'}">${E(b.status)}</span></div>
      <p style="margin:0"><b>${E(b.client || 'Walk-in customer')}</b>${b.pet ? ' &middot; ' + E(b.pet) : ''}${b.service ? ' &middot; ' + E(b.service) : ''}${b.prepared_by ? `<br><small class="muted">Charge sheet by ${E(b.prepared_by)}</small>` : ''}</p>
      ${+b.desk_changed ? '<p class="devnote" style="margin:.6rem 0 0">Changed by the front desk after the vet sent it.</p>' : ''}
      <table class="cs" style="margin-top:.6rem"><tbody>${items}</tbody></table>
      <div class="total"><span>Bill total</span><span>${peso(b.total)}</span></div>${+b.paid > 0 ? `<div class="total"><span>Already paid</span><span>${peso(b.paid)}</span></div>` : ''}
      <div class="total"><b>Balance of this bill</b><b>${peso(bal)}</b></div>
      ${b.appt_id ? `<p style="margin:.4rem 0 0"><a class="link" href="charge.php?appt=${b.appt_id}">Review or change the charge sheet</a></p>` : ''}</div>${old}</div>
    <div class="card stack"><h2>Payment</h2><div id="lines"></div>
      <div class="btns"><button type="button" class="btn ghost sm" id="addl">+ Add another payment line (split payment)</button></div>
      <div class="total"><span>To pay now</span><b id="due"></b></div><div class="total"><span>Entered</span><span id="ent"></span></div><div class="total"><span id="remL">Remaining balance</span><b id="rem"></b></div>
      <p class="err" id="err"></p><button class="btn bigdone" id="go" type="button">Take payment</button><a class="btn plain" href="bills.php">Cancel</a></div></div>`;
  $$('[data-o]').forEach(c => c.onchange = () => { c.checked ? picked.add(+c.dataset.o) : picked.delete(+c.dataset.o); sums(); });
  if ($('#pall')) $('#pall').onclick = () => { others.forEach(o => picked.add(+o.id)); draw(); }; if ($('#pnone')) $('#pnone').onclick = () => { picked.clear(); draw(); };
  $('#addl').onclick = () => { const left = r2(due() - paidIn()); lines.push({ method: 'GCash', amount: left > 0 ? left.toFixed(2) : '', received: '' }); drawLines(); };
  $('#go').onclick = submit; drawLines();
}
function drawLines() {
  $('#lines').innerHTML = lines.map((l, k) => `<div class="payline"><div class="fr"><label>Method<select data-k="${k}" data-f="method">${PAY_METHODS.map(m => `<option ${m === l.method ? 'selected' : ''}>${m}</option>`).join('')}</select></label>
      <label>Amount (&#8369;)<input data-k="${k}" data-f="amount" type="number" min="0" step="0.01" value="${E(l.amount)}"></label></div>
      ${l.method === 'Cash' ? `<label>Cash received (&#8369;)<input data-k="${k}" data-f="received" type="number" min="0" step="0.01" value="${E(l.received)}" placeholder="Amount handed over"></label><p class="chg" id="chg${k}"></p>` : ''}
      ${l.method === 'GCash' ? `<label>GCash reference no.<input data-k="${k}" data-f="ref" value="${E(l.ref || '')}" maxlength="60"></label>` : ''}
      ${l.method === 'Card' ? `<label>Card last 4 digits / approval code<input data-k="${k}" data-f="ref" value="${E(l.ref || '')}" maxlength="60"></label>` : ''}
      ${l.method === 'Check' ? `<div class="fr"><label>Bank<input data-k="${k}" data-f="bank" value="${E(l.bank || '')}" maxlength="60"></label><label>Check no.<input data-k="${k}" data-f="check_no" value="${E(l.check_no || '')}" maxlength="40"></label></div>
        <label>Date on the check<input type="date" data-k="${k}" data-f="check_date" value="${E(l.check_date || '')}"></label><p class="hint">The check stays <b>Pending clearing</b> until you mark it cleared in Billing &gt; Checks.</p>` : ''}
      ${lines.length > 1 ? `<button type="button" class="link" data-del="${k}">Remove this line</button>` : ''}</div>`).join('');
  $$('#lines [data-f]').forEach(el => el.onchange = el.oninput = e => {
    const l = lines[el.dataset.k], f = el.dataset.f; l[f] = el.value;
    if (f === 'method' && e.type === 'change') { Object.assign(l, { received: '', ref: '', bank: '', check_no: '', check_date: '' }); drawLines(); return; }
    sums();
  });
  $$('#lines [data-del]').forEach(b => b.onclick = () => { lines.splice(+b.dataset.del, 1); drawLines(); });
  sums();
}
function sums() {
  const d = due(), e = paidIn(), left = r2(d - e);
  $('#due').textContent = peso(d); $('#ent').textContent = peso(e); $('#rem').textContent = peso(Math.max(0, left));
  $('#remL').textContent = left > 0.004 ? 'Stays as the customer\'s balance' : 'Remaining balance';
  lines.forEach((l, k) => { const c = $('#chg' + k); if (c) { const rc = +l.received || 0, am = +l.amount || 0; c.textContent = rc > 0 && am > 0 ? (rc >= am ? 'Change to give: ' + peso(rc - am) : 'Cash received is less than the amount.') : ''; c.className = 'chg' + (rc > 0 && rc < am ? ' bad' : ''); } });
}
async function submit() {
  $('#err').textContent = ''; const d = due(), e = paidIn(), left = r2(d - e);
  if (e <= 0) { $('#err').textContent = 'Enter the amount the customer is paying.'; return; }
  if (e > d + 0.004) { $('#err').textContent = 'The payment is more than what is due (' + peso(d) + ').'; return; }
  if (left > 0.004) { if (!bill.client_id) { $('#err').textContent = 'A sale with no client must be paid in full.'; return; } if (!confirm(`${peso(left)} will stay unpaid as ${bill.client}'s balance. Continue?`)) return; }
  $('#go').disabled = true;
  try {
    const ids = [bill.id, ...others.filter(o => picked.has(+o.id)).map(o => +o.id)];
    const r = await api('/api/bills/pay', { ids, lines: lines.map(l => ({ method: l.method, amount: l.amount, received: l.method === 'Cash' ? (l.received || l.amount) : undefined, ref: l.ref, bank: l.bank, check_no: l.check_no, check_date: l.check_date })) });
    location = 'receipt.php?group=' + r.group;
  } catch (x) { $('#err').textContent = x.message; $('#go').disabled = false; }
}
load();
</script>
<?php bottom(); ?>

<?php require 'layout.php'; top('General Records', 'g', 'Every vet\'s records in one place'); $isVet = APP_ROLE === 'vet'; ?>
<div id="pethead"></div>
<div class="toolbar" id="tb"><input id="q" placeholder="Search by pet name, owner name or phone number..." style="flex:1">
  <select id="type" style="width:11rem"><option value="">All records</option><option value="pending">Pending records</option><option value="vaccination">Vaccinations</option><option value="checkup">Check-ups</option><option value="confinement">Confinements</option><option value="surgery">Surgeries</option></select>
  <select id="vet" style="width:11rem"><option value="">All vets</option></select>
  <label class="inl">From<input type="date" id="from"></label><label class="inl">To<input type="date" id="to"></label></div>
<div class="card"><div class="hd"><h2 id="ttl">Records</h2><small class="muted" id="pn"></small></div><div id="tbl"></div><div class="pager"><span id="info"></span><div id="pages"></div></div>
  <p class="muted" style="margin:.6rem 0 0"><small>The date shown is the <b>visit date</b>. When the findings were typed is shown in small text. <?= $isVet ? '' : 'Records are written by the veterinarians; the front desk can read them.' ?></small></p></div>
<script>
const IS_VET = ROLE === 'vet', TNAME = { vaccination: 'Vaccination', checkup: 'Check-up', confinement: 'Confinement', surgery: 'Surgery', pending: 'Pending' };
let page = 1, t, petId = param('pet'), tlMode = 'tl';
// Update 15: the pet's history as a vertical timeline with an icon for each kind of visit (falls back to the table when ui14.js is off)
const TL = { vaccination: ['syringe', 'vac'], checkup: ['stethoscope', 'chk'], confinement: ['bed', 'cnf'], surgery: ['scalpel', 'srg'], pending: ['clock', 'pnd'] };
const timeline = rows => !rows.length ? '<p class="empty">No records yet.</p>' : `<div class="tl">${rows.map(x => { const [ic, c] = TL[x.rtype] || ['paw', '']; return `<div class="tl-i ${c}"><span class="tl-ic">${UI14.icon(ic)}</span>
  <div class="tl-d">${D(x.vdate)}${x.recorded_at ? ' &middot; recorded ' + D(x.recorded_at.slice(0, 10)) : ''}</div><div class="tl-t">${E(sv(x))}${x.title && x.rtype !== 'pending' && x.rtype !== 'checkup' ? ' &middot; ' + E(x.title) : ''}</div>
  <div class="tl-s">${x.state === 'Pending' ? '<span class="badge p">Pending record</span>' : E(x.summary || '')}</div>
  <div class="tl-d">${x.vet ? E(x.vet) + ' &middot; ' : ''}${x.edited_by ? 'edited by ' + E(x.edited_by) + ' &middot; ' : ''}${act(x)}</div></div>`; }).join('')}</div>`;
VETS.forEach(v => $('#vet').add(new Option(v, v)));
if (param('type')) $('#type').value = param('type'); if (param('mine') && IS_VET) $('#vet').value = ME_NAME;
const sv = x => x.service || TNAME[x.rtype];
const act = x => x.rtype === 'pending'
  ? (IS_VET ? `<a class="btn sm" href="service_form.php?type=${APPT_TYPE[x.service]}&pet_id=${x.pet_id}&appt=${x.appt_id}">Write record</a>` : '<span class="muted">waiting for the vet</span>')
  : `<button type="button" class="link" data-v="${x.rtype}" data-id="${x.rid}">View</button>${IS_VET && CAN_EDIT_REC ? ` &middot; <a class="link" href="service_form.php?type=${x.rtype}&id=${x.rid}">Edit</a>` : ''}`;
const row = x => `<tr><td><b>${D(x.vdate)}</b>${x.recorded_at ? `<br><small class="muted">recorded ${D(x.recorded_at.slice(0, 10))}</small>` : ''}</td>
  <td><a class="link" href="general.php?pet=${x.pet_id}">${E(x.pet)}</a><br><small class="muted">${E(x.species || '')}</small></td><td>${x.client_id ? `<a class="link" href="client.php?id=${x.client_id}">${E(x.client)}</a>` : ''}${x.phone ? `<br><small class="muted">${E(x.phone)}</small>` : ''}</td>
  <td>${E(sv(x))}${x.title && x.rtype !== 'pending' && x.rtype !== 'checkup' ? `<br><small class="muted">${E(x.title)}</small>` : ''}</td><td>${E(x.vet || '-')}</td>
  <td>${x.state === 'Pending' ? '<span class="badge p">Pending record</span>' : clip(x.summary, 60)}${x.edited_by ? `<br><small class="muted">Edited by ${E(x.edited_by)}</small>` : ''}</td><td class="nowrap">${act(x)}</td></tr>`;
async function load() {
  try {
    let r;
    if (petId) {
      r = await api('/api/general/pet/' + petId); const p = r.pet;
      $('#tb').hidden = true;
      $('#pethead').innerHTML = `<div class="card cs-head"><div class="pn">${pav(p.name, p.species, p.photo, 'xl')}<div><h2 style="margin:0">${E(p.name)} <span class="tag">${E(p.species || '')}</span></h2><p class="muted" style="margin:.15rem 0 0">${E(p.breed || '')}${p.sex ? ' &middot; ' + E(p.sex) : ''}${p.birthdate ? ' &middot; ' + petAge(p.birthdate) : ''}<br>Owner: <a class="link" href="client.php?id=${p.cid}">${E(p.client)}</a>${p.phone ? ' &middot; ' + E(p.phone) : ''}</p></div></div>
        <div class="cs-meta">${+r.balance > 0 ? `<span class="owes">Owes ${peso(r.balance)}</span>` : ''}<a class="btn ghost sm" href="pet.php?id=${p.id}">Pet profile</a><a class="btn plain sm" href="general.php">All records</a></div></div>`;
      $('#ttl').textContent = 'Timeline'; r.rows.forEach(x => { x.pet = p.name; x.species = p.species; x.client = p.client; x.client_id = p.cid; x.phone = p.phone; });
      const showTL = () => {
        $('#tbl').innerHTML = (window.UI14 ? `<div class="tlswitch"><button type="button" data-m="tl" class="${tlMode === 'tl' ? 'on' : ''}">Timeline</button><button type="button" data-m="tb" class="${tlMode === 'tb' ? 'on' : ''}">Table</button></div>` : '') + (window.UI14 && tlMode === 'tl' ? timeline(r.rows) : tbl(r.rows));
        $$('#tbl [data-m]').forEach(b => b.onclick = () => { tlMode = b.dataset.m; showTL(); }); wire(r.rows);
      };
      showTL(); $('#info').textContent = r.rows.length + ' record' + (r.rows.length === 1 ? '' : 's'); $('#pages').innerHTML = ''; return;
    }
    const u = `/api/general?page=${page}&q=${encodeURIComponent($('#q').value.trim())}&type=${$('#type').value}&vet=${encodeURIComponent($('#vet').value)}&from=${$('#from').value}&to=${$('#to').value}`;
    r = await api(u); $('#pn').textContent = r.pending ? r.pending + ' visit' + (r.pending === 1 ? '' : 's') + ' waiting for findings' : '';
    $('#tbl').innerHTML = tbl(r.rows); wire(r.rows); pager(r, page, n => { page = n; load(); }, $('#info'), $('#pages'));
  } catch (x) { $('#tbl').innerHTML = `<p class="err">${E(x.message)}</p>`; }
}
const tbl = rows => `<table><thead><tr><th>Visit date</th><th>Pet</th><th>Owner</th><th>Type</th><th>Vet</th><th>Findings</th><th></th></tr></thead><tbody>${rows.length ? rows.map(row).join('') : '<tr><td colspan="7" class="empty">No records found.</td></tr>'}</tbody></table>`;
function wire() {
  $$('#tbl [data-v]').forEach(b => b.onclick = async () => { try { const rec = await api(`/api/records/${b.dataset.v}/${b.dataset.id}`); const pr = await api('/api/pets/' + rec.pet_id); rec.client = pr.client; showRecord(b.dataset.v, rec); } catch (x) { alert(x.message); } });
}
$('#q').oninput = () => { clearTimeout(t); t = setTimeout(() => { page = 1; load(); }, 250); };
['type', 'vet', 'from', 'to'].forEach(i => $('#' + i).onchange = () => { page = 1; load(); });
load();
</script>
<?php bottom(); ?>

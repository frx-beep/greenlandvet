<?php header('Location: general.php'); exit;   // Records moved to General Records (Update 12)

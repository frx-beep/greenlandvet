<?php require 'layout.php'; top('Queue', 'k', 'Check-ups are first come, first served'); $isStaff = APP_ROLE === 'staff'; ?>
<script src="qrread.js?v=<?= filemtime(__DIR__ . '/qrread.js') ?>"></script>
<div id="strip"></div>
<div class="ci">
  <div class="stackc">
<?php if ($isStaff): ?>
    <div class="card"><h2>Scan or upload the QR code</h2>
      <div class="camwrap"><video id="cam" playsinline muted></video><div class="camhint" id="camhint">The camera is off</div></div>
      <div class="btns"><button class="btn" id="start" type="button">Start camera</button><button class="btn plain" id="stop" type="button" hidden>Stop camera</button>
        <label class="btn ghost" style="margin:0;cursor:pointer">Upload a saved QR<input type="file" id="up" accept="image/*" hidden></label></div>
      <p class="err" id="serr"></p></div>
<?php endif; ?>
    <div class="card waitq"><div class="hd"><h2>Expected today</h2><small class="muted" id="expN"></small></div><div id="today"></div>
      <div id="latebox" hidden><h4>Cancelled automatically</h4><p class="muted" style="margin:0 0 .6rem;font-size:.85rem">If the owner still comes, check them in and the visit becomes a walk-in.</p><div id="late"></div></div></div>
  </div>
  <div class="stackc">
    <div class="card" id="res"><p class="muted" style="margin:0"><?= $isStaff ? "Scan the pet owner's QR code, upload a saved QR image, or pick someone from the list. A confirmation will show who requested the appointment." : 'This is the live queue. The front desk checks patients in; open My Patients to see who is assigned to you.' ?></p></div>
  </div>
</div>
<div class="card" style="margin-top:1.5rem"><div class="board-h"><h2 style="margin:0">Queue board: vets, rooms and the line</h2><small id="boardT"></small></div><div class="board" id="board"></div></div>
<script>
const LATE_AT = <?= (int)LATE_ALERT_MINUTES ?>, CANCEL_AT = <?= (int)LATE_CANCEL_MINUTES ?>, SEV = <?= json_encode(SEVERITY_MINUTES) ?>, IS_STAFF = <?= $isStaff ? 'true' : 'false' ?>;
let stream = null, timer = null, decoders = null, cur = null, B = null;   // cur = the appointment on screen, B = the queue board
const loadScript = src => new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.append(s); });
const toMin = t => { const [h, m] = t.split(':'); return +h * 60 + +m; }, nowMin = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); };
const sevText = s => s === 'Routine' ? 'about 1 hour' : s === 'Moderate' ? 'about 1&frac12; hours' : 'about 2 to 3 hours';
const whenOf = a => a.is_queue ? 'Any time (first come, first served)' : fmtTime(a.time);
const owesHTML = (n, cid) => +n > 0 ? `<p class="owes-b"><b>Owes ${peso(n)}</b> to the clinic. Service is never refused, but please remind the owner. ${IS_STAFF ? `<a class="link" href="bills.php?tab=balances&client=${cid}">View balance</a>` : ''}</p>` : '';

// ---------- QR reading: the browser's own reader if it has one, then our offline reader, then a CDN library as a last resort ----------
function pixels(el, maxSide = 2000) {
  const w0 = el.videoWidth || el.naturalWidth || el.width, h0 = el.videoHeight || el.naturalHeight || el.height, k = Math.min(1, maxSide / Math.max(w0, h0));
  const c = document.createElement('canvas'); c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
  const x = c.getContext('2d', { willReadFrequently: true }); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(el, 0, 0, c.width, c.height);
  return { c, img: x.getImageData(0, 0, c.width, c.height) };
}
async function getDecoders() {
  if (decoders) return decoders; decoders = [];
  if ('BarcodeDetector' in window) { try { const bd = new BarcodeDetector({ formats: ['qr_code'] }); decoders.push(async el => { const r = await bd.detect(el); return r.length ? r[0].rawValue : null; }); } catch (e) {} }
  decoders.push(async el => { const { img } = pixels(el); return QRRead.decode(img); });
  if (!window.jsQR) for (const u of ['https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js', 'https://cdnjs.cloudflare.com/ajax/libs/jsQR/1.4.0/jsQR.min.js']) { try { await Promise.race([loadScript(u), new Promise((_, r) => setTimeout(r, 4000))]); if (window.jsQR) break; } catch (e) {} }
  if (window.jsQR) decoders.push(async el => { const { img } = pixels(el, 1000), r = jsQR(img.data, img.width, img.height); return r ? r.data : null; });
  return decoders;
}
async function readQR(el) { for (const d of await getDecoders()) { try { const t = await d(el); if (t) return t; } catch (e) {} } return null; }

async function startCam() {
  $('#serr').textContent = '';
  try {
    if (!navigator.mediaDevices) throw new Error('The camera needs a secure page (https, or localhost). You can upload a saved QR or use the list instead.');
    await getDecoders();
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    const v = $('#cam'); v.srcObject = stream; await v.play();
    $('#camhint').hidden = true; $('#start').hidden = true; $('#stop').hidden = false;
    timer = setInterval(async () => { if (v.readyState < 2) return; const code = await readQR(v); if (code && /^GV:/i.test(code)) { stopCam(); lookup({ token: code }, true); } }, 400);
  } catch (x) { stopCam(); $('#serr').textContent = x.name === 'NotAllowedError' ? 'Camera access was blocked. Allow the camera in the browser, or upload a saved QR image.' : (x.message || 'Could not start the camera.'); }
}
function stopCam() { clearInterval(timer); if (stream) stream.getTracks().forEach(t => t.stop()); stream = null; $('#cam').srcObject = null; $('#camhint').hidden = false; $('#start').hidden = false; $('#stop').hidden = true; }
if (IS_STAFF) { $('#start').onclick = startCam; $('#stop').onclick = stopCam; }
if (IS_STAFF) $('#up').onchange = async e => {   // an uploaded picture: read it and show the confirmation straight away
  const f = e.target.files[0]; e.target.value = ''; if (!f) return; $('#serr').textContent = 'Reading the picture...';
  try {
    const img = new Image(); img.src = URL.createObjectURL(f); await img.decode();
    let code = await readQR(img); URL.revokeObjectURL(img.src);
    if (!code) throw new Error('No QR code was found in that picture. Try a clearer screenshot of the QR, or pick the appointment from the list.');
    if (!/^GV:/i.test(code)) throw new Error('That picture has a QR code, but it is not a Greenland appointment QR.');
    $('#serr').textContent = ''; await lookup({ token: code }, true);
  } catch (x) { $('#serr').textContent = x.message; }
};


async function lookup(body, viaQR) {
  $('#serr') && ($('#serr').textContent = '');
  try { const a = await api('/api/checkin/lookup', body); cur = a; await loadBoard(a.branch); if (viaQR) verifyDialog(a); else showPanel(a, false); }
  catch (x) { ($('#serr') || $('#res')).textContent = x.message; }
}
const via = a => a.source === 'Online' ? 'Online, by the pet owner' : a.source === 'Walk-in' ? 'Walk-in' : 'At the clinic (' + E(a.source) + ')';
const dueNote = a => a.status === 'Completed' ? 'This appointment is already completed.' : a.status === 'Cancelled' ? (a.cancelled_by === 'System' ? 'This appointment was cancelled automatically because the patient did not arrive. Checking in will convert it to a walk-in.' : 'This appointment was cancelled' + (a.cancel_reason ? ' (' + a.cancel_reason + ')' : '') + '.') : a.appt_date !== a.today ? `This appointment is on ${fmtDay(a.appt_date)}, not today.` : '';
const petOf = a => ({ id: a.pet_id, name: a.pet, species: a.species, breed: a.breed, sex: a.sex, birthdate: a.birthdate });
const others = a => (a.group || []).filter(g => g.id !== a.id);

// ---------- confirmation popup right after a QR is scanned or uploaded ----------
function verifyDialog(a) {
  const d = document.createElement('dialog'); d.className = 'wide'; document.body.append(d); d.showModal(); d.onclose = () => d.remove();
  const render = () => {
    const miss = missingOf(a), warn = dueNote(a), bad = a.status === 'Completed' || (a.status === 'Cancelled' && a.cancelled_by !== 'System');
    d.innerHTML = `<div class="verified ${warn ? 'warn' : ''}"><span class="ok">${bad ? '!' : '&#10003;'}</span><div><b>QR code verified</b>
        <p>This appointment was requested by <b>${E(a.client)}</b> for <b>${E(a.pet)}</b>${a.has_account ? '' : ' <span class="muted">(no portal account)</span>'}.</p></div></div>
      ${owesHTML(a.balance, a.client_id)}
      <dl class="ci-grid"><div><dt>Pet owner</dt><dd>${E(a.client)}${a.phone ? ' &middot; ' + E(a.phone) : ''}</dd></div><div><dt>Pet</dt><dd>${E(a.pet)} (${E(a.species || '-')}${a.breed ? ', ' + E(a.breed) : ''})</dd></div>
      <div><dt>Service</dt><dd>${E(a.service)}</dd></div><div><dt>When</dt><dd>${E(fmtDay(a.appt_date))}, ${whenOf(a)} (${E(a.branch || '-')})</dd></div>
      <div><dt>Booked</dt><dd>${via(a)}</dd></div><div><dt>${a.is_queue ? 'Preferred vet' : 'Assigned vet'}</dt><dd>${E(a.vet || (a.is_queue ? 'Any vet who is free' : 'Not assigned yet'))}</dd></div>
      ${a.reason ? `<div style="grid-column:1/-1"><dt>Notes from the owner</dt><dd>${E(a.reason)}</dd></div>` : ''}
      ${others(a).length ? `<div style="grid-column:1/-1"><dt>Also booked together</dt><dd>${others(a).map(g => E(g.pet) + ' (' + E(g.service) + (g.is_queue ? '' : ', ' + fmtTime(g.time)) + ')').join('; ')}</dd></div>` : ''}</dl>
      ${warn ? `<p class="devnote">${E(warn)}</p>` : ''}
      ${miss.length ? `<details class="blk" open><summary>${E(a.pet)}'s details are incomplete (missing: ${miss.join(', ')}). Complete them with the owner now.</summary>${detailsFormHTML(petOf(a), 'vd')}
        <h4>Upload documents (optional)</h4>${a.docs ? `<p class="muted" style="margin:0 0 .5rem">${a.docs} document(s) already on file.</p>` : ''}${docFormHTML('vu')}</details>`
      : `<details class="blk"><summary>Upload a pet document (birth certificate, vaccination card...)${a.docs ? ' &middot; ' + a.docs + ' on file' : ''}</summary>${docFormHTML('vu')}</details>`}
      <div class="actions"><button type="button" class="btn plain" data-no>Not this person</button><span style="flex:1"></span>
        <button type="button" class="btn ghost" data-prof>Open pet profile</button><button type="button" class="btn" data-go>${bad ? 'View appointment' : 'Continue to check-in'}</button></div>`;
    $('[data-no]', d).onclick = () => { d.close(); cur = null; resetPanel(); };
    $('[data-go]', d).onclick = () => { d.close(); showPanel(a, true); };
    $('[data-prof]', d).onclick = () => petProfileDialog(a.pet_id, { onClose: refresh });
    if ($('#vd', d)) bindDetails($('#vd', d), petOf(a), refresh); bindDocs($('#vu', d), a.pet_id, refresh);
  };
  const refresh = async () => { try { const n = await api('/api/checkin/lookup', { appt_id: a.id }); Object.assign(a, n); if (d.isConnected) render(); } catch (x) {} };
  render();
}
function resetPanel() { $('#res').innerHTML = '<p class="muted" style="margin:0">Scan the pet owner\'s QR code, upload a saved QR image, or pick someone from the list.</p>'; }

// ---------- the check-in panel ----------
function showPanel(a, verified) {
  if (IS_STAFF) stopCam();
  const done = a.status === 'Completed', arrived = !!a.checked_in_at, isToday = a.appt_date === a.today, sysCancel = a.status === 'Cancelled' && a.cancelled_by === 'System';
  const can = IS_STAFF && !done && ((isToday && a.status !== 'Cancelled') || sysCancel) && !arrived, miss = missingOf(a), warn = dueNote(a), q = !!+a.is_queue;
  const onDuty = B ? B.vets.filter(v => v.on) : [], late = q && !a.queue_open && !arrived;
  const st = arrived ? stateOf(a.id) : null;
  $('#res').innerHTML = `${verified ? `<div class="verified"><span class="ok">&#10003;</span><div><b>QR verified</b><p>Requested by ${E(a.client)} for ${E(a.pet)}.</p></div></div>` : ''}
    <div class="hd"><h2>${E(a.pet)} <span class="tag">${E(a.species || '')}</span></h2>${badge(a.status)}</div>
    ${owesHTML(a.balance, a.client_id)}
    <dl class="ci-grid"><div><dt>Owner</dt><dd><a class="link" href="client.php?id=${a.client_id}">${E(a.client)}</a>${a.phone ? ' &middot; ' + E(a.phone) : ''}</dd></div>
      <div><dt>Service</dt><dd>${E(a.service)}</dd></div>
      <div><dt>When</dt><dd>${E(fmtDay(a.appt_date))}, ${whenOf(a)} (${E(a.branch || '-')})</dd></div><div><dt>Booked</dt><dd>${via(a)}</dd></div>
      ${a.reason ? `<div style="grid-column:1/-1"><dt>Notes</dt><dd>${E(a.reason)}</dd></div>` : ''}
      ${arrived ? `<div><dt>Arrived</dt><dd>${E(a.checked_in_at.slice(11, 16))}${a.queue_no ? ' &middot; queue number ' + a.queue_no : ''}</dd></div>` : ''}
      ${others(a).length ? `<div style="grid-column:1/-1"><dt>Also booked together (checked in with this visit)</dt><dd>${others(a).map(g => E(g.pet) + ' (' + E(g.service) + ')').join('; ')}</dd></div>` : ''}</dl>
    ${warn ? `<p class="devnote">${E(warn)}</p>` : ''}
    ${st ? `<p class="statebox">${st}</p>` : ''}
    ${miss.length && !done ? `<p class="devnote">${E(a.pet)}'s details are incomplete (${miss.join(', ')}). <button type="button" class="link" data-prof>Complete pet details</button></p>` : ''}
    ${can && q ? `<div class="ci-form one">${a.service === 'Vaccination' ? '<p class="hint" style="margin:0">Vaccination: a quick visit (about 15 minutes). It waits in the same line, in the order of arrival.</p>' : `<div class="field"><span class="lbl">How serious does it look? (only changes the waiting-time estimate, not the order)</span>
        <div class="sevpick">${Object.keys(SEV).map((k, i) => `<label class="sev s${i}"><input type="radio" name="sev" value="${k}" ${i === 0 ? 'checked' : ''}><b>${k}</b><small>${sevText(k)}</small></label>`).join('')}</div></div>`}
      <label>Preferred veterinarian (optional)<select id="cv"><option value="">Any vet who is free next</option>${onDuty.map(v => `<option value="${E(v.name)}">${E(v.name)}${v.status === 'busy' ? ' (with a patient)' : ''}</option>`).join('')}</select></label>
      ${late ? `<label class="chk late"><input type="checkbox" id="ov"> New check-ups and vaccinations closed at ${fmtTime(a.last_arrival)}. Allow this patient anyway.</label>` : ''}</div>
      <p class="hint" id="qh"></p><p class="err" id="cerr"></p>` : ''}
    ${can && !q ? `<div class="ci-form"><label>Veterinarian<select id="cv"><option value="">Assign automatically (free vet)</option>${onDuty.map(v => `<option value="${E(v.name)}" ${v.name === a.vet ? 'selected' : ''}>${E(v.name)}${v.status === 'busy' ? ' (with a patient)' : ' (free)'}</option>`).join('')}</select></label>
      <label>Room<select id="cr"><option value="">First free room</option>${(B ? B.rooms : []).map(r => `<option ${r.free ? '' : 'disabled'}>${E(r.name)}${r.free ? '' : ' (occupied)'}</option>`).join('')}</select></label></div><p class="err" id="cerr"></p>` : ''}
    <div class="ci-actions">${can ? `<button class="btn" id="ci" type="button">${sysCancel ? 'Check in as walk-in' : a.status === 'Pending' ? 'Approve &amp; check in' : 'Check in'}</button>` : ''}
      <button class="btn ghost" type="button" data-prof>Open pet profile</button></div>`;
  $$('#res [data-prof]').forEach(b => b.onclick = () => petProfileDialog(a.pet_id, { onClose: async () => { try { Object.assign(a, await api('/api/checkin/lookup', { appt_id: a.id })); showPanel(a, verified); } catch (x) {} } }));
  if (!can) return;
  if (q) { const f = $('#qh'); const w = B ? B.queue.length : 0, free = B ? B.vets.filter(v => v.status === 'free').length : 0, rf = B ? B.rooms.filter(r => r.free).length : 0;
    f.textContent = !onDuty.length ? 'No vet is on duty today. The patient will wait until a vet is marked on duty.' : (free && rf && !w) ? 'A vet and a room are free, so this patient will be called straight away.' : `${w} patient${w === 1 ? '' : 's'} already waiting.`;
    f.className = 'hint' + (!onDuty.length ? ' warn' : ''); }
  $('#ci').onclick = async () => {
    $('#ci').disabled = true; $('#cerr').textContent = '';
    const body = { appt_id: a.id, vet: $('#cv') ? $('#cv').value : '', room: $('#cr') ? $('#cr').value : '', severity: ($('input[name=sev]:checked') || {}).value || 'Routine', override: $('#ov') && $('#ov').checked ? 1 : 0 };
    try { const r = await api('/api/checkin', body); await loadBoard(a.branch); checkedIn(a, r); loadToday(); }
    catch (x) { $('#cerr').textContent = x.message; $('#ci').disabled = false; if (x.data && x.data.needs_override && !$('#ov')) { a.queue_open = false; showPanel(a, verified); $('#cerr').textContent = x.message + ' Tick the box above to allow it.'; } }
  };
}
// where a checked-in patient is right now (from the board)
function stateOf(id) {
  if (!B) return '';
  const w = B.queue.find(x => x.id === id); if (w) return `<b>Waiting: queue number ${w.no}, position ${w.pos}.</b> ${w.pos === 1 ? 'Next to be called.' : (w.pos - 1) + ' ahead.'} Estimated wait: ${E(w.wait_text)}.${w.priority ? ' <span class="badge x">Emergency: ' + E(w.priority_reason || '') + '</span>' : ''}`;
  const s = B.inroom.find(x => x.id === id); if (s) return `<b>Being seen</b> in ${E(s.room || 'a room')}${s.vet ? ' by ' + E(s.vet) : ''}, since ${fmtTime(s.since)}.`;
  return '';
}
async function checkedIn(a, r) {
  let fresh = a; try { fresh = Object.assign(a, await api('/api/checkin/lookup', { appt_id: a.id })); } catch (e) {}
  const miss = missingOf(fresh), called = r.state === 'called';
  $('#res').innerHTML = `<div class="verified"><span class="ok">&#10003;</span><div><b>${E(a.pet)} is checked in${r.walkin ? ' (walk-in)' : ''}${r.late_ok ? ' (after the last-arrival time)' : ''}</b>
      <p>${called ? 'Please send them to <b>' + E(r.room || 'the room') + '</b>' + (r.vet ? ' with <b>' + E(r.vet) + '</b>' : '') + '.' : r.queue_no ? 'Their queue number is below.' : 'Done.'}</p></div></div>
    ${r.queue_no ? `<div class="qbig"><span>Queue number</span><b>${r.queue_no}</b><small>${called ? 'Called now' : r.pos === 1 ? 'Next to be called' : (r.pos - 1) + ' ahead of them &middot; ' + E(r.wait_text || '')}</small></div>` : ''}
    ${owesHTML(r.balance, a.client_id)}
    ${miss.length ? `<p class="devnote">${E(a.pet)}'s details are still incomplete (${miss.join(', ')}).</p>` : ''}
    <div class="ci-actions"><button class="btn ghost" type="button" data-prof>Open pet profile</button><a class="btn plain" href="checkin.php">Check in another</a></div>`;
  $$('#res [data-prof]').forEach(b => b.onclick = () => petProfileDialog(a.pet_id, { onClose: () => checkedIn(a, r) }));
}

// ---------- expected today ----------
async function loadToday() {
  const rows = await api(`/api/appointments/day?date=${today()}&branch=${encodeURIComponent(ME_BRANCH || '')}`), n = nowMin();
  const wait = rows.filter(r => !r.checked_in_at && !['Completed', 'Cancelled'].includes(r.status)), gone = rows.filter(r => r.status === 'Cancelled' && r.cancelled_by === 'System');
  $('#expN').textContent = wait.length ? wait.length + ' expected' : '';
  const row = r => { const lt = !+r.is_queue && n - toMin(r.time); return `<button type="button" class="lbtn" data-id="${r.id}"><span class="t">${+r.is_queue ? 'Any time' : fmtTime(r.time)}</span><span style="flex:1"><b>${E(r.pet)}</b><small>${E(r.client)} &middot; ${E(r.service)}${r.vet ? ' &middot; ' + E(r.vet) : ''}</small></span>${r.status === 'Pending' ? '<span class="badge p">Pending</span>' : ''}${lt >= LATE_AT ? `<span class="badge x">Late ${lt} min</span>` : ''}</button>`; };
  $('#today').innerHTML = wait.length ? wait.map(row).join('') : '<p class="muted" style="margin:0">Nobody else is expected today.</p>';
  $('#latebox').hidden = !gone.length; $('#late').innerHTML = gone.map(row).join('');
  $$('#today [data-id], #late [data-id]').forEach(el => el.onclick = () => IS_STAFF ? lookup({ appt_id: el.dataset.id }, false) : null);
}

// ---------- the board: vets on duty, rooms, the line ----------
async function loadBoard(branch) {
  try { B = await api('/api/board?branch=' + encodeURIComponent(branch || ME_BRANCH || '')); drawBoard(); } catch (x) { $('#board').innerHTML = `<p class="err">${E(x.message)}</p>`; }
}
const qChip = x => x.service === 'Vaccination' ? '<span class="sevc routine">Vaccination</span>' : sevChip(x.severity);
const sevChip = s => `<span class="sevc ${E((s || 'Routine').toLowerCase())}">${E(s || 'Routine')}</span>`;
function drawBoard() {
  $('#boardT').textContent = `${B.branch} branch · updated ${fmtTime(B.now)}`;
  const n = B.on_duty;
  $('#strip').innerHTML = (n === 0 ? '<p class="devnote strip">No vet is on duty at this branch today. Patients will wait until a vet is marked on duty below.</p>' : n < (B.min_vets || 1) ? `<p class="devnote strip">Only ${n} vet${n === 1 ? ' is' : 's are'} on duty today. This branch normally has at least ${B.min_vets || 1}.</p>` : '')
    + (!B.queue_open ? `<p class="devnote strip">New check-ups closed at ${fmtTime(B.last_arrival)}. Everyone already waiting will still be seen.</p>` : '')
    + (window.UI14 ? '<div class="stlegend"><span data-st="wait">Waiting</span><span data-st="room">In a room</span><span data-st="emerg">Emergency</span><span data-st="conf">Confined</span><span data-st="done">Done</span><span data-st="ref">Referred</span></div>' : '');
  const st = { free: 'Free', busy: 'With a patient', off: 'Not on duty today' };
  const vets = B.vets.map(v => `<div class="vrow"><span class="dot ${v.status === 'off' ? 'off' : v.status}"></span><div><b>${E(v.name)}</b>
      <small>${v.status === 'busy' ? 'With ' + E(v.patient) + ' since ' + fmtTime(v.since) + (v.until ? ' (about ' + fmtTime(v.until) + ')' : '') : st[v.status]}${v.source === 'default' ? ' &middot; weekly pattern' : v.source === 'set' ? ' &middot; set for today' : ''}</small></div>
      ${IS_STAFF || v.name === ME_NAME ? `<button type="button" class="btn plain sm" data-duty="${v.id}" data-on="${v.on ? 0 : 1}">${v.on ? 'Not on duty' : 'Put on duty'}</button>` : ''}</div>`).join('') || '<p class="muted">No veterinarians at this branch yet.</p>';
  const rooms = B.rooms.map(r => `<div class="rrow ${r.free ? 'free' : 'occ' + stc('room')}"><span class="dot ${r.free ? 'free' : 'busy'}"></span>${r.free ? '' : pav(r.pet, r.species, null, 'sm')}<div><b>${E(r.name)}</b><small>${r.free ? 'Free' : E(r.pet) + (r.vet ? ' with ' + E(r.vet) : '') + ' &middot; since ' + fmtTime(r.since)}</small></div></div>`).join('');
  const seen = B.inroom.map(s => `<div class="qrow seen${stc('room')}"><span class="n">${s.no || '&bull;'}</span>${pav(s.pet, s.species, null)}<div><b>${E(s.pet)}</b><small>${E(s.client)} &middot; ${E(s.service)}${s.vet ? ' &middot; ' + E(s.vet) : ''}${s.room ? ' &middot; ' + E(s.room) : ''}</small>
      <small><a class="link" href="charge.php?appt=${s.id}">Charge sheet</a>${IS_STAFF ? ` &middot; <button type="button" class="link" data-done="${s.id}" data-pet="${E(s.pet)}">Mark done (if the vet could not)</button>` : ''}</small></div>${qChip(s)}</div>`).join('');
  const queue = B.queue.length ? B.queue.map(x => `<div class="qrow ${x.priority ? 'emerg' : ''}${stc(x.priority ? 'emerg' : 'wait')}"><span class="n">${x.no}</span>${pav(x.pet, x.species, null)}<div><b>${E(x.pet)}</b> ${qChip(x)}<small>${E(x.client)} &middot; ${E(x.service)} &middot; arrived ${fmtTime(x.arrived)}</small>
      <small>${x.priority ? '<b>Emergency: ' + E(x.priority_reason || '') + '</b> &middot; ' : ''}${x.wait === null ? 'No vet on duty' : 'Estimated wait: ' + E(x.wait_text)}</small>
      ${IS_STAFF ? `<small>${x.service === 'Vaccination' ? '' : `<select data-sev="${x.id}" aria-label="Severity">${Object.keys(SEV).map(k => `<option ${k === x.severity ? 'selected' : ''}>${k}</option>`).join('')}</select>`}
        ${x.priority ? `<button type="button" class="link" data-emx="${x.id}" data-clear="1">Remove emergency</button>` : `<button type="button" class="link" data-emx="${x.id}">Emergency: move up</button>`}
        ${x.pos === 1 ? `<button type="button" class="link" data-assign="${x.id}">Assign vet / room</button>` : ''}</small>` : ''}</div></div>`).join('') : '<p class="muted" style="margin:0">Nobody is waiting.</p>';
  const surgHTML = (B.surgery || []).map(r => `<div class="rrow ${r.free ? 'free' : 'occ'}"><span class="dot ${r.free ? 'free' : 'busy'}"></span><div><b>${E(r.name)}</b><small>${r.free ? 'Free' + (r.next ? ' &middot; next surgery ' + fmtTime(r.next) : '') : 'Surgery: ' + E(r.pet) + (r.vet ? ' with ' + E(r.vet) : '') + ' &middot; since ' + fmtTime(r.since)}</small></div></div>`).join('')
    + `<p style="margin:.6rem 0 0"><a class="link" href="confined.php">Confined patients: ${+B.confined || 0}</a></p>`;
  $('#board').innerHTML = `<div><h4>Veterinarians</h4>${vets}${IS_STAFF ? '<p style="margin:.6rem 0 0"><a class="link" href="roster.php">Plan the week (duty roster)</a></p>' : ''}</div><div><h4>Rooms</h4>${rooms}${surgHTML}${seen ? `<h4 style="margin-top:1rem">Being seen</h4>${seen}` : ''}</div>
    <div><h4>The line (first come, first served) ${B.expected ? `<small class="muted">(${B.expected} more expected)</small>` : ''}</h4>${queue}</div>`;
  $$('#board [data-duty]').forEach(b => b.onclick = async () => {
    const on = b.dataset.on === '1';
    if (!on && !confirm('Mark this vet as not on duty today? Their booked surgeries and other timed visits move to other free vets.')) return;
    try { const r = await api('/api/duty', { vet_id: b.dataset.duty, date: today(), on }); if (r.moved || r.unassigned) alert(`${r.moved} appointment(s) moved to other vets.${r.unassigned ? ' ' + r.unassigned + ' could not be placed: reschedule them.' : ''}`); if (r.warn) alert(r.warn); loadBoard(); loadToday(); } catch (x) { alert(x.message); }
  });
  $$('#board [data-sev]').forEach(s => s.onchange = async () => { try { await api('/api/queue/severity', { appt_id: s.dataset.sev, severity: s.value }); loadBoard(); } catch (x) { alert(x.message); } });
  $$('#board [data-emx]').forEach(b => b.onclick = () => {
    if (b.dataset.clear) { api('/api/queue/emergency', { appt_id: b.dataset.emx, clear: 1 }).then(() => loadBoard()).catch(x => alert(x.message)); return; }
    dialog(`<h3>Move an emergency up the line</h3><p class="muted" style="margin:0">Use this only for a real emergency. The reason is saved in the audit log and the admin is told.</p>
      <label>Why is this patient moved up?<input name="reason" maxlength="120" placeholder="e.g. Bleeding, difficulty breathing, hit by a car" required></label>`,
      async f => { await api('/api/queue/emergency', { appt_id: b.dataset.emx, reason: f.reason }); loadBoard(); }, 'Move to the front');
  });
  $$('#board [data-assign]').forEach(b => b.onclick = () => {
    const free = B.vets.filter(v => v.status === 'free'), fr = B.rooms.filter(r => r.free);
    dialog(`<h3>Assign the next patient</h3><div class="fr"><label>Veterinarian<select name="vet"><option value="">Choose automatically</option>${free.map(v => `<option>${E(v.name)}</option>`).join('')}</select></label>
      <label>Room<select name="room"><option value="">Choose automatically</option>${fr.map(r => `<option>${E(r.name)}</option>`).join('')}</select></label></div>
      <p class="muted" style="margin:0">Only a free vet and a free room can be chosen. If none is free the patient is called automatically when one is.</p>`,
      async f => { await api('/api/queue/assign', { appt_id: b.dataset.assign, vet: f.vet, room: f.room }); loadBoard(); }, 'Assign');
  });
  $$('#board [data-done]').forEach(b => b.onclick = async () => {
    if (!confirm(`Mark ${b.dataset.pet} as done? Use this only if the vet could not. The room and vet are freed and the bill goes to Billing.`)) return;
    try { const r = await api(`/api/appointments/${b.dataset.done}/done`, {}); alert(r.already ? 'Already marked done.' : 'Marked done. The bill is ready in Billing.'); loadBoard(); } catch (x) { alert(x.message); }
  });
}
loadToday(); loadBoard();
setInterval(() => { loadBoard(cur ? cur.branch : undefined); loadToday(); if (cur && cur.checked_in_at) { const e = $('#res .statebox'); if (e) e.innerHTML = stateOf(cur.id); } }, 15000);
if (param('appt') && IS_STAFF) lookup({ appt_id: param('appt') }, false);
</script>
<?php bottom(); ?>

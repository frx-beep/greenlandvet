<?php require 'layout.php'; top('Clients', 'c', 'Client Management'); ?>
<form class="searchrow" id="sf"><input id="q" placeholder="Search by name, pet, or contact number..."><a class="btn" href="client_new.php" style="white-space:nowrap">+ New Client</a></form>
<div class="card">
  <table><thead><tr><th>Client Name</th><th>Contact Number</th><th>Email Address</th><th>Pets</th><th>Last Visit</th><th></th></tr></thead><tbody id="rows"></tbody></table>
  <div class="pager"><span id="info"></span><div id="pages"></div></div>
</div>
<script>
let page = 1, t;
$('#q').value = param('q') || '';
async function load() {
  const r = await api(`/api/clients?per=8&page=${page}&q=${encodeURIComponent($('#q').value.trim())}`);
  $('#rows').innerHTML = r.rows.length ? r.rows.map(c => `<tr><td><span class="pn">${pavs(c.pet_pairs)}<span>${esc(c.name)}</span></span>${+c.balance > 0 ? ` <span class="owes">Owes ${peso(c.balance)}</span>` : ''}</td><td>${esc(c.phone)}</td><td>${esc(c.email)}</td><td>${c.npets}</td><td>${fmtDate(c.last_visit)}</td>
    <td><a class="link" href="client.php?id=${c.id}">View &rsaquo;</a></td></tr>`).join('') : '<tr><td colspan="6" class="empty">No clients found.</td></tr>';
  const pages = Math.max(1, Math.ceil(r.total / r.per));
  $('#info').textContent = r.total ? `Showing ${(page - 1) * r.per + 1}-${Math.min(page * r.per, r.total)} of ${r.total} clients` : '';
  $('#pages').innerHTML = `<button data-p="${page - 1}" ${page < 2 ? 'disabled' : ''}>&lsaquo;</button>` +
    Array.from({ length: pages }, (_, i) => `<button data-p="${i + 1}" class="${i + 1 === page ? 'on' : ''}">${i + 1}</button>`).join('') +
    `<button data-p="${page + 1}" ${page >= pages ? 'disabled' : ''}>&rsaquo;</button>`;
  $$('#pages button').forEach(b => b.onclick = () => { page = +b.dataset.p; load(); });
}
$('#sf').onsubmit = e => { e.preventDefault(); page = 1; load(); };
$('#q').oninput = () => { clearTimeout(t); t = setTimeout(() => { page = 1; load(); }, 250); };
load();
</script>
<?php bottom(); ?>

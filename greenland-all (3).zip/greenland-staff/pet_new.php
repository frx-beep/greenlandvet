<?php require 'layout.php'; top('Add Pet', 'c', 'Clients > Add Pet'); ?>
<div class="card fit"><h2>Pet Registration</h2>
  <form id="f" class="form">
    <label>Owner<div id="owner"></div></label>
    <label>Pet's Name<input name="name" required></label>
    <div class="fr"><label>Species<select name="species"><option>Dog</option><option>Cat</option><option>Bird</option><option>Rabbit</option><option>Other</option></select></label>
    <label>Breed<input name="breed"></label></div>
    <div class="fr"><label>Birthdate<input type="date" name="birthdate"></label><label>Sex<select name="sex"><option>Male</option><option>Female</option></select></label></div>
    <p class="err"></p>
    <div class="actions"><button class="btn">Save Pet</button><a class="btn plain" href="javascript:history.back()">Cancel</a></div>
  </form></div>
<script>
const cb = clientCombo($('#owner'));
if (param('client_id')) api('/api/clients/' + param('client_id')).then(c => cb.pick(c));
bindForm('#f', async d => {
  if (!cb.id) throw new Error('Search and choose the owner first.');
  await api(`/api/clients/${cb.id}/pets`, d); location = 'client.php?id=' + cb.id;
});
</script>
<?php bottom(); ?>

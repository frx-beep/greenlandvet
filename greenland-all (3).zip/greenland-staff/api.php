<?php
require 'authlib.php';
$me   = require_login(true);
$in   = json_decode(file_get_contents('php://input'), true) ?? [];
$path = trim($_SERVER['PATH_INFO'] ?? '', '/');
$p    = explode('/', $path);
$post = $_SERVER['REQUEST_METHOD'] === 'POST';
function pet_label(int $pid): string { $r = q('SELECT p.name, c.name cn FROM pets p JOIN clients c ON c.id=p.client_id WHERE p.id=?', [$pid])->fetch(); return $r ? $r['name'] . ' (' . $r['cn'] . ')' : 'pet #' . $pid; }
function appt_label(int $id): string {
    $r = q("SELECT p.name pet, c.name cn, a.service, a.appt_date, a.is_queue, TIME_FORMAT(a.appt_time,'%H:%i') t FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id WHERE a.id=?", [$id])->fetch();
    return $r ? "{$r['pet']} ({$r['cn']}): {$r['service']}, {$r['appt_date']}" . ($r['is_queue'] ? '' : ' ' . $r['t']) : 'appointment #' . $id;
}
function appt_row(string $where, array $args): ?array {
    return q("SELECT a.id, a.status, a.service, a.appt_date, TIME_FORMAT(a.appt_time,'%H:%i') time, a.branch, a.vet, a.reason, a.room, a.checked_in_at, a.started_at, a.called_at, a.done_at, a.source, a.group_token, a.cancelled_by, a.cancel_reason, a.is_queue, a.queue_no, a.severity, a.priority, a.priority_reason, a.record_done, a.next_step, a.followup_date, a.followup_purpose, a.referral_reason, a.referred_from, a.from_appt_id,
        p.id pet_id, p.name pet, p.species, p.breed, p.sex, p.birthdate, p.photo, c.id client_id, c.name client, c.phone, c.email
        FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id WHERE $where LIMIT 1", $args)->fetch() ?: null;
}
function my_branch(): string { return in_array($_GET['branch'] ?? '', BRANCHES) ? $_GET['branch'] : (($GLOBALS['me']['branch'] ?? null) ?: BRANCHES[0]); }
function need_date(?string $d, ?string $dflt = null): string { return preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$d) ? $d : ($dflt ?? date('Y-m-d')); }

// ---- smart scheduling for TIMED services (vaccination, confinement, surgery): which times are free ----
function req_items(array $src): array {   // the services asked for: items=[{svc}] (JSON), or service=
    if (!empty($src['items'])) { $j = json_decode((string)$src['items'], true); return clean_items(is_array($j) ? $j : []); }
    return clean_items([['svc' => $src['service'] ?? 'Vaccination']]);
}
if (!$post && $path === 'schedule/slots') {
    $d = $_GET['date'] ?? ''; if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) fail('Choose a date.', 'date');
    $br = my_branch(); $items = array_values(array_filter(req_items($_GET), fn($i) => !is_queue_svc($i['svc']))); $ign = [];
    if (!empty($_GET['appt'])) {   // rescheduling: the booking's own times count as free, and the whole booking moves together
        $ign = appt_group_ids((int)$_GET['appt']); $rows = appt_rows($ign);
        if ($rows) { $items = array_values(array_filter(array_map(fn($r) => ['svc' => $r['service'], 'concern' => null], $rows), fn($i) => !is_queue_svc($i['svc']))); $br = (string)$rows[0]['branch']; }
    }
    if (!$items) send(['slots' => [], 'closed' => is_closed($d), 'minutes' => 0, 'queue_only' => true]);
    send(['slots' => $d < date('Y-m-d') ? [] : chain_slots($d, $br, $items, nul($_GET['vet'] ?? null), $ign), 'closed' => is_closed($d), 'minutes' => chain_len($items)]);
}
if (!$post && $path === 'schedule/days') {   // days a service (e.g. surgery) can be done and which vets are free
    $br = my_branch();
    $svc = in_array($_GET['service'] ?? '', SERVICES) ? $_GET['service'] : 'Surgery';
    $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from'] ?? '') && $_GET['from'] > date('Y-m-d') ? $_GET['from'] : date('Y-m-d');
    send(free_days($svc, $br, $from, 7, null, nul($_GET['vet'] ?? null)));
}

// ---- today's board: vets, rooms, queue ----
if (!$post && $path === 'board') {
    $br = my_branch(); maintenance(); send(board($br) + ['branch' => $br, 'rooms_all' => ROOMS, 'surgery_rooms' => SURGERY_ROOMS, 'sev' => array_keys(SEVERITY_MINUTES)]);
}

// ---- duty roster: which vets are in on which day (2 to 4 per branch rotate) ----
if (!$post && $path === 'duty') {   // a week from $from: [{date, vets:[{id,name,on,source}]}] + each vet's weekly default pattern
    $br = my_branch(); $from = need_date($_GET['from'] ?? null); $days = [];
    for ($i = 0; $i < 7; $i++) { $d = date('Y-m-d', strtotime("$from +$i day")); $days[] = ['date' => $d, 'closed' => is_closed($d), 'vets' => duty_list($br, $d)]; }
    $def = [];
    try { foreach (q('SELECT account_id, weekday FROM vet_duty_default')->fetchAll() as $r) $def[(int)$r['account_id']][] = (int)$r['weekday']; } catch (PDOException $e) {}
    send(['branch' => $br, 'days' => $days, 'defaults' => (object)$def, 'vets' => q("SELECT id, name FROM accounts WHERE role='vet' AND status='Active' AND branch=? ORDER BY name", [$br])->fetchAll(), 'min_vets' => MIN_VETS_ON_DUTY[$br] ?? 1]);
}
function duty_target(array $in, array $me): array {
    $v = q("SELECT * FROM accounts WHERE id=? AND role='vet' AND status='Active'", [(int)($in['vet_id'] ?? 0)])->fetch();
    if (!$v) fail('Veterinarian not found.');
    if (APP_ROLE === 'vet' && (int)$v['id'] !== (int)$me['id']) fail('You can only change your own duty. Ask the front desk to change another vet.', null, 403);
    if (APP_ROLE === 'staff' && $v['branch'] !== $me['branch']) fail('That vet works at the other branch.', null, 403);
    return $v;
}
if ($post && $path === 'duty') {   // on: true = in, false = not in, null = go back to the weekly pattern
    $v = duty_target($in, $me); $date = need_date($in['date'] ?? null);
    if ($date < date('Y-m-d')) fail('Choose today or a later date.');
    $on = array_key_exists('on', $in) ? $in['on'] : true;
    if ($on === null) { q('DELETE FROM vet_duty WHERE account_id=? AND duty_date=?', [$v['id'], $date]); log_act((int)$me['id'], 'Reset a vet duty to the weekly pattern', $v['name'] . ', ' . $date); queue_advance($v['branch']); send(['ok' => 1, 'moved' => 0, 'unassigned' => 0]); }
    if ($on) {
        q('INSERT INTO vet_duty(account_id,duty_date,on_duty) VALUES(?,?,1) ON DUPLICATE KEY UPDATE on_duty=1', [$v['id'], $date]);
        log_act((int)$me['id'], 'Marked a vet as on duty', $v['name'] . ', ' . $date); queue_advance($v['branch']); send(['ok' => 1, 'moved' => 0, 'unassigned' => 0]);
    }
    if ($date === date('Y-m-d') && q("SELECT 1 FROM appointments WHERE vet=? AND branch=? AND appt_date=CURDATE() AND called_at IS NOT NULL AND status NOT IN ('Completed','Cancelled') LIMIT 1", [$v['name'], $v['branch']])->fetch())
        fail($v['name'] . ' is with a patient right now. Press Done on that visit first.');
    q('INSERT INTO vet_duty(account_id,duty_date,on_duty) VALUES(?,?,0) ON DUPLICATE KEY UPDATE on_duty=0', [$v['id'], $date]);
    $moved = 0; $left = 0;   // timed bookings (vaccination etc.) booked with this vet move to another vet who is free
    $rows = q("SELECT id, service, TIME_FORMAT(appt_time,'%H:%i') t FROM appointments WHERE appt_date=? AND vet=? AND branch=? AND is_queue=0 AND status IN ('Pending','Confirmed') AND started_at IS NULL", [$date, $v['name'], $v['branch']])->fetchAll();
    foreach ($rows as $r) {
        $al = chain_alloc(day_appts($date, $v['branch'], [(int)$r['id']]), vet_pool($v['branch'], $date), [['svc' => $r['service'], 'concern' => null]], tmin($r['t']));
        $nv = $al[0]['vet'] ?? null;
        q('UPDATE appointments SET vet=? WHERE id=?', [$nv, $r['id']]);
        $rr = appt_rows([(int)$r['id']])[0];
        if ($nv) { $moved++; notify_vet($nv, 'booked', 'Appointment assigned to you', $rr['pet'] . ' (' . $rr['service'] . ') at ' . hm12($rr['time']) . ' was moved from ' . $v['name'] . '.', 'appointments.php?date=' . $date); notify_owner((int)$rr['client_id'], 'info', 'Your veterinarian changed', $rr['pet'] . ' will now be seen by ' . $nv . ' at ' . hm12($rr['time']) . '.', 'appointments.php'); }
        else $left++;
    }
    q("UPDATE appointments SET vet=NULL WHERE appt_date=? AND vet=? AND branch=? AND is_queue=1 AND called_at IS NULL AND status NOT IN ('Completed','Cancelled')", [$date, $v['name'], $v['branch']]);   // a preferred vet who is not in: any vet will do
    log_act((int)$me['id'], 'Marked a vet as not on duty', $v['name'] . ', ' . $date . " ($moved moved, $left need a vet)");
    $left_on = count(vet_pool($v['branch'], $date));
    if ($left) notify_role('staff', $v['branch'], 'late', $v['name'] . ' is not in', "$left appointment(s) on $date have no free vet. Please reschedule them or assign a vet.", 'appointments.php?date=' . $date, (int)$me['id']);
    queue_advance($v['branch']);
    send(['ok' => 1, 'moved' => $moved, 'unassigned' => $left, 'on_duty' => $left_on, 'warn' => $left_on < (MIN_VETS_ON_DUTY[$v['branch']] ?? 1) ? 'Only ' . $left_on . ' vet' . ($left_on === 1 ? ' is' : 's are') . ' on duty that day. This branch normally has at least ' . (MIN_VETS_ON_DUTY[$v['branch']] ?? 1) . '.' : null]);
}
if ($post && $path === 'duty/default') {   // weekly pattern: the weekdays this vet normally works (empty list = no pattern, always in)
    $v = duty_target($in, $me);
    $days = array_values(array_unique(array_filter(array_map('intval', is_array($in['days'] ?? null) ? $in['days'] : []), fn($d) => $d >= 0 && $d <= 6 && !in_array($d, CLOSED_DAYS, true))));
    q('DELETE FROM vet_duty_default WHERE account_id=?', [$v['id']]);
    foreach ($days as $d) q('INSERT INTO vet_duty_default(account_id,weekday) VALUES(?,?)', [$v['id'], $d]);
    log_act((int)$me['id'], 'Set a weekly duty pattern', $v['name'] . ': ' . ($days ? implode(', ', array_map(fn($d) => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][$d], $days)) : 'every day'));
    queue_advance($v['branch']); send(['ok' => 1]);
}

// ---- front desk dashboard numbers ----
if (!$post && $path === 'dash') {
    if (APP_ROLE !== 'staff') fail('This is for the front desk.', null, 403);
    $br = $me['branch'] ?: BRANCHES[0]; $bd = board($br);
    send(['waiting' => count($bd['queue']), 'in_room' => count($bd['inroom']), 'confined' => $bd['confined'], 'surgery' => $bd['surgery'], 'on_duty' => $bd['on_duty'], 'queue_open' => $bd['queue_open'], 'last_arrival' => QUEUE_LAST_ARRIVAL,
        'pending_records' => (int)q("SELECT COUNT(*) FROM appointments WHERE status='Completed' AND record_done=0 AND branch=?", [$br])->fetchColumn(),
        'trend' => dash_trend($br)]);
}
// Update 15: numbers behind the KPI trend line (patients seen, today against the same weekday last week, plus the last 7 days)
function dash_trend(string $br): array {
    try {
        $days = []; for ($i = 6; $i >= 0; $i--) $days[] = date('Y-m-d', strtotime("-$i day"));
        $pa = array_column(q("SELECT appt_date d, COUNT(*) n FROM appointments WHERE branch=? AND status<>'Cancelled' AND appt_date BETWEEN ? AND ? GROUP BY appt_date", [$br, date('Y-m-d', strtotime('-7 day')), date('Y-m-d')])->fetchAll(), 'n', 'd');
        $lw = date('Y-m-d', strtotime('-7 day')); $t = date('Y-m-d');
        return ['patients' => (int)($pa[$t] ?? 0), 'patients_lw' => (int)($pa[$lw] ?? 0), 'patients_7' => array_map(fn($d) => (int)($pa[$d] ?? 0), $days), 'weekday' => date('l')];
    } catch (PDOException $e) { return []; }   // an older database: the cards simply show no trend
}
// ---- Update 15: "Now serving" for the front desk (dashboard card and the small panel on every staff page). Staff only. ----
if (!$post && $path === 'nowserving') {
    if (APP_ROLE !== 'staff') fail('This is for the front desk.', null, 403);
    if (!(defined('UI_NOW_SERVING') && UI_NOW_SERVING)) fail('Now serving is switched off in config.php.', null, 404);
    $br = $me['branch'] ?: BRANCHES[0]; $bd = board($br); $rm = [];
    foreach ($bd['rooms'] as $r) if (!empty($r['appt_id'])) $rm[$r['appt_id']] = $r;
    send(['branch' => $br, 'now' => $bd['now'], 'queue_open' => $bd['queue_open'], 'on_duty' => $bd['on_duty'],
        'serving' => array_map(fn($x) => ['id' => $x['id'], 'no' => $x['no'], 'pet' => $x['pet'], 'species' => $x['species'] ?? null, 'client' => $x['client'], 'service' => $x['service'], 'vet' => $x['vet'], 'room' => $x['room'], 'since' => $x['since'], 'with_vet' => !empty($rm[$x['id']]['with_vet'])], $bd['inroom']),
        'next' => array_map(fn($x) => ['no' => $x['no'], 'pet' => $x['pet'], 'species' => $x['species'] ?? null, 'client' => $x['client'], 'wait_text' => $x['wait_text'], 'priority' => (int)$x['priority']], array_slice($bd['queue'], 0, 5)), 'more' => max(0, count($bd['queue']) - 5)]);
}
// ---- QR check-in ----
function owes(int $clientId): float { return client_balance($clientId); }
if ($post && $path === 'checkin/lookup') {
    $t = preg_replace('/^GV:/i', '', trim((string)($in['token'] ?? '')));
    $row = !empty($in['appt_id']) ? appt_row('a.id=?', [(int)$in['appt_id']]) : ($t !== '' ? appt_row('a.qr_token=?', [$t]) : null);
    if (!$row) fail('That QR code is not recognized. Check the code, or find the appointment in the list.');
    $group = $row['group_token'] ? appt_rows(array_map('intval', q("SELECT id FROM appointments WHERE group_token=? AND status<>'Completed'", [$row['group_token']])->fetchAll(PDO::FETCH_COLUMN))) : [];
    $acct = q("SELECT 1 FROM accounts WHERE client_id=? AND role='client'", [$row['client_id']])->fetch();
    $br = (string)($row['branch'] ?: $me['branch']);
    send($row + ['rooms' => ROOMS, 'today' => date('Y-m-d'), 'group' => $group, 'has_account' => (bool)$acct, 'docs' => (int)q('SELECT COUNT(*) FROM pet_documents WHERE pet_id=?', [$row['pet_id']])->fetchColumn(),
        'balance' => owes((int)$row['client_id']), 'queue_open' => queue_open_today(), 'last_arrival' => QUEUE_LAST_ARRIVAL, 'ahead' => count(board($br)['queue']),
        'on_duty' => count(vet_pool($br, date('Y-m-d'))), 'severities' => array_keys(SEVERITY_MINUTES)]);
}
if ($post && $path === 'checkin') {   // the patient arrived. Check-ups join the first-come-first-served line; timed visits go straight to their vet.
    $row = appt_row('a.id=?', [(int)($in['appt_id'] ?? 0)]);
    if (!$row) fail('Appointment not found.');
    if ($row['status'] === 'Completed') fail('This appointment is already completed.');
    $walkin = false;
    if ($row['status'] === 'Cancelled') {   // cancelled automatically for being late (timed) or for not coming on the day (queue): the owner did come after all, so it becomes a walk-in
        if ($row['cancelled_by'] !== 'System') fail('This appointment was cancelled' . ($row['cancel_reason'] ? ' (' . $row['cancel_reason'] . ')' : '') . '. Please create a new appointment for this walk-in.');
        if ($row['appt_date'] !== date('Y-m-d')) fail('This appointment was on ' . $row['appt_date'] . '. Please register this walk-in again.');
        $walkin = true;
    } elseif ($row['appt_date'] !== date('Y-m-d')) fail('This appointment is on ' . $row['appt_date'] . ', not today.');
    $br = (string)($row['branch'] ?: $me['branch']);
    $ids = [(int)$row['id']];
    if ($row['group_token']) $ids = array_map('intval', q("SELECT id FROM appointments WHERE group_token=? AND appt_date=CURDATE() AND status<>'Completed' AND (status<>'Cancelled' OR cancelled_by='System')", [$row['group_token']])->fetchAll(PDO::FETCH_COLUMN));
    $sev = in_array($in['severity'] ?? '', array_keys(SEVERITY_MINUTES), true) ? $in['severity'] : 'Routine';
    $late = !queue_open_today() && $row['is_queue'] && empty($row['checked_in_at']);
    if ($late && APP_ROLE === 'staff' && empty($in['override'])) send(['error' => 'New check-ups and vaccinations after ' . hm12(QUEUE_LAST_ARRIVAL) . ' are normally not accepted. Allow this patient anyway?', 'needs_override' => true], 409);
    if ($late && APP_ROLE !== 'staff') fail('New check-ups and vaccinations after ' . hm12(QUEUE_LAST_ARRIVAL) . ' are not accepted. Please ask the front desk.');
    $want = nul($in['vet'] ?? null); $room = in_array($in['room'] ?? '', ROOMS, true) ? $in['room'] : null;
    $res = with_queue_lock($br, function () use ($ids, $br, $sev, $want, $room, $walkin, $me, $row, $late) {
        $pool = vet_pool($br, date('Y-m-d')); $names = array_column($pool, 'name');
        if ($want && !in_array($want, $names, true)) fail("$want is not on duty today at the $br branch. Choose another vet or let the system assign one.", 'vet');
        $bd = board($br); $busyV = array_filter(array_column(array_filter($bd['vets'], fn($v) => $v['status'] === 'busy'), 'name')); $busyR = array_filter(array_column(array_filter($bd['rooms'], fn($r) => !$r['free']), 'name'));
        $next = (int)q('SELECT COALESCE(MAX(queue_no),0) FROM appointments WHERE appt_date=CURDATE() AND branch=? AND is_queue=1', [$br])->fetchColumn();
        $timedAssigned = []; $noByPet = [];
        foreach (appt_rows($ids) as $r) {
            if (!empty($r['checked_in_at']) && $r['status'] !== 'Cancelled') continue;   // already in
            $extra = $walkin ? ", status='Confirmed', source='Walk-in', cancelled_at=NULL, cancel_reason=NULL, cancelled_by=NULL, reason=CONCAT(COALESCE(reason,''), ' [walk-in after auto-cancel]')" : ", status='Confirmed'";
            if ($r['is_queue']) {   // line up: strict first come, first served. The planner below hands out vets and rooms.
                if (!isset($noByPet[$r['pet_id']])) $noByPet[$r['pet_id']] = ++$next;   // one number per pet: a check-up and a vaccination for the same pet are one visit
                $next_no = $noByPet[$r['pet_id']];
                q("UPDATE appointments SET checked_in_at=NOW(), queue_no=?, severity=?, vet=?, room=NULL, called_at=NULL, priority=0$extra WHERE id=?", [$next_no, $sev, $want ?: ($r['vet'] && in_array($r['vet'], $names, true) ? $r['vet'] : null), $r['id']]);
            } else {   // timed visit: their booked vet (or any free one) and a free room right away
                $vet = $want ?: ($r['vet'] && in_array($r['vet'], $names, true) ? $r['vet'] : null);
                if (!$vet) { $c = array_values(array_diff($names, $busyV, $timedAssigned)); $vet = $c[0] ?? ($names[0] ?? null); }
                $pool2 = $r['service'] === 'Surgery' ? SURGERY_ROOMS : ROOMS;
                $rm = $room && in_array($room, $pool2, true) && !in_array($room, $busyR, true) ? $room : (array_values(array_diff($pool2, $busyR))[0] ?? null);
                if ($rm) $busyR[] = $rm; if ($vet) { $busyV[] = $vet; $timedAssigned[] = $vet; }
                q("UPDATE appointments SET checked_in_at=NOW(), called_at=NOW(), vet=?, room=?$extra WHERE id=?", [$vet, $rm, $r['id']]);
                if ($vet) notify_vet($vet, 'checkin', 'Patient arrived', $r['pet'] . ' (' . $r['service'] . ')' . ($rm ? " in $rm" : '') . ' is here.', 'index.php', (int)$me['id']);
            }
        }
        $plan = queue_advance($br);
        return $plan;
    });
    $rows = appt_rows($ids); $what = appt_summary($rows);
    log_act((int)$me['id'], $walkin ? 'Checked in a late patient as a walk-in' : 'Checked in a patient', appt_label((int)$row['id']) . ($late ? ' (after the last-arrival time, allowed by the front desk)' : ''));
    $mine = null; foreach ($rows as $r) { $st = queue_position((int)$r['id']); if (!$mine || $st['state'] !== 'none') $mine = $st + ['id' => (int)$r['id'], 'pet' => $r['pet']]; }
    $msg = $what . ' checked in.';
    if ($mine && ($mine['state'] ?? '') === 'waiting') $msg .= ' Your queue number is ' . $mine['no'] . ($mine['ahead'] ? ' (' . $mine['ahead'] . ' ahead of you, ' . $mine['wait_text'] . ').' : ' (you are next).');
    elseif ($mine && ($mine['state'] ?? '') === 'called') $msg .= " Please go to {$mine['room']}.";
    notify_owner((int)$row['client_id'], 'checkin', 'You are checked in', $msg, 'appointments.php');
    $bal = owes((int)$row['client_id']);
    send(['ok' => 1, 'walkin' => $walkin, 'late_ok' => $late, 'state' => $mine['state'] ?? 'none', 'queue_no' => $mine['no'] ?? null, 'pos' => $mine['pos'] ?? null, 'wait_text' => $mine['wait_text'] ?? null, 'vet' => $mine['vet'] ?? ($rows[0]['vet'] ?? null), 'room' => $mine['room'] ?? ($rows[0]['room'] ?? null), 'pet_id' => (int)$row['pet_id'], 'balance' => $bal]);
}
// ---- queue controls (front desk) ----
function queue_target(int $id): array {
    $a = appt_row('a.id=?', [$id]); if (!$a) fail('Appointment not found.', null, 404);
    if (!$a['checked_in_at'] || in_array($a['status'], ['Completed', 'Cancelled'], true)) fail('That patient is not in the queue.');
    return $a;
}
if ($post && $path === 'queue/emergency') {   // an emergency is moved up the line by a person, with a reason, and it is logged
    if (APP_ROLE !== 'staff') fail('Only the front desk can move a patient up the line.', null, 403);
    $a = queue_target((int)($in['appt_id'] ?? 0));
    if ($a['called_at']) fail('This patient is already being seen.');
    if (!empty($in['clear'])) { q('UPDATE appointments SET priority=0, priority_reason=NULL WHERE id=?', [$a['id']]); log_act((int)$me['id'], 'Removed an emergency priority', appt_label((int)$a['id'])); queue_advance($a['branch']); send(['ok' => 1]); }
    $why = trim((string)($in['reason'] ?? '')); if ($why === '') fail('Please type why this patient is moved up (for example: bleeding, difficulty breathing).', 'reason');
    q("UPDATE appointments SET priority=1, priority_reason=?, severity='Severe' WHERE id=?", [mb_substr($why, 0, 120), $a['id']]);
    log_act((int)$me['id'], 'Moved an emergency to the front of the queue', appt_label((int)$a['id']) . ': ' . $why);
    notify_role('admin', null, 'info', 'Emergency moved up the queue', $a['pet'] . ' (' . $a['branch'] . '): ' . $why . ' (by ' . $me['name'] . ')', 'activity.php', (int)$me['id']);
    queue_advance($a['branch']); send(['ok' => 1]);
}
if ($post && $path === 'queue/severity') {   // how serious the case looks: only changes the waiting-time estimates, never the order
    $sv = $in['severity'] ?? ''; if (!isset(SEVERITY_MINUTES[$sv])) fail('Choose Routine, Moderate or Severe.');
    $a = appt_row('a.id=?', [(int)($in['appt_id'] ?? 0)]); if (!$a || in_array($a['status'], ['Completed', 'Cancelled'], true)) fail('Appointment not found.');
    q('UPDATE appointments SET severity=? WHERE id=?', [$sv, $a['id']]); log_act((int)$me['id'], 'Set the severity of a visit', appt_label((int)$a['id']) . ': ' . $sv); send(['ok' => 1]);
}
if ($post && $path === 'queue/assign') {   // change the vet/room of a patient being seen, or send the NEXT patient to a chosen vet/room
    if (APP_ROLE !== 'staff') fail('Only the front desk can change the vet or room.', null, 403);
    $a = queue_target((int)($in['appt_id'] ?? 0)); $br = (string)$a['branch'];
    $err = with_queue_lock($br, function () use ($a, $in, $br) {
        if (!$a['called_at']) { $first = board($br)['queue'][0]['id'] ?? null; if ($first !== (int)$a['id']) return 'The line is first come, first served, so only the next patient can be assigned. To move someone up, use Emergency.'; }
        return queue_assign((int)$a['id'], nul($in['vet'] ?? null), nul($in['room'] ?? null), $br);
    });
    if ($err) fail($err);
    if (!empty($in['vet'])) notify_vet($in['vet'], 'checkin', 'Patient assigned to you', $a['pet'] . ' (' . $a['service'] . ')', 'index.php', (int)$me['id']);
    log_act((int)$me['id'], 'Assigned a vet or room', appt_label((int)$a['id']) . ': ' . ($in['vet'] ?? '-') . ' / ' . ($in['room'] ?? '-')); send(['ok' => 1]);
}

// ---- my profile ----
if ($p[0] === 'profile') {
    if (!$post && count($p) === 1) send(q('SELECT name,email,phone,username,branch,photo FROM accounts WHERE id=?', [$me['id']])->fetch());
    if ($post && $path === 'profile') {
        $n = trim($in['name'] ?? ''); $em = strtolower(trim($in['email'] ?? ''));
        if ($n === '') fail('Please enter your name.', 'name');
        if (!filter_var($em, FILTER_VALIDATE_EMAIL)) fail('Please enter a valid email address.', 'email');
        try { q('UPDATE accounts SET name=?, email=?, phone=? WHERE id=?', [$n, $em, nul($in['phone'] ?? null), $me['id']]); }
        catch (PDOException $e) { fail('That email is already used by another staff account.', 'email'); }
        log_act((int)$me['id'], 'Updated profile');
        send(['ok' => 1]);
    }
    if ($post && $path === 'profile/photo') {
        $ph = (string)($in['photo'] ?? '');
        if ($ph !== '' && (strpos($ph, 'data:image/jpeg;base64,') !== 0 || strlen($ph) > 400000 || base64_decode(substr($ph, 23), true) === false)) fail('That photo could not be used. Please choose a smaller image.');
        q('UPDATE accounts SET photo=? WHERE id=?', [$ph === '' ? null : $ph, $me['id']]); log_act((int)$me['id'], 'Changed profile photo'); send(['ok' => 1]);
    }
    if ($post && $path === 'profile/password') {
        if (!password_verify($in['current'] ?? '', $me['password'])) fail('Your current password is incorrect.', 'current');
        $pw = $in['password'] ?? '';
        if (strlen($pw) < 8) fail('The new password needs at least 8 characters.', 'password');
        if ($pw !== ($in['confirm'] ?? '')) fail('The two passwords do not match.', 'confirm');
        q('UPDATE accounts SET password=?, must_change=0 WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $me['id']]);
        log_act((int)$me['id'], 'Password changed'); send(['ok' => 1]);
    }
}

// ---- appointments ----
const APPT_COLS = "a.id, TIME_FORMAT(a.appt_time,'%H:%i') AS time, a.service, a.status, a.branch, a.vet, a.reason, a.source, a.pet_id, a.checked_in_at, a.started_at, a.called_at, a.done_at, a.room, a.group_token, a.cancel_reason, a.cancelled_by, a.is_queue, a.queue_no, a.severity, a.priority, a.record_done, a.referred_from, a.next_step,
    (SELECT s.status FROM sales s WHERE s.appt_id=a.id ORDER BY s.id DESC LIMIT 1) bill_status, (SELECT s.id FROM sales s WHERE s.appt_id=a.id ORDER BY s.id DESC LIMIT 1) bill_id, p.name pet, p.species, c.name client, c.id client_id";
if ($p[0] === 'appointments') {
    if (!$post && $path === 'appointments/mix') {   // Update 15: how many of each service on each day (the coloured calendar dots)
        $out = [];
        foreach (q("SELECT appt_date d, service s, COUNT(*) n FROM appointments WHERE appt_date LIKE ? AND status<>'Cancelled' GROUP BY appt_date, service", [($_GET['month'] ?? '') . '-%'])->fetchAll() as $r) $out[$r['d']][$r['s']] = (int)$r['n'];
        send((object)$out);
    }
    if (!$post && $path === 'appointments/counts')
        send((object)array_column(q("SELECT appt_date d, COUNT(*) n FROM appointments WHERE appt_date LIKE ? AND status<>'Cancelled' GROUP BY appt_date", [($_GET['month'] ?? '') . '-%'])->fetchAll(), 'n', 'd'));
    if (!$post && $path === 'appointments/day' && isset($_GET['paged'])) {   // Appointments tab: 10 per page
        $per = 10; $page = max(1, (int)($_GET['page'] ?? 1)); $off = ($page - 1) * $per;
        $mine = (APP_ROLE === 'vet' && !empty($_GET['mine'])) ? $me['name'] : '';   // vets can show only their own patients
        $a = [$_GET['date'] ?? '', $_GET['branch'] ?? '', $_GET['branch'] ?? '', $_GET['status'] ?? '', $_GET['status'] ?? '', $mine, $mine];
        $W = "a.appt_date=? AND (?='' OR a.branch=?) AND (?='' OR a.status=?) AND (?='' OR a.vet=?)";
        $total = (int)q("SELECT COUNT(*) FROM appointments a WHERE $W", $a)->fetchColumn();
        $rows = q("SELECT " . APPT_COLS . " FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id WHERE $W ORDER BY a.is_queue, a.appt_time, a.queue_no, a.id LIMIT $per OFFSET $off", $a)->fetchAll();
        send(compact('rows', 'total', 'page', 'per'));
    }
    if (!$post && $path === 'appointments/day')
        send(q("SELECT " . APPT_COLS . " FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id
            WHERE a.appt_date=? AND (?='' OR a.branch=?) AND (?='' OR a.status=?) ORDER BY a.is_queue, a.appt_time, a.queue_no, a.id",
            [$_GET['date'] ?? '', $_GET['branch'] ?? '', $_GET['branch'] ?? '', $_GET['status'] ?? '', $_GET['status'] ?? ''])->fetchAll());
    if ($post && $path === 'appointments') {   // one or several pets/services in one booking. Check-ups = a day registration (no time); the others keep a booked time.
        $list = !empty($in['items']) && is_array($in['items']) ? $in['items'] : [['pet_id' => $in['pet_id'] ?? 0, 'service' => $in['service'] ?? '']];
        if (empty($in['date'])) fail('Choose a client, pet, service and date');
        if (count($list) > MAX_BOOKING_ITEMS) fail('You can book up to ' . MAX_BOOKING_ITEMS . ' services at once.');
        $items = []; $pets = []; $clientIds = [];
        foreach ($list as $it) {
            $pid = (int)($it['pet_id'] ?? 0); $svc = $it['service'] ?? ($it['svc'] ?? '');
            if (!$pid || !in_array($svc, SERVICES, true)) fail('Choose a client, pet, service and date');
            $pr = q('SELECT id, client_id FROM pets WHERE id=?', [$pid])->fetch(); if (!$pr) fail('Pet not found.');
            $clientIds[$pr['client_id']] = 1; $pets[] = $pid; $items[] = ['svc' => $svc, 'concern' => null];
        }
        if (count($clientIds) > 1) fail('All pets in one booking must belong to the same client.', 'pet_id');
        $br = in_array($in['branch'] ?? '', BRANCHES) ? $in['branch'] : $me['branch'];
        foreach ($items as $it) {
            if ($it['svc'] === 'Confinement') fail('A confinement starts when the vet decides it at Done (or it is a referral). It is not booked in advance.', 'service');
            if ($it['svc'] === 'Surgery' && $br !== MAIN_BRANCH) fail('Surgery is done at the ' . MAIN_BRANCH . ' branch only. Choose the ' . MAIN_BRANCH . ' branch (a Taytay vet refers the patient there).', 'branch');
        }
        $want = nul($in['vet'] ?? null);
        $timed = array_values(array_filter($items, fn($i) => !is_queue_svc($i['svc'])));
        $hasQ = count($timed) < count($items);
        if ($timed && empty($in['time'])) fail('Choose a time for the ' . strtolower($timed[0]['svc']) . '.', 'time');
        $override = APP_ROLE === 'staff' && !empty($in['override']);
        if ($hasQ) { if ($override && $in['date'] === date('Y-m-d')) { if (is_closed($in['date'])) fail('The clinic is closed today.', 'date'); } else queue_check_day($in['date'], $br); }
        $al = $timed ? pick_chain($in['date'], $in['time'], $br, $timed, $want) : [];   // checks hours, clashes, rooms and who is on duty
        $gt = count($items) > 1 ? bin2hex(random_bytes(12)) : null; $status = !empty($in['confirmed']) ? 'Confirmed' : 'Pending'; $ids = []; $ti = 0;
        $db = db(); $db->beginTransaction();
        foreach ($items as $i => $it) {
            if (is_queue_svc($it['svc'])) {
                if (q("SELECT 1 FROM appointments WHERE pet_id=? AND appt_date=? AND branch=? AND is_queue=1 AND service=? AND status<>'Cancelled' LIMIT 1", [$pets[$i], $in['date'], $br, $it['svc']])->fetch()) { $db->rollBack(); fail('This pet is already registered for a ' . strtolower($it['svc']) . ' that day.', 'pet_id'); }
                q("INSERT INTO appointments(pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,group_token,is_queue) VALUES(?,?,'00:00:00',?,?,?,?,?,?,?,?,1)",
                  [$pets[$i], $in['date'], $it['svc'], $want, $br, $status, nul($in['reason'] ?? null), APP_NAME, bin2hex(random_bytes(12)), $gt]);
            } else {
                q('INSERT INTO appointments(pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,group_token) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                  [$pets[$i], $in['date'], mtime($al[$ti]['start']), $it['svc'], $al[$ti]['vet'] ?: $want, $br, $status, nul($in['reason'] ?? null), APP_NAME, bin2hex(random_bytes(12)), $gt]); $ti++;
            }
            $ids[] = (int)$db->lastInsertId();
        }
        $db->commit();
        $rows = appt_rows($ids); $what = appt_summary($rows); $when = appt_when($rows[0]);
        log_act((int)$me['id'], 'Booked an appointment', $what . ', ' . $when);
        foreach (array_unique(array_filter(array_column($rows, 'vet'))) as $v) notify_vet($v, 'booked', 'New appointment', "$what, $when.", 'appointments.php?date=' . $in['date'], (int)$me['id']);
        notify_owner((int)$rows[0]['client_id'], 'booked', $status === 'Confirmed' ? 'Appointment scheduled' : 'Appointment booked at the clinic', "$what, $when ($br)." . ($status === 'Confirmed' ? '' : ' It will be confirmed shortly.') . ($hasQ ? ' Check-ups are first come, first served: come any time that day and show your QR code.' : ''), 'appointments.php');
        send(['ok' => 1, 'ids' => $ids, 'vet' => $rows[0]['vet'] ?? null, 'queue' => $hasQ]);
    }
    if ($post && count($p) === 3 && $p[2] === 'start' && ctype_digit($p[1])) {   // the vet opened the patient: the patient is now with the vet
        $rows = appt_rows([(int)$p[1]]); if (!$rows) fail('Appointment not found.', null, 404);
        $r = $rows[0];
        if (!in_array($r['status'], ['Completed', 'Cancelled'], true) && ($r['called_at'] || !$r['is_queue']))
            q("UPDATE appointments SET started_at=COALESCE(started_at, NOW()), checked_in_at=COALESCE(checked_in_at, NOW()), called_at=COALESCE(called_at, NOW()), status='Confirmed' WHERE id=?", [$p[1]]);
        send(['ok' => 1]);
    }
    if ($post && count($p) === 3 && $p[2] === 'done' && ctype_digit($p[1])) {   // Done: normally the vet on the tablet; the front desk can also press it. Safe to press twice.
        $rows = appt_rows([(int)$p[1]]); if (!$rows) fail('Appointment not found.', null, 404);
        if (APP_ROLE === 'vet' && $rows[0]['vet'] && $rows[0]['vet'] !== $me['name'] && $rows[0]['status'] !== 'Completed') fail('This patient is with ' . $rows[0]['vet'] . '. Ask them, or the front desk, to press Done.', null, 403);
        send(appt_done((int)$p[1], $me, APP_ROLE, is_array($in['next'] ?? null) ? $in['next'] : null));
    }
    if ($post && count($p) === 2 && ctype_digit($p[1])) {
        $id = (int)$p[1]; $rows = appt_rows([$id]); if (!$rows) fail('Appointment not found.', null, 404); $a = $rows[0];
        $lbl = appt_label($id);
        if (!empty($in['delete'])) {   // permanent removal: front desk only, and only for requests that were never approved or that are already cancelled
            if (APP_ROLE !== 'staff') fail('Only the front desk can delete appointments. Cancel it instead.', null, 403);
            if (!in_array($a['status'], ['Pending', 'Cancelled'], true)) fail('Only pending or cancelled appointments can be deleted. Cancel it first.');
            q('DELETE FROM appointments WHERE id=?', [$id]); log_act((int)$me['id'], 'Deleted an appointment', $lbl); send(['ok' => 1]);
        }
        if (!empty($in['cancel'])) {
            $reason = trim($in['reason'] ?? ''); if ($reason === '') fail('Please choose a reason for cancelling.', 'reason');
            $why = APP_ROLE === 'staff' ? staff_can_change($a) : vet_can_cancel($a, $me); if ($why) fail($why);
            appt_cancel(appt_group_ids($id), APP_ROLE === 'staff' ? 'Staff' : 'Vet', $reason, $me); send(['ok' => 1]);
        }
        if (!empty($in['reschedule'])) {
            if (APP_ROLE !== 'staff') fail('Only the front desk can reschedule. Ask them, or cancel your appointment with a reason.', null, 403);
            if ($why = staff_can_change($a)) fail($why);
            if (empty($in['date']) || (empty($in['time']) && !$a['is_queue'])) fail($a['is_queue'] ? 'Choose a new date.' : 'Choose a new date and time.', 'time');
            appt_reschedule($id, $in['date'], (string)($in['time'] ?? '00:00'), 'Staff', $me); send(['ok' => 1]);
        }
        if (in_array($in['status'] ?? '', ['Pending', 'Confirmed'])) {
            if (in_array($a['status'], ['Completed', 'Cancelled'], true)) fail('This appointment is already ' . strtolower($a['status']) . '.');
            q('UPDATE appointments SET status=?, reason=? WHERE id=?', [$in['status'], nul($in['reason'] ?? null), $id]);
            $approving = $a['status'] === 'Pending' && $in['status'] === 'Confirmed';
            if ($approving && $a['group_token']) q("UPDATE appointments SET status='Confirmed' WHERE group_token=? AND status='Pending'", [$a['group_token']]);
            log_act((int)$me['id'], $approving ? 'Approved an appointment' : 'Updated an appointment', $lbl);
            if ($approving) {
                $all = $a['group_token'] ? appt_rows(array_map('intval', q("SELECT id FROM appointments WHERE group_token=?", [$a['group_token']])->fetchAll(PDO::FETCH_COLUMN))) : [$a];
                $what = appt_summary($all); $when = appt_when($a);
                notify_owner((int)$a['client_id'], 'approve', 'Appointment approved', "$what, $when ({$a['branch']}). Show your QR code when you arrive.", 'appointments.php');
                foreach (array_unique(array_filter(array_column($all, 'vet'))) as $v) notify_vet($v, 'booked', 'Appointment confirmed', "$what, $when.", 'appointments.php?date=' . $a['appt_date'], (int)$me['id']);
            }
        }
        send(['ok' => 1]);
    }
}
// ---- vet: my patients today (tablet home screen) ----
if (!$post && $path === 'mypatients') {
    if (APP_ROLE !== 'vet') fail('This screen is for veterinarians.', null, 403);
    maintenance(); $br = $me['branch'] ?: BRANCHES[0];
    $rows = q("SELECT " . APPT_COLS . ", (SELECT s.total FROM sales s WHERE s.appt_id=a.id ORDER BY s.id DESC LIMIT 1) bill_total,
        (SELECT COALESCE(SUM(s2.total-s2.paid),0) FROM sales s2 WHERE s2.client_id=c.id AND s2.status IN ('Unpaid','Partially paid')) owes
        FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id
        WHERE a.appt_date=CURDATE() AND a.status<>'Cancelled' AND a.vet=? AND (a.checked_in_at IS NOT NULL OR a.is_queue=0)
        ORDER BY (a.status='Completed'), COALESCE(a.called_at, a.checked_in_at), a.appt_time, a.id", [$me['name']])->fetchAll();
    $pend = (int)q("SELECT COUNT(*) FROM appointments WHERE status='Completed' AND record_done=0 AND vet=?", [$me['name']])->fetchColumn();
    $bd = board($br); $duty = array_values(array_filter($bd['vets'], fn($v) => (int)$v['id'] === (int)$me['id']))[0] ?? null;
    send(['rows' => $rows, 'pending_records' => $pend, 'confined' => $bd['confined'], 'surgery' => $bd['surgery'], 'waiting' => count($bd['queue']), 'on_duty' => $duty ? $duty['on'] : true, 'branch' => $br, 'queue_open' => $bd['queue_open']]);
}
if (!$post && $path === 'records/pending') {   // visits that happened but whose findings are not typed yet
    $mine = !empty($_GET['mine']) && APP_ROLE === 'vet' ? $me['name'] : '';
    send(q("SELECT a.id appt_id, a.appt_date, a.service, a.vet, a.done_at, a.pet_id, p.name pet, p.species, c.name client, DATEDIFF(CURDATE(), a.appt_date) days
        FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id WHERE a.status='Completed' AND a.record_done=0 AND (?='' OR a.vet=?) ORDER BY a.appt_date, a.id LIMIT 200", [$mine, $mine])->fetchAll());
}


// ---- medical records (vaccination, checkup, confinement, surgery) ----
// The date shown on a record is always the VISIT date (the appointment date). When it was typed is kept apart in recorded_at.
const REC = [
    'vaccination' => ['vaccinations', 'vac_date', ['vaccine', 'vac_date', 'next_due', 'notes', 'item_type']],
    'checkup'     => ['checkups', 'checkup_date', ['checkup_date', 'vet', 'details', 'findings', 'next_step', 'followup_date', 'chief_complaint', 'tests', 'test_results', 'diagnosis', 'prescription', 'followup_purpose']],
    'confinement' => ['confinements', 'admitted', ['admitted', 'discharged', 'status', 'reason', 'treatment', 'notes', 'outcome']],
    'surgery'     => ['surgeries', 'surgery_date', ['procedure_name', 'surgery_date', 'vet', 'findings', 'notes', 'outcome']],
];
const REC_ITEM_TYPES = ['Vaccine', 'Deworming', 'Tick and flea', 'Other'];   // one vaccination visit can hold several of these, each with its own next schedule
const STAFF_CAN_EDIT_RECORDS = false;   // the front desk reads records but does not write them
if ($p[0] === 'records' && isset(REC[$p[1] ?? ''])) {
    [$tbl, $dcol, $cols] = REC[$p[1]];
    $apptRec = null;
    if ($post) {
        if (APP_ROLE !== 'vet' && !STAFF_CAN_EDIT_RECORDS) fail('Medical records are written by the veterinarian. The front desk can read them in General Records.', null, 403);
        if (count($p) === 3 && $p[1] === 'confinement') {   // admission, discharge and status belong to the confinement itself (they drive the bill)
            $o0 = q('SELECT admitted, discharged, status, sale_id FROM confinements WHERE id=?', [$p[2]])->fetch();
            if ($o0 && $o0['sale_id']) { $in['admitted'] = $o0['admitted']; $in['discharged'] = $o0['discharged']; $in['status'] = $o0['status']; }
        }
        if (count($p) === 2 && !empty($in['appt_id'])) {   // the visit date comes from the appointment, never from the day it is typed
            $apptRec = appt_row('a.id=?', [(int)$in['appt_id']]);
            if (!$apptRec || (int)$apptRec['pet_id'] !== (int)($in['pet_id'] ?? 0)) fail('That appointment does not belong to this pet.');
            $in[$dcol] = $apptRec['appt_date'];
            if (in_array('vet', $cols) && empty($in['vet'])) $in['vet'] = $apptRec['vet'] ?: (APP_ROLE === 'vet' ? $me['name'] : null);
        }
        if ($p[1] === 'checkup' && $apptRec && $apptRec['next_step'] !== null) {   // decided when the visit was marked Done: the write-up just repeats it
            $in['next_step'] = $apptRec['next_step']; $in['followup_date'] = $apptRec['followup_date'] ?: null; $in['followup_purpose'] = $apptRec['followup_purpose'] ?: null;
        }
        if ($p[1] === 'checkup' && array_key_exists('next_step', $in)) {
            $in['next_step'] = in_array($in['next_step'], ['Confinement', 'Surgery']) ? $in['next_step'] : 'None';
            if (!empty($in['followup_date']) && !empty($in['checkup_date']) && $in['followup_date'] < $in['checkup_date']) fail("The next check-up can't be earlier than this check-up.", 'followup_date');
            if (!empty($in['followup_date']) && $in['followup_date'] < date('Y-m-d') && !($apptRec && $apptRec['next_step'] !== null)) fail('The next check-up date has already passed.', 'followup_date');
        }
        $items = null;
        if ($p[1] === 'vaccination') {
            if (count($p) === 2 && isset($in['items']) && is_array($in['items'])) {   // several things given at one visit (vaccine, deworming, tick and flea...)
                $items = [];
                foreach (array_slice($in['items'], 0, 12) as $it) {
                    $n = mb_substr(trim((string)($it['vaccine'] ?? '')), 0, 120); if ($n === '') continue;
                    $nd = nul($it['next_due'] ?? null);
                    if ($nd && !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$nd)) fail('Check the next schedule date of ' . $n . '.');
                    if ($nd && !empty($in['vac_date']) && $nd < $in['vac_date']) fail('The next schedule of ' . $n . " can't be earlier than the date it was given.", 'next_due');
                    $items[] = ['vaccine' => $n, 'next_due' => $nd, 'item_type' => in_array($it['item_type'] ?? '', REC_ITEM_TYPES, true) ? $it['item_type'] : 'Vaccine'];
                }
                if (!$items) fail('Type at least one vaccine or treatment that was given.');
                $in['vaccine'] = $items[0]['vaccine']; $in['next_due'] = $items[0]['next_due']; $in['item_type'] = $items[0]['item_type'];
            }
            if (count($p) === 2 || array_key_exists('item_type', $in)) $in['item_type'] = in_array($in['item_type'] ?? '', REC_ITEM_TYPES, true) ? $in['item_type'] : 'Vaccine';
        }
        if (in_array($p[1], ['confinement', 'surgery']) && array_key_exists('outcome', $in)) {
            $in['outcome'] = in_array($in['outcome'], ['Survived', 'Died'], true) ? $in['outcome'] : null;
            if ($p[1] === 'confinement') {
                if (($in['status'] ?? '') === 'Discharged' && !$in['outcome']) fail('Choose whether the pet survived or died.', 'outcome');
                if (($in['status'] ?? '') === 'Admitted' && $in['outcome']) fail('A pet that is still admitted has no outcome yet. Discharge it first.', 'outcome');
            }
        }
        $vals = array_map(fn($c) => nul($in[$c] ?? null), $cols);
        if ($vals[array_search($dcol, $cols)] === null) fail('Please enter the date');
        if (in_array($p[1], ['vaccination', 'surgery']) && !$vals[0]) fail($p[1] === 'surgery' ? 'Enter the type of surgery' : 'Enter the vaccine name');
        if ($p[1] === 'confinement' && !in_array($in['status'] ?? '', ['Admitted', 'Discharged'])) fail('Choose a confinement status');
    }
    if (count($p) === 2 && !$post) {
        $pid = (int)($_GET['pet_id'] ?? 0);
        if (isset($_GET['paged'])) {   // "View all" page: filters + 10 per page
            $per = 10; $page = max(1, (int)($_GET['page'] ?? 1)); $off = ($page - 1) * $per;
            $s = trim($_GET['q'] ?? ''); $like = "%$s%"; $f = $_GET['from'] ?? ''; $t = $_GET['to'] ?? '';
            $w = ["(? = '' OR x.name LIKE ? OR c.name LIKE ?)", "(? = '' OR r.$dcol >= ?)", "(? = '' OR r.$dcol <= ?)"];
            $a = [$s, $like, $like, $f, $f, $t, $t];
            if (in_array('vet', $cols)) { $w[] = "(? = '' OR r.vet = ?)"; array_push($a, $_GET['vet'] ?? '', $_GET['vet'] ?? ''); }
            if (in_array('status', $cols)) { $w[] = "(? = '' OR r.status = ?)"; array_push($a, $_GET['status'] ?? '', $_GET['status'] ?? ''); }
            $from = "FROM $tbl r JOIN pets x ON x.id=r.pet_id JOIN clients c ON c.id=x.client_id WHERE " . implode(' AND ', $w);
            $total = (int)q("SELECT COUNT(*) $from", $a)->fetchColumn();
            $rows = q("SELECT r.*, x.name pet, x.client_id, c.name client $from ORDER BY r.$dcol DESC, r.id DESC LIMIT $per OFFSET $off", $a)->fetchAll();
            send(compact('rows', 'total', 'page', 'per'));
        }
        $lim = min(max((int)($_GET['limit'] ?? 50), 1), 200);
        send(q("SELECT r.*, x.name pet, x.client_id, c.name client FROM $tbl r JOIN pets x ON x.id=r.pet_id JOIN clients c ON c.id=x.client_id WHERE (?=0 OR r.pet_id=?) ORDER BY r.$dcol DESC, r.id DESC LIMIT $lim", [$pid, $pid])->fetchAll());
    }
    if (count($p) === 2 && $post) {
        $pid = (int)($in['pet_id'] ?? 0);
        if (!$pid) fail('Choose a client and pet');
        $rid = 0;
        foreach ($items ?? [null] as $it) {   // a vaccination visit saves one row per item, all with the same visit date
            $v2 = $vals;
            if ($it) { $v2[0] = $it['vaccine']; $v2[2] = $it['next_due']; $v2[array_search('item_type', $cols)] = $it['item_type']; }
            q("INSERT INTO $tbl(pet_id,appt_id,recorded_at,recorded_by," . implode(',', $cols) . ') VALUES(?,?,NOW(),?' . str_repeat(',?', count($cols)) . ')', array_merge([$pid, $apptRec ? (int)$apptRec['id'] : null, $me['name']], $v2));
            if (!$rid) $rid = (int)db()->lastInsertId();
        }
        log_act((int)$me['id'], 'Recorded ' . ['vaccination' => 'a vaccination', 'checkup' => 'a check-up', 'confinement' => 'a confinement', 'surgery' => 'a surgery'][$p[1]], pet_label($pid) . ($items && count($items) > 1 ? ' (' . count($items) . ' items)' : '') . ($apptRec ? ', visit ' . $apptRec['appt_date'] : ''));
        if ($apptRec) {
            q('UPDATE appointments SET record_done=1 WHERE id=?', [$apptRec['id']]);
            if ($apptRec['status'] === 'Completed') notify_owner((int)$apptRec['client_id'], 'done', 'Medical record ready', $apptRec['pet'] . "'s " . strtolower($apptRec['service']) . ' record is ready. You can view it in My Pets.', 'pets.php');
        }
        $fu = null;
        $dupFu = ($p[1] === 'checkup' && !empty($in['followup_date'])) ? q("SELECT 1 FROM appointments WHERE pet_id=? AND appt_date=? AND is_queue=1 AND status<>'Cancelled' LIMIT 1", [$pid, $in['followup_date']])->fetch() : null;
        if ($p[1] === 'checkup' && !empty($in['followup_date']) && !$dupFu) {   // the follow-up is a check-up registration for that day (first come, first served)
            $fb = ($apptRec['branch'] ?? null) ?: ($me['branch'] ?: BRANCHES[0]);
            [$fid, $fd] = register_queue($pid, $in['followup_date'], $fb, nul($in['vet'] ?? null), !empty($in['followup_purpose']) ? 'Follow-up: ' . mb_substr(trim($in['followup_purpose']), 0, 150) : 'Follow-up check-up', 'Confirmed', null, APP_NAME, true);
            $fu = [$fd, null];
            $fr = appt_rows([$fid]);
            if ($fr) { notify_owner((int)$fr[0]['client_id'], 'booked', 'Follow-up check-up scheduled', $fr[0]['pet'] . ': ' . appt_when($fr[0]) . ' (' . $fr[0]['branch'] . ').', 'appointments.php'); }
        }
        send(['ok' => 1, 'id' => $rid, 'followup' => $fu]);
    }
    if (count($p) === 3 && !$post) {
        $r = q("SELECT r.*, x.client_id, x.name pet FROM $tbl r JOIN pets x ON x.id=r.pet_id WHERE r.id=?", [$p[2]])->fetch();
        if (!$r) send(['error' => 'Record not found'], 404);
        $r['edits'] = q('SELECT edited_by, changes, edited_at FROM record_edits WHERE rtype=? AND record_id=? ORDER BY id DESC LIMIT 10', [$p[1], $p[2]])->fetchAll();
        send($r);
    }
    if (count($p) === 3 && $post) {   // any vet may edit a record (switch: VET_CAN_EDIT_RECORDS in config.php); every change is logged (who, when, what changed)
        if (!VET_CAN_EDIT_RECORDS) fail('Editing saved records is switched off. Ask the administrator.', null, 403);
        $old = q("SELECT * FROM $tbl WHERE id=?", [$p[2]])->fetch(); if (!$old) fail('Record not found.', null, 404);
        $uc = []; $uv = []; $diff = [];
        foreach ($cols as $i => $c) if (array_key_exists($c, $in)) {
            $uc[] = $c; $uv[] = $vals[$i];
            if ((string)$old[$c] !== (string)($vals[$i] ?? '')) $diff[] = $c . ': "' . mb_substr((string)$old[$c], 0, 60) . '" to "' . mb_substr((string)($vals[$i] ?? ''), 0, 60) . '"';
        }
        if ($diff) {
            q("UPDATE $tbl SET " . implode('=?,', $uc) . '=?, edited_by=?, edited_at=NOW() WHERE id=?', array_merge($uv, [$me['name'], $p[2]]));
            q('INSERT INTO record_edits(rtype,record_id,edited_by,changes) VALUES(?,?,?,?)', [$p[1], $p[2], $me['name'], implode("\n", $diff)]);
            if ($old['recorded_by'] && $old['recorded_by'] !== $me['name']) { $own = q("SELECT id FROM accounts WHERE role='vet' AND name=? AND status='Active'", [$old['recorded_by']])->fetch(); if ($own) notify_vet($old['recorded_by'], 'info', 'Your record was edited', $me['name'] . ' edited a ' . $p[1] . ' record.', 'general.php', (int)$me['id']); }
        }
        log_act((int)$me['id'], 'Edited a ' . $p[1] . ' record', 'record #' . $p[2] . ($diff ? ': ' . implode('; ', array_slice($diff, 0, 3)) : ' (no change)'));
        send(['ok' => 1]);
    }
}

// ---- General Records: every vet's records in one searchable list (the front desk can read, not edit) ----
function rec_union(): string {
    return "SELECT 'vaccination' rtype, r.id rid, r.vac_date vdate, r.recorded_at, r.recorded_by vet, r.edited_by, r.pet_id, r.appt_id, r.vaccine title, LEFT(CONCAT(IF(r.item_type IS NULL OR r.item_type='Vaccine','',CONCAT(r.item_type,'. ')), COALESCE(r.notes,'')),120) summary, 'Completed' state, 'Vaccination' service FROM vaccinations r
      UNION ALL SELECT 'checkup', r.id, r.checkup_date, r.recorded_at, COALESCE(NULLIF(r.vet,''), r.recorded_by), r.edited_by, r.pet_id, r.appt_id, 'Check-up', LEFT(COALESCE(NULLIF(r.diagnosis,''), NULLIF(r.findings,''), NULLIF(r.chief_complaint,''), r.details, ''),120), 'Completed', 'Check-Up' FROM checkups r
      UNION ALL SELECT 'confinement', r.id, r.admitted, r.recorded_at, r.recorded_by, r.edited_by, r.pet_id, r.appt_id, CONCAT(r.status, IF(r.outcome IS NULL,'',CONCAT(' (', r.outcome, ')'))), LEFT(COALESCE(r.reason,''),120), 'Completed', 'Confinement' FROM confinements r
      UNION ALL SELECT 'surgery', r.id, r.surgery_date, r.recorded_at, COALESCE(NULLIF(r.vet,''), r.recorded_by), r.edited_by, r.pet_id, r.appt_id, CONCAT(r.procedure_name, IF(r.outcome IS NULL,'',CONCAT(' (', r.outcome, ')'))), LEFT(COALESCE(r.findings,''),120), 'Completed', 'Surgery' FROM surgeries r
      UNION ALL SELECT 'pending', a.id, a.appt_date, NULL, a.vet, NULL, a.pet_id, a.id, a.service, 'Findings not recorded yet', 'Pending', a.service FROM appointments a WHERE a.status='Completed' AND a.record_done=0";
}
if ($p[0] === 'general' && !$post) {
    $pad = fn($t) => $t;
    if (count($p) === 3 && $p[1] === 'pet') {   // one pet's timeline
        $pet = q('SELECT x.*, c.name client, c.phone, c.id cid FROM pets x JOIN clients c ON c.id=x.client_id WHERE x.id=?', [(int)$p[2]])->fetch(); if (!$pet) send(['error' => 'Pet not found'], 404);
        $rows = q('SELECT u.* FROM (' . rec_union() . ') u WHERE u.pet_id=? ORDER BY u.vdate DESC, u.rid DESC LIMIT 300', [(int)$p[2]])->fetchAll();
        send(['pet' => $pet, 'rows' => $rows, 'balance' => client_balance((int)$pet['cid'])]);
    }
    $per = 12; $page = max(1, (int)($_GET['page'] ?? 1)); $off = ($page - 1) * $per;
    $s = trim($_GET['q'] ?? ''); $like = "%$s%"; $f = need_date($_GET['from'] ?? '', ''); $t = need_date($_GET['to'] ?? '', ''); $ty = $_GET['type'] ?? ''; $vet = $_GET['vet'] ?? '';
    $W = "(?='' OR x.name LIKE ? OR c.name LIKE ? OR c.phone LIKE ?) AND (?='' OR u.vdate>=?) AND (?='' OR u.vdate<=?) AND (?='' OR u.rtype=? OR (?='done' AND u.rtype<>'pending')) AND (?='' OR u.vet=?)";
    $a = [$s, $like, $like, $like, $f, $f, $t, $t, $ty, $ty, $ty, $vet, $vet];
    $base = 'FROM (' . rec_union() . ") u JOIN pets x ON x.id=u.pet_id JOIN clients c ON c.id=x.client_id WHERE $W";
    $total = (int)q("SELECT COUNT(*) $base", $a)->fetchColumn();
    $rows = q("SELECT u.*, x.name pet, x.species, c.id client_id, c.name client, c.phone $base ORDER BY u.vdate DESC, u.rid DESC LIMIT $per OFFSET $off", $a)->fetchAll();
    $pending = (int)q("SELECT COUNT(*) FROM appointments WHERE status='Completed' AND record_done=0")->fetchColumn();
    send(compact('rows', 'total', 'page', 'per', 'pending'));
}

// ---- product / medicine catalog (name and price only) ----
if ($p[0] === 'products') {
    $br = $me['branch'] ?: BRANCHES[0];
    $sel = 'SELECT p.id, p.name, p.price FROM products p';
    if (!$post) send(q("$sel WHERE p.active=1 AND p.name LIKE ? ORDER BY p.name LIMIT 30", ['%' . trim($_GET['q'] ?? '') . '%'])->fetchAll());
    $n = trim($in['name'] ?? ''); $pr = (float)($in['price'] ?? 0);
    if ($n === '') fail('Enter the product name.', 'name');
    if ($pr < 0) fail('The price cannot be negative.', 'price');
    q('INSERT INTO products(name,price) VALUES(?,?) ON DUPLICATE KEY UPDATE price=VALUES(price), active=1', [$n, $pr]);
    log_act((int)$me['id'], 'Saved a product', $n);
    send(q("$sel WHERE p.name=?", [$n])->fetch());
}
// ---- charge sheet: what was done and used for one patient. The vet fills it, the front desk only takes payment. ----
if ($p[0] === 'charge' && count($p) === 2 && ctype_digit($p[1])) {
    $id = (int)$p[1]; $a = appt_row('a.id=?', [$id]); if (!$a) fail('Appointment not found.', null, 404);
    $sale = q('SELECT * FROM sales WHERE appt_id=? ORDER BY id DESC LIMIT 1', [$id])->fetch() ?: null;
    if (!$sale) { if ($a['status'] === 'Cancelled') fail('This appointment was cancelled.'); if ($a['status'] !== 'Completed') $sale = bill_draft($id, $me); }
    if ($post) {
        if (!$sale) fail('There is no bill for this visit.');
        if (APP_ROLE === 'vet' && $sale['status'] !== 'Draft') fail('This bill was already sent to the front desk. Ask the front desk to change it.');
        if (APP_ROLE === 'vet' && $a['vet'] && $a['vet'] !== $me['name']) fail('This patient is with ' . $a['vet'] . '.', null, 403);
        $sum = bill_save((int)$sale['id'], is_array($in['items'] ?? null) ? $in['items'] : [], $me, APP_ROLE === 'staff');
        send(['ok' => 1, 'items' => bill_items((int)$sale['id'])] + $sum);
    }
    $owed = client_balance((int)$a['client_id']);
    $sum = $sale ? ['total' => (float)$sale['total'], 'paid' => (float)$sale['paid']] : ['total' => 0, 'paid' => 0];
    $locked = !$sale || in_array($sale['status'], ['Paid', 'Transferred'], true) || (APP_ROLE === 'vet' && $sale['status'] !== 'Draft');
    send(['appt' => $a, 'sale' => $sale, 'items' => $sale ? bill_items((int)$sale['id']) : [], 'payments' => $sale ? bill_payments((int)$sale['id']) : [], 'owes' => $owed, 'fees' => SERVICE_FEES, 'locked' => $locked, 'can_done' => $a['status'] !== 'Completed' && (bool)$a['checked_in_at']] + $sum);
}


// ---- Update 13: surgery room status, confined patients, the confinement charge sheet ----
if (!$post && $path === 'surgery/options') {   // for the "What happens next?" step: can surgery start right now, and who could operate
    $aid = (int)($_GET['appt_id'] ?? 0); $st = surgery_now_state($aid);
    $a = $aid ? appt_row('a.id=?', [$aid]) : null; $dec = $a ? $a['vet'] : null;
    $vets = $st['vets']; if ($dec && ($k = array_search($dec, $vets, true)) !== false) { array_splice($vets, $k, 1); array_unshift($vets, $dec); }   // the deciding vet is offered first
    send(['branch' => MAIN_BRANCH, 'from_main' => !$a || $a['branch'] === MAIN_BRANCH, 'now_ok' => (bool)$st['room'] && (bool)$vets && (!$a || $a['branch'] === MAIN_BRANCH), 'room' => $st['room'], 'why' => $st['why'], 'free_vets' => $vets,
        'on_duty' => $st['on_duty'], 'deciding_vet' => $dec, 'minutes' => svc_len('Surgery')]);
}
function conf_list_row(array $r, array $me): array {
    $c = conf_sync_bill((int)$r['id'], $me); $d = conf_days($c);
    $sale = $c['sale_id'] ? q('SELECT id, status, total, paid FROM sales WHERE id=?', [$c['sale_id']])->fetch() : null;
    return ['id' => (int)$c['id'], 'pet_id' => (int)$c['pet_id'], 'pet' => $c['pet'], 'species' => $c['species'], 'client' => $c['client'], 'client_id' => (int)$c['client_id'], 'phone' => $c['phone'], 'vet' => $c['vet'], 'reason' => $c['reason'],
        'admitted' => $c['admitted'], 'discharged' => $c['discharged'], 'status' => $c['status'], 'days' => $d['days'], 'days_auto' => $d['auto'], 'days_override' => $d['override'], 'rate' => (float)($c['daily_rate'] ?: CONFINEMENT_DAILY_RATE),
        'referred_from' => $c['referred_from'], 'arrived_at' => $c['arrived_at'], 'branch' => conf_branch($c), 'sale_id' => $sale ? (int)$sale['id'] : null, 'bill_status' => $sale['status'] ?? null, 'total' => $sale ? (float)$sale['total'] : 0.0];
}
if ($p[0] === 'confined') {
    $br = $me['branch'] ?: MAIN_BRANCH;
    if (!$post && count($p) === 1) {   // tab=now: patients staying with us; tab=past: recently discharged
        $past = ($_GET['tab'] ?? 'now') === 'past';
        $rows = q("SELECT c.id FROM confinements c WHERE c.status=? AND (COALESCE(c.branch,?)=? OR c.referred_from=?) ORDER BY " . ($past ? 'c.discharged DESC, c.id DESC LIMIT 30' : 'c.admitted, c.id LIMIT 100'), [$past ? 'Discharged' : 'Admitted', MAIN_BRANCH, $br, $br])->fetchAll();
        $list = array_map(fn($r) => conf_list_row($r, $me), $rows);
        send(['rows' => $list, 'branch' => $br, 'main' => MAIN_BRANCH, 'rate' => CONFINEMENT_DAILY_RATE]);
    }
    if ($post && count($p) === 3 && ctype_digit($p[1]) && $p[2] === 'arrived') {   // a patient referred from another branch has arrived (front desk of the main branch)
        if (APP_ROLE !== 'staff') fail('The front desk marks a referred patient as arrived.', null, 403);
        $c = conf_row((int)$p[1]); if (!$c) fail('Confinement not found.', null, 404);
        if (!$c['referred_from']) fail('This patient was not referred.');
        if (!$c['arrived_at']) {
            q('UPDATE confinements SET arrived_at=NOW() WHERE id=?', [$c['id']]);
            log_act((int)$me['id'], 'Marked a referred patient as arrived', $c['pet'] . ' (' . $c['client'] . ') from ' . $c['referred_from']);
            notify_vet($c['vet'], 'checkin', 'Referred patient arrived', $c['pet'] . ' has arrived at ' . MAIN_BRANCH . '.', 'confined.php', (int)$me['id']);
            notify_role('vet', MAIN_BRANCH, 'checkin', 'Referred patient arrived', $c['pet'] . ' (' . $c['client'] . ') from ' . $c['referred_from'] . ' is here.', 'confined.php', (int)$me['id']);
        }
        send(['ok' => 1]);
    }
    if ($post && count($p) === 3 && ctype_digit($p[1]) && $p[2] === 'days') {   // overwrite the number of days (or null = count automatically again); logged
        $c = conf_row((int)$p[1]); if (!$c) fail('Confinement not found.', null, 404);
        if ($c['status'] !== 'Admitted') fail('The days are final after discharge. The front desk can change the bill.');
        $v = $in['days'] ?? null; $new = ($v === null || $v === '') ? null : (int)$v;
        if ($new !== null && ($new < 1 || $new > 365)) fail('Enter a number of days from 1 to 365.', 'days');
        $old = conf_days($c);
        q('UPDATE confinements SET days_override=? WHERE id=?', [$new, $c['id']]);
        $c2 = conf_sync_bill((int)$c['id'], $me); $d = conf_days($c2);
        log_act((int)$me['id'], 'Changed the confinement days', $c['pet'] . ' (' . $c['client'] . '): ' . $old['days'] . ' to ' . $d['days'] . ($new === null ? ' (automatic count)' : ' (typed in)'));
        send(['ok' => 1, 'days' => $d['days']]);
    }
    if ($post && count($p) === 3 && ctype_digit($p[1]) && $p[2] === 'discharge') {
        if (APP_ROLE !== 'vet') fail('The veterinarian discharges the patient. The front desk then collects payment.', null, 403);
        send(conf_discharge((int)$p[1], $me, nul($in['followup_date'] ?? null), nul($in['outcome'] ?? null)));
    }
}
if ($p[0] === 'charge' && count($p) === 3 && $p[1] === 'conf' && ctype_digit($p[2])) {   // the running charge sheet of a confinement
    $c = conf_row((int)$p[2]); if (!$c) fail('Confinement not found.', null, 404);
    $c = conf_sync_bill((int)$c['id'], $me); $sale = q('SELECT * FROM sales WHERE id=?', [$c['sale_id']])->fetch();
    if ($post) {
        if (APP_ROLE === 'vet' && $sale['status'] !== 'Draft') fail('This bill was already sent to the front desk. Ask the front desk to change it.');
        $sum = bill_save((int)$sale['id'], is_array($in['items'] ?? null) ? $in['items'] : [], $me, APP_ROLE === 'staff');
        $c = conf_sync_bill((int)$c['id'], $me);   // the daily line always follows the day count
        send(['ok' => 1, 'items' => bill_items((int)$sale['id'])] + $sum);
    }
    $sale = q('SELECT * FROM sales WHERE id=?', [$c['sale_id']])->fetch(); $d = conf_days($c);
    $owed = client_balance((int)$c['client_id']);
    $a = ['id' => null, 'pet' => $c['pet'], 'species' => $c['species'], 'client' => $c['client'], 'phone' => $c['phone'], 'service' => 'Confinement', 'room' => null, 'vet' => $c['vet'], 'severity' => null,
        'status' => $c['status'] === 'Admitted' ? 'Admitted' : 'Completed', 'pet_id' => (int)$c['pet_id'], 'appt_date' => $c['admitted'], 'record_done' => 1, 'called_at' => null, 'started_at' => null, 'branch' => conf_branch($c)];
    $locked = $sale['status'] === 'Paid' || (APP_ROLE === 'vet' && $sale['status'] !== 'Draft');
    send(['appt' => $a, 'conf' => ['id' => (int)$c['id'], 'status' => $c['status'], 'days' => $d['days'], 'auto' => $d['auto'], 'override' => $d['override'], 'rate_item_id' => (int)$c['rate_item_id'], 'admitted' => $c['admitted'], 'discharged' => $c['discharged'],
        'referred_from' => $c['referred_from'], 'arrived' => (bool)$c['arrived_at'], 'reason' => $c['reason']],
        'sale' => $sale, 'items' => bill_items((int)$sale['id']), 'payments' => bill_payments((int)$sale['id']), 'owes' => $owed, 'fees' => SERVICE_FEES, 'locked' => $locked, 'can_done' => false, 'total' => (float)$sale['total'], 'paid' => (float)$sale['paid']]);
}

// ---- billing: bills ready for payment, payments, checks, balances (front desk) ----
if (in_array($p[0], ['bills', 'checks', 'balances', 'receipt'], true) && APP_ROLE !== 'staff') fail('Billing is handled by the front desk.', null, 403);
const BILL_SEL = "SELECT s.id, s.sale_date, s.total, s.paid, s.status, s.ready_at, s.prepared_by, s.desk_changed, s.branch, s.appt_id, c.id client_id, c.name client, c.phone, p.name pet, p.species,
    COALESCE((SELECT a.service FROM appointments a WHERE a.id=s.appt_id), s.service) service,
    (SELECT GROUP_CONCAT(i.item SEPARATOR ', ') FROM sale_items i WHERE i.sale_id=s.id) items,
    (SELECT COALESCE(SUM(s2.total-s2.paid),0) FROM sales s2 WHERE s2.client_id=s.client_id AND s2.status IN ('Unpaid','Partially paid')) client_owes
    FROM sales s LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN pets p ON p.id=s.pet_id";
if ($p[0] === 'bills') {
    if (!$post && count($p) === 1) {   // tab=ready: unpaid bills of this branch, oldest first. tab=history: everything.
        $tab = $_GET['tab'] ?? 'ready'; $br = $me['branch'] ?: BRANCHES[0]; $s = trim($_GET['q'] ?? ''); $like = "%$s%";
        $page = max(1, (int)($_GET['page'] ?? 1)); $per = 12; $off = ($page - 1) * $per;
        $W = $tab === 'ready' ? "s.status IN ('Unpaid','Partially paid') AND (s.branch=? OR ?=1)" : "s.status<>'Draft' AND (s.branch=? OR ?=1)";
        $a = [$br, $tab === 'history' && !empty($_GET['all']) ? 1 : 0];
        $W .= " AND (?='' OR c.name LIKE ? OR p.name LIKE ? OR s.id=?)"; array_push($a, $s, $like, $like, (int)ltrim($s, '#'));
        $total = (int)q("SELECT COUNT(*) FROM sales s LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN pets p ON p.id=s.pet_id WHERE $W", $a)->fetchColumn();
        $rows = q(BILL_SEL . " WHERE $W ORDER BY " . ($tab === 'ready' ? 's.ready_at, s.id' : 's.id DESC') . " LIMIT $per OFFSET $off", $a)->fetchAll();
        $ready = (int)q("SELECT COUNT(*) FROM sales WHERE status IN ('Unpaid','Partially paid') AND branch=?", [$br])->fetchColumn();
        $checks = (int)q("SELECT COUNT(*) FROM sale_payments p JOIN sales s ON s.id=p.sale_id WHERE p.method='Check' AND p.check_status='Pending clearing' AND s.branch=?", [$br])->fetchColumn();
        $owing = r2(q("SELECT COALESCE(SUM(total-paid),0) FROM sales WHERE status IN ('Unpaid','Partially paid')")->fetchColumn());
        send(compact('rows', 'total', 'page', 'per', 'ready', 'checks', 'owing'));
    }
    if (!$post && count($p) === 2 && ctype_digit($p[1])) {   // one bill with its items, payments and the client's other unpaid bills
        $b = q(BILL_SEL . ' WHERE s.id=?', [$p[1]])->fetch(); if (!$b) fail('Bill not found.', null, 404);
        $b['items'] = bill_items((int)$p[1]); $b['payments'] = bill_payments((int)$p[1]);
        $b['others'] = $b['client_id'] ? q("SELECT s.id, s.sale_date, s.total, s.paid, s.total-s.paid balance, (SELECT GROUP_CONCAT(i.item SEPARATOR ', ') FROM sale_items i WHERE i.sale_id=s.id) items FROM sales s WHERE s.client_id=? AND s.id<>? AND s.status IN ('Unpaid','Partially paid') ORDER BY s.sale_date, s.id", [$b['client_id'], $p[1]])->fetchAll() : [];
        $b['methods'] = PAY_METHODS; send($b);
    }
    if ($post && $path === 'bills/pay') {   // ids = the bill(s) being paid (the current bill, plus old balances if the customer chooses), lines = payment lines (split payment)
        $r = bill_pay(is_array($in['ids'] ?? null) ? $in['ids'] : [], is_array($in['lines'] ?? null) ? $in['lines'] : [], $me);
        send($r);
    }
    if ($post && count($p) === 3 && $p[1] === 'check' && ctype_digit($p[2])) { bill_check_status((int)$p[2], (string)($in['status'] ?? ''), $me); send(['ok' => 1]); }
    if (!$post && $path === 'bills/checks') {   // check payments and where they stand
        $st = $_GET['status'] ?? '';
        send(q("SELECT p.id, p.sale_id, p.amount, p.bank, p.check_no, p.check_date, p.check_status, p.created_at, p.taken_by, c.name client, s.branch FROM sale_payments p JOIN sales s ON s.id=p.sale_id LEFT JOIN clients c ON c.id=s.client_id
            WHERE p.method='Check' AND (?='' OR p.check_status=?) ORDER BY (p.check_status='Pending clearing') DESC, p.check_date, p.id DESC LIMIT 200", [$st, $st])->fetchAll());
    }
}
// ---- receipts: for one payment event (group) or for a whole bill ----
if ($p[0] === 'receipt' && !$post) {
    $g = preg_replace('/[^a-z0-9]/i', '', (string)($_GET['group'] ?? '')); $bid = (int)($_GET['id'] ?? 0);
    $pays = $g !== '' ? q('SELECT * FROM sale_payments WHERE pay_group=? ORDER BY id', [$g])->fetchAll() : ($bid ? q('SELECT * FROM sale_payments WHERE sale_id=? ORDER BY id', [$bid])->fetchAll() : []);
    $ids = $g !== '' ? array_values(array_unique(array_map('intval', array_column($pays, 'sale_id')))) : ($bid ? [$bid] : []);
    if (!$ids) fail('Receipt not found.', null, 404);
    $bills = []; foreach ($ids as $i) { $b = q(BILL_SEL . ' WHERE s.id=?', [$i])->fetch(); if ($b) { $b['items'] = bill_items($i); $b['balance'] = max(0, r2($b['total'] - $b['paid'])); $bills[] = $b; } }
    $cl = $bills ? $bills[0]['client_id'] : null;
    send(['bills' => $bills, 'payments' => $pays, 'client_balance' => $cl ? client_balance((int)$cl) : 0, 'branch' => $bills[0]['branch'] ?? null, 'taken_by' => $pays ? end($pays)['taken_by'] : null, 'at' => $pays ? end($pays)['created_at'] : null, 'group' => $g]);
}
// ---- customer balances: who owes the clinic, how much, how old ----
if ($p[0] === 'balances' && !$post) {
    if (count($p) === 2 && ctype_digit($p[1])) {   // statement of account for one client
        $c = q('SELECT id, name, phone, email, address FROM clients WHERE id=?', [$p[1]])->fetch(); if (!$c) fail('Client not found.', null, 404);
        $bills = q("SELECT s.id, s.sale_date, s.total, s.paid, s.status, s.branch, DATEDIFF(CURDATE(), s.sale_date) age, (SELECT GROUP_CONCAT(i.item SEPARATOR ', ') FROM sale_items i WHERE i.sale_id=s.id) items, p.name pet, p.species
            FROM sales s LEFT JOIN pets p ON p.id=s.pet_id WHERE s.client_id=? AND s.status IN ('Unpaid','Partially paid') ORDER BY s.sale_date, s.id", [$p[1]])->fetchAll();
        $recent = q("SELECT p.created_at, p.method, p.amount, p.sale_id, p.check_status FROM sale_payments p JOIN sales s ON s.id=p.sale_id WHERE s.client_id=? ORDER BY p.id DESC LIMIT 15", [$p[1]])->fetchAll();
        send(['client' => $c, 'bills' => $bills, 'payments' => $recent, 'balance' => client_balance((int)$c['id']), 'printed' => date('Y-m-d H:i')]);
    }
    $s = trim($_GET['q'] ?? ''); $like = "%$s%"; $age = $_GET['age'] ?? '';
    $rows = q("SELECT c.id, c.name, c.phone, SUM(s.total-s.paid) owed, COUNT(*) bills, MIN(s.sale_date) oldest, DATEDIFF(CURDATE(), MIN(s.sale_date)) age
        FROM sales s JOIN clients c ON c.id=s.client_id WHERE s.status IN ('Unpaid','Partially paid') AND (?='' OR c.name LIKE ? OR c.phone LIKE ?) GROUP BY c.id, c.name, c.phone HAVING owed > 0.004 ORDER BY oldest, c.name", [$s, $like, $like])->fetchAll();
    $bk = ['a' => 0.0, 'b' => 0.0, 'c' => 0.0];
    foreach (q("SELECT DATEDIFF(CURDATE(), sale_date) age, total-paid bal FROM sales WHERE status IN ('Unpaid','Partially paid')")->fetchAll() as $r) $bk[$r['age'] <= 30 ? 'a' : ($r['age'] <= 60 ? 'b' : 'c')] += (float)$r['bal'];
    if ($age !== '') $rows = array_values(array_filter($rows, fn($r) => $age === 'a' ? $r['age'] <= 30 : ($age === 'b' ? $r['age'] > 30 && $r['age'] <= 60 : $r['age'] > 60)));
    send(['rows' => $rows, 'total' => r2(array_sum(array_column($rows, 'owed'))), 'buckets' => array_map('r2', $bk)]);
}

// ---- sales at the desk (no visit): becomes a bill, then is paid on the payment screen ----
// ---- end-of-shift daily sheet: what was sold, what was collected and who was scheduled on one day (the secretary prints it) ----
if ($p[0] === 'daily' && !$post) {
    if (APP_ROLE !== 'staff') fail('The daily sheet is for the front desk.', null, 403);
    $d = need_date($_GET['date'] ?? '', date('Y-m-d')); $br = $me['branch'] ?: BRANCHES[0];
    $bills = q("SELECT s.id, s.status, s.total, s.paid, s.transferred_to, c.name client, p.name pet, p.species,
        COALESCE((SELECT a.service FROM appointments a WHERE a.id=s.appt_id), s.service, 'Sale') service,
        (SELECT GROUP_CONCAT(CONCAT(i.item, IF(i.qty>1, CONCAT(' x', i.qty), '')) SEPARATOR ', ') FROM sale_items i WHERE i.sale_id=s.id) items
        FROM sales s LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN pets p ON p.id=s.pet_id WHERE s.sale_date=? AND s.branch=? AND s.status<>'Draft' ORDER BY s.id", [$d, $br])->fetchAll();
    $pays = q("SELECT sp.sale_id, sp.method, sp.amount, sp.check_status, sp.taken_by, TIME_FORMAT(sp.created_at,'%H:%i') t, c.name client, p.name pet
        FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN pets p ON p.id=s.pet_id
        WHERE DATE(sp.created_at)=? AND s.branch=? AND NOT (sp.method='Check' AND sp.check_status='Bounced') ORDER BY sp.created_at, sp.id", [$d, $br])->fetchAll();
    $sched = q("SELECT a.service, a.is_queue, a.queue_no, a.status, a.vet, a.reason, TIME_FORMAT(a.appt_time,'%H:%i') t, TIME_FORMAT(a.checked_in_at,'%H:%i') arrived, p.name pet, c.name client
        FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id WHERE a.appt_date=? AND a.branch=? AND a.status<>'Cancelled'
        ORDER BY a.is_queue, COALESCE(a.queue_no, 0), a.appt_time, a.id", [$d, $br])->fetchAll();
    $by = []; foreach ($pays as $x) $by[$x['method']] = r2(($by[$x['method']] ?? 0) + $x['amount']);
    $count = array_values(array_filter($bills, fn($b) => $b['status'] !== 'Transferred'));
    send(['date' => $d, 'branch' => $br, 'bills' => $bills, 'payments' => $pays, 'scheduled' => $sched, 'by_method' => (object)$by, 'online_methods' => ONLINE_PAY_METHODS,
          'sold' => r2(array_sum(array_map(fn($b) => (float)$b['total'], $count))), 'collected' => r2(array_sum(array_map(fn($x) => (float)$x['amount'], $pays))),
          'unpaid' => r2(array_sum(array_map(fn($b) => max(0, (float)$b['total'] - (float)$b['paid']), array_filter($count, fn($b) => in_array($b['status'], ['Unpaid', 'Partially paid'], true))))),
          'prepared_by' => $me['name'], 'printed' => date('M j, Y g:i A')]);
}
if ($p[0] === 'sales' && APP_ROLE !== 'staff') fail('Sales is only available to staff accounts.', null, 403);
if ($p[0] === 'sales' && ($p[1] ?? '') === 'summary' && !$post) { [$f, $t2, $b] = sales_range($_GET); send(sales_summary($f, $t2, $b)); }
if ($p[0] === 'sales' && count($p) === 2 && !$post) {
    $s = q('SELECT s.*, c.name client, p.name pet FROM sales s LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN pets p ON p.id=s.pet_id WHERE s.id=?', [$p[1]])->fetch();
    if (!$s) send(['error' => 'Sale not found'], 404);
    $s['items'] = bill_items((int)$p[1]); $s['payments'] = bill_payments((int)$p[1]); $s['balance'] = max(0, r2($s['total'] - $s['paid'])); send($s);
}
if ($p[0] === 'sales') {
    if (!$post) send(sales_list($_GET));
    $items = is_array($in['items'] ?? null) ? $in['items'] : [];
    if (empty($in['date'])) fail('Choose the date');
    $sid = bill_create((int)($in['client_id'] ?? 0) ?: null, (int)($in['pet_id'] ?? 0) ?: null, $items, $me['branch'] ?: BRANCHES[0], $me, $in['date']);
    send(['id' => $sid]);
}

// ---- pet profile popup + documents (birth certificate etc.) ----
if ($p[0] === 'pets' && count($p) === 3 && $p[2] === 'profile' && !$post) {
    $pet = q('SELECT x.* FROM pets x WHERE x.id=?', [$p[1]])->fetch(); if (!$pet) send(['error' => 'Pet not found'], 404);
    $cl = q('SELECT id, name, phone, email FROM clients WHERE id=?', [$pet['client_id']])->fetch(); $cl['balance'] = client_balance((int)$cl['id']);
    $get = fn($t, $o, $n) => q("SELECT * FROM $t WHERE pet_id=? ORDER BY $o DESC, id DESC LIMIT $n", [$p[1]])->fetchAll();
    send(['pet' => $pet, 'client' => $cl, 'missing' => array_values(array_filter([empty($pet['breed']) ? 'breed' : null, empty($pet['sex']) ? 'sex' : null, empty($pet['birthdate']) ? 'birthdate' : null])),
        'documents' => q('SELECT id, doc_type, name, mime, uploaded_by, created_at FROM pet_documents WHERE pet_id=? ORDER BY id DESC', [$p[1]])->fetchAll(),
        'vaccination' => $get('vaccinations', 'vac_date', 3), 'checkup' => $get('checkups', 'checkup_date', 3),
        'confined' => (bool)q("SELECT 1 FROM confinements WHERE pet_id=? AND status='Admitted'", [$p[1]])->fetch(),
        'next_appt' => q("SELECT appt_date, TIME_FORMAT(appt_time,'%H:%i') time, service FROM appointments WHERE pet_id=? AND appt_date>=CURDATE() AND status IN ('Pending','Confirmed') ORDER BY appt_date, appt_time LIMIT 1", [$p[1]])->fetch() ?: null]);
}
if ($p[0] === 'pets' && count($p) === 3 && $p[2] === 'documents' && $post) {
    $pet = q('SELECT id FROM pets WHERE id=?', [$p[1]])->fetch(); if (!$pet) fail('Pet not found.', null, 404);
    $mime = $in['mime'] ?? ''; $data = (string)($in['data'] ?? ''); $type = in_array($in['doc_type'] ?? '', ['Birth certificate', 'Vaccination card', 'Medical history', 'Pedigree / registration', 'Other']) ? $in['doc_type'] : 'Other';
    if (!in_array($mime, ['image/jpeg', 'application/pdf'], true) || strpos($data, "data:$mime;base64,") !== 0) fail('Please upload a photo (JPG/PNG) or a PDF.');
    if (strlen($data) > 3500000) fail('That file is too large (limit about 2.5 MB).');
    if (base64_decode(substr($data, strlen("data:$mime;base64,")), true) === false) fail('That file could not be read.');
    q('INSERT INTO pet_documents(pet_id,doc_type,name,mime,data,uploaded_by) VALUES(?,?,?,?,?,?)', [$p[1], $type, substr(trim($in['name'] ?? 'document'), 0, 150), $mime, $data, $me['name']]);
    log_act((int)$me['id'], 'Uploaded a pet document', pet_label((int)$p[1]) . ': ' . $type); send(['ok' => 1]);
}
if ($p[0] === 'pets' && count($p) === 4 && $p[2] === 'documents' && !$post) {
    $d = q('SELECT id, doc_type, name, mime, data FROM pet_documents WHERE id=? AND pet_id=?', [(int)$p[3], $p[1]])->fetch();
    $d ? send($d) : send(['error' => 'Document not found'], 404);
}

// ---- pets ----
function addPet($cid, array $b) {
    q('INSERT INTO pets(client_id,name,species,breed,sex,birthdate) VALUES(?,?,?,?,?,?)', [$cid, trim($b['name']), $b['species'] ?? null, $b['breed'] ?? null, $b['sex'] ?? null, nul($b['birthdate'] ?? null)]);
}
if ($p[0] === 'pets' && count($p) === 2) {
    if (!$post) {
        $pet = q('SELECT x.*, c.name client FROM pets x JOIN clients c ON c.id=x.client_id WHERE x.id=?', [$p[1]])->fetch();
        if (!$pet) send(['error' => 'Pet not found'], 404);
        $pet['confined'] = (bool)q("SELECT 1 FROM confinements WHERE pet_id=? AND status='Admitted'", [$p[1]])->fetch();
        send($pet);
    }
    if (!trim($in['name'] ?? '')) fail('Pet name is required');
    log_act((int)$me['id'], 'Updated a pet', trim($in['name']));
    q('UPDATE pets SET name=?,species=?,breed=?,sex=?,birthdate=? WHERE id=?', [trim($in['name']), $in['species'] ?? null, $in['breed'] ?? null, $in['sex'] ?? null, nul($in['birthdate'] ?? null), $p[1]]);
    send(['ok' => 1]);
}

// ---- clients ----
function check_account(string $email, string $user, string $pw): void {
    $email = strtolower(trim($email)); $user = trim($user);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('A valid email address is needed to create a portal account (sign-in codes are emailed).', 'email');
    if (!preg_match('/^[A-Za-z0-9._-]{3,30}$/', $user)) fail('Username must be 3-30 characters: letters, numbers, dots, dashes or underscores.', 'acct_username');
    if (strlen($pw) < 8) fail('The temporary password needs at least 8 characters.', 'acct_password');
    if (q('SELECT 1 FROM accounts WHERE LOWER(username)=?', [strtolower($user)])->fetch()) fail('That username is already taken.', 'acct_username');
    if (q("SELECT 1 FROM accounts WHERE role='client' AND LOWER(email)=?", [$email])->fetch()) fail('A portal account with that email already exists.', 'email');
}
function new_account(int $cid, string $name, string $email, string $user, string $pw, ?string $branch): void {
    q("INSERT INTO accounts(role,name,email,username,password,branch,client_id,must_change) VALUES('client',?,?,?,?,?,?,1)",
      [$name, strtolower(trim($email)), trim($user), password_hash($pw, PASSWORD_DEFAULT), $branch, $cid]);
    log_act((int)db()->lastInsertId(), 'Account created');
}
if ($p[0] === 'clients') {
    if (count($p) === 1 && !$post) {
        $like = '%' . ($_GET['q'] ?? '') . '%'; $per = min(max((int)($_GET['per'] ?? 8), 1), 500); $page = max((int)($_GET['page'] ?? 1), 1); $off = ($page - 1) * $per;
        $w = 'c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR EXISTS(SELECT 1 FROM pets x WHERE x.client_id=c.id AND x.name LIKE ?)'; $a = [$like, $like, $like, $like];
        $total = (int)q("SELECT COUNT(*) FROM clients c WHERE $w", $a)->fetchColumn();
        $rows = q("SELECT c.id,c.name,c.phone,c.email,
            (SELECT COUNT(*) FROM pets WHERE client_id=c.id) npets, (SELECT COALESCE(SUM(s.total-s.paid),0) FROM sales s WHERE s.client_id=c.id AND s.status IN ('Unpaid','Partially paid')) balance, (SELECT GROUP_CONCAT(name SEPARATOR ', ') FROM pets WHERE client_id=c.id) pets, (SELECT GROUP_CONCAT(CONCAT(COALESCE(species,''), '~', name) ORDER BY id SEPARATOR '|') FROM pets WHERE client_id=c.id) pet_pairs,
            (SELECT MAX(a.appt_date) FROM appointments a JOIN pets x ON x.id=a.pet_id WHERE x.client_id=c.id AND a.appt_date<=CURDATE()) last_visit
            FROM clients c WHERE $w ORDER BY c.name LIMIT $per OFFSET $off", $a)->fetchAll();
        send(compact('rows', 'total', 'page', 'per'));
    }
    if (count($p) === 1 && $post) {
        if (!trim($in['name'] ?? '') || !trim($in['phone'] ?? '')) fail('Name and contact number are required');
        $mk = !empty($in['create_account']);
        if ($mk) check_account((string)($in['email'] ?? ''), (string)($in['acct_username'] ?? ''), (string)($in['acct_password'] ?? ''));
        q('INSERT INTO clients(name,address,email,phone,branch) VALUES(?,?,?,?,?)', [trim($in['name']), $in['address'] ?? null, $in['email'] ?? null, trim($in['phone']), $me['branch'] ?? null]);
        $cid = (int)db()->lastInsertId();
        if ($mk) new_account($cid, trim($in['name']), (string)$in['email'], (string)$in['acct_username'], (string)$in['acct_password'], $me['branch']);
        log_act((int)$me['id'], 'Registered a client', trim($in['name']));
        if ($mk) log_act((int)$me['id'], 'Created a portal account', trim($in['name']));
        send(['id' => $cid]);
    }
    if (count($p) === 2 && !$post) {
        $c = q('SELECT * FROM clients WHERE id=?', [$p[1]])->fetch();
        if (!$c) send(['error' => 'Client not found'], 404);
        $c['pets'] = q('SELECT * FROM pets WHERE client_id=? ORDER BY name', [$p[1]])->fetchAll();
        $c['balance'] = client_balance((int)$p[1]);
        $c['account'] = q("SELECT status FROM accounts WHERE client_id=? AND role='client' LIMIT 1", [$p[1]])->fetch() ?: null;
        $c['records'] = q("(SELECT v.vac_date AS `date`, x.name pet, 'Vaccination' service, v.vaccine notes, v.id rid, 'vaccination' rtype FROM vaccinations v JOIN pets x ON x.id=v.pet_id WHERE x.client_id=?)
            UNION ALL (SELECT k.checkup_date, x.name, 'Check-Up', LEFT(k.details,60), k.id, 'checkup' FROM checkups k JOIN pets x ON x.id=k.pet_id WHERE x.client_id=?)
            UNION ALL (SELECT f.admitted, x.name, 'Confinement', f.reason, f.id, 'confinement' FROM confinements f JOIN pets x ON x.id=f.pet_id WHERE x.client_id=?)
            UNION ALL (SELECT s.surgery_date, x.name, 'Surgery', s.procedure_name, s.id, 'surgery' FROM surgeries s JOIN pets x ON x.id=s.pet_id WHERE x.client_id=?)
            ORDER BY `date` DESC LIMIT 10", [$p[1], $p[1], $p[1], $p[1]])->fetchAll();
        send($c);
    }
    if (count($p) === 2 && $post) {
        if (!trim($in['name'] ?? '') || !trim($in['phone'] ?? '')) fail('Name and contact number are required');
        q('UPDATE clients SET name=?,address=?,email=?,phone=? WHERE id=?', [trim($in['name']), $in['address'] ?? null, $in['email'] ?? null, trim($in['phone']), $p[1]]);
        log_act((int)$me['id'], 'Updated a client', trim($in['name']));
        $em = strtolower(trim($in['email'] ?? ''));   // keep the portal account in step with the client record
        if (filter_var($em, FILTER_VALIDATE_EMAIL)) {
            try { q("UPDATE accounts SET name=?, email=? WHERE client_id=? AND role='client'", [trim($in['name']), $em, $p[1]]); }
            catch (PDOException $e) { fail('That email is already used by another portal account.', 'email'); }
        }
        send(['ok' => 1]);
    }
    if (count($p) === 3 && $p[2] === 'account' && $post) {   // portal account for an existing client
        $c = q('SELECT * FROM clients WHERE id=?', [$p[1]])->fetch();
        if (!$c) fail('Client not found');
        if (q("SELECT 1 FROM accounts WHERE client_id=? AND role='client'", [$p[1]])->fetch()) fail('This client already has a portal account.');
        check_account((string)$c['email'], (string)($in['username'] ?? ''), (string)($in['password'] ?? ''));
        new_account((int)$c['id'], $c['name'], (string)$c['email'], (string)$in['username'], (string)$in['password'], $me['branch']);
        log_act((int)$me['id'], 'Created a portal account', $c['name']);
        send(['ok' => 1]);
    }
    if (count($p) === 3 && $p[2] === 'pets' && $post) {
        if (!trim($in['name'] ?? '')) fail('Pet name is required');
        addPet((int)$p[1], $in); log_act((int)$me['id'], 'Added a pet', trim($in['name'])); send(['ok' => 1]);
    }
}
send(['error' => 'Not found'], 404);

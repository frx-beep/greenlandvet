<?php require 'layout.php'; top('Appointments', 'a', 'Appointment Management'); ?>
<div class="toolbar">
  <input type="date" id="d" style="width:14rem">
  <select id="b" style="width:12rem"><option value="">All branches</option><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select>
  <select id="s" style="width:12rem"><option value="">All statuses</option><option>Pending</option><option>Confirmed</option><option>Completed</option><option>Cancelled</option></select>
  <label class="inl" id="mineL" hidden><input type="checkbox" id="mine" checked style="width:auto"> Only my patients</label><span class="sp"></span><a class="btn" href="appt_new.php">+ New Appointment</a>
</div>
<div class="card"><table><thead><tr><th>Time</th><th>Client</th><th>Pet</th><th>Service</th><th>Vet</th><th>Branch</th><th>Status</th><th></th></tr></thead><tbody id="rows"></tbody></table>
  <div class="pager"><span id="info"></span><div id="pages"></div></div></div>
<script>
$('#d').value = param('date') || today(); if (ROLE === 'vet') $('#mineL').hidden = false; let rows = [], page = 1;
async function load() {
  const r = await api(`/api/appointments/day?paged=1&page=${page}&date=${$('#d').value}&branch=${$('#b').value}&status=${$('#s').value}&mine=${ROLE === 'vet' && $('#mine').checked ? 1 : 0}`); rows = r.rows;
  $('#rows').innerHTML = rows.length ? rows.map((a, i) => `<tr><td>${+a.is_queue ? 'Any time' + (a.queue_no ? '<br><small class="muted">queue #' + a.queue_no + '</small>' : '') : fmtTime(a.time)}</td><td><a class="link" href="client.php?id=${a.client_id}">${E(a.client)}</a></td><td>${E(a.pet)}</td>
    <td>${E(a.service)}</td><td>${E(a.vet || '-')}</td><td>${E(a.branch || '-')}</td><td>${badge(a.status)}${a.source === 'Online' ? ' <span class="badge g">Online</span>' : a.source === 'Walk-in' ? ' <span class="badge g">Walk-in</span>' : ''}${a.referred_from ? ` <span class="tag">Referred from ${E(a.referred_from)}</span>` : ''}${a.group_token ? ' <span class="badge g">Multi</span>' : ''}${a.checked_in_at ? ' <span class="badge">Arrived' + (a.room ? ', ' + E(a.room) : '') + '</span>' : ''}</td><td><button class="btn ghost sm" data-m="${i}">Manage</button></td></tr>`).join('')
    : '<tr><td colspan="8" class="empty">No appointments match these filters.</td></tr>';
  $$('[data-m]').forEach(b => b.onclick = () => manageAppt(rows[b.dataset.m], $('#d').value, load));
  pager(r, page, n => { page = n; load(); }, $('#info'), $('#pages'));
}
['d', 'b', 's', 'mine'].forEach(i => $('#' + i).onchange = () => { page = 1; load(); });
load();
</script>
<?php bottom(); ?>

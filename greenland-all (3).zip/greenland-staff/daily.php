<?php require 'layout.php'; top('Daily Sales Sheet', 'l', 'Sales > Daily sheet'); ?>
<div class="toolbar noprint"><label style="display:flex;gap:.5rem;align-items:center;margin:0">Date <input type="date" id="d" style="width:13rem"></label><span style="flex:1"></span>
  <button class="btn" onclick="window.print()">Print daily sheet</button><a class="btn plain" href="sales.php">Back to Sales</a></div>
<div class="receipt card wide" id="ds"><p class="muted">Loading...</p></div>
<script>
async function load() {
  const d = $('#d').value;
  try {
    const r = await api('/api/daily?date=' + encodeURIComponent(d));
    const rowsB = r.bills.map(b => `<tr><td>#${b.id}</td><td>${E(b.client || 'Walk-in')}${b.pet ? '<br><small class="muted">' + E(b.pet) + '</small>' : ''}</td><td>${E(b.service || '')}</td><td>${clip(b.items, 60)}</td><td class="r">${peso(b.total)}</td><td class="r">${peso(b.paid)}</td><td>${b.status === 'Transferred' ? 'Added to bill #' + b.transferred_to : E(b.status)}</td></tr>`).join('');
    const methods = Object.keys(r.by_method).length ? Object.entries(r.by_method).map(([m, v]) => `<tr><td>${E(m)}</td><td class="r">${peso(v)}</td></tr>`).join('') : '<tr><td colspan="2" class="muted">No payments taken.</td></tr>';
    const onl = Object.entries(r.by_method).filter(([m]) => (r.online_methods || []).includes(m)).reduce((a, [, v]) => a + v, 0), inClinic = r.collected - onl;
    const split = `<tr><td><b>Online payments (${E((r.online_methods || []).join(', '))})</b></td><td class="r"><b>${peso(onl)}</b></td></tr><tr><td><b>In the clinic (cash, card, checks)</b></td><td class="r"><b>${peso(inClinic)}</b></td></tr>`;
    const rowsP = r.payments.map(x => `<tr><td>${E(x.t)}</td><td>#${x.sale_id}</td><td>${E(x.client || 'Walk-in')}${x.pet ? ' &middot; ' + E(x.pet) : ''}</td><td>${E(x.method)}${x.method === 'Check' ? (x.check_status === 'Cleared' ? ' (cleared)' : ' (pending clearing)') : ''}</td><td>${E(x.taken_by || '')}</td><td class="r">${peso(x.amount)}</td></tr>`).join('');
    const rowsS = r.scheduled.map(a => `<tr><td>${a.is_queue == 1 ? (a.queue_no ? '#' + a.queue_no : 'Queue') : E(fmtTime(a.t))}</td><td>${E(a.client)}<br><small class="muted">${E(a.pet)}</small></td><td>${E(a.service)}</td><td>${E(a.vet || '-')}</td><td>${E(statusLabel(a.status))}${a.arrived ? '<br><small class="muted">arrived ' + E(fmtTime(a.arrived)) + '</small>' : ''}</td></tr>`).join('');
    $('#ds').innerHTML = `<div class="center"><h2 style="margin:0">Greenland Veterinary Clinic</h2><b>${E(r.branch)} Branch</b><h3 style="margin:.8rem 0 0">DAILY SALES SHEET</h3><p class="muted" style="margin:.2rem 0">${E(fmtDay(r.date))}</p></div>
      <dl class="rdl"><dt>Total billed</dt><dd><b>${peso(r.sold)}</b></dd><dt>Total collected</dt><dd><b>${peso(r.collected)}</b></dd><dt>Still unpaid (today's bills)</dt><dd>${peso(r.unpaid)}</dd></dl>
      <h4 style="margin:1rem 0 .3rem">Bills of the day</h4>
      <table><thead><tr><th>Bill</th><th>Owner / pet</th><th>Service</th><th>Items</th><th class="r">Total</th><th class="r">Paid</th><th>Status</th></tr></thead><tbody>${rowsB || '<tr><td colspan="7" class="empty">No bills this day.</td></tr>'}</tbody></table>
      <h4 style="margin:1rem 0 .3rem">Money collected, by payment method</h4>
      <table><tbody>${methods}${Object.keys(r.by_method).length ? split : ""}</tbody></table><div class="total"><b>TOTAL COLLECTED</b><b>${peso(r.collected)}</b></div>
      ${rowsP ? `<h4 style="margin:1rem 0 .3rem">Payment lines</h4><table><thead><tr><th>Time</th><th>Bill</th><th>Owner / pet</th><th>Method</th><th>Taken by</th><th class="r">Amount</th></tr></thead><tbody>${rowsP}</tbody></table>` : ''}
      <h4 style="margin:1rem 0 .3rem">Scheduled and seen today</h4>
      <table><thead><tr><th>Time / No.</th><th>Owner / pet</th><th>Service</th><th>Vet</th><th>Status</th></tr></thead><tbody>${rowsS || '<tr><td colspan="5" class="empty">Nobody was scheduled.</td></tr>'}</tbody></table>
      <p class="muted" style="margin-top:1rem"><small>Prepared by ${E(r.prepared_by)} &middot; printed ${E(r.printed)}. Check payments count after the check clears. Compare the collected amount with the cash and e-wallet on hand.</small></p>
      <div class="sigline"><span>Prepared by</span><span>Checked by</span></div>`;
  } catch (x) { $('#ds').innerHTML = `<p class="err">${E(x.message)}</p>`; }
}
$('#d').value = param('date') || today(); $('#d').onchange = load; load();
</script>
<?php bottom(); ?>

<?php
require 'layout.php';
$T = ['vaccination' => 'Vaccination Record', 'checkup' => 'Check-Up Record', 'confinement' => 'Confinement Record', 'surgery' => 'Surgery Record'];
$title = $T[$_GET['type'] ?? ''] ?? null;
if (!$title || APP_ROLE !== 'vet') { header('Location: general.php'); exit; }   // the front desk reads records in General Records; vets write them
top($title, 'g'); ?>
<div class="split">
  <div class="card"><h2 id="h"></h2><form id="f" class="form"></form></div>
  <div class="card"><h2 id="sideT"></h2><div id="side"></div></div>
</div>
<script>
const type = param('type'), S = SVC[type], rid = param('id');
let rec = {}, visit = null;
const multi = type === 'vaccination' && !rid;   // a new vaccination visit can hold several items (vaccine, deworming, tick and flea...), each with its own next schedule   // visit = the appointment this record belongs to (its date is the date shown on the record)
$('#crumb').textContent = `General Records > ${S.name} > ${rid ? 'Edit' : 'New'} Record`;
$('#h').textContent = `${rid ? 'Edit' : 'New'} ${S.form}`;
async function side() {
  const pid = $('#pet')?.value;
  $('#sideT').textContent = S.side + ($('#pet')?.selectedOptions[0]?.text && pid ? ' - ' + $('#pet').selectedOptions[0].text : '');
  renderTable($('#side'), S.pet.slice(0, S.sideN), pid ? await api(`/api/records/${type}?pet_id=${pid}`) : [], type);
}
// After a check-up: optional confinement/surgery popup, then back to the patient list
function flow(d) {
  const pet = d.pet_id;
  const bill = () => location = 'index.php';
  const step = d.next_step;
  if (step === 'Surgery') {   // plan the surgery now: shows which days a surgery-capable vet is free
    return surgeryDialog({ pet_id: pet, label: $('#pet').selectedOptions[0].text, branch: ME_BRANCH, reason: (d.diagnosis || d.chief_complaint || d.findings || d.details || '').slice(0, 80), skipLabel: 'Skip for now', done: bill });
  }
  if (step !== 'Confinement') return bill();
  const t = step.toLowerCase(), S2 = SVC[t];
  const defaults = { admitted: today(), status: 'Admitted', reason: (d.diagnosis || d.chief_complaint || d.details || '').slice(0, 120) };
  const dlg = dialog(`<h3>${S2.form}</h3><p class="muted" style="margin:0">Pet: ${E($('#pet').selectedOptions[0].text)}</p>${fieldsHTML(S2.fields, defaults)}`,
    async f => { await api('/api/records/' + t, { ...f, pet_id: pet }); }, 'Next', 'Skip');
  dlg.addEventListener('close', bill, { once: true });
}
(async () => {
  let pre = { client: param('client_id'), pet: param('pet_id') };
  if (!rid && param('appt')) {
    visit = await api('/api/checkin/lookup', { appt_id: param('appt') });
    if (visit.status === 'Cancelled') { alert('That appointment was cancelled.'); location = 'index.php'; return; }
    pre = { client: visit.client_id, pet: visit.pet_id };
    api('/api/appointments/' + param('appt') + '/start', {}).catch(() => {});   // the patient is now with the vet
  }
  if (rid) { rec = await api(`/api/records/${type}/${rid}`); pre = { client: rec.client_id, pet: rec.pet_id }; }
  else if (pre.pet && !visit) { const p = await api('/api/pets/' + pre.pet); pre.client = p.client_id; }
  $('#f').innerHTML = `<div class="fr"><label>Client<div id="owner"></div></label><label>Pet<select name="pet_id" id="pet" required></select></label></div>` +
    (visit ? `<p class="devnote" style="margin:0">Visit date: <b>${E(fmtDay(visit.appt_date))}</b>${visit.appt_date !== today() ? ' (taken from the appointment, not today)' : ''}. Records always show the day of the visit, even when you type the findings later.</p>` : '')
    + (rid ? `<p class="muted" style="margin:0">${rec.recorded_by ? 'Recorded by ' + E(rec.recorded_by) + (rec.recorded_at ? ' on ' + D(rec.recorded_at.slice(0, 10)) : '') + '. ' : ''}${rec.edited_by ? 'Last edited by ' + E(rec.edited_by) + '.' : ''}</p>` : '')
    + fieldsHTML(S.fields.filter(f => !(rid && f.flow) && !(multi && ['item_type', 'vaccine', 'next_due'].includes(f.k))), visit ? { ...rec, [S.fields.find(f => f.t === 'date').k]: visit.appt_date } : rec, !!rid || !!visit) + `<p class="err"></p><div class="actions"><button class="btn" id="saveBtn">Save Record</button>${visit ? `<a class="btn ghost" href="charge.php?appt=${visit.id || param('appt')}">Back to charge sheet</a>` : ''}<a class="btn plain" href="javascript:history.back()">Cancel</a></div>`;
  if (multi) {
    const row = () => `<div class="itrow"><select class="it-type" aria-label="Type">${ITEM_TYPES.map(x => `<option>${x}</option>`).join('')}</select><input class="it-name" placeholder="Vaccine / treatment given" aria-label="Vaccine or treatment"><input class="it-due" type="date" aria-label="Next schedule" title="Next schedule"><button type="button" class="btn ghost sm it-x" title="Remove this line">&times;</button></div>`;
    $('[name=notes]').closest('label').insertAdjacentHTML('beforebegin', `<div class="blk itblk"><b>Given at this visit</b><p class="muted" style="margin:.2rem 0 .4rem">Add everything given today. Each line has its own next schedule (leave it empty if none).</p><div id="items">${row()}</div><button type="button" class="btn ghost sm" id="addIt">+ Add another</button></div>`);
    const mins = () => { const d = $('[name=vac_date]').value; $$('.it-due').forEach(e => e.min = d && d > today() ? d : (visit ? '' : today())); };
    $('#addIt').onclick = () => { $('#items').insertAdjacentHTML('beforeend', row()); mins(); $$('.it-name').pop().focus(); };
    $('#items').onclick = e => { const b = e.target.closest('.it-x'); if (b && $$('.itrow').length > 1) b.closest('.itrow').remove(); };
    $('[name=vac_date]').addEventListener('change', mins); mins();
  }
  const cb = await pickers($('#owner'), $('#pet'), side, pre);
  if (visit) { const df = $(`[name=${S.fields.find(f => f.t === 'date').k}]`); if (df) df.readOnly = true; cb.lock?.(); }   // the visit date cannot be typed over
  if (rid && rec.edits && rec.edits.length) $('#f').insertAdjacentHTML('beforeend', `<details class="blk"><summary>Edit history (${rec.edits.length})</summary>${rec.edits.map(e => `<p style="margin:.3rem 0"><b>${E(e.edited_by)}</b> <small class="muted">${E(e.edited_at)}</small><br><small>${E(e.changes).replace(/\n/g, '<br>')}</small></p>`).join('')}</details>`);
  const ns = $('[name=next_step]');
  const decided = !!(visit && visit.next_step);   // decided when the visit was marked Done: this write-up just repeats it
  if (ns && decided) {
    ns.value = visit.next_step; ns.disabled = true; const fu = $('[name=followup_date]'); if (fu) { fu.value = visit.followup_date || ''; fu.disabled = true; } const fp = $('[name=followup_purpose]'); if (fp) { fp.value = visit.followup_purpose || ''; fp.disabled = true; }
    ns.closest('label')?.insertAdjacentHTML('beforeend', `<small class="muted">Decided when the visit was marked Done${visit.next_step === 'Confinement' ? ' (see Confined patients)' : visit.next_step === 'Surgery' ? ' (surgery is booked)' : ''}.</small>`);
  }
  if (visit?.referral_reason && type === 'checkup') { const t = $('[name=tests]'); if (t && !t.value) t.value = 'Referred to ' + MAIN_BRANCH + ': ' + visit.referral_reason; }
  if (rid && type === 'confinement' && rec.sale_id) {   // admission and discharge are handled on the Confined page (they drive the bill)
    for (const k of ['admitted', 'discharged', 'status']) { const e = $(`[name=${k}]`); if (e) e.disabled = true; }
    $('#f').insertAdjacentHTML('afterbegin', '<p class="devnote" style="margin:0">Admission and discharge dates are set by the confinement itself. Use <b>Discharge</b> on the Confined page when the pet goes home. Daily notes and treatment can be edited any time.</p>');
  }
  if (ns && !decided) {   // Confinement/Surgery: no follow-up date here, and the button becomes "Next"
    const upd = () => {
      const more = ns.value !== 'None', row = $('[name=followup_date]').closest('.fr');
      row.hidden = more; const pl = $('[name=followup_purpose]').closest('label'); pl.hidden = more; if (more) { $('[name=followup_date]').value = ''; $('[name=followup_time]').value = ''; $('[name=followup_purpose]').value = ''; }
      $('#saveBtn').textContent = more ? 'Next' : 'Save Record';
    };
    ns.onchange = upd; upd();
  }
  // the later date can't be before the earlier one
  const link = (a, b) => { const A = $(`[name=${a}]`), B = $(`[name=${b}]`); if (!A || !B) return; const f = () => { B.min = A.value && A.value > today() ? A.value : (rid ? '' : today()); }; A.onchange = f; f(); };
  link('vac_date', 'next_due'); link('checkup_date', 'followup_date'); link('admitted', 'discharged');
  if (!pre.client) side();
  bindForm('#f', async d => {
    if (!cb.id) throw new Error('Search and choose a client first.');
    if (!d.pet_id) throw new Error('Choose a pet.');
    if (param('appt')) d.appt_id = param('appt');
    if (multi) {
      d.items = $$('.itrow').map(r => ({ item_type: $('.it-type', r).value, vaccine: $('.it-name', r).value.trim(), next_due: $('.it-due', r).value || null })).filter(x => x.vaccine);
      if (!d.items.length) throw new Error('Type at least one vaccine or treatment that was given.');
    }
    await api(`/api/records/${type}` + (rid ? '/' + rid : ''), d);
    if (!rid) {   // a new record goes back to the patient list (billing was already done on the charge sheet)
      if (type === 'checkup') return flow(d);
      return location = 'index.php';
    }
    location = 'general.php?pet=' + d.pet_id;
  });
})();
</script>
<?php bottom(); ?>

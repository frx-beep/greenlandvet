<?php require 'layout.php'; top('New Sale', 'l', 'Sales > New Sale (no visit)'); ?>
<div class="split" style="grid-template-columns:2fr 1fr">
  <div class="card"><h2>Sale Items</h2>
    <table><thead><tr><th>Item / Product</th><th style="width:6rem">Qty</th><th style="width:9rem">Unit Price</th><th>Amount</th><th></th></tr></thead><tbody id="items"></tbody></table>
    <button type="button" class="btn ghost" id="add" style="margin-top:1rem">+ Add Item</button> <button type="button" class="btn plain" id="addProd" style="margin-top:1rem">+ Add Product</button></div>
  <div class="card stack"><h2>Sale Summary</h2>
    <label>Date<input type="date" id="date"></label>
    <label>Client (optional)<div id="client"></div></label>
    <div class="total"><span>Subtotal</span><span id="sub"></span></div><div class="total"><span>Total</span><b id="tot"></b></div>
    <p class="muted" style="margin:0">The sale becomes a bill. Next you choose how the customer pays (cash, GCash, card or check, or a mix).</p><p class="err" id="err"></p>
    <button class="btn" id="done">Continue to payment</button><a class="btn plain" href="sales.php">Cancel</a></div>
</div>
<script>
let items = [{ item: '', qty: 1, price: 0 }];
$('#date').value = today(); $('#date').min = today();
const cc = clientCombo($('#client'), null, 'Walk-in customer (search to attach a client)');
const total = () => items.reduce((s, r) => s + r.qty * r.price, 0);
function sums() { items.forEach((r, i) => $('#a' + i).textContent = peso(r.qty * r.price)); $('#sub').textContent = $('#tot').textContent = peso(total()); }
function draw() {
  $('#items').innerHTML = items.map((r, i) => `<tr><td><input data-i="${i}" data-k="item" value="${E(r.item)}" placeholder="Item name"></td>
    <td><input data-i="${i}" data-k="qty" type="number" min="1" value="${r.qty}"></td><td><input data-i="${i}" data-k="price" type="number" min="0" step="0.01" value="${r.price}"></td>
    <td id="a${i}"></td><td><button type="button" class="x" data-r="${i}" aria-label="Remove item">&times;</button></td></tr>`).join('');
  $$('#items input').forEach(el => el.oninput = () => { const r = items[el.dataset.i], k = el.dataset.k; r[k] = k === 'item' ? el.value : +el.value || 0; sums(); });
  $$('[data-r]').forEach(b => b.onclick = () => { items.splice(b.dataset.r, 1); if (!items.length) items.push({ item: '', qty: 1, price: 0 }); draw(); });
  sums();
}
$('#add').onclick = () => { items.push({ item: '', qty: 1, price: 0 }); draw(); };
const addItem = p => {   // same product again just adds to the quantity
  items = items.filter(r => r.item.trim() !== '');
  const e = items.find(r => r.item.trim().toLowerCase() === p.item.trim().toLowerCase() && r.price === p.price);
  if (e) e.qty += p.qty; else items.push({ ...p });
};
$('#addProd').onclick = () => productPicker(addItem, draw);
$('#done').onclick = async () => {
  try { const r = await api('/api/sales', { date: $('#date').value, client_id: cc.id, items: items.filter(i => i.item.trim()) }); location = 'pay.php?id=' + r.id; }
  catch (x) { $('#err').textContent = x.message; }
};
draw();
</script>
<?php bottom(); ?>

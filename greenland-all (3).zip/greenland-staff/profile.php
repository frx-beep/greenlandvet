<?php require 'layout.php'; top('My Profile', '', 'Account'); ?>
<div class="split" style="grid-template-columns:1fr 2fr">
  <div class="card center"><div class="avatar big" id="pic"></div><h2 id="nm" style="margin:.75rem 0 0"></h2><p class="muted" id="rl" style="margin:.2rem 0 1rem"></p>
    <input type="file" id="file" accept="image/*" hidden>
    <div class="btns" style="justify-content:center"><button type="button" class="btn ghost" id="chg">Change photo</button><button type="button" class="btn plain" id="rm">Remove</button></div>
    <p class="err" id="perr"></p></div>
  <div>
    <div class="card"><h2>My Information</h2>
      <form id="f" class="form" novalidate>
        <div class="fr"><label>Full Name<input name="name"><small class="ferr" data-f="name"></small></label><label>Contact Number<input name="phone" placeholder="09XX XXX XXXX"></label></div>
        <label>Email Address (sign-in codes are sent here)<input name="email" type="email"><small class="ferr" data-f="email"></small></label>
        <div class="fr"><label>Username<input id="un" disabled></label><label>Branch<input id="br" disabled></label></div>
        <p class="muted" style="margin:0">Your username and branch are set by an admin.</p>
        <p class="err"></p><p class="okmsg" id="ok" hidden>Saved.</p>
        <div class="actions"><button class="btn">Save changes</button></div>
      </form></div>
    <div class="card"><h2>Change Password</h2>
      <form id="pf" class="form" novalidate>
        <label>Current password<input name="current" type="password" autocomplete="current-password"><small class="ferr" data-f="current"></small></label>
        <div class="fr"><label>New password (8+ characters)<input name="password" type="password" autocomplete="new-password"><small class="ferr" data-f="password"></small></label>
        <label>Confirm new password<input name="confirm" type="password" autocomplete="new-password"><small class="ferr" data-f="confirm"></small></label></div>
        <p class="err"></p><p class="okmsg" id="pok" hidden>Password changed.</p>
        <div class="actions"><button class="btn">Change password</button></div>
      </form></div>
  </div>
</div>
<script>
let me = {};
async function load() {
  me = await api('/api/profile');
  $('#nm').textContent = me.name; $('#rl').textContent = (ROLE === 'vet' ? 'Veterinarian' : 'Staff') + ' \u00B7 ' + (me.branch || '');
  const p = $('#pic'); p.style.backgroundImage = me.photo ? `url(${me.photo})` : ''; p.textContent = me.photo ? '' : me.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const f = $('#f'); f.name.value = me.name; f.email.value = me.email; f.phone.value = me.phone || ''; $('#un').value = me.username; $('#br').value = me.branch || '';
  paintAvatar(me);
}
async function savePhoto(photo) { try { $('#perr').textContent = ''; await api('/api/profile/photo', { photo }); load(); } catch (x) { $('#perr').textContent = x.message; } }
$('#chg').onclick = () => $('#file').click();
$('#rm').onclick = () => savePhoto('');
$('#file').onchange = e => {
  const file = e.target.files[0]; if (!file) return;
  const img = new Image();
  img.onload = () => {   // crop to a square and shrink so it stays small
    const s = 256, c = document.createElement('canvas'), m = Math.min(img.width, img.height); c.width = c.height = s;
    c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, s, s);
    URL.revokeObjectURL(img.src); savePhoto(c.toDataURL('image/jpeg', 0.85));
  };
  img.onerror = () => $('#perr').textContent = 'That file is not a valid image.';
  img.src = URL.createObjectURL(file);
};
bindForm('#f', async d => { $('#ok').hidden = true; await api('/api/profile', d); $('#ok').hidden = false; load(); });
bindForm('#pf', async d => { $('#pok').hidden = true; await api('/api/profile/password', d); $('#pok').hidden = false; $('#pf').reset(); });
load();
</script>
<?php bottom(); ?>

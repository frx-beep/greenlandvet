<?php $t = $_GET['type'] ?? ''; header('Location: general.php' . ($t ? '?type=' . urlencode($t) : '')); exit;   // moved to General Records (Update 12)

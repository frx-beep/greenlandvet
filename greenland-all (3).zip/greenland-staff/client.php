<?php require 'layout.php'; top('Client Profile', 'c', 'Clients'); ?>
<a class="btn plain" href="clients.php" style="margin-bottom:16px">&larr; Back to Clients</a>
<div id="owe"></div>
<div class="row2" style="grid-template-columns:minmax(260px,1fr) 1.6fr">
  <div class="card"><div class="hd"><h2>Client Information</h2><button class="btn plain" id="edit">Edit</button></div><dl id="info"></dl></div>
  <div class="card"><div class="hd"><h2 id="petsTitle">Pets</h2><a class="btn" id="addPet">+ Add Pet</a></div>
    <table><thead><tr><th>Pet</th><th>Species</th><th>Breed</th><th>Birthdate</th><th>Sex</th><th></th></tr></thead><tbody id="pets"></tbody></table></div>
</div>
<div class="card"><h2>Recent Service Records</h2>
  <table><thead><tr><th>Visit date</th><th>Pet</th><th>Service</th><th>Notes</th></tr></thead><tbody id="recs"></tbody></table></div>
<script>
const id = param('id'); let c;
async function load() {
  try { c = await api('/api/clients/' + id); } catch (x) { return $('#info').innerHTML = `<p class="err">${esc(x.message)}</p>`; }
  $('#crumb').textContent = 'Clients > ' + c.name;
  $('#owe').innerHTML = +c.balance > 0 ? `<p class="owes-b"><b>${esc(c.name)} owes ${peso(c.balance)}</b> across unpaid bills (both branches). Service is never refused. ${ROLE === 'staff' ? `<a class="link" href="statement.php?client=${id}">Statement</a> &middot; <a class="link" href="pay.php?client=${id}">Take payment</a>` : ''}</p>` : '';
  $('#info').innerHTML = [['Name', c.name], ['Address', c.address], ['Email', c.email], ['Contact', c.phone], ['Registered at', c.branch]]
    .map(([k, v]) => `<dt>${k}</dt><dd>${esc(v || '-')}</dd>`).join('');
  const ac = c.account;
  $('#info').insertAdjacentHTML('beforeend', `<dt>Portal account</dt><dd>${ac ? `<span class="badge ${ac.status === 'Active' ? '' : 'g'}">${esc(ac.status)}</span> <span class="muted">Admins can reset the password or disable it.</span>`
    : 'No account yet <button class="btn ghost sm" id="mkacct" type="button">Create portal account</button>'}</dd>`);
  if (!ac) $('#mkacct').onclick = () => dialog(`<h3>Create portal account</h3><p class="muted">${esc(c.name)} will sign in with the username and temporary password below, then choose a new password. A sign-in code is emailed to ${esc(c.email || 'their email')}.</p>
    <label>Username<input name="username" value="${esc((c.email || '').split('@')[0].toLowerCase().replace(/[^a-z0-9._-]/g, ''))}"></label>
    <label>Temporary Password (8+ characters)<input name="password" type="text"></label>`, async f => { await api('/api/clients/' + id + '/account', f); load(); });
  $('#petsTitle').textContent = `Pets (${c.pets.length})`;
  $('#addPet').href = 'pet_new.php?client_id=' + id;
  $('#pets').innerHTML = c.pets.length ? c.pets.map(p => `<tr><td><span class="pn">${pav(p.name, p.species, null, 'sm')}${esc(p.name)}</span></td><td>${esc(p.species)}</td><td>${esc(p.breed)}</td><td>${fmtDate(p.birthdate)}</td><td>${esc(p.sex)}</td><td><a class="link" href="pet.php?id=${p.id}">Open &rsaquo;</a></td></tr>`).join('')
    : '<tr><td colspan="6" class="empty">No pets yet. Use "+ Add Pet".</td></tr>';
  $('#recs').innerHTML = c.records.length ? c.records.map(r => `<tr class="click" data-t="${r.rtype}" data-id="${r.rid}" title="Click to view details"><td>${fmtDate(r.date)}</td><td>${esc(r.pet)}</td><td>${esc(r.service)}</td><td>${esc(r.notes)}</td></tr>`).join('')
    : '<tr><td colspan="4" class="empty">No service records yet.</td></tr>';
  $$('#recs tr[data-id]').forEach(tr => tr.onclick = async () => showRecord(tr.dataset.t, await api(`/api/records/${tr.dataset.t}/${tr.dataset.id}`)));
}
$('#edit').onclick = () => dialog(`<h3>Edit client</h3>
  <label>Client's Name<input name="name" value="${esc(c.name)}" required></label><label>Address<input name="address" value="${esc(c.address)}"></label>
  <div class="fr"><label>Email Address<input name="email" type="email" value="${esc(c.email)}"></label><label>Contact Number<input name="phone" value="${esc(c.phone)}" required></label></div>`,
  async f => { await api('/api/clients/' + id, f); load(); });
load();
</script>
<?php bottom(); ?>

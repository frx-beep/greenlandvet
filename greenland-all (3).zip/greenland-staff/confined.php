<?php require 'layout.php'; top('Confined Patients', 'f', 'Patients staying at the clinic'); ?>
<div id="cinfo"></div>
<div class="card"><div class="hd"><h2 id="ct">Staying with us</h2><div class="btns" style="margin:0"><button type="button" class="btn" id="t-now">Staying now</button><button type="button" class="btn plain" id="t-past">Recently discharged</button></div></div><div id="cf"><p class="muted">Loading...</p></div></div>
<script>
const IS_STAFF = ROLE === 'staff', MAIN = <?= json_encode(MAIN_BRANCH) ?>;
let tab = 'now', R = null;
const refTag = r => !r.referred_from ? '' : (r.referred_from === ME_BRANCH && ME_BRANCH !== MAIN ? `<span class="tag">Referred to ${E(MAIN)}</span>` : `<span class="tag">Referred from ${E(r.referred_from)}</span>`)
  + (r.referred_from && !r.arrived_at && r.status === 'Admitted' ? ' <span class="badge x">not arrived yet</span>' : '');
function row(r) {
  const adm = r.status === 'Admitted', wait = r.referred_from && !r.arrived_at, atMain = ME_BRANCH === MAIN;
  const acts = [`<a class="btn ghost" href="charge.php?conf=${r.id}">${adm ? 'Charge sheet' : 'View bill'}</a>`];
  if (IS_STAFF && adm && wait && atMain) acts.push(`<button type="button" class="btn" data-arr="${r.id}" data-pet="${E(r.pet)}">Mark arrived</button>`);
  if (adm) acts.push(`<button type="button" class="btn plain" data-days="${r.id}" data-auto="${r.days_auto}" data-ov="${r.days_override ? r.days : ''}">Change days</button>`);
  if (!IS_STAFF) acts.push(`<a class="btn plain" href="service_form.php?type=confinement&id=${r.id}">Daily notes</a>`);
  if (!IS_STAFF && adm && !wait && atMain) acts.push(`<a class="btn" href="charge.php?conf=${r.id}">Discharge</a>`);
  if (IS_STAFF && !adm && ['Unpaid', 'Partially paid'].includes(r.bill_status)) acts.push(`<a class="btn" href="pay.php?id=${r.sale_id}">Take payment</a>`);
  return `<div class="cf ${wait && adm ? 'ref' : ''}${stc(adm ? (wait ? 'ref' : 'conf') : 'done')}"><div class="cf-n"><b>${r.days}</b><small>day${r.days === 1 ? '' : 's'}${r.days_override ? ' (typed)' : ''}</small></div>${pav(r.pet, r.species, null, 'lg')}
    <div class="cf-b"><h3>${E(r.pet)} <span class="tag">${E(r.species || '')}</span> ${refTag(r)}</h3>
      <p>${E(r.client)}${r.phone ? ' &middot; ' + E(r.phone) : ''}${r.vet ? ' &middot; ' + E(r.vet) : ''}</p>
      <p>${adm ? 'Since ' + E(fmtDay(r.admitted)) : E(fmtDay(r.admitted)) + ' to ' + E(fmtDay(r.discharged))}${r.reason ? ' &middot; ' + E(r.reason) : ''}</p></div>
    <div class="cf-t"><b>${peso(r.total)}</b><small>${adm ? 'running total' : E(r.bill_status || '')}</small></div><div class="cf-a">${acts.join('')}</div></div>`;
}
async function load() {
  try { R = await api('/api/confined?tab=' + tab); } catch (x) { $('#cf').innerHTML = `<p class="err">${E(x.message)}</p>`; return; }
  $('#ct').textContent = tab === 'now' ? `Staying with us (${R.rows.length})` : 'Recently discharged';
  $('#t-now').className = 'btn' + (tab === 'now' ? '' : ' plain'); $('#t-past').className = 'btn' + (tab === 'past' ? '' : ' plain');
  $('#cinfo').innerHTML = ME_BRANCH !== R.main ? `<p class="devnote strip">Confinement and surgery are done at the ${E(R.main)} branch. Patients from ${E(ME_BRANCH)} appear here as referrals.</p>` : '';
  $('#cf').innerHTML = R.rows.length ? R.rows.map(row).join('') : `<p class="muted" style="margin:0">${tab === 'now' ? 'No patient is confined right now. A vet confines a patient at Done, after a check-up or surgery.' : 'Nobody was discharged recently.'}</p>`;
  $$('#cf [data-arr]').forEach(b => b.onclick = async () => { if (!confirm(`Mark ${b.dataset.pet} as arrived at ${MAIN}?`)) return; try { await api(`/api/confined/${b.dataset.arr}/arrived`, {}); load(); } catch (x) { alert(x.message); } });
  $$('#cf [data-days]').forEach(b => b.onclick = () => dialog(`<h3>Change the number of days</h3><p class="muted" style="margin:0">Counted automatically: <b>${b.dataset.auto}</b> (the admission day counts). Type a number to overwrite it, or leave it empty to count automatically. Every change is logged.</p>
    <label>Days<input name="days" type="number" min="1" max="365" value="${b.dataset.ov}" placeholder="automatic (${b.dataset.auto})"></label>`, async f => { await api(`/api/confined/${b.dataset.days}/days`, { days: f.days === '' ? null : +f.days }); load(); }, 'Save'));
}
$('#t-now').onclick = () => { tab = 'now'; load(); }; $('#t-past').onclick = () => { tab = 'past'; load(); };
load(); setInterval(() => { if (!document.querySelector('dialog[open]')) load(); }, 30000);
</script>
<?php bottom(); ?>

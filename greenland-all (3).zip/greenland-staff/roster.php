<?php require 'layout.php'; top('Duty Roster', 'k', 'Which vets are in each day (2 to 4 rotate)'); ?>
<div class="toolbar"><button class="btn plain" id="prev" type="button">&lsaquo; Earlier</button><b id="range" style="flex:1;text-align:center"></b><button class="btn plain" id="next" type="button">Later &rsaquo;</button><button class="btn ghost" id="thisw" type="button">This week</button></div>
<div class="card"><h2>Who is in</h2><p class="muted" style="margin-top:0">Only vets who are <b>in</b> on a day receive patients. Tap a cell to switch it. Days follow the weekly pattern below until you change them. Past days cannot be changed.</p>
  <div style="overflow:auto"><table class="roster" id="rt"></table></div><p class="err" id="err"></p></div>
<div class="card"><h2>Usual weekly pattern</h2><p class="muted" style="margin-top:0">Tick the days each vet normally works. A vet with no days ticked is treated as in every day. You can still change single days above.</p><div id="pat"></div></div>
<script>
const DN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
let from = new Date(); from.setHours(0, 0, 0, 0); const ymd = d => d.toLocaleDateString('en-CA');
function monday(d) { const x = new Date(d); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; }
from = monday(from); let R = null;
async function load() {
  try { R = await api('/api/duty?from=' + ymd(from)); } catch (x) { $('#err').textContent = x.message; return; }
  $('#err').textContent = '';
  $('#range').textContent = fmtDate(R.days[0].date) + ' to ' + fmtDate(R.days[6].date) + ' (' + R.branch + ')';
  const t = today();
  $('#rt').innerHTML = `<thead><tr><th>Veterinarian</th>${R.days.map(d => `<th class="c ${d.date === t ? 'today' : ''}">${DN[new Date(d.date + 'T00:00').getDay()]}<br><small>${new Date(d.date + 'T00:00').getDate()}</small></th>`).join('')}</tr></thead><tbody>
    ${R.vets.map(v => `<tr><td><b>${E(v.name)}</b></td>${R.days.map(d => { const c = d.vets.find(x => x.id === v.id) || {}; const past = d.date < t;
      return `<td class="c">${d.closed ? '<span class="muted">Closed</span>' : `<button type="button" class="dutyc ${c.on ? 'in' : 'out'} ${c.source}" data-v="${v.id}" data-d="${d.date}" data-on="${c.on ? 0 : 1}" ${past ? 'disabled' : ''}>${c.on ? 'In' : 'Off'}</button>${c.source === 'set' && !past ? `<br><button type="button" class="link tiny" data-r="${v.id}" data-d="${d.date}">reset</button>` : ''}`}</td>`; }).join('')}</tr>`).join('') || '<tr><td colspan="8" class="empty">No veterinarian accounts at this branch yet.</td></tr>'}
    <tr class="cnt"><td><b>On duty</b></td>${R.days.map(d => { const n = d.vets.filter(x => x.on).length; return `<td class="c">${d.closed ? '' : `<span class="${n < R.min_vets ? 'lowv' : ''}">${n}</span>`}</td>`; }).join('')}</tr></tbody>`;
  $$('#rt [data-v]').forEach(b => b.onclick = () => set(b.dataset.v, b.dataset.d, b.dataset.on === '1'));
  $$('#rt [data-r]').forEach(b => b.onclick = () => set(b.dataset.r, b.dataset.d, null));
  $('#pat').innerHTML = R.vets.map(v => { const mine = R.defaults[v.id] || []; return `<div class="patrow"><b>${E(v.name)}</b>${[1, 2, 3, 4, 5, 6].map(w => `<label class="chk"><input type="checkbox" data-pv="${v.id}" value="${w}" ${mine.includes(w) ? 'checked' : ''}> ${DN[w]}</label>`).join('')}<button type="button" class="btn ghost sm" data-ps="${v.id}">Save</button></div>`; }).join('') || '<p class="muted">No veterinarians yet.</p>';
  $$('[data-ps]').forEach(b => b.onclick = async () => { const days = $$(`[data-pv="${b.dataset.ps}"]:checked`).map(c => +c.value); try { await api('/api/duty/default', { vet_id: b.dataset.ps, days }); toast('Saved', 'The weekly pattern was updated.'); load(); } catch (x) { alert(x.message); } });
}
async function set(vet, date, on) {
  if (on === false && !confirm('Mark this vet as not on duty? Their booked vaccinations and other timed visits that day move to other free vets.')) return;
  try { const r = await api('/api/duty', { vet_id: vet, date, on }); if (r.moved || r.unassigned) alert(`${r.moved} appointment(s) moved.${r.unassigned ? ' ' + r.unassigned + ' need a new time.' : ''}`); if (r.warn) alert(r.warn); load(); } catch (x) { alert(x.message); }
}
$('#prev').onclick = () => { from.setDate(from.getDate() - 7); load(); }; $('#next').onclick = () => { from.setDate(from.getDate() + 7); load(); }; $('#thisw').onclick = () => { from = monday(new Date()); load(); };
load();
</script>
<?php bottom(); ?>

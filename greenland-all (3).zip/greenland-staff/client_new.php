<?php require 'layout.php'; top('New Client', 'c', 'Clients > New Client'); ?>
<div class="card fit"><h2>Client Registration</h2>
  <form id="f" class="form">
    <label>Client's Name<input name="name" placeholder="Full name" required></label>
    <label>Address<input name="address" placeholder="House no., street, barangay, city" required></label>
    <div class="fr"><label>Email Address<input name="email" type="email" placeholder="name@email.com" required></label>
    <label>Contact Number<input name="phone" placeholder="09XX XXX XXXX" required></label></div>
    <div class="acctbox">
      <label class="chk"><input type="checkbox" name="create_account" value="1" id="mk"> Create a client portal account</label>
      <div id="acct" hidden>
        <p class="muted" style="margin:.4rem 0">The client signs in on the customer site with this username and temporary password, then chooses their own password. Give them both. A sign-in code is emailed to the address above. Admins can reset the password or disable the account later.</p>
        <label>Username<input name="acct_username" id="un" placeholder="e.g. erik.taduran" autocomplete="off"></label>
        <label>Temporary Password (8+ characters)<div class="pwrow"><input name="acct_password" type="text" id="tp" placeholder="Temporary password"><button type="button" class="btn ghost" id="gen">Generate</button></div></label>
      </div>
    </div>
    <p class="err"></p>
    <div class="actions"><button class="btn" value="save">Save Client</button><button class="btn ghost" value="pet">Save &amp; Add Pet</button><a class="btn plain" href="clients.php">Cancel</a></div>
  </form></div>
<script>
$('[name=email]').onblur = () => { if (!$('#un').value) $('#un').value = $('[name=email]').value.split('@')[0].toLowerCase().replace(/[^a-z0-9._-]/g, ''); };
$('#mk').onchange = () => { $('#acct').hidden = !$('#mk').checked; if (!$('#mk').checked) { $('#tp').value = ''; $('#un').value = ''; } };
$('#gen').onclick = () => { const c = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789'; $('#tp').value = Array.from({ length: 10 }, () => c[Math.floor(Math.random() * c.length)]).join(''); };
bindForm('#f', async d => {
  const c = await api('/api/clients', d);
  const go = d.action === 'pet' ? 'pet_new.php?client_id=' + c.id : 'client.php?id=' + c.id;
  if (!d.create_account) return location = go;
  const m = document.createElement('dialog');
  m.innerHTML = `<h3>Client saved</h3><p>The portal account is ready. Give the client these sign-in details. The password won't be shown again.</p>
    <dl><dt>Username</dt><dd><b>${E(d.acct_username)}</b></dd><dt>Temporary password</dt><dd><b>${E(d.acct_password)}</b></dd></dl>
    <p class="muted">They sign in on the customer site and will be asked to choose a new password.</p>
    <div class="actions"><button class="btn plain" id="cp" type="button">Copy</button><button class="btn" id="ok" type="button">Continue</button></div>`;
  document.body.append(m); m.showModal();
  $('#cp', m).onclick = () => { navigator.clipboard?.writeText(`Username: ${d.acct_username}\nTemporary password: ${d.acct_password}`); $('#cp', m).textContent = 'Copied'; };
  $('#ok', m).onclick = () => location = go;
});
</script>
<?php bottom(); ?>

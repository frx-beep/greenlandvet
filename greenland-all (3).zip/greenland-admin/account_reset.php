<?php require 'layout.php'; top('Reset Password', 'a', 'Accounts > Reset Password'); ?>
<div class="card fit"><h2 id="h">Reset password</h2><p class="muted" id="who"></p>
  <form id="f" class="form" novalidate>
    <label class="option"><input type="radio" name="mode" value="temp" checked><span><b>Generate a temporary password</b><span class="muted">A one-time password is shown here for you to give to the user.</span></span></label>
    <label class="option"><input type="radio" name="mode" value="link"><span><b>Send a reset link to the account email</b><span class="muted">The user sets a new password from the emailed link.</span></span></label>
    <label class="chk"><input type="checkbox" name="require_change" value="1" checked> Require a new password on next login</label>
    <p class="err"></p><div class="okmsg" id="res" hidden></div>
    <div class="actions"><button class="btn">Reset Password</button><a class="btn plain" id="back">Cancel</a></div>
  </form></div>
<script>
const id = param('id'); $('#back').href = 'account.php?id=' + id;
api('/api/accounts/' + id).then(a => { $('#h').textContent = 'Reset password for ' + a.name; $('#who').textContent = roleName(a.role) + ' \u00B7 ' + a.email; });
bindForm('#f', async d => {
  const r = await api(`/api/accounts/${id}/reset`, { mode: d.mode, require_change: d.require_change });
  $('#res').hidden = false;
  $('#res').innerHTML = r.temp ? `Temporary password: <b style="font-size:1.2rem">${E(r.temp)}</b><br><small>Copy it now. It will not be shown again.</small>`
    : `Reset link sent to the account email.` + (r.link ? `<br><small>Testing mode link: <a href="${E(r.link)}">${E(r.link)}</a></small>` : '');
});
</script>
<?php bottom(); ?>

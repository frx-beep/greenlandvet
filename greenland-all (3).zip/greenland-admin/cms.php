<?php require 'layout.php'; top('Page Management', 'w', 'Admin Console > Page Management'); ?>
<p class="muted" style="margin-top:0">Edit what visitors see on the public website: the banner, promo message, items on sale, the services intro, the About text and the footer note. Changes appear on the pet owner site straight away. <a class="link" href="<?= htmlspecialchars(SITE_URLS['client']) ?>" target="_blank" rel="noopener">Open the public homepage</a></p>
<div class="split" style="grid-template-columns:1.1fr 1fr;align-items:start">
  <div class="card"><h2>Homepage Content</h2>
    <form id="f" class="form" novalidate>
      <label>Banner title<input name="hero_title" maxlength="120" placeholder="Greenland Veterinary Clinic"></label>
      <label>Banner text<textarea name="hero_text" maxlength="400" placeholder="One short line under the title"></textarea></label>
      <div class="field"><span class="lbl">Banner picture (optional)</span><div class="cmsprev" id="hprev">No picture</div>
        <input type="file" id="hfile" accept="image/*" hidden>
        <div class="btns" style="margin:0"><button type="button" class="btn ghost sm" id="hchg">Choose picture</button><button type="button" class="btn plain sm" id="hrm">Remove</button></div><small class="ferr" data-f="hero_image"></small></div>
      <label class="chk"><input type="checkbox" name="promo_on" value="1" id="promo_on"> Show the promo message strip at the top</label>
      <label>Promo message<input name="promo_text" maxlength="200" placeholder="e.g. Free nail trim with every vaccination this month!"></label>
      <label>Items-on-sale heading<input name="offers_title" maxlength="80" placeholder="Promos &amp; items on sale"></label>
      <label>Services heading<input name="services_title" maxlength="80" placeholder="What we do"></label>
      <label>Services intro<textarea name="services_text" rows="2" maxlength="400" placeholder="One or two lines above the service cards"></textarea></label>
      <label>About title<input name="about_title" maxlength="80" placeholder="About us"></label>
      <label>About text<textarea name="about_text" rows="4" placeholder="Tell visitors about the clinic, branches and hours."></textarea></label>
      <label>Footer note<input name="footer_text" maxlength="200" placeholder="e.g. Caring for your pets, together."></label>
      <p class="err"></p><p class="okmsg" id="ok" hidden>Saved. The public site is updated.</p>
      <div class="actions"><button class="btn">Save changes</button></div>
    </form></div>
  <div><div class="card"><div class="hd"><h2>Promos &amp; Items on Sale</h2><button class="btn sm" id="add">+ Add item</button></div>
    <p class="muted" style="margin-top:0">Add products, services or promos with a price and a picture. Turn an item off to hide it without deleting it.</p>
    <table><thead><tr><th></th><th>Item</th><th>Price</th><th>Shown</th><th></th></tr></thead><tbody id="items"></tbody></table></div>
</div>
</div>
<script>
let heroImg, items = [];
const KEYS = ['hero_title', 'hero_text', 'promo_text', 'offers_title', 'services_title', 'services_text', 'about_title', 'about_text', 'footer_text'];
function showHero(v) { const p = $('#hprev'); p.style.backgroundImage = v ? `url(${v})` : ''; p.textContent = v ? '' : 'No picture'; }
async function load() {
  const r = await api('/api/cms'), c = r.content, f = $('#f'); items = r.items;
  KEYS.forEach(k => f.elements[k].value = c[k] || ''); f.elements.promo_on.checked = c.promo_on === '1';
  heroImg = c.hero_image || ''; showHero(heroImg); drawItems();
}
function drawItems() {
  $('#items').innerHTML = items.length ? items.map((x, i) => `<tr><td><div class="cmsthumb" style="${x.image ? `background-image:url(${x.image})` : ''}"></div></td>
    <td><b>${E(x.title)}</b><br><small class="muted">${x.kind === 'service' ? 'Service' : 'Promo / product'}${x.description ? ' &middot; ' + E(x.description.slice(0, 60)) : ''}</small></td>
    <td>${x.price === null ? '-' : peso(x.price)}${x.old_price !== null && +x.old_price > +x.price ? `<br><s class="muted">${peso(x.old_price)}</s>` : ''}</td>
    <td><span class="badge ${+x.active ? '' : 'g'}">${+x.active ? 'On' : 'Hidden'}</span></td>
    <td class="nowrap"><button class="link" data-e="${i}">Edit</button> <button class="link" data-d="${i}">Delete</button></td></tr>`).join('') : '<tr><td colspan="5" class="empty">No items yet. Add your first promo.</td></tr>';
  $$('#items [data-e]').forEach(b => b.onclick = () => itemDialog(items[b.dataset.e]));
  $$('#items [data-d]').forEach(b => b.onclick = () => { const x = items[b.dataset.d]; if (confirm(`Delete "${x.title}" from the homepage?`)) api(`/api/cms/items/${x.id}/delete`, {}).then(load); });
}
function itemDialog(x) {
  let img = x ? x.image : '';
  const d = dialog(`<h3>${x ? 'Edit item' : 'Add item'}</h3>
    <div class="fr"><label>Type<select name="kind"><option value="promo" ${x?.kind !== 'service' ? 'selected' : ''}>Promo / product on sale</option><option value="service" ${x?.kind === 'service' ? 'selected' : ''}>Service</option></select></label>
    <label>Title<input name="title" value="${E(x?.title)}" maxlength="120"></label></div>
    <label>Description<textarea name="description" maxlength="400">${E(x?.description)}</textarea></label>
    <div class="fr"><label>Price (&#8369;)<input name="price" type="number" step="0.01" min="0" value="${x && x.price !== null ? x.price : ''}"></label>
    <label>Old price, shown crossed out (&#8369;)<input name="old_price" type="number" step="0.01" min="0" value="${x && x.old_price !== null ? x.old_price : ''}"></label></div>
    <div class="field"><span class="lbl">Picture</span><div class="cmsprev" id="iprev"></div><input type="file" id="ifile" accept="image/*" hidden>
      <div class="btns" style="margin:0"><button type="button" class="btn ghost sm" id="ichg">Choose picture</button><button type="button" class="btn plain sm" id="irm">Remove</button></div></div>
    <div class="fr"><label>Order (small numbers first)<input name="sort_order" type="number" value="${x ? x.sort_order : 0}"></label>
    <label class="chk" style="padding-top:1.4rem"><input type="checkbox" name="active" value="1" ${!x || +x.active ? 'checked' : ''}> Show on the website</label></div>`,
    async f => { await api(x ? '/api/cms/items/' + x.id : '/api/cms/items', { ...f, image: img || '' }); load(); });
  const show = () => { const p = $('#iprev', d); p.style.backgroundImage = img ? `url(${img})` : ''; p.textContent = img ? '' : 'No picture'; }; show();
  $('#ichg', d).onclick = () => $('#ifile', d).click(); $('#irm', d).onclick = () => { img = ''; show(); };
  $('#ifile', d).onchange = async e => { const fl = e.target.files[0]; e.target.value = ''; if (!fl) return; try { img = await resizeWide(fl, 800); show(); } catch (z) { $('.err', d).textContent = z.message; } };
}
$('#add').onclick = () => itemDialog(null);
$('#hchg').onclick = () => $('#hfile').click(); $('#hrm').onclick = () => { heroImg = ''; showHero(''); };
$('#hfile').onchange = async e => { const fl = e.target.files[0]; e.target.value = ''; if (!fl) return; try { heroImg = await resizeWide(fl, 1200); showHero(heroImg); } catch (z) { $('#f .err').textContent = z.message; } };
bindForm('#f', async d => {
  $('#ok').hidden = true;
  const body = {}; KEYS.forEach(k => body[k] = d[k] || ''); body.promo_on = d.promo_on ? 1 : 0; body.hero_image = heroImg;
  await api('/api/cms', body); $('#ok').hidden = false;
});
load().catch(x => $('#f .err').textContent = x.message);
</script>
<?php bottom(); ?>

<?php require 'authlib.php';
if (q("SELECT 1 FROM accounts WHERE role='admin'")->fetch()) { header('Location: login.php'); exit; }
auth_open('First-time setup'); ?>
<h3>Create the first admin</h3><p class="muted">This page only works once. After the admin exists it closes itself.</p>
<form id="f" class="form" novalidate>
  <label>Full name<input name="name"></label><label>Email address (receives sign-in codes)<input name="email" type="email"></label>
  <label>Username<input name="username"></label><label>Password (8+ characters)<input name="password" type="password"></label>
  <p class="err"></p><button class="btn wide">Create admin</button>
</form>
<script>bindForm('#f', async d => { await api('/api/auth/setup', d); location = 'login.php'; });</script>
<?php auth_close(); ?>

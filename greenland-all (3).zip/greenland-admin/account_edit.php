<?php require 'layout.php'; top('Edit Profile', 'a', 'Accounts > Edit Profile'); ?>
<a class="btn plain" id="back" style="margin-bottom:1rem">&larr; Back to Account</a>
<div class="split" style="grid-template-columns:1fr 2fr">
  <div class="card center"><div class="avatar big" id="pic"></div><h2 id="nm" style="margin:.75rem 0 0"></h2><p class="muted" id="rl" style="margin:.2rem 0 1rem"></p>
    <input type="file" id="file" accept="image/*" hidden>
    <div class="btns" style="justify-content:center"><button type="button" class="btn ghost" id="chg">Change photo</button><button type="button" class="btn plain" id="rm">Remove</button></div>
    <p class="err" id="perr"></p></div>
  <div>
    <div class="card"><h2>Profile Information</h2>
      <form id="f" class="form" novalidate>
        <div class="fr"><label>Full Name<input name="name"><small class="ferr" data-f="name"></small></label><label>Username<input name="username"><small class="ferr" data-f="username"></small></label></div>
        <div class="fr"><label>Email Address<input name="email" type="email"><small class="ferr" data-f="email"></small></label><label>Contact Number<input name="phone"></label></div>
        <label>Branch<select name="branch"><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select><small class="ferr" data-f="branch"></small></label>
        <label id="addrl">Address<input name="address"></label>
        <p class="err"></p><p class="okmsg" id="ok" hidden>Saved.</p>
        <div class="actions"><button class="btn">Save changes</button></div>
      </form></div>
    <div class="card" id="petcard" hidden><div class="hd"><h2>Pets</h2><button type="button" class="btn sm" id="addpet">+ Add Pet</button></div>
      <table><thead><tr><th></th><th>Name</th><th>Species</th><th>Breed</th><th>Sex</th><th>Birthdate</th><th></th></tr></thead><tbody id="pets"></tbody></table></div>
  </div>
</div>
<script>
const id = param('id'); let acc = null, newPhoto;
const initials = n => n.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
async function load() {
  acc = await api('/api/accounts/' + id);
  $('#back').href = 'account.php?id=' + id; $('#crumb').textContent = 'Accounts > ' + acc.name + ' > Edit';
  $('#nm').textContent = acc.name; $('#rl').textContent = ({ client: 'Client (Pet Owner)', staff: 'Staff (Front desk)', vet: 'Veterinarian' })[acc.role];
  const p = $('#pic'); p.style.backgroundImage = acc.photo ? `url(${acc.photo})` : ''; p.textContent = acc.photo ? '' : initials(acc.name);
  const f = $('#f');
  ['name', 'username', 'email', 'phone', 'address'].forEach(k => f.elements[k].value = acc[k] || ''); f.elements.branch.value = acc.branch || BRANCHES[0];
  const isC = acc.role === 'client'; $('#addrl').hidden = !isC; $('#petcard').hidden = !isC;
  if (isC) {
    const pets = acc.pets || [];
    $('#pets').innerHTML = pets.length ? pets.map((x, i) => `<tr><td><div class="ph sm" style="${x.photo ? `background-image:url(${x.photo})` : ''}"></div></td><td>${E(x.name)}</td><td>${E(x.species)}</td><td>${E(x.breed)}</td><td>${E(x.sex)}</td><td>${fmtDate(x.birthdate)}</td>
      <td><button type="button" class="link" data-i="${i}">Edit</button></td></tr>`).join('') : '<tr><td colspan="7" class="empty">No pets registered.</td></tr>';
    $$('#pets [data-i]').forEach(b => b.onclick = () => petDialog(pets[b.dataset.i]));
  }
}
function petDialog(p) {
  newPhoto = undefined;
  const d = dialog(`<h3>${p ? 'Edit pet' : 'Add pet'}</h3><label>Pet's Name<input name="name" value="${E(p?.name)}"></label>
    <div class="fr"><label>Species<select name="species">${['Dog', 'Cat', 'Bird', 'Rabbit', 'Other'].map(x => `<option ${x === p?.species ? 'selected' : ''}>${x}</option>`).join('')}</select></label><label>Breed<input name="breed" value="${E(p?.breed)}"></label></div>
    <div class="fr"><label>Sex<select name="sex">${['Male', 'Female'].map(x => `<option ${x === p?.sex ? 'selected' : ''}>${x}</option>`).join('')}</select></label><label>Birthdate<input type="date" name="birthdate" value="${E(p?.birthdate)}"></label></div>
    <label>Photo<input type="file" accept="image/*" id="pfile"></label>${p && p.photo ? '<label class="chk"><input type="checkbox" id="prm"> Remove current photo</label>' : ''}`,
    async f => {
      const body = { ...f }; if (newPhoto !== undefined) body.photo = newPhoto; else if ($('#prm', d) && $('#prm', d).checked) body.photo = '';
      await api(p ? '/api/pets/' + p.id : `/api/accounts/${id}/pets`, body); load();
    });
  $('#pfile', d).onchange = async e => { try { newPhoto = await resizeImage(e.target.files[0]); } catch (x) { $('.err', d).textContent = x.message; } };
}
async function savePhoto(photo) { try { $('#perr').textContent = ''; await api(`/api/accounts/${id}/photo`, { photo }); load(); } catch (x) { $('#perr').textContent = x.message; } }
$('#chg').onclick = () => $('#file').click();
$('#rm').onclick = () => savePhoto('');
$('#file').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (!f) return; try { savePhoto(await resizeImage(f)); } catch (x) { $('#perr').textContent = x.message; } };
$('#addpet').onclick = () => petDialog(null);
bindForm('#f', async d => { $('#ok').hidden = true; await api(`/api/accounts/${id}/update`, d); $('#ok').hidden = false; load(); });
load().catch(x => $('#perr').textContent = x.message);
</script>
<?php bottom(); ?>

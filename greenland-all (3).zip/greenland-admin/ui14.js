// Update 15 - look and feel helpers. Loaded only when UI_UPGRADE is true in config.php.
// app.js already works without this file: its small wrappers (pav, uic, spark, trendHTML) return '' when window.UI14 is missing.
(function () {
  const A = 'viewBox="0 0 24 24" aria-hidden="true"';
  const I = {
    paw: '<circle cx="6" cy="11" r="2"/><circle cx="10" cy="6" r="2"/><circle cx="14" cy="6" r="2"/><circle cx="18" cy="11" r="2"/><path d="M12 12c-3 0-5.5 3-5.5 5.2 0 1.8 1.5 2.3 3 2 1-.2 1.6-.5 2.5-.5s1.5.3 2.5.5c1.5.3 3-.2 3-2C17.5 15 15 12 12 12z"/>',
    dog: '<ellipse cx="12" cy="13" rx="5.5" ry="6"/><path d="M6.5 9 4 7c-1 3 0 6 2 8"/><path d="M17.5 9 20 7c1 3 0 6-2 8"/><circle cx="12" cy="15" r=".8"/>',
    cat: '<path d="M5 9V3l5 3h4l5-3v6a7 7 0 0 1-14 0z"/><path d="M9.5 11v.01M14.5 11v.01"/>',
    syringe: '<path d="m18 2 4 4"/><path d="m17 7 3-3"/><path d="M19 9 8.7 19.3a2 2 0 0 1-2.8 0l-1.2-1.2a2 2 0 0 1 0-2.8L15 5"/><path d="m9 11 4 4"/><path d="m5 19-3 3"/><path d="m14 4 6 6"/>',
    stethoscope: '<path d="M11 2v2"/><path d="M5 2v2"/><path d="M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1"/><path d="M8 15a6 6 0 0 0 12 0v-3"/><circle cx="20" cy="10" r="2"/>',
    bed: '<path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8"/><path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4"/><path d="M12 4v6"/><path d="M2 18h20"/>',
    scalpel: '<path d="M3 21l7-7"/><path d="M9 15l3-3"/><path d="M12 12c3-1 6-4 9-9-5 3-8 6-9 9z"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    receipt: '<path d="M4 2v20l3-2 3 2 3-2 3 2 3-2V2l-3 2-3-2-3 2-3-2z"/><path d="M8 8h8M8 12h8"/>',
    wallet: '<path d="M20 12V8H6a2 2 0 0 1 0-4h12v4"/><path d="M4 6v12a2 2 0 0 0 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>',
    box: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    cash: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    alert: '<path d="M12 3 2 21h20z"/><path d="M12 10v5M12 18v.01"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>'
  };
  const icon = n => `<svg ${A}>${I[n] || I.paw}</svg>`;
  const kind = sp => { const s = String(sp || '').toLowerCase(); return /dog|canine|puppy/.test(s) ? 'dog' : /cat|feline|kitten/.test(s) ? 'cat' : 'oth'; };
  // a round pet picture: the real photo if we have one, otherwise a coloured circle with the first letter and a small dog / cat / paw mark
  function pav(name, species, photo, cls) {
    const k = kind(species), l = String(name || '?').trim().charAt(0).toUpperCase() || '?', mark = `<span class="sp"><svg ${A}>${I[k === 'oth' ? 'paw' : k]}</svg></span>`;
    if (photo) return `<span class="pav ${k} ${cls || ''}" style="background-image:url(${photo})" title="${E(name)}">${mark}</span>`;
    return `<span class="pav ${k} ${cls || ''}" title="${E(name)}">${E(l)}${mark}</span>`;
  }
  // a tiny line chart for a KPI card; values is an array of numbers (oldest first)
  function spark(values) {
    const v = (values || []).map(Number); if (v.length < 2) return '';
    const w = 100, h = 24, max = Math.max(...v), min = Math.min(...v), span = (max - min) || 1;
    const pts = v.map((n, i) => [(i / (v.length - 1)) * w, h - 3 - ((n - min) / span) * (h - 6)]);
    const line = pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' '), last = pts[pts.length - 1];
    return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><polygon class="ar" points="0,${h} ${line} ${w},${h}"/><polyline points="${line}" vector-effect="non-scaling-stroke"/><circle cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="2" vector-effect="non-scaling-stroke"/></svg>`;
  }
  // "up 3 from last Saturday"
  function trend(cur, prev, what, fmt) {
    if (prev === null || prev === undefined) return '';
    const d = Number(cur) - Number(prev), f = fmt || (n => n), cls = d > 0 ? 'up' : d < 0 ? 'dn' : 'eq';
    const txt = d === 0 ? 'same as' : (d > 0 ? 'up ' : 'down ') + f(Math.abs(d)) + ' from';
    return `<div class="tr ${cls}"><b>${d > 0 ? '▲' : d < 0 ? '▼' : '▬'}</b><span>${txt} ${what}</span></div>`;
  }
  // appointment / bill status -> one of the six shared colours
  const ST = { Pending: 'wait', Unpaid: 'wait', 'Partially paid': 'wait', Waiting: 'wait', Confirmed: 'room', 'In room': 'room', Arrived: 'room', Admitted: 'conf', Confined: 'conf',
    Completed: 'done', Discharged: 'done', Paid: 'done', Referred: 'ref', Emergency: 'emerg', Cancelled: 'emerg' };
  const stOf = s => ST[s] || '';

  window.UI14 = { on: true, icon, pav, spark, trend, stOf, kind };

  // ---- dark mode switch (staff and vet only: set by UI_DARK_MODE) ----
  function setTheme(t) { try { localStorage.setItem('gv_theme', t); } catch (e) {} document.documentElement.dataset.theme = t === 'dark' ? 'dark' : ''; }
  document.addEventListener('DOMContentLoaded', () => {
    if (!(window.UI14_CFG && UI14_CFG.dark)) return;
    const bar = document.querySelector('header.bar') || document.querySelector('.pubnav') || document.body; if (document.getElementById('themeBtn')) return;
    const floating = bar === document.body;   // login and sign-up pages have no top bar: float the button in the corner
    const b = document.createElement('button'); b.type = 'button'; b.className = 'themebtn noprint'; b.id = 'themeBtn'; b.title = 'Switch between light and dark'; b.setAttribute('aria-label', 'Switch between light and dark');
    b.innerHTML = `<svg class="moon" ${A}>${I.moon}</svg><svg class="sun" ${A}>${I.sun}</svg>`;
    b.onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
    if (floating) { b.style.cssText = 'position:fixed;top:1rem;right:1rem;z-index:50'; bar.append(b); return; }
    const av = document.getElementById('av'); bar.insertBefore(b, av || null);
  });

  // ---- "Now serving" for the front desk (staff app, UI_NOW_SERVING) ----
  // A full card on the dashboard (#nsCard) and a small collapsible panel on every other staff page (not on the Queue page, which has the board).
  function nsRows(d, fresh) {
    const serving = d.serving.length ? d.serving.map(s => `<div class="ns-row st-room ${fresh.includes(s.id) ? 'fresh' : ''}" style="--stc:var(--st-room)"><span class="no">${s.no || '&bull;'}</span>${pav(s.pet, s.species, null, 'sm')}<div><b>${E(s.pet)}</b><small>${E(s.client)} &middot; ${E(s.service)}${s.vet ? ' &middot; ' + E(s.vet) : ''}</small><small>${s.with_vet ? 'With the vet' : 'Called, please bring them in'} &middot; since ${fmtTime(s.since)}</small></div><span class="rm">${E(s.room || '')}</span></div>`).join('') : '<div class="ns-empty">No one is being seen right now.</div>';
    const next = d.next.length ? d.next.map(n => `<div class="ns-row nx ${n.priority ? 'em' : ''}"><span class="no">${n.no || '&bull;'}</span>${pav(n.pet, n.species, null, 'sm')}<div><b>${E(n.pet)}</b><small>${E(n.client)}${n.priority ? ' &middot; emergency' : ''}</small></div><small>${n.wait_text ? E(n.wait_text) : 'no vet on duty'}</small></div>`).join('') + (d.more ? `<div class="ns-empty">and ${d.more} more waiting</div>` : '') : '<div class="ns-empty">Nobody is waiting.</div>';
    return [serving, next];
  }
  function ding() { try { const c = ding.c = ding.c || new (window.AudioContext || window.webkitAudioContext)(); [880, 1175].forEach((f, i) => { const o = c.createOscillator(), g = c.createGain(); o.frequency.value = f; o.connect(g); g.connect(c.destination); const t = c.currentTime + i * .22; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.2, t + .03); g.gain.exponentialRampToValueAtTime(.0001, t + .4); o.start(t); o.stop(t + .45); }); } catch (e) {} }
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
  // which patients were already being seen the last time any page looked: the new ones are "their turn now"
  function nsFresh(d) {
    let prev = null; try { prev = JSON.parse(sessionStorage.getItem('gv_ns') || 'null'); } catch (e) {}
    const ids = d.serving.map(s => s.id); try { sessionStorage.setItem('gv_ns', JSON.stringify(ids)); } catch (e) {}
    return prev === null ? [] : ids.filter(i => !prev.includes(i));
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (!(window.UI14_CFG && UI14_CFG.ns) || !document.querySelector('header.bar')) return;
    const card = document.getElementById('nsCard'), onQueue = !!document.getElementById('board');
    if (!card && onQueue) return;
    let panel = null, open = lsGet('gv_ns_open', '0') === '1', sound = lsGet('gv_ns_sound', '0') === '1', last = null, hideT = null;
    if (!card) {
      panel = document.createElement('div'); panel.className = 'nspanel noprint'; panel.hidden = true; document.body.append(panel);
    }
    const draw = (d, fresh) => {
      const [sv, nx] = nsRows(d, fresh), calls = d.serving.filter(s => fresh.includes(s.id));
      const ctl = `<span class="ctl"><button type="button" data-snd>${sound ? 'Sound on' : 'Sound off'}</button><a class="link" href="checkin.php">Full queue &rsaquo;</a></span>`;
      if (card) {
        card.innerHTML = `<div class="ns-h"><h2>Now serving &middot; ${E(d.branch)}</h2>${ctl}</div><div class="ns-grid"><div class="ns-col"><h4>In the rooms</h4>${sv}</div><div class="ns-col"><h4>Next in line</h4>${nx}</div></div>`;
        const b = card.querySelector('[data-snd]'); b.onclick = () => { sound = !sound; lsSet('gv_ns_sound', sound ? '1' : '0'); b.textContent = sound ? 'Sound on' : 'Sound off'; if (sound) ding(); };
      } else {
        const first = d.serving[0], nextN = d.next[0];
        const label = `Now ${d.serving.length ? d.serving.map(s => '#' + (s.no || '\u2022')).join(' ') : 'none'} \u00B7 Next ${nextN ? '#' + (nextN.no || '\u2022') : 'none'}`;
        panel.innerHTML = `<div class="box" ${open ? '' : 'hidden'}>${calls.map(s => `<div class="call">#${s.no || ''} ${E(s.pet)}: go to ${E(s.room || 'a room')}</div>`).join('')}<div class="ns-h"><b>Now serving</b>${ctl}</div><div class="ns-col"><h4>In the rooms</h4>${sv}</div><div class="ns-col"><h4>Next in line</h4>${nx}</div></div><button type="button" class="pill-t" data-tog aria-expanded="${open}"><i></i><span>${E(label)}</span></button>`;
        panel.hidden = false; panel.classList.toggle('hasnew', calls.length > 0);
        panel.querySelector('[data-tog]').onclick = () => { open = !open; lsSet('gv_ns_open', open ? '1' : '0'); panel.querySelector('.box').hidden = !open; panel.classList.remove('hasnew'); };
        const b = panel.querySelector('[data-snd]'); b.onclick = () => { sound = !sound; lsSet('gv_ns_sound', sound ? '1' : '0'); b.textContent = sound ? 'Sound on' : 'Sound off'; if (sound) ding(); };
        if (calls.length && !open) { panel.querySelector('.box').hidden = false; clearTimeout(hideT); hideT = setTimeout(() => { if (!open) { const bx = panel.querySelector('.box'); if (bx) bx.hidden = true; } panel.classList.remove('hasnew'); }, 12000); }
      }
      if (calls.length && sound) ding();
    };
    const load = async () => {
      try { const d = await api('/api/nowserving'); const fresh = nsFresh(d); const sig = JSON.stringify(d); if (sig !== last || fresh.length) { last = sig; draw(d, fresh); } }
      catch (x) { if (card) card.innerHTML = `<p class="muted">${E(x.message)}</p>`; }
    };
    load(); setInterval(load, 15000);
  });
})();

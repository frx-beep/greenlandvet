<?php require 'authlib.php'; auth_open('Reset password'); ?>
<h3>Choose a new password</h3><p class="muted">Enter and confirm your new password.</p>
<form id="f" class="form" novalidate>
  <label>New password (8+ characters)<input name="password" type="password" autocomplete="new-password"><small class="ferr" data-f="password"></small></label>
  <label>Confirm new password<input name="confirm" type="password" autocomplete="new-password"><small class="ferr" data-f="confirm"></small></label>
  <p class="err"></p><button class="btn wide">Reset password</button>
</form>
<div id="done" hidden><p class="okmsg">Your password has been reset.</p><a class="btn wide" href="login.php">Go to login</a></div>
<script>bindForm('#f', async d => { await api('/api/auth/reset', { ...d, token: param('token') }); $('#f').hidden = true; $('#done').hidden = false; });</script>
<?php auth_close(); ?>

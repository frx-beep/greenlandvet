<?php require 'layout.php'; top('Reports & Analytics', 'r', 'Admin Console > Reports & Analytics'); ?>
<div class="filters">
  <label>From<input type="date" id="from"></label><label>To<input type="date" id="to"></label>
  <label>Branch<select id="br"><option value="">Both branches</option><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select></label>
  <div class="tabs2" style="margin:0"><button type="button" data-r="7">Last 7 days</button><button type="button" data-r="30" class="on">Last 30 days</button><button type="button" data-r="90">Last 90 days</button></div>
  <button class="btn ghost sm" id="csv" type="button">Download CSV</button>
</div>
<p class="err" id="err"></p>
<div class="kpis" id="kpis"></div>
<div class="charts">
  <div class="card chart wide" id="c-daily"></div>
  <div class="card chart" id="c-service"></div>
  <div class="card chart" id="c-vet"></div>
  <div class="card chart" id="c-cancel"></div>
  <div class="card chart" id="c-reasons"></div>
  <div class="card chart" id="c-sales"></div>
  <div class="card chart" id="c-pay"></div>
  <div class="card chart" id="c-branch"></div>
<?php if (ui_on()): ?>  <div class="card chart" id="c-weekday"></div>
  <div class="card chart" id="c-due"></div>
<?php endif; ?></div>
<script>
const COL = { booked: 'var(--c1)', completed: 'var(--c2)', cancelled: 'var(--c3)' };   // fixed order: blue, aqua, orange; colour follows the measure
const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const fmtN = n => Number(n).toLocaleString('en');
const NS = 'http://www.w3.org/2000/svg';
const svgEl = (t, a = {}, p) => { const e = document.createElementNS(NS, t); for (const k in a) e.setAttribute(k, a[k]); if (p) p.append(e); return e; };
const niceMax = v => { if (v <= 4) return 4; const p = Math.pow(10, Math.floor(Math.log10(v))), f = v / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; };
let DATA = null;

// A chart card: title, a chart/table switch, a body. `draw(body)` paints the chart, `table` = {cols, rows} is the equivalent table.
function card(id, title, sub, draw, table, empty) {
  const el = $('#c-' + id); el.innerHTML = `<div class="head"><div><h2>${E(title)}</h2><small class="muted">${E(sub)}</small></div><button type="button" class="btn plain sm" data-t>View table</button></div><div class="body"></div>`;
  const body = $('.body', el); let tv = false;
  const paint = () => {
    body.innerHTML = '';
    if (empty) { body.innerHTML = `<p class="muted empty">${E(empty)}</p>`; return; }
    if (tv) body.innerHTML = `<table class="tbl-sm"><thead><tr>${table.cols.map(c => `<th>${E(c)}</th>`).join('')}</tr></thead><tbody>${table.rows.map(r => `<tr>${r.map(c => `<td>${E(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    else draw(body);
    $('[data-t]', el).textContent = tv ? 'View chart' : 'View table';
  };
  $('[data-t]', el).onclick = () => { tv = !tv; paint(); }; $('[data-t]', el).hidden = !!empty; paint();
}
function tipBox(host) { const t = document.createElement('div'); t.className = 'tip'; t.hidden = true; host.append(t); return t; }
function placeTip(t, host, x, y) { const w = host.clientWidth; t.hidden = false; t.style.left = Math.min(Math.max(4, x + 14), w - t.offsetWidth - 4) + 'px'; t.style.top = Math.max(4, y - t.offsetHeight - 10) + 'px'; }
function legend(body, items, line) { const l = document.createElement('div'); l.className = 'legend'; items.forEach(([n, c]) => { const s = document.createElement('span'); const i = document.createElement('i'); i.className = line ? 'l' : ''; i.style.background = c; s.append(i, n); l.append(s); }); body.append(l); }

// Line chart: crosshair snaps to the nearest day; one tooltip lists every series.
function lineChart(body, labels, series) {
  const W = Math.max(300, Math.round(body.clientWidth)), H = 260, m = { l: 36, r: 14, t: 10, b: 28 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
  const max = niceMax(Math.max(1, ...series.flatMap(s => s.values))), n = labels.length, X = i => m.l + (n < 2 ? iw / 2 : i * iw / (n - 1)), Y = v => m.t + ih - v / max * ih;
  legend(body, series.map(s => [s.name, s.color]), true);
  const wrap = document.createElement('div'); wrap.style.position = 'relative'; body.append(wrap);
  const svg = svgEl('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Line chart of ' + series.map(s => s.name).join(', ') + ' per day' }, wrap);
  for (let k = 0; k <= 4; k++) { const v = max / 4 * k, y = Y(v); svgEl('line', { class: k ? 'gl' : 'ax', x1: m.l, x2: W - m.r, y1: y, y2: y }, svg); svgEl('text', { x: m.l - 6, y: y + 4, 'text-anchor': 'end' }, svg).textContent = fmtN(Math.round(v * 10) / 10); }
  const step = Math.max(1, Math.ceil(n / 7));
  labels.forEach((l, i) => { if (i === n - 1 || (i % step === 0 && n - 1 - i >= Math.ceil(step * .7))) svgEl('text', { x: X(i), y: H - 8, 'text-anchor': i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle' }, svg).textContent = shortDay(l); });
  series.forEach(s => svgEl('path', { class: 'ln', stroke: s.color, d: s.values.map((v, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1)).join('') }, svg));
  const xh = svgEl('line', { class: 'xh', y1: m.t, y2: m.t + ih, visibility: 'hidden' }, svg), dots = series.map(s => svgEl('circle', { r: 4, fill: s.color, stroke: '#fff', 'stroke-width': 2, visibility: 'hidden' }, svg));
  const tip = tipBox(wrap), hit = svgEl('rect', { x: m.l, y: m.t, width: iw, height: ih, fill: 'transparent', tabindex: 0 }, svg);
  const at = i => {
    xh.setAttribute('x1', X(i)); xh.setAttribute('x2', X(i)); xh.setAttribute('visibility', 'visible'); dots.forEach((d, k) => { d.setAttribute('cx', X(i)); d.setAttribute('cy', Y(series[k].values[i])); d.setAttribute('visibility', 'visible'); });
    tip.innerHTML = ''; const d = document.createElement('div'); d.className = 'td'; d.textContent = fmtDate(labels[i]); tip.append(d);
    series.forEach(s => { const r = document.createElement('div'); r.className = 'tr'; const k = document.createElement('i'); k.style.background = s.color; const v = document.createElement('b'); v.textContent = fmtN(s.values[i]); const nm = document.createElement('span'); nm.className = 'muted'; nm.textContent = s.name; r.append(k, v, nm); tip.append(r); });
    placeTip(tip, wrap, X(i) / W * wrap.clientWidth, m.t + 40);
  };
  const idxOf = ev => { const r = svg.getBoundingClientRect(), x = (ev.clientX - r.left) / r.width * W; return Math.max(0, Math.min(n - 1, Math.round((x - m.l) / iw * (n - 1)))); };
  hit.addEventListener('pointermove', ev => at(idxOf(ev)));
  hit.addEventListener('pointerleave', () => { xh.setAttribute('visibility', 'hidden'); dots.forEach(d => d.setAttribute('visibility', 'hidden')); tip.hidden = true; });
  let fi = n - 1; hit.addEventListener('focus', () => at(fi));
  hit.addEventListener('keydown', ev => { if (ev.key === 'ArrowLeft') fi = Math.max(0, fi - 1); else if (ev.key === 'ArrowRight') fi = Math.min(n - 1, fi + 1); else return; ev.preventDefault(); at(fi); });
}
const shortDay = d => new Date(d + 'T00:00:00').toLocaleDateString('en', { month: 'short', day: 'numeric' });

// Vertical bars: each bar is its own hover/focus target, thin (max 24 px) with a 4 px rounded top.
function colChart(body, labels, values, color, name, money) {
  const W = Math.max(300, Math.round(body.clientWidth)), H = 240, m = { l: 44, r: 10, t: 10, b: 28 }, iw = W - m.l - m.r, ih = H - m.t - m.b, n = labels.length;
  const max = niceMax(Math.max(1, ...values)), slot = iw / n, bw = Math.min(24, slot * .7), Y = v => m.t + ih - v / max * ih, f = v => money ? peso(v) : fmtN(v);
  const wrap = document.createElement('div'); wrap.style.position = 'relative'; body.append(wrap);
  const svg = svgEl('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': name + ' per day' }, wrap), tip = tipBox(wrap);
  for (let k = 0; k <= 4; k++) { const v = max / 4 * k, y = Y(v); svgEl('line', { class: k ? 'gl' : 'ax', x1: m.l, x2: W - m.r, y1: y, y2: y }, svg); svgEl('text', { x: m.l - 6, y: y + 4, 'text-anchor': 'end' }, svg).textContent = money && v >= 1000 ? fmtN(v / 1000) + 'k' : fmtN(Math.round(v)); }
  const step = Math.max(1, Math.ceil(n / 7));
  labels.forEach((l, i) => {
    const x = m.l + slot * i + slot / 2, h = Math.max(values[i] ? 2 : 0, ih - (Y(values[i]) - m.t));
    if (i % step === 0) svgEl('text', { x, y: H - 8, 'text-anchor': 'middle' }, svg).textContent = shortDay(l);
    const g = svgEl('g', {}, svg);
    svgEl('rect', { x: x - slot / 2, y: m.t, width: slot, height: ih, fill: 'transparent' }, g);   // wide hit area
    const r = svgEl('rect', { class: 'col', x: x - bw / 2, y: m.t + ih - h, width: bw, height: h, rx: 3, fill: color, tabindex: 0 }, g);
    const show = () => { tip.innerHTML = ''; const d = document.createElement('div'); d.className = 'td'; d.textContent = fmtDate(l); const v = document.createElement('b'); v.textContent = f(values[i]); const s = document.createElement('div'); s.className = 'muted'; s.textContent = name; tip.append(d, v, s); placeTip(tip, wrap, x / W * wrap.clientWidth, Y(values[i]) / H * wrap.clientHeight); };
    g.addEventListener('pointermove', show); g.addEventListener('pointerleave', () => tip.hidden = true); r.addEventListener('focus', show); r.addEventListener('blur', () => tip.hidden = true);
  });
}
// Horizontal bars with the value at the end of each bar (identity is the row label, so one colour).
function hBars(body, rows, color, f = fmtN) {
  const max = Math.max(1, ...rows.map(r => r.n)), tip = tipBox(body); body.style.position = 'relative';
  rows.forEach(r => {
    const row = document.createElement('div'); row.className = 'hb'; row.tabIndex = 0;
    const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = r.name; nm.title = r.name;
    const tk = document.createElement('span'); tk.className = 'tk'; const br = document.createElement('span'); br.className = 'br'; br.style.width = (r.n / max * 100) + '%'; br.style.background = color; tk.append(br);
    const v = document.createElement('span'); v.className = 'v'; v.textContent = f(r.n); row.append(nm, tk, v); body.append(row);
    const show = ev => { tip.innerHTML = ''; const b = document.createElement('b'); b.textContent = f(r.n); const s = document.createElement('div'); s.className = 'muted'; s.textContent = r.name; tip.append(b, s); const bb = body.getBoundingClientRect(), rr = row.getBoundingClientRect(); placeTip(tip, body, ev && ev.clientX ? ev.clientX - bb.left : 120, rr.top - bb.top + 6); };
    row.addEventListener('pointermove', show); row.addEventListener('pointerleave', () => tip.hidden = true); row.addEventListener('focus', () => show()); row.addEventListener('blur', () => tip.hidden = true);
  });
}
function kpi(label, val, sub) { return `<div class="card"><h2>${E(label)}</h2><div class="big">${E(val)}</div><small class="muted">${E(sub || '')}</small></div>`; }
const pct = (a, b) => b ? Math.round(a / b * 100) + '%' : '0%';

function days(from, to) { const out = []; for (let d = new Date(from + 'T00:00:00'); ymd(d) <= to; d.setDate(d.getDate() + 1)) out.push(ymd(d)); return out; }
function render(r) {
  DATA = r; const k = r.kpi, labels = days(r.from, r.to), dm = Object.fromEntries(r.daily.map(x => [x.d, x])), sm = Object.fromEntries(r.salesDaily.map(x => [x.d, x]));
  $('#kpis').innerHTML = kpi('Appointments booked', fmtN(k.booked), `${fmtN(k.online)} online, ${fmtN(k.clinic)} at the clinic`) + kpi('Completed visits', fmtN(k.completed), pct(k.completed, k.booked) + ' of booked')
    + kpi('Cancellations', fmtN(k.cancelled), pct(k.cancelled, k.booked) + ' of booked') + kpi('Bills', fmtN(k.sales), 'in this period') + kpi('Money collected', peso(k.revenue), (k.uncleared > 0 ? peso(k.uncleared) + ' in checks not yet cleared (not counted)' : 'cash, GCash, card and cleared checks'))
    + kpi('Unpaid balances', peso(k.outstanding), `Unpaid bills today: 0-30 days ${peso(k.ageing['0-30'])}, 31-60 ${peso(k.ageing['31-60'])}, over 60 ${peso(k.ageing['60+'])}`);
  const none = k.booked ? '' : 'No appointments in this period.';
  const per = fmtDate(r.from) + ' to ' + fmtDate(r.to) + (r.br ? ', ' + r.br : '');
  const dv = key => labels.map(d => +(dm[d]?.[key] || 0));
  card('daily', 'Appointments per day', per, b => { lineChart(b, labels, [{ name: 'Booked', color: COL.booked, values: dv('booked') }, { name: 'Completed', color: COL.completed, values: dv('completed') }, { name: 'Cancelled', color: COL.cancelled, values: dv('cancelled') }]); },
    { cols: ['Date', 'Booked', 'Completed', 'Cancelled'], rows: labels.map(d => [fmtDate(d), dm[d]?.booked || 0, dm[d]?.completed || 0, dm[d]?.cancelled || 0]) }, none);
  const nr = a => a.map(x => ({ name: x.name, n: +x.n }));
  card('service', 'By service', 'Excluding cancelled', b => hBars(b, nr(r.byService), COL.booked), { cols: ['Service', 'Appointments'], rows: r.byService.map(x => [x.name, x.n]) }, r.byService.length ? '' : 'No appointments in this period.');
  card('vet', 'By veterinarian', 'Top 8, excluding cancelled', b => hBars(b, nr(r.byVet), COL.booked), { cols: ['Veterinarian', 'Appointments'], rows: r.byVet.map(x => [x.name, x.n]) }, r.byVet.length ? '' : 'No appointments in this period.');
  const cb = Object.entries(k.cancel_by).map(([name, n]) => ({ name: name === 'System' ? 'System (' + <?= (int)LATE_CANCEL_MINUTES ?> + ' min late)' : name, n }));
  card('cancel', 'Cancelled by', 'Who cancelled the appointment', b => hBars(b, cb, COL.cancelled), { cols: ['Cancelled by', 'Appointments'], rows: cb.map(x => [x.name, x.n]) }, k.cancelled ? '' : 'No cancellations in this period.');
  card('reasons', 'Cancellation reasons', 'Most common', b => hBars(b, nr(r.reasons), COL.cancelled), { cols: ['Reason', 'Appointments'], rows: r.reasons.map(x => [x.name, x.n]) }, r.reasons.length ? '' : 'No cancellations in this period.');
  card('sales', 'Money collected per day', 'By bill date, payments received', b => colChart(b, labels, labels.map(d => +(sm[d]?.total || 0)), COL.booked, 'Revenue', true),
    { cols: ['Date', 'Bills', 'Collected'], rows: labels.filter(d => sm[d]).map(d => [fmtDate(d), sm[d].n, peso(sm[d].total)]) }, k.sales ? '' : 'No sales in this period.');
  card('pay', 'Collected by payment method', 'Cleared payments only', b => hBars(b, r.payments.map(x => ({ name: x.name, n: +x.total })), COL.completed, peso), { cols: ['Payment', 'Payments', 'Collected'], rows: r.payments.map(x => [x.name, x.n, peso(x.total)]) }, r.payments.length ? '' : 'No sales in this period.');
  card('branch', 'By branch', 'Both branches, same dates', b => { b.innerHTML = `<table class="tbl-sm"><thead><tr><th>Branch</th><th>Booked</th><th>Completed</th><th>Cancelled</th></tr></thead><tbody>${r.byBranch.map(x => `<tr><td>${E(x.name)}</td><td>${fmtN(x.booked)}</td><td>${fmtN(x.completed)}</td><td>${fmtN(x.cancelled)}</td></tr>`).join('')}</tbody></table>`; },
    { cols: ['Branch', 'Booked', 'Completed', 'Cancelled'], rows: r.byBranch.map(x => [x.name, x.booked, x.completed, x.cancelled]) }, r.byBranch.length ? '' : 'No appointments in this period.');
  // Update 15: two more charts (only on the page when UI_UPGRADE is on)
  if ($('#c-weekday')) {
    const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], wc = [0, 0, 0, 0, 0, 0, 0];
    labels.forEach(d => { wc[new Date(d + 'T00:00:00').getDay()] += +(dm[d]?.booked || 0) - +(dm[d]?.cancelled || 0); });
    const wr = [1, 2, 3, 4, 5, 6, 0].map(i => ({ name: WD[i], n: wc[i] }));
    card('weekday', 'Busiest days of the week', 'Appointments in this period, excluding cancelled', b => hBars(b, wr, COL.booked), { cols: ['Day', 'Appointments'], rows: wr.map(x => [x.name, x.n]) }, k.booked ? '' : 'No appointments in this period.');
  }
  if ($('#c-due')) {
    const nxt = []; for (let i = 0; i < 14; i++) { const d = new Date(); d.setDate(d.getDate() + i); nxt.push(ymd(d)); }
    const dd = Object.fromEntries((r.due || []).map(x => [x.d, +x.n])), tot = nxt.reduce((a, d) => a + (dd[d] || 0), 0);
    card('due', 'Vaccinations coming due', 'Next 14 days, from the next date typed on each vaccination record', b => colChart(b, nxt, nxt.map(d => dd[d] || 0), COL.completed, 'Vaccinations due', false),
      { cols: ['Date', 'Due'], rows: nxt.filter(d => dd[d]).map(d => [fmtDate(d), dd[d]]) }, tot ? '' : 'No vaccination is due in the next 14 days.');
  }
}
async function load() {
  $('#err').textContent = '';
  try { render(await api(`/api/reports?from=${$('#from').value}&to=${$('#to').value}&branch=${encodeURIComponent($('#br').value)}`)); } catch (x) { $('#err').textContent = x.message; }
}
function setRange(n) { const t = new Date(), f = new Date(); f.setDate(t.getDate() - (n - 1)); $('#from').value = ymd(f); $('#to').value = ymd(t); $$('.tabs2 button').forEach(b => b.classList.toggle('on', +b.dataset.r === n)); }
$$('.tabs2 button').forEach(b => b.onclick = () => { setRange(+b.dataset.r); load(); });
['from', 'to', 'br'].forEach(id => $('#' + id).onchange = () => { if (id !== 'br') $$('.tabs2 button').forEach(b => b.classList.remove('on')); load(); });
$('#csv').onclick = () => {
  if (!DATA) return; const q = v => '"' + String(v).replace(/"/g, '""') + '"', labels = days(DATA.from, DATA.to), dm = Object.fromEntries(DATA.daily.map(x => [x.d, x])), sm = Object.fromEntries(DATA.salesDaily.map(x => [x.d, x]));
  const rows = [['Date', 'Booked', 'Completed', 'Cancelled', 'Bills', 'Collected'], ...labels.map(d => [d, dm[d]?.booked || 0, dm[d]?.completed || 0, dm[d]?.cancelled || 0, sm[d]?.n || 0, sm[d]?.total || 0])];
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([rows.map(r => r.map(q).join(',')).join('\r\n')], { type: 'text/csv' })); a.download = `greenland-report-${DATA.from}-to-${DATA.to}.csv`; a.click();
};
let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => DATA && render(DATA), 200); });
$('#from').max = $('#to').max = ymd(new Date()); setRange(30); load();
</script>
<?php bottom(); ?>

<?php require 'layout.php'; top('All Accounts', 'a', 'Admin Console > Accounts'); ?>
<div class="toolbar"><input id="q" placeholder="Search by name, email, or username..." style="flex:1">
  <select id="b" style="width:12rem"><option value="">All branches</option><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select>
  <select id="s" style="width:12rem"><option value="">All statuses</option><option>Active</option><option>Disabled</option></select>
  <a class="btn" href="account_new.php">+ Create Account</a></div>
<div class="tabs2" id="tabs"></div>
<div class="card"><table><thead><tr><th>Name</th><th>Role</th><th>Email / Username</th><th>Branch</th><th>Status</th><th>Last Login</th><th>Actions</th></tr></thead><tbody id="rows"></tbody></table>
  <div class="pager"><span id="info"></span><div id="pages"></div></div></div>
<script>
let role = '', page = 1, t;
$('#q').value = param('q') || '';
async function load() {
  const r = await api(`/api/accounts?role=${role}&page=${page}&q=${encodeURIComponent($('#q').value.trim())}&branch=${$('#b').value}&status=${$('#s').value}`);
  const c = r.counts, all = (c.client || 0) + (c.staff || 0) + (c.vet || 0);
  $('#tabs').innerHTML = [['', `All (${all})`], ['client', `Clients (${c.client || 0})`], ['staff', `Staff (${c.staff || 0})`], ['vet', `Vets (${c.vet || 0})`]]
    .map(([k, l]) => `<button class="${k === role ? 'on' : ''}" data-r="${k}">${l}</button>`).join('');
  $$('#tabs button').forEach(b => b.onclick = () => { role = b.dataset.r; page = 1; load(); });
  $('#rows').innerHTML = r.rows.length ? r.rows.map(a => `<tr><td>${E(a.name)}</td><td>${roleName(a.role)}</td><td>${E(a.email + ' (' + a.username + ')')}</td><td>${E(a.branch || '-')}</td>
    <td>${badge(a.status === 'Active' ? 'Confirmed' : 'Discharged').replace(/Confirmed|Discharged/, a.status)}${+a.email_verified ? '' : ' <span class="badge p">Unverified</span>'}</td><td>${a.last_login ? fmtDate(a.last_login.slice(0, 10)) : 'Never'}</td>
    <td><div class="acts"><a class="link" href="account.php?id=${a.id}">View</a><a class="link" href="account_edit.php?id=${a.id}">Edit</a><a class="link" href="account_reset.php?id=${a.id}">Reset</a>
    <a class="link" href="account_disable.php?id=${a.id}">${a.status === 'Active' ? 'Disable' : 'Enable'}</a></div></td></tr>`).join('') : '<tr><td colspan="7" class="empty">No accounts match.</td></tr>';
  const pages = Math.max(1, Math.ceil(r.total / r.per));
  $('#info').textContent = r.total ? `Showing ${(page - 1) * r.per + 1}-${Math.min(page * r.per, r.total)} of ${r.total} accounts` : '';
  $('#pages').innerHTML = Array.from({ length: pages }, (_, i) => `<button data-p="${i + 1}" class="${i + 1 === page ? 'on' : ''}">${i + 1}</button>`).join('');
  $$('#pages button').forEach(b => b.onclick = () => { page = +b.dataset.p; load(); });
}
$('#q').oninput = () => { clearTimeout(t); t = setTimeout(() => { page = 1; load(); }, 250); };
['b', 's'].forEach(i => $('#' + i).onchange = () => { page = 1; load(); });
load();
</script>
<?php bottom(); ?>

<?php require 'authlib.php'; require_login(); auth_open('Set a new password'); ?>
<h3>Set a new password</h3><p class="muted">For your security, please choose a new password before continuing.</p>
<form id="f" class="form" novalidate>
  <label>New password (8+ characters)<input name="password" type="password" autocomplete="new-password"><small class="ferr" data-f="password"></small></label>
  <label>Confirm new password<input name="confirm" type="password" autocomplete="new-password"><small class="ferr" data-f="confirm"></small></label>
  <p class="err"></p><button class="btn wide">Save password</button>
</form>
<script>bindForm('#f', async d => { const r = await api('/api/auth/change', d); location = r.next; });</script>
<?php auth_close(); ?>

<?php require 'authlib.php'; if (current_account()) { header('Location: ' . HOME); exit; } auth_open(LOGIN_TITLE); ?>
<h3><?= LOGIN_TITLE ?></h3><p class="muted"><?= LOGIN_SUB ?></p>
<form id="f" class="form" novalidate>
  <?php if (NEEDS_BRANCH): ?><label>Branch<select name="branch"><option value="">Select branch</option><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select><small class="ferr" data-f="branch"></small></label><?php endif; ?>
  <label><?= LOGIN_BY === 'email' ? 'Email Address' : 'Username' ?><input name="identity" autocomplete="username" placeholder="<?= LOGIN_BY === 'email' ? 'you@email.com' : 'Enter username' ?>"><small class="ferr" data-f="identity"></small></label>
  <label>Password<input name="password" type="password" autocomplete="current-password" placeholder="Enter password"><small class="ferr" data-f="password"></small></label>
  <p class="err"></p><button class="btn wide">Sign In</button>
</form>
<?php if (APP_ROLE === 'client'): ?><p class="center" style="margin:1rem 0 .25rem"><a class="link" href="forgot.php">Forgot password?</a></p><p class="center muted" style="margin:.25rem 0">New here? <a class="link" href="register.php">Create an account</a></p><?php endif; ?>
<script>bindForm('#f', async d => { const r = await api('/api/auth/login', d); location = r.next; });</script>
<?php auth_close(); ?>

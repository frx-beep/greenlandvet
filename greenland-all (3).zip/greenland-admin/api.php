<?php
require 'authlib.php';
$me   = require_login(true);
$in   = json_decode(file_get_contents('php://input'), true) ?? [];
$path = trim($_SERVER['PATH_INFO'] ?? '', '/');
$p    = explode('/', $path);
$post = $_SERVER['REQUEST_METHOD'] === 'POST';
function acct(int $id): array {
    $a = q("SELECT id,role,name,email,username,branch,phone,photo,client_id,status,disabled_reason,must_change,last_login,created_at FROM accounts WHERE id=? AND role<>'admin'", [$id])->fetch();
    if (!$a) send(['error' => 'Account not found'], 404);
    return $a;
}

if (!$post && $path === 'stats') {
    $n = fn($w) => (int)q("SELECT COUNT(*) FROM accounts WHERE role<>'admin' $w")->fetchColumn();
    send(['total' => $n(''), 'client' => $n("AND role='client'"), 'staff' => $n("AND role='staff'"), 'vet' => $n("AND role='vet'"), 'disabled' => $n("AND status='Disabled'"),
          'owed' => (float)q("SELECT COALESCE(SUM(total-paid),0) FROM sales WHERE status IN ('Unpaid','Partially paid')")->fetchColumn(),
          'pending_records' => (int)q("SELECT COUNT(*) FROM appointments WHERE is_queue=1 AND status='Completed' AND record_done=0")->fetchColumn(),
          'activity' => q("SELECT a.name, a.role, l.action, l.detail, l.created_at FROM activity_log l JOIN accounts a ON a.id=l.account_id WHERE a.role<>'admin' AND l.action<>'Verification code sent' ORDER BY l.id DESC LIMIT 6")->fetchAll()]);
}
if (!$post && $path === 'accounts') {
    $w = ["role<>'admin'"]; $a = [];
    if (in_array($_GET['role'] ?? '', ['client', 'staff', 'vet'])) { $w[] = 'role=?'; $a[] = $_GET['role']; }
    if (trim($_GET['q'] ?? '') !== '') { $w[] = '(name LIKE ? OR email LIKE ? OR username LIKE ?)'; $l = '%' . trim($_GET['q']) . '%'; array_push($a, $l, $l, $l); }
    if (in_array($_GET['branch'] ?? '', BRANCHES)) { $w[] = 'branch=?'; $a[] = $_GET['branch']; }
    if (in_array($_GET['status'] ?? '', ['Active', 'Disabled'])) { $w[] = 'status=?'; $a[] = $_GET['status']; }
    $page = max(1, (int)($_GET['page'] ?? 1)); $per = 10; $off = ($page - 1) * $per; $W = implode(' AND ', $w);
    $total = (int)q("SELECT COUNT(*) FROM accounts WHERE $W", $a)->fetchColumn();
    $rows = q("SELECT id,name,role,email,username,branch,status,email_verified,last_login FROM accounts WHERE $W ORDER BY name LIMIT $per OFFSET $off", $a)->fetchAll();
    $counts = array_column(q("SELECT role, COUNT(*) n FROM accounts WHERE role<>'admin' GROUP BY role")->fetchAll(), 'n', 'role');
    send(compact('rows', 'total', 'page', 'per', 'counts'));
}
if (!$post && $p[0] === 'accounts' && count($p) === 2) {
    $a = acct((int)$p[1]);
    $a['activity'] = q("SELECT action, detail, created_at FROM activity_log WHERE account_id=? AND action<>'Verification code sent' ORDER BY id DESC LIMIT 8", [$p[1]])->fetchAll();
    if ($a['client_id']) {   // a client: show the clinic's client record and their pets
        $cl = q('SELECT address, phone FROM clients WHERE id=?', [$a['client_id']])->fetch() ?: [];
        $a['address'] = $cl['address'] ?? null; $a['phone'] = $cl['phone'] ?? $a['phone'];
        $a['pets'] = q('SELECT id,name,species,breed,sex,birthdate,photo FROM pets WHERE client_id=? ORDER BY name', [$a['client_id']])->fetchAll();
    }
    send($a);
}
if ($post && $path === 'accounts') {   // create account
    $role = $in['role'] ?? ''; $name = trim($in['name'] ?? ''); $email = strtolower(trim($in['email'] ?? '')); $pw = $in['password'] ?? '';
    if (!in_array($role, ['client', 'staff', 'vet'])) fail('Please choose a role.', 'role');
    if ($name === '') fail('Please enter the full name.', 'name');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Please enter a valid email address.', 'email');
    if (!in_array($in['branch'] ?? '', BRANCHES)) fail('Please choose a branch.', 'branch');
    $user = trim($in['username'] ?? '');
    if (!preg_match('/^[A-Za-z0-9._-]{3,30}$/', $user)) fail('Username must be 3-30 characters: letters, numbers, dots, dashes or underscores.', 'username');
    if (strlen($pw) < 8) fail('The temporary password needs at least 8 characters.', 'password');
    if (q('SELECT 1 FROM accounts WHERE LOWER(username)=?', [strtolower($user)])->fetch()) fail('That username is already taken.', 'username');
    if (q('SELECT 1 FROM accounts WHERE role=? AND LOWER(email)=?', [$role, $email])->fetch()) fail('An account with that email already exists for this role.', 'email');
    $client = null;
    if ($role === 'client') {   // link to the clinic's existing client record (same email) or create one
        $c = q('SELECT id FROM clients WHERE LOWER(email)=? LIMIT 1', [$email])->fetch();
        if ($c) $client = (int)$c['id'];
        else { q('INSERT INTO clients(name,email,branch) VALUES(?,?,?)', [$name, $email, $in['branch']]); $client = (int)db()->lastInsertId(); }
    }
    q('INSERT INTO accounts(role,name,email,username,password,branch,client_id,must_change) VALUES(?,?,?,?,?,?,?,1)', [$role, $name, $email, $user, password_hash($pw, PASSWORD_DEFAULT), $in['branch'], $client]);
    $id = (int)db()->lastInsertId(); log_act($id, 'Account created', 'by admin ' . $me['name']); log_act((int)$me['id'], 'Created an account', $name . ' (' . $role . ')'); send(['id' => $id]);
}
if ($post && $p[0] === 'accounts' && count($p) === 3) {
    $a = acct((int)$p[1]); $id = (int)$a['id'];
    if ($p[2] === 'update') {   // edit the profile
        $name = trim($in['name'] ?? ''); $email = strtolower(trim($in['email'] ?? '')); $user = trim($in['username'] ?? '');
        if ($name === '') fail('Please enter the full name.', 'name');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Please enter a valid email address.', 'email');
        if (!preg_match('/^[A-Za-z0-9._-]{3,30}$/', $user)) fail('Username must be 3-30 characters: letters, numbers, dots, dashes or underscores.', 'username');
        if (!in_array($in['branch'] ?? '', BRANCHES)) fail('Please choose a branch.', 'branch');
        if (q('SELECT 1 FROM accounts WHERE LOWER(username)=? AND id<>?', [strtolower($user), $id])->fetch()) fail('That username is already taken.', 'username');
        if (q('SELECT 1 FROM accounts WHERE role=? AND LOWER(email)=? AND id<>?', [$a['role'], $email, $id])->fetch()) fail('That email is already used by another account.', 'email');
        q('UPDATE accounts SET name=?, email=?, username=?, branch=?, phone=? WHERE id=?', [$name, $email, $user, $in['branch'], nul($in['phone'] ?? null), $id]);
        if ($a['role'] === 'client' && $a['client_id']) q('UPDATE clients SET name=?, email=?, phone=?, address=?, branch=? WHERE id=?', [$name, $email, nul($in['phone'] ?? null), nul($in['address'] ?? null), $in['branch'], $a['client_id']]);
        log_act($id, 'Profile edited by an admin', $me['name']); send(['ok' => 1]);
    }
    if ($p[2] === 'photo') { q('UPDATE accounts SET photo=? WHERE id=?', [photo_value($in['photo'] ?? ''), $id]); log_act($id, 'Photo changed by an admin', $me['name']); send(['ok' => 1]); }
    if ($p[2] === 'pets') {   // add a pet to this client
        if ($a['role'] !== 'client' || !$a['client_id']) fail('Only client accounts have pets.');
        $n = trim($in['name'] ?? ''); if ($n === '') fail('Pet name is required.', 'name');
        q('INSERT INTO pets(client_id,name,species,breed,sex,birthdate,photo) VALUES(?,?,?,?,?,?,?)', [$a['client_id'], $n, nul($in['species'] ?? null), nul($in['breed'] ?? null), nul($in['sex'] ?? null), nul($in['birthdate'] ?? null), photo_value($in['photo'] ?? '')]);
        log_act($id, 'Pet added by an admin', $n); send(['ok' => 1]);
    }
    if ($p[2] === 'reset') {
        if (($in['mode'] ?? '') === 'link') {
            $t = bin2hex(random_bytes(24));
            q('INSERT INTO password_resets(account_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))', [$id, hash('sha256', $t)]);
            $link = SITE_URLS[$a['role']] . 'reset.php?token=' . $t;
            mail_to($a['email'], 'Reset your Greenland Veterinary Clinic password', "Hello {$a['name']},\n\nAn administrator started a password reset for your account. Use this link to set a new password (valid for 1 hour):\n$link");
            log_act($id, 'Password reset link sent'); send(['sent' => true, 'link' => DEV_SHOW_CODE ? $link : null]);
        }
        $t = substr(bin2hex(random_bytes(8)), 0, 10);
        q('UPDATE accounts SET password=?, must_change=? WHERE id=?', [password_hash($t, PASSWORD_DEFAULT), empty($in['require_change']) ? 0 : 1, $id]);
        log_act($id, 'Password reset'); send(['temp' => $t]);
    }
    if ($p[2] === 'disable') {
        $reason = trim($in['reason'] ?? ''); if ($reason === '') fail('Please select a reason.', 'reason');
        q("UPDATE accounts SET status='Disabled', disabled_reason=? WHERE id=?", [$reason, $id]); log_act($id, 'Account disabled');
        if (!empty($in['notify'])) mail_to($a['email'], 'Your Greenland Veterinary Clinic account was disabled', "Hello {$a['name']},\n\nYour account has been disabled. Please contact the clinic if you have questions.");
        send(['ok' => 1]);
    }
    if ($p[2] === 'enable') { q("UPDATE accounts SET status='Active', disabled_reason=NULL WHERE id=?", [$id]); log_act($id, 'Account enabled'); send(['ok' => 1]); }
}
// ---- edit a pet ----
if ($post && $p[0] === 'pets' && count($p) === 2) {
    $pet = q('SELECT * FROM pets WHERE id=?', [(int)$p[1]])->fetch();
    if (!$pet) fail('Pet not found.', null, 404);
    $n = trim($in['name'] ?? ''); if ($n === '') fail('Pet name is required.', 'name');
    $photo = array_key_exists('photo', $in) ? photo_value($in['photo']) : $pet['photo'];
    q('UPDATE pets SET name=?, species=?, breed=?, sex=?, birthdate=?, photo=? WHERE id=?', [$n, nul($in['species'] ?? null), nul($in['breed'] ?? null), nul($in['sex'] ?? null), nul($in['birthdate'] ?? null), $photo, $pet['id']]);
    $acc = q("SELECT id FROM accounts WHERE client_id=? AND role='client'", [$pet['client_id']])->fetch();
    if ($acc) log_act((int)$acc['id'], 'Pet edited by an admin', $n);
    send(['ok' => 1]);
}
// ---- audit log: who did what, filterable by role, category, date and text ----
const AUDIT_CATS = [   // category => SQL fragment over l.action
    'account' => "(l.action LIKE 'Account%' OR l.action LIKE '%account%' OR l.action LIKE 'Registered%' OR l.action LIKE 'Password%' OR l.action='Logged in')",
    'booking' => "(l.action LIKE 'Booked%' OR l.action LIKE 'Requested an appointment%' OR l.action LIKE 'Approved%' OR l.action LIKE 'Checked in%' OR l.action LIKE 'Rescheduled%')",
    'edit'    => "(l.action LIKE 'Updated%' OR l.action LIKE 'Edited%' OR l.action LIKE 'Saved%' OR l.action LIKE '%edited by%' OR l.action LIKE 'Changed%' OR l.action LIKE 'Rescheduled%' OR l.action LIKE 'Marked a vet%' OR l.action LIKE 'Page content%')",
    'cancel'  => "(l.action LIKE '%ancel%')",
    'delete'  => "(l.action LIKE 'Deleted%' OR l.action LIKE 'Removed%')",
    'billing' => "(l.action LIKE '%billing%' OR l.action LIKE 'Recorded%')",
];
if (!$post && $path === 'activity') {
    $role = in_array($_GET['role'] ?? '', ['staff', 'vet', 'client', 'admin']) ? $_GET['role'] : '';
    $cat = $_GET['cat'] ?? '';
    $per = 12; $page = max(1, (int)($_GET['page'] ?? 1)); $off = ($page - 1) * $per;
    $s = trim($_GET['q'] ?? ''); $like = "%$s%";
    $w = ["l.action<>'Verification code sent'", "(?='' OR a.name LIKE ? OR a.username LIKE ? OR l.action LIKE ? OR l.detail LIKE ?)"]; $args = [$s, $like, $like, $like, $like];
    if ($role) { $w[] = 'a.role=?'; $args[] = $role; }
    if (isset(AUDIT_CATS[$cat])) $w[] = AUDIT_CATS[$cat];
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from'] ?? '')) { $w[] = 'DATE(l.created_at)>=?'; $args[] = $_GET['from']; }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to'] ?? '')) { $w[] = 'DATE(l.created_at)<=?'; $args[] = $_GET['to']; }
    $W = implode(' AND ', $w);
    $total = (int)q("SELECT COUNT(*) FROM activity_log l JOIN accounts a ON a.id=l.account_id WHERE $W", $args)->fetchColumn();
    $rows = q("SELECT a.name, a.username, a.role, l.action, l.detail, l.created_at FROM activity_log l JOIN accounts a ON a.id=l.account_id WHERE $W ORDER BY l.id DESC LIMIT $per OFFSET $off", $args)->fetchAll();
    send(compact('rows', 'total', 'page', 'per'));
}
// ---- Page Management (CMS) for the public homepage ----
const CMS_KEYS = ['hero_title', 'hero_text', 'hero_image', 'promo_on', 'promo_text', 'about_title', 'about_text', 'offers_title', 'services_title', 'services_text', 'footer_text'];
function cms_image($v): ?string {   // a JPEG data URL up to ~700 KB, or '' to remove
    $v = (string)$v; if ($v === '') return null;
    if (strpos($v, 'data:image/jpeg;base64,') !== 0 || strlen($v) > 950000 || base64_decode(substr($v, 23), true) === false) fail('That image could not be used. Please choose a smaller picture.', 'image');
    return $v;
}
if ($p[0] === 'cms') {
    if (!$post && count($p) === 1) send(['content' => cms(), 'items' => cms_items(false)]);
    if ($post && count($p) === 1) {
        $changed = [];
        foreach (CMS_KEYS as $k) {
            if (!array_key_exists($k, $in)) continue;
            $v = $k === 'hero_image' ? cms_image($in[$k]) : trim((string)$in[$k]);
            if (in_array($k, ['promo_on'], true)) $v = empty($in[$k]) ? '0' : '1';
            if (strlen((string)$v) > ($k === 'hero_image' ? 950000 : 1200)) fail('That text is too long.', $k);
            q('INSERT INTO cms_content(k,v) VALUES(?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)', [$k, $v]); $changed[] = $k;
        }
        log_act((int)$me['id'], 'Page content updated', implode(', ', $changed)); send(['ok' => 1]);
    }
    if ($post && $p[1] === 'items') {   // cms/items (create) or cms/items/{id} (update) or cms/items/{id}/delete
        $id = isset($p[2]) ? (int)$p[2] : 0;
        if ($id && ($p[3] ?? '') === 'delete') {
            $t = q('SELECT title FROM cms_items WHERE id=?', [$id])->fetchColumn();
            q('DELETE FROM cms_items WHERE id=?', [$id]); log_act((int)$me['id'], 'Deleted a homepage item', (string)$t); send(['ok' => 1]);
        }
        $title = trim($in['title'] ?? ''); if ($title === '') fail('Enter a title.', 'title');
        $kind = in_array($in['kind'] ?? '', ['promo', 'service'], true) ? $in['kind'] : 'promo';
        $price = ($in['price'] ?? '') === '' ? null : $in['price']; $old = ($in['old_price'] ?? '') === '' ? null : $in['old_price'];
        foreach (['price' => $price, 'old_price' => $old] as $k => $v) if ($v !== null && (!is_numeric($v) || (float)$v < 0)) fail('Enter a valid price.', $k);
        $row = [$kind, $title, nul(substr(trim($in['description'] ?? ''), 0, 400)), $price === null ? null : (float)$price, $old === null ? null : (float)$old, empty($in['active']) ? 0 : 1, (int)($in['sort_order'] ?? 0)];
        if ($id) {
            $cur = q('SELECT image FROM cms_items WHERE id=?', [$id])->fetchColumn();
            $img = array_key_exists('image', $in) ? cms_image($in['image']) : $cur;
            q('UPDATE cms_items SET kind=?, title=?, description=?, price=?, old_price=?, active=?, sort_order=?, image=? WHERE id=?', [...$row, $img, $id]);
            log_act((int)$me['id'], 'Edited a homepage item', $title);
        } else {
            q('INSERT INTO cms_items(kind,title,description,price,old_price,active,sort_order,image) VALUES(?,?,?,?,?,?,?,?)', [...$row, cms_image($in['image'] ?? '')]);
            log_act((int)$me['id'], 'Added a homepage item', $title);
        }
        send(['ok' => 1]);
    }
}
// ---- Reports & Analytics ----
if (!$post && $path === 'reports') {
    $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from'] ?? '') ? $_GET['from'] : date('Y-m-d', strtotime('-29 days'));
    $to   = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to'] ?? '') ? $_GET['to'] : date('Y-m-d');
    if ($to < $from) [$from, $to] = [$to, $from];
    if ((strtotime($to) - strtotime($from)) / 86400 > 366) $from = date('Y-m-d', strtotime($to . ' -366 days'));
    $br = in_array($_GET['branch'] ?? '', BRANCHES) ? $_GET['branch'] : '';
    $aw = 'a.appt_date BETWEEN ? AND ?' . ($br ? ' AND a.branch=?' : ''); $aa = $br ? [$from, $to, $br] : [$from, $to];
    $sw = "s.status NOT IN ('Draft','Transferred') AND s.sale_date BETWEEN ? AND ?" . ($br ? ' AND s.branch=?' : '');  $sa = $aa;
    $one = fn($sql, $a) => q($sql, $a)->fetch();
    $k = $one("SELECT COUNT(*) booked, SUM(a.status='Completed') completed, SUM(a.status='Cancelled') cancelled, SUM(a.source='Online') online, SUM(a.source<>'Online') clinic,
                      SUM(a.cancelled_by='Owner') c_owner, SUM(a.cancelled_by='Staff') c_staff, SUM(a.cancelled_by='Vet') c_vet, SUM(a.cancelled_by='System') c_system FROM appointments a WHERE $aw", $aa);
    $sal = $one("SELECT COUNT(*) n, COALESCE(SUM(s.paid),0) revenue, COALESCE(SUM(CASE WHEN s.status IN ('Unpaid','Partially paid') THEN s.total-s.paid ELSE 0 END),0) outstanding FROM sales s WHERE $sw", $sa);
    $unc = (float)q("SELECT COALESCE(SUM(p.amount),0) FROM sale_payments p JOIN sales s ON s.id=p.sale_id WHERE $sw AND p.method='Check' AND p.check_status='Pending clearing'", $sa)->fetchColumn();
    $age = $one("SELECT COALESCE(SUM(CASE WHEN DATEDIFF(CURDATE(),s.sale_date)<=30 THEN s.total-s.paid ELSE 0 END),0) a1, COALESCE(SUM(CASE WHEN DATEDIFF(CURDATE(),s.sale_date) BETWEEN 31 AND 60 THEN s.total-s.paid ELSE 0 END),0) a2,
                        COALESCE(SUM(CASE WHEN DATEDIFF(CURDATE(),s.sale_date)>60 THEN s.total-s.paid ELSE 0 END),0) a3 FROM sales s WHERE s.status IN ('Unpaid','Partially paid')" . ($br ? ' AND s.branch=?' : ''), $br ? [$br] : []);
    $kpi = ['booked' => (int)$k['booked'], 'completed' => (int)$k['completed'], 'cancelled' => (int)$k['cancelled'], 'online' => (int)$k['online'], 'clinic' => (int)$k['clinic'],
            'cancel_by' => ['Owner' => (int)$k['c_owner'], 'Staff' => (int)$k['c_staff'], 'Vet' => (int)$k['c_vet'], 'System' => (int)$k['c_system']],
            'sales' => (int)$sal['n'], 'revenue' => (float)$sal['revenue'], 'outstanding' => (float)$sal['outstanding'], 'uncleared' => $unc, 'ageing' => ['0-30' => (float)$age['a1'], '31-60' => (float)$age['a2'], '60+' => (float)$age['a3']]];
    $daily = q("SELECT a.appt_date d, COUNT(*) booked, SUM(a.status='Completed') completed, SUM(a.status='Cancelled') cancelled FROM appointments a WHERE $aw GROUP BY a.appt_date ORDER BY a.appt_date", $aa)->fetchAll();
    $byService = q("SELECT a.service name, COUNT(*) n FROM appointments a WHERE $aw AND a.status<>'Cancelled' GROUP BY a.service ORDER BY n DESC", $aa)->fetchAll();
    $byVet = q("SELECT COALESCE(NULLIF(a.vet,''),'Unassigned') name, COUNT(*) n FROM appointments a WHERE $aw AND a.status<>'Cancelled' GROUP BY name ORDER BY n DESC LIMIT 8", $aa)->fetchAll();
    $byBranch = q("SELECT COALESCE(a.branch,'-') name, COUNT(*) booked, SUM(a.status='Completed') completed, SUM(a.status='Cancelled') cancelled FROM appointments a WHERE a.appt_date BETWEEN ? AND ? GROUP BY name ORDER BY name", [$from, $to])->fetchAll();
    $reasons = q("SELECT COALESCE(NULLIF(a.cancel_reason,''),'No reason given') name, COUNT(*) n FROM appointments a WHERE $aw AND a.status='Cancelled' GROUP BY name ORDER BY n DESC LIMIT 6", $aa)->fetchAll();
    $salesDaily = q("SELECT s.sale_date d, COUNT(*) n, SUM(s.paid) total FROM sales s WHERE $sw GROUP BY s.sale_date ORDER BY s.sale_date", $sa)->fetchAll();
    $payments = q("SELECT p.method name, COUNT(*) n, SUM(p.amount) total FROM sale_payments p JOIN sales s ON s.id=p.sale_id WHERE $sw AND NOT (p.method='Check' AND p.check_status IN ('Pending clearing','Bounced')) GROUP BY p.method ORDER BY total DESC", $sa)->fetchAll();
    $due = [];   // Update 15: vaccinations whose next date is coming up (the two weeks ahead), whatever dates are chosen above
    try { $due = q("SELECT next_due d, COUNT(*) n FROM vaccinations WHERE next_due BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 13 DAY) GROUP BY next_due ORDER BY next_due")->fetchAll(); } catch (PDOException $e) {}
    send(compact('from', 'to', 'br', 'kpi', 'daily', 'byService', 'byVet', 'byBranch', 'reasons', 'salesDaily', 'payments', 'due'));
}
// ---- Update 19: Sales and money (read only; every figure of the clinic's money) ----
if (!$post && $p[0] === 'sales') {
    if (($p[1] ?? '') === 'summary') { [$f, $t2, $b] = sales_range($_GET); send(sales_summary($f, $t2, $b)); }
    send(sales_list($_GET));
}
// ---- product / medicine catalog (name, price, on or off the list) ----
if ($p[0] === 'products') {
    if (!$post && count($p) === 1) {
        $s = trim($_GET['q'] ?? ''); $per = 10; $page = max(1, (int)($_GET['page'] ?? 1)); $off = ($page - 1) * $per;
        $total = (int)q("SELECT COUNT(*) FROM products WHERE (?='' OR name LIKE ?)", [$s, "%$s%"])->fetchColumn();
        $rows = q("SELECT id,name,price,active FROM products WHERE (?='' OR name LIKE ?) ORDER BY name LIMIT $per OFFSET $off", [$s, "%$s%"])->fetchAll();
        send(compact('rows', 'total', 'page', 'per'));
    }
    if ($post) {
        $n = trim($in['name'] ?? ''); $pr = $in['price'] ?? '';
        if ($n === '') fail('Enter the product name.', 'name');
        if (!is_numeric($pr) || (float)$pr < 0) fail('Enter a valid price.', 'price');
        try {
            if (count($p) === 1) q('INSERT INTO products(name,price) VALUES(?,?)', [$n, (float)$pr]);
            else q('UPDATE products SET name=?, price=?, active=? WHERE id=?', [$n, (float)$pr, empty($in['active']) ? 0 : 1, (int)$p[1]]);
        } catch (PDOException $e) { fail('A product with that name already exists.', 'name'); }
        log_act((int)$me['id'], count($p) === 1 ? 'Added a product' : 'Edited a product', $n);
        send(['ok' => 1]);
    }
}
send(['error' => 'Not found'], 404);

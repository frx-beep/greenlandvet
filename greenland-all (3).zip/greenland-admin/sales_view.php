<?php /* Update 19: the Sales module. Shared by the staff and the admin apps; every money figure of the clinic lives here (it was taken off the dashboards). */ ?>
<div class="salesbar">
  <div class="tabs2" id="per"><button type="button" data-p="today" class="on">Today</button><button type="button" data-p="7">Last 7 days</button><button type="button" data-p="month">This month</button><button type="button" data-p="last">Last month</button><button type="button" data-p="custom">Pick dates</button></div>
  <div class="srange" id="rng" hidden><label>From <input type="date" id="from"></label><label>To <input type="date" id="to"></label></div>
  <select id="br" aria-label="Branch"><option value="">Both branches</option><?php foreach (BRANCHES as $b) echo '<option>' . htmlspecialchars($b) . '</option>'; ?></select>
  <span class="sp"></span>
  <?php if (APP_ROLE === 'staff'): ?><a class="btn ghost" href="daily.php">Daily sheet</a><a class="btn" href="sale_new.php">+ New Sale</a><?php endif; ?>
</div>
<p class="muted slabel" id="rlabel"></p>

<div class="kpis msum" id="kp">
  <div class="card kp"><h2>Collected</h2><div class="big" id="k1">-</div><span class="muted" id="k1s">money received</span></div>
  <div class="card kp"><h2>Collected online</h2><div class="big" id="k2">-</div><span class="muted" id="k2s">GCash</span></div>
  <div class="card kp"><h2>Collected in clinic</h2><div class="big" id="k3">-</div><span class="muted">cash, card and checks</span></div>
  <div class="card kp"><h2>Billed</h2><div class="big" id="k4">-</div><span class="muted" id="k4s"></span></div>
  <div class="card kp hot" id="kOwe"><h2>Unpaid balances</h2><div class="big" id="k5">-</div><span class="muted" id="k5s">as of today</span></div>
</div>

<div class="row2m">
  <div class="card"><div class="hd"><h2>Money collected per day</h2><span class="muted" id="barnote"></span></div><div class="bars" id="bars"></div></div>
  <div class="card"><h2>By payment method</h2><div id="meth"></div><p class="muted" id="chk" style="margin:.75rem 0 0"></p></div>
</div>

<div class="card" id="oweCard"><div class="hd"><h2>Unpaid balances</h2><?php if (APP_ROLE === 'staff'): ?><a class="btn plain sm" href="bills.php?tab=balances">Open all balances</a><?php endif; ?></div>
  <div class="ageing" id="age"></div>
  <table><thead><tr><th>Customer</th><th>Phone</th><th>Unpaid bills</th><th>Oldest</th><th class="r">Owes</th></tr></thead><tbody id="who"></tbody></table>
  <p class="muted" id="whoMore" style="margin:.6rem 0 0"></p></div>

<div class="card"><div class="hd"><h2>Sales history</h2><label class="chk" style="margin:0"><input type="checkbox" id="all"> All dates</label></div>
  <div class="toolbar"><input id="q" placeholder="Search by sale number, customer, pet or item..." style="flex:1">
    <select id="st" style="width:11rem"><option value="">All statuses</option><option>Unpaid</option><option>Partially paid</option><option>Paid</option><option>Transferred</option></select></div>
  <table><thead><tr><th>Sale #</th><th>Date</th><th>Customer</th><th>Items</th><th>Branch</th><th class="r">Total</th><th class="r">Paid</th><th class="r">Balance</th><th>Status</th></tr></thead><tbody id="rows"></tbody></table>
  <div class="pager"><span id="info"></span><div id="pages"></div></div></div>

<script>
const STAFF = ROLE === 'staff', ymd = d => d.toLocaleDateString('en-CA'), day = n => { const d = new Date(); d.setDate(d.getDate() + n); return d; };
let per = 'today', page = 1, timer, ONL = [];
if (STAFF && ME_BRANCH) $('#br').value = ME_BRANCH;
function range() {
  const t = new Date();
  if (per === 'today') return [ymd(t), ymd(t)];
  if (per === '7') return [ymd(day(-6)), ymd(t)];
  if (per === 'month') return [ymd(new Date(t.getFullYear(), t.getMonth(), 1)), ymd(t)];
  if (per === 'last') return [ymd(new Date(t.getFullYear(), t.getMonth() - 1, 1)), ymd(new Date(t.getFullYear(), t.getMonth(), 0))];
  return [$('#from').value || ymd(t), $('#to').value || ymd(t)];
}
const nice = k => new Date(k + 'T00:00').toLocaleDateString('en', { month: 'short', day: 'numeric' });
function delta(now, prev, label) {
  const d = Math.round((now - prev) * 100) / 100;
  if (!prev && !now) return `<span class="muted">nothing yet ${label}</span>`;
  if (d === 0) return `<span class="muted">same as ${label}</span>`;
  return `<span class="dlt ${d > 0 ? 'up' : 'dn'}">${d > 0 ? '&#9650; up' : '&#9660; down'} ${peso(Math.abs(d))}</span> <span class="muted">from ${label}</span>`;
}
const ageTag = d => `<span class="agep ${d <= 30 ? 'a1' : d <= 60 ? 'a2' : 'a3'}">${d} day${d === 1 ? '' : 's'}</span>`;
async function loadSummary() {
  const [f, t] = range(), br = $('#br').value;
  const r = await api(`/api/sales/summary?from=${f}&to=${t}&branch=${encodeURIComponent(br)}`); ONL = r.online_methods || [];
  $('#rlabel').textContent = (r.from === r.to ? new Date(r.from + 'T00:00').toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }) : `${nice(r.from)} to ${nice(r.to)} (${r.days} days)`) + ' · ' + (br || 'both branches');
  const lab = r.days === 1 ? 'the day before' : 'the ' + r.days + ' days before';
  $('#k1').textContent = peso(r.collected); $('#k1s').innerHTML = delta(r.collected, r.prev_collected, lab);
  $('#k2').textContent = peso(r.online); $('#k2s').textContent = ONL.length ? ONL.join(', ') : 'no online methods set';
  $('#k3').textContent = peso(r.clinic);
  $('#k4').textContent = peso(r.billed); $('#k4s').textContent = `${r.bills} bill${r.bills === 1 ? '' : 's'} · ${r.items} item${r.items === 1 ? '' : 's'}`;
  $('#k5').textContent = peso(r.owed); $('#k5s').textContent = `${r.owed_clients} customer${r.owed_clients === 1 ? '' : 's'} · as of today`;
  $('#kOwe').classList.toggle('hot', r.owed > 0);
  // per-day bars
  const mx = Math.max(1, ...r.series.map(s => s.amt)), many = r.series.length > 14;
  $('#barnote').textContent = r.series.length > 1 ? `best day ${peso(mx > 1 ? mx : 0)}` : '';
  $('#bars').innerHTML = r.series.map((s, i) => `<div class="bar1" title="${nice(s.d)}: ${peso(s.amt)}"><span class="v">${s.amt && !many ? peso(s.amt) : ''}</span><i style="height:${Math.max(s.amt ? 3 : 0, s.amt / mx * 100)}%"></i><em>${many ? (i % 5 === 0 ? new Date(s.d + 'T00:00').getDate() : '') : new Date(s.d + 'T00:00').toLocaleDateString('en', { weekday: 'short', day: 'numeric' })}</em></div>`).join('');
  // payment methods
  const tot = r.methods.reduce((a, m) => a + m.amt, 0);
  $('#meth').innerHTML = r.methods.length ? r.methods.map(m => `<div class="mrow"><div class="mh"><b>${E(m.method)}</b>${ONL.includes(m.method) ? ' <span class="badge g">online</span>' : ''}<span class="sp"></span><span>${peso(m.amt)}</span></div><div class="mb"><i style="width:${tot ? Math.max(2, m.amt / tot * 100) : 0}%"></i></div><small class="muted">${m.n} payment${m.n === 1 ? '' : 's'}${tot ? ' · ' + Math.round(m.amt / tot * 100) + '%' : ''}</small></div>`).join('') : '<p class="muted">No payments in this period.</p>';
  $('#chk').innerHTML = r.checks_n ? `${r.checks_n} check${r.checks_n === 1 ? '' : 's'} (${peso(r.checks_amt)}) still waiting to clear.${STAFF ? ' <a class="link" href="bills.php?tab=checks">Open checks</a>' : ''}` : '';
  // unpaid balances
  $('#age').innerHTML = `<span class="agep a1">0 to 30 days <b>${peso(r.ageing['0-30'])}</b></span><span class="agep a2">31 to 60 days <b>${peso(r.ageing['31-60'])}</b></span><span class="agep a3">over 60 days <b>${peso(r.ageing['60+'])}</b></span><span class="agep tot">${r.owed_bills} unpaid bill${r.owed_bills === 1 ? '' : 's'} <b>${peso(r.owed)}</b></span>`;
  $('#who').innerHTML = r.who.length ? r.who.map(w => `<tr${STAFF ? ` class="click" onclick="location='client.php?id=${w.id}'"` : ''}><td><b>${E(w.name)}</b></td><td>${E(w.phone || '')}</td><td>${w.bills}</td><td>${ageTag(w.age)}</td><td class="r"><b>${peso(w.owed)}</b></td></tr>`).join('') : '<tr><td colspan="5" class="empty">Nobody owes the clinic anything.</td></tr>';
  $('#whoMore').textContent = r.owed_clients > r.who.length ? `Showing the ${r.who.length} oldest of ${r.owed_clients} customers with a balance.` : '';
}
async function loadList() {
  const [f, t] = range(), all = $('#all').checked;
  const r = await api(`/api/sales?q=${encodeURIComponent($('#q').value)}&status=${encodeURIComponent($('#st').value)}&branch=${encodeURIComponent($('#br').value)}${all ? '' : `&from=${f}&to=${t}`}&page=${page}`);
  const bal = x => ['Unpaid', 'Partially paid'].includes(x.status) ? Math.max(0, x.total - x.paid) : 0;
  $('#rows').innerHTML = r.rows.length ? r.rows.map(x => `<tr${STAFF ? ` class="click" onclick="location='receipt.php?id=${x.id}'" title="Click to view the billing statement"` : ''}><td>#${x.id}</td><td>${fmtDate(x.sale_date)}</td><td>${E(x.client || 'Walk-in')}${x.pet ? `<br><small class="muted">${E(x.pet)}</small>` : ''}</td><td>${E(x.items || '')}</td><td>${E(x.branch || '')}</td><td class="r">${peso(x.total)}</td><td class="r">${peso(x.paid)}</td><td class="r">${bal(x) ? `<b>${peso(bal(x))}</b>` : '-'}</td><td><span class="badge ${x.status === 'Paid' || x.status === 'Transferred' ? 'g' : x.status === 'Partially paid' ? 'p' : 'x'}">${E(x.status)}</span></td></tr>`).join('')
    : '<tr><td colspan="9" class="empty">No sales found.</td></tr>';
  pager(r, page, n => { page = n; loadList(); }, $('#info'), $('#pages'));
}
function reload() { loadSummary().catch(() => {}); loadList().catch(() => {}); }
$$('#per button').forEach(b => b.onclick = () => { per = b.dataset.p; $$('#per button').forEach(x => x.classList.toggle('on', x === b)); $('#rng').hidden = per !== 'custom'; if (per === 'custom') { $('#from').value = $('#from').value || ymd(day(-6)); $('#to').value = $('#to').value || ymd(new Date()); } page = 1; reload(); });
['#from', '#to', '#br', '#st', '#all'].forEach(s => $(s).onchange = () => { page = 1; reload(); });
$('#q').oninput = () => { clearTimeout(timer); timer = setTimeout(() => { page = 1; loadList(); }, 250); };
reload(); setInterval(() => loadSummary().catch(() => {}), 30000);
</script>

<?php
require_once __DIR__ . '/authlib.php';
function top(string $title, string $active, string $crumb = ''): void {
    $me = require_login();
    $vets = in_array(APP_ROLE, ['staff', 'vet']) ? vets() : []; $vinfo = in_array(APP_ROLE, ['staff', 'vet']) ? vet_info() : []; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> - Greenland Veterinary Clinic</title>
<link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>">
<script>const IDLE_MIN = <?= defined('IDLE_LOGOUT_MINUTES') ? (int)IDLE_LOGOUT_MINUTES : 0 ?>, VETS = <?= json_encode($vets) ?>, BRANCHES = <?= json_encode(BRANCHES) ?>, SERVICES = <?= json_encode(SERVICES) ?>, ROLE = <?= json_encode(APP_ROLE) ?>, ME_NAME = <?= json_encode($me['name']) ?>, VETINFO = <?= json_encode($vinfo) ?>, FEES = <?= json_encode(defined('SERVICE_FEES') ? SERVICE_FEES : new stdClass) ?>, ME_BRANCH = <?= json_encode($me['branch'] ?? null) ?>, SVC_MIN = <?= json_encode(SERVICE_MINUTES) ?>, PAY_METHODS = <?= json_encode(PAY_METHODS) ?>, QUEUE_SERVICES = <?= json_encode(QUEUE_SERVICES) ?>, CAN_EDIT_REC = <?= json_encode(defined('VET_CAN_EDIT_RECORDS') && VET_CAN_EDIT_RECORDS) ?>, MAIN_BRANCH = <?= json_encode(defined('MAIN_BRANCH') ? MAIN_BRANCH : BRANCHES[0]) ?>, REFERRAL_REASONS = <?= json_encode(defined('REFERRAL_REASONS') ? REFERRAL_REASONS : []) ?>;</script>
<script src="app.js?v=<?= filemtime(__DIR__ . '/app.js') ?>"></script><?php ui_head(); ?></head><body>
<aside class="side">
  <div class="logobox"><img src="logo.png" alt="Greenland Veterinary Clinic"></div><p class="portal"><?= PORTAL_LABEL ?></p>
  <nav><?php foreach (NAV as $k => [$href, $label]) echo "<a href=\"$href\" class=\"" . ($active === $k ? 'on' : '') . "\">$label</a>"; ?></nav>
  <button class="outbtn" id="out">Log out</button>
</aside>
<div class="scrim" id="scrim"></div>
<div class="content">
  <header class="bar">
    <button type="button" class="menubtn noprint" id="menubtn" aria-label="Open the menu"><svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>
    <div><?php if (basename($_SERVER['SCRIPT_NAME']) !== HOME): ?><a class="backlink noprint" href="<?= HOME ?>" data-home="<?= HOME ?>" onclick="return goBack(this)">&lsaquo; Back</a> <?php endif; ?><small id="crumb"><?= htmlspecialchars($crumb) ?></small><h1><?= htmlspecialchars($title) ?></h1></div>
    <?php if (HAS_SEARCH): ?><form class="gsearch" action="<?= SEARCH_ACTION ?>"><input name="q" placeholder="<?= SEARCH_PH ?>"></form><?php endif; ?>
    <?php if (SHOW_BRANCH): ?><span class="chip" id="branch"></span><?php endif; ?>
    <?php if (HAS_BELL): ?><div class="bellwrap"><button type="button" class="bell" id="bell" aria-label="Notifications"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg><i id="bellN" hidden>0</i></button><div class="bellmenu" id="bellMenu" hidden></div></div><?php endif; ?>
    <?php if (PROFILE_URL): ?><a class="avatar" id="av" href="<?= PROFILE_URL ?>" title="My profile"></a><?php else: ?><span class="avatar" id="av"></span><?php endif; ?>
  </header>
  <main class="main">
<?php }
function bottom(): void { ?>
  </main>
</div>
<script>shell();(function () { const b = document.getElementById('menubtn'), s = document.getElementById('scrim'), t = o => document.body.classList.toggle('navopen', o);
  if (b) b.onclick = () => t(!document.body.classList.contains('navopen')); if (s) s.onclick = () => t(false);
  document.querySelectorAll('.side nav a').forEach(a => a.addEventListener('click', () => t(false))); document.addEventListener('keydown', e => { if (e.key === 'Escape') t(false); }); })();</script></body></html>
<?php }

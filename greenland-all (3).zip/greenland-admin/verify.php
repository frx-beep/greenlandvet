<?php require 'authlib.php';
if (empty($_SESSION['pending'])) { header('Location: login.php'); exit; }
$acc = q('SELECT email FROM accounts WHERE id=?', [$_SESSION['pending']])->fetch();
auth_open('Verify'); ?>
<h3><?= APP_ROLE === 'client' ? 'Verify Your Email' : 'Verify Your Identity' ?></h3>
<p class="muted">We've sent a 6-digit verification code to your <?= APP_ROLE === 'client' ? 'email address' : 'registered email address' ?>.</p>
<p class="maskmail"><?= htmlspecialchars(mask_email($acc['email'])) ?></p>
<?php if (DEV_SHOW_CODE && !empty($_SESSION['dev_code'])): ?><p class="devnote">Testing mode: email isn't set up yet, so your code is <b id="dev"><?= htmlspecialchars($_SESSION['dev_code']) ?></b></p><?php endif; ?>
<form id="f" class="form" novalidate>
  <div class="codes"><?php for ($i = 0; $i < 6; $i++) echo '<input class="cbox" maxlength="1" inputmode="numeric" autocomplete="off" aria-label="Digit ' . ($i + 1) . '">'; ?></div>
  <p class="muted center" id="timer" style="margin:0"></p><p class="err center"></p><button class="btn wide">Verify</button>
</form>
<p class="center muted" style="margin:1rem 0 .25rem">Didn't receive the code? <button class="link" id="resend" type="button">Resend code</button></p>
<p class="center"><a class="link plainlink" href="login.php" id="back">&larr; Back to login</a></p>
<script>
const boxes = $$('.cbox');
boxes.forEach((b, i) => {
  b.oninput = () => { b.value = b.value.replace(/\D/g, ''); if (b.value && boxes[i + 1]) boxes[i + 1].focus(); };
  b.onkeydown = e => { if (e.key === 'Backspace' && !b.value && boxes[i - 1]) boxes[i - 1].focus(); };
  b.onpaste = e => { const t = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6); if (t) { e.preventDefault(); t.split('').forEach((c, j) => boxes[j].value = c); boxes[Math.min(t.length, 5)].focus(); } };
});
boxes[0].focus();
let left = 0, tick;
function draw() { $('#timer').textContent = left > 0 ? `Code expires in ${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}` : 'This code has expired. Request a new one.'; if (left > 0) left--; }
function start(s) { left = s; clearInterval(tick); tick = setInterval(draw, 1000); draw(); }
api('/api/auth/verify_info').then(r => start(r.seconds_left)).catch(() => location = 'login.php');
bindForm('#f', async () => {
  const code = boxes.map(b => b.value).join('');
  if (code.length < 6) throw new Error('Enter the 6-digit code.');
  const r = await api('/api/auth/verify', { code }); location = r.next;
});
$('#resend').onclick = async () => {
  try { const r = await api('/api/auth/resend', {}); start(r.seconds_left); if (r.dev_code && $('#dev')) $('#dev').textContent = r.dev_code; boxes.forEach(b => b.value = ''); boxes[0].focus(); $('.err').textContent = ''; }
  catch (x) { $('.err').textContent = x.message; }
};
$('#back').onclick = async e => { e.preventDefault(); await api('/api/auth/logout', {}); location = 'login.php'; };
</script>
<?php auth_close(); ?>

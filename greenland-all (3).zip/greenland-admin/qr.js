// qr.js: a small QR code generator (byte mode, error correction M, versions 1-10). No internet or libraries needed.
const QR = (() => {
  const ECC = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26];   // error-correction codewords per block, by version
  const BLK = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];             // number of blocks, by version
  const rawModules = v => { let r = (16 * v + 128) * v + 64; if (v >= 2) { const a = Math.floor(v / 7) + 2; r -= (25 * a - 10) * a - 55; if (v >= 7) r -= 36; } return r; };
  const dataCap = v => Math.floor(rawModules(v) / 8) - ECC[v] * BLK[v];
  const mul = (x, y) => { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z; };
  const divisor = d => { const r = new Array(d - 1).fill(0).concat([1]); let root = 1; for (let i = 0; i < d; i++) { for (let j = 0; j < r.length; j++) { r[j] = mul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = mul(root, 2); } return r; };
  const remainder = (data, div) => { const r = div.map(() => 0); for (const b of data) { const f = b ^ r.shift(); r.push(0); div.forEach((c, i) => r[i] ^= mul(c, f)); } return r; };
  const gb = (x, i) => ((x >>> i) & 1) !== 0;

  function encode(text) {
    const bytes = Array.from(new TextEncoder().encode(text));
    let ver = 1;
    for (; ver <= 10; ver++) if (4 + (ver < 10 ? 8 : 16) + bytes.length * 8 <= dataCap(ver) * 8) break;
    if (ver > 10) throw new Error('Text is too long for this QR code');
    const bits = [], put = (v, n) => { for (let i = n - 1; i >= 0; i--) bits.push((v >>> i) & 1); }, cap = dataCap(ver) * 8;
    put(4, 4); put(bytes.length, ver < 10 ? 8 : 16); bytes.forEach(b => put(b, 8));
    put(0, Math.min(4, cap - bits.length)); while (bits.length % 8) bits.push(0);
    for (let pad = 0xEC; bits.length < cap; pad ^= 0xEC ^ 0x11) put(pad, 8);
    const data = []; for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));

    // split into blocks, add error correction, interleave
    const nb = BLK[ver], eccLen = ECC[ver], raw = Math.floor(rawModules(ver) / 8), nShort = nb - raw % nb, shortLen = Math.floor(raw / nb);
    const div = divisor(eccLen), blocks = []; let k = 0;
    for (let i = 0; i < nb; i++) {
      const dat = data.slice(k, k + shortLen - eccLen + (i < nShort ? 0 : 1)); k += dat.length;
      const ecc = remainder(dat, div); if (i < nShort) dat.push(0); blocks.push(dat.concat(ecc));
    }
    const all = [];
    for (let i = 0; i < blocks[0].length; i++) blocks.forEach((b, j) => { if (i !== shortLen - eccLen || j >= nShort) all.push(b[i]); });

    // draw the fixed patterns
    const size = ver * 4 + 17, m = Array.from({ length: size }, () => new Array(size).fill(false)), fn = Array.from({ length: size }, () => new Array(size).fill(false));
    const setF = (x, y, d) => { m[y][x] = d; fn[y][x] = true; };
    for (let i = 0; i < size; i++) { setF(6, i, i % 2 === 0); setF(i, 6, i % 2 === 0); }
    const finder = (cx, cy) => { for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = Math.max(Math.abs(dx), Math.abs(dy)), x = cx + dx, y = cy + dy; if (x >= 0 && x < size && y >= 0 && y < size) setF(x, y, d !== 2 && d !== 4); } };
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    const na = ver === 1 ? 0 : Math.floor(ver / 7) + 2, pos = [];
    if (na) { const step = Math.ceil((ver * 4 + 4) / (na * 2 - 2)) * 2; pos.push(6); for (let p = size - 7; pos.length < na; p -= step) pos.splice(1, 0, p); }
    for (let i = 0; i < na; i++) for (let j = 0; j < na; j++) if (!((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)))
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) setF(pos[i] + dx, pos[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    const drawFmt = mask => {   // error correction level M = 00
      let rem = mask; for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      const bits = ((mask << 10) | rem) ^ 0x5412;
      for (let i = 0; i <= 5; i++) setF(8, i, gb(bits, i));
      setF(8, 7, gb(bits, 6)); setF(8, 8, gb(bits, 7)); setF(7, 8, gb(bits, 8));
      for (let i = 9; i < 15; i++) setF(14 - i, 8, gb(bits, i));
      for (let i = 0; i < 8; i++) setF(size - 1 - i, 8, gb(bits, i));
      for (let i = 8; i < 15; i++) setF(8, size - 15 + i, gb(bits, i));
      setF(8, size - 8, true);
    };
    drawFmt(0);
    if (ver >= 7) { let rem = ver; for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25); const bits = (ver << 12) | rem; for (let i = 0; i < 18; i++) { const c = gb(bits, i), a = size - 11 + i % 3, b = Math.floor(i / 3); setF(a, b, c); setF(b, a, c); } }

    // place the data bits in the zig-zag order
    let bi = 0;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (let vert = 0; vert < size; vert++) for (let j = 0; j < 2; j++) {
        const x = right - j, y = ((right + 1) & 2) === 0 ? size - 1 - vert : vert;
        if (!fn[y][x] && bi < all.length * 8) { m[y][x] = gb(all[bi >>> 3], 7 - (bi & 7)); bi++; }
      }
    }

    // pick the mask with the lowest penalty
    const inv = (mask, x, y) => [(x + y) % 2 === 0, y % 2 === 0, x % 3 === 0, (x + y) % 3 === 0, (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
      (x * y) % 2 + (x * y) % 3 === 0, ((x * y) % 2 + (x * y) % 3) % 2 === 0, ((x + y) % 2 + (x * y) % 3) % 2 === 0][mask];
    const applyMask = mask => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && inv(mask, x, y)) m[y][x] = !m[y][x]; };
    const penalty = () => {
      let p = 0, dark = 0;
      const cols = m[0].map((_, x) => m.map(r => r[x]));
      for (const line of [...m, ...cols]) {
        let run = 1;
        for (let i = 1; i <= size; i++) { if (i < size && line[i] === line[i - 1]) run++; else { if (run >= 5) p += 3 + run - 5; run = 1; } }
        for (let i = 0; i + 11 <= size; i++) { const s = line.slice(i, i + 11).map(v => v ? 1 : 0).join(''); if (s === '10111010000' || s === '00001011101') p += 40; }
      }
      for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) if (m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
      m.forEach(r => r.forEach(v => { if (v) dark++; }));
      return p + Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10;
    };
    let best = 0, bp = Infinity;
    for (let mk = 0; mk < 8; mk++) { applyMask(mk); drawFmt(mk); const pp = penalty(); if (pp < bp) { bp = pp; best = mk; } applyMask(mk); }
    applyMask(best); drawFmt(best);
    return m;
  }
  function canvas(text, scale = 8, quiet = 4) {
    const m = encode(text), n = m.length, c = document.createElement('canvas'); c.width = c.height = (n + quiet * 2) * scale;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = '#000';
    m.forEach((r, y) => r.forEach((v, xx) => { if (v) x.fillRect((xx + quiet) * scale, (y + quiet) * scale, scale, scale); }));
    return c;
  }
  return { encode, canvas };
})();
if (typeof module !== 'undefined') module.exports = QR;

// Pop-up that shows an appointment's QR code and lets the pet owner save it as a picture.
function qrDialog(a) {
  const when = `${fmtDay(a.appt_date)}, ${fmtTime(a.time)}`, d = document.createElement('dialog');
  d.innerHTML = `<h3>Your appointment QR</h3><p class="muted" style="margin-top:0">Show this to the veterinarian when you arrive. Save it to your phone so you can open it anytime. You can also come back here and press Show QR.</p>
    <div class="qrbox"></div><dl><dt>Pet</dt><dd>${E(a.pet)}</dd><dt>Service</dt><dd>${E(a.service)}</dd><dt>When</dt><dd>${E(when)}</dd><dt>Branch</dt><dd>${E(a.branch || '-')}</dd></dl>
    <div class="actions"><button type="button" class="btn plain" data-x>Close</button><button type="button" class="btn" id="qsave">Save to device</button></div>`;
  const cv = QR.canvas('GV:' + a.qr_token, 8, 4); cv.className = 'qrimg'; d.querySelector('.qrbox').append(cv);
  document.body.append(d); d.showModal(); d.onclose = () => d.remove(); d.querySelector('[data-x]').onclick = () => d.close();
  d.querySelector('#qsave').onclick = () => {   // a picture with the clinic name and appointment details around the QR
    const w = cv.width + 80, lines = [a.pet + ': ' + a.service, when, (a.branch || '') + ' branch', 'Show this QR to the veterinarian'];
    const c = document.createElement('canvas'); c.width = w; c.height = cv.height + 190; const x = c.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = '#0a4a45'; x.textAlign = 'center';
    x.font = 'bold 26px sans-serif'; x.fillText('Greenland Veterinary Clinic', w / 2, 40); x.drawImage(cv, 40, 56);
    x.font = '22px sans-serif'; x.fillStyle = '#16302b'; lines.forEach((t, i) => x.fillText(t, w / 2, cv.height + 96 + i * 30));
    const link = document.createElement('a'); link.download = `greenland-appointment-${a.appt_date}.png`; link.href = c.toDataURL('image/png'); link.click();
  };
  return d;
}

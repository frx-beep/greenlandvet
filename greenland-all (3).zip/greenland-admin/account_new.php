<?php require 'layout.php'; top('Create Account', 'a', 'Accounts > Create Account'); ?>
<div class="card fit"><h2>New Account</h2>
  <form id="f" class="form" novalidate>
    <label>Role<select name="role" id="role"><option value="">Select role</option><option value="client">Client</option><option value="staff">Staff (front desk)</option><option value="vet">Veterinarian</option></select><small class="ferr" data-f="role"></small></label>
    <label>Full Name<input name="name" placeholder="Full name"><small class="ferr" data-f="name"></small></label>
    <div class="fr"><label>Email Address<input name="email" type="email" placeholder="name@email.com"><small class="ferr" data-f="email"></small></label>
    <label>Branch<select name="branch"><option value="">Select branch</option><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select><small class="ferr" data-f="branch"></small></label></div>
    <label id="ul">Username<input name="username" placeholder="Username"><small class="ferr" data-f="username"></small></label>
    <label>Temporary Password (8+ characters)<input name="password" type="text" placeholder="Temporary password"><small class="ferr" data-f="password"></small></label>
    <p class="muted" style="margin:0">The user will be asked to choose a new password the first time they sign in. Client accounts are linked to the clinic's client record with the same email, so the owner sees their own pets.</p>
    <p class="err"></p><div class="actions"><button class="btn">Create Account</button><a class="btn plain" href="accounts.php">Cancel</a></div>
  </form></div>
<script>
bindForm('#f', async d => { const r = await api('/api/accounts', d); location = 'account.php?id=' + r.id; });
</script>
<?php bottom(); ?>

<?php require 'layout.php'; top('Disable Account', 'a', 'Accounts > Disable Account'); ?>
<div class="card fit"><h2 id="h"></h2><p class="muted" id="who"></p><p id="txt"></p>
  <form id="f" class="form" novalidate>
    <label id="rl">Reason for disabling<select name="reason"><option value="">Select a reason</option><option>Inactive account</option><option>Left the clinic</option><option>Security concern</option><option>Requested by the user</option><option>Other</option></select><small class="ferr" data-f="reason"></small></label>
    <label class="chk" id="nl"><input type="checkbox" name="notify" value="1" checked> Notify the user by email</label>
    <p class="err"></p><div class="actions"><button class="btn" id="go">Disable Account</button><a class="btn plain" id="back">Cancel</a></div>
  </form></div>
<script>
const id = param('id'); $('#back').href = 'account.php?id=' + id; let on = true;
api('/api/accounts/' + id).then(a => {
  on = a.status === 'Active';
  $('#h').textContent = (on ? 'Disable ' : 'Enable ') + a.name + "'s account?"; $('#who').textContent = roleName(a.role) + ' \u00B7 ' + a.email;
  $('#txt').textContent = on ? 'The user will no longer be able to sign in. All pet and medical records stay saved, and the account can be enabled again at any time.' : 'The user will be able to sign in again.';
  if (!on) { $('#rl').hidden = $('#nl').hidden = true; $('#go').textContent = 'Enable Account'; }
});
bindForm('#f', async d => { await api(`/api/accounts/${id}/${on ? 'disable' : 'enable'}`, d); location = 'account.php?id=' + id; });
</script>
<?php bottom(); ?>

<?php require 'layout.php'; top('Audit Log', 'g', 'Admin Console > Audit Log'); ?>
<p class="muted" style="margin-top:0">A record of what every account did: creating accounts, booking, editing, cancelling and deleting. Filter by who, what kind of action, or date.</p>
<div class="card">
  <div class="filters">
    <label>Search<input id="q" placeholder="Name, action or detail..." style="min-width:15rem"></label>
    <label>Who<select id="role"><option value="">Everyone</option><option value="staff">Staff</option><option value="vet">Veterinarians</option><option value="client">Pet owners</option><option value="admin">Admins</option></select></label>
    <label>Type of action<select id="cat"><option value="">All actions</option><option value="account">Accounts</option><option value="booking">Bookings</option><option value="edit">Edits</option><option value="cancel">Cancellations</option><option value="delete">Deletions</option><option value="billing">Billing and records</option></select></label>
    <label>From<input type="date" id="from"></label><label>To<input type="date" id="to"></label>
    <button class="btn plain sm" id="clr" type="button">Clear</button>
  </div>
  <div id="t"></div><div class="pager"><span id="i"></span><div id="p"></div></div>
</div>
<script>
let page = 1, timer;
const ROLE = { staff: 'Staff', vet: 'Veterinarian', client: 'Pet owner', admin: 'Admin' };
const kind = a => /ancel/i.test(a) ? ['cancel', 'Cancellation'] : /^(Deleted|Removed)/.test(a) ? ['delete', 'Deletion'] : /^(Booked|Requested|Approved|Checked in|Rescheduled)/.test(a) ? ['booking', 'Booking']
  : /account|Registered|Password/i.test(a) ? ['account', 'Account'] : /billing|^Recorded/i.test(a) ? ['', 'Billing / record'] : /^(Updated|Edited|Saved|Changed|Page content|Marked)|edited by|Added/.test(a) ? ['', 'Edit'] : ['', 'Other'];
async function load() {
  const qs = new URLSearchParams({ page, q: $('#q').value.trim(), role: $('#role').value, cat: $('#cat').value, from: $('#from').value, to: $('#to').value });
  try {
    const r = await api('/api/activity?' + qs);
    $('#t').innerHTML = `<table><thead><tr><th>When</th><th>Who</th><th>Type</th><th>Action</th></tr></thead><tbody>` + (r.rows.length ? r.rows.map(x => { const [c, l] = kind(x.action);
      return `<tr><td class="nowrap">${E(new Date(x.created_at.replace(' ', 'T')).toLocaleString('en', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }))}</td>
      <td>${E(x.name)}<br><small class="muted">${E(ROLE[x.role] || x.role)} &middot; ${E(x.username)}</small></td><td><span class="cat ${c}">${l}</span></td>
      <td>${E(x.action)}${x.detail ? '<br><small class="muted">' + E(x.detail) + '</small>' : ''}</td></tr>`; }).join('') : '<tr><td colspan="4" class="empty">Nothing matches these filters.</td></tr>') + '</tbody></table>';
    pager(r, page, n => { page = n; load(); }, $('#i'), $('#p'));
  } catch (x) { $('#t').innerHTML = `<p class="err">${E(x.message)}</p>`; }
}
['role', 'cat', 'from', 'to'].forEach(id => $('#' + id).onchange = () => { page = 1; load(); });
$('#q').oninput = () => { clearTimeout(timer); timer = setTimeout(() => { page = 1; load(); }, 250); };
$('#clr').onclick = () => { ['q', 'role', 'cat', 'from', 'to'].forEach(id => $('#' + id).value = ''); page = 1; load(); };
load();
</script>
<?php bottom(); ?>

<?php require 'authlib.php'; auth_open('Forgot password'); ?>
<h3>Forgot your password?</h3><p class="muted">Enter your username or email address and we'll email you a link to set a new password.</p>
<form id="f" class="form" novalidate>
  <label>Username or email address<input name="identity" placeholder="Username or you@email.com"><small class="ferr" data-f="identity"></small></label>
  <p class="err"></p><button class="btn wide">Send reset link</button>
</form>
<div id="done" hidden><p class="okmsg">If an account exists for that email, a reset link has been sent. Please check your inbox.</p><p class="devnote" id="devlink" hidden></p></div>
<p class="center"><a class="link plainlink" href="login.php">&larr; Back to login</a></p>
<script>bindForm('#f', async d => {
  const r = await api('/api/auth/forgot', d); $('#f').hidden = true; $('#done').hidden = false;
  if (r.link) { $('#devlink').hidden = false; $('#devlink').innerHTML = `Testing mode: <a href="${E(r.link)}">open your reset link</a>`; }
});</script>
<?php auth_close(); ?>

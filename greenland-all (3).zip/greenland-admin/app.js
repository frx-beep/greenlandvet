const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const E = esc;
// the Back link on every inner page: the page you came from (if it is in this app), otherwise the home page
function goBack(a) { try { if (document.referrer && new URL(document.referrer).origin === location.origin && history.length > 1) { history.back(); return false; } } catch (e) {} return true; }
const fmtDate = d => d ? new Date(d + 'T00:00').toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' }) : '-';
const D = fmtDate;
const fmtTime = t => { const [h, m] = t.split(':'); return `${h % 12 || 12}:${m} ${h < 12 ? 'AM' : 'PM'}`; };
const peso = n => '\u20B1 ' + Number(n).toLocaleString('en', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const param = k => new URLSearchParams(location.search).get(k);
const today = () => new Date().toLocaleDateString('en-CA');
// Pet owners see friendlier wording: Pending -> "Pending approval", Confirmed -> "Approved"
const statusLabel = s => (typeof ROLE !== 'undefined' && ROLE === 'client') ? ({ Pending: 'Pending approval', Confirmed: 'Approved' }[s] || s) : s;
const badge = s => { const st = window.UI14 ? UI14.stOf(s) : ''; return `<span class="badge ${s === 'Confirmed' || s === 'Admitted' ? '' : s === 'Discharged' || s === 'Completed' ? 'g' : s === 'Cancelled' ? 'x' : 'p'}"${st ? ` data-st="${st}"` : ''}>${E(statusLabel(s))}</span>`; };
// Update 15 look-and-feel helpers. They return '' when ui14.js is not loaded, so removing it (UI_UPGRADE = false) leaves every page working.
const pav = (name, species, photo, cls) => window.UI14 ? UI14.pav(name, species, photo, cls) : '';
const uic = n => window.UI14 ? `<span class="kic">${UI14.icon(n)}</span>` : '';
const spark = v => window.UI14 ? UI14.spark(v) : '';
const trendHTML = (cur, prev, what, fmt) => window.UI14 ? UI14.trend(cur, prev, what, fmt) : '';
const pavs = (pairs, max) => !window.UI14 || !pairs ? '' : '<span class="pavs">' + String(pairs).split('|').slice(0, max || 3).map(x => { const i = x.indexOf('~'); return UI14.pav(x.slice(i + 1), x.slice(0, i), null, 'sm'); }).join('') + '</span>';
const stc = k => window.UI14 && k ? ' st-' + k : '';

async function api(url, body) {
  const u = url.replace('/api/auth/', 'auth_api.php/').replace('/api/', 'api.php/');
  const xi = { 'X-Idle': String(Math.floor((Date.now() - (typeof LAST_ACT === 'number' ? LAST_ACT : Date.now())) / 1000)) };
  const r = await fetch(u, body ? { method: 'POST', headers: { 'Content-Type': 'application/json', ...xi }, body: JSON.stringify(body) } : { headers: xi });
  const txt = await r.text(); let d = null;
  try { d = JSON.parse(txt); } catch (e) {}
  const snip = txt.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 300);
  if (r.status === 401 && !/login|verify|forgot|reset|setup/.test(location.pathname)) location = 'login.php' + (d && d.idle ? '?idle=1' : '');
  if (d && d._debug) console.warn('The server printed extra output:', d._debug);
  if (!r.ok) { const e = new Error((d && d.error) || ('Server error: ' + (snip || r.status))); e.field = d && d.field; e.data = d; throw e; }
  if (d === null) throw new Error('The server sent an unexpected reply: ' + (snip || '(empty)'));
  return d;
}

function paintAvatar(me) {
  const av = $('#av'); if (!av) return;
  av.title = me.name;
  if (me.photo) { av.style.backgroundImage = `url(${me.photo})`; av.textContent = ''; }
  else { av.style.backgroundImage = ''; av.textContent = me.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase(); }
}
async function shell() {
  const me = await api('/api/auth/me');
  if ($('#branch')) $('#branch').textContent = me.branch || '';
  paintAvatar(me);
  $('#out').onclick = async () => { await api('/api/auth/logout', {}); location = 'login.php'; };
  initBell();
}

function bindForm(sel, submit) {
  const f = $(sel);
  f.onsubmit = async e => {
    e.preventDefault();
    $$('.ferr', f).forEach(x => x.textContent = ''); $$('.bad', f).forEach(x => x.classList.remove('bad'));
    if ($('.err', f)) $('.err', f).textContent = '';
    const data = Object.fromEntries(new FormData(f)); data.action = e.submitter?.value;
    try { await submit(data); }
    catch (x) {
      const t = x.field && $(`[data-f="${x.field}"]`, f);
      if (t) { t.textContent = x.message; $(`[name="${x.field}"]`, f)?.classList.add('bad'); } else if ($('.err', f)) $('.err', f).textContent = x.message;
    }
  };
}

function dialog(html, onSubmit, label = 'Save changes', cancel = 'Cancel') {
  const d = document.createElement('dialog');
  d.innerHTML = `<form class="form">${html}<p class="err"></p><div class="actions">
    <button type="button" class="btn ghost" data-x>${cancel}</button><button class="btn">${label}</button></div></form>`;
  document.body.append(d); d.showModal();
  $('[data-x]', d).onclick = () => d.close();
  d.onclose = () => d.remove();
  $('form', d).onsubmit = async e => {
    e.preventDefault();
    try { await onSubmit(Object.fromEntries(new FormData(e.target))); d.close(); } catch (x) { $('.err', d).textContent = x.message; }
  };
  return d;
}

// Searchable client picker: type a name, pet name, phone or email; results come from the server, so 1,000 clients is no problem.
function clientCombo(host, onPick, placeholder = 'Search client by name, pet, or phone...') {
  host.classList.add('combo');
  host.innerHTML = `<input class="cin" placeholder="${E(placeholder)}" autocomplete="off"><ul class="opts" hidden></ul>`;
  const inp = $('.cin', host), ul = $('.opts', host);
  let t, sel = null, items = [], hi = -1;
  const mark = () => $$('li[data-i]', ul).forEach((li, i) => li.classList.toggle('hi', i === hi));
  const show = async () => {
    const r = await api('/api/clients?per=8&q=' + encodeURIComponent(inp.value.trim()));
    items = r.rows; hi = -1;
    ul.innerHTML = items.length
      ? items.map((c, i) => `<li data-i="${i}"><b>${E(c.name)}</b><small>${E([c.phone, c.pets].filter(Boolean).join(' \u00B7 '))}</small></li>`).join('') +
        (r.total > items.length ? `<li class="more">${r.total - items.length} more. Keep typing to narrow it down.</li>` : '')
      : '<li class="more">No clients found</li>';
    ul.hidden = false;
  };
  const pick = c => { sel = c; inp.value = c ? c.name : ''; ul.hidden = true; onPick?.(c); };
  inp.oninput = () => { if (sel) { sel = null; onPick?.(null); } clearTimeout(t); t = setTimeout(show, 200); };
  inp.onfocus = () => { if (!sel) show(); };
  inp.onkeydown = e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (ul.hidden) return show(); hi = Math.max(0, Math.min(items.length - 1, hi + (e.key === 'ArrowDown' ? 1 : -1))); mark(); }
    else if (e.key === 'Enter' && !ul.hidden && items.length) { e.preventDefault(); pick(items[Math.max(hi, 0)]); }
    else if (e.key === 'Escape') ul.hidden = true;
  };
  ul.onmousedown = e => { const li = e.target.closest('li[data-i]'); if (li) { e.preventDefault(); pick(items[li.dataset.i]); } };
  inp.onblur = () => setTimeout(() => ul.hidden = true, 150);
  return { get id() { return sel ? sel.id : ''; }, pick, clear: () => pick(null) };
}

// client search box + pet dropdown (a client only has a few pets, so a dropdown is fine there)
async function pickers(host, ps, onPet, pre = {}) {
  let want = null;
  const loadPets = async c => {
    if (!c) { ps.innerHTML = '<option value="">Choose a client first</option>'; return onPet?.(); }
    const d = await api('/api/clients/' + c.id);
    ps.innerHTML = d.pets.length ? d.pets.map(p => `<option value="${p.id}">${E(p.name)} (${E(p.species || '')})</option>`).join('') : '<option value="">This client has no pets yet</option>';
    if (want) { ps.value = want; want = null; }
    onPet?.();
  };
  const cb = clientCombo(host, loadPets);
  ps.innerHTML = '<option value="">Choose a client first</option>';
  ps.onchange = () => onPet?.();
  if (pre.client) { want = pre.pet; cb.pick(await api('/api/clients/' + pre.client)); }
  return cb;
}

// ---- service records: one config drives the Services, Pet Profile and record form pages ----
const outBadge = o => o ? `<span class="badge ${o === 'Died' ? 'x' : 'g'}">${E(o)}</span>` : '-';
const clip = (t, n = 45) => { t = t || ''; return `<span title="${E(t)}">${E(t.length > n ? t.slice(0, n) + '...' : t || '-')}</span>`; };
const ITEM_TYPES = ['Vaccine', 'Deworming', 'Tick and flea', 'Other'];
const SVC = {
  vaccination: {
    name: 'Vaccination', form: 'Vaccination Record', card: 'Vaccination History', side: 'Vaccination History', sub: 'Vaccines administered and next schedules.', sideN: 3,
    fields: [{ k: 'item_type', l: 'Type', t: 'itemtype' }, { k: 'vaccine', l: 'Vaccine / Treatment Given', ph: 'e.g. Anti-rabies, Deworming tablet, Tick and flea drops', req: 1 }, { k: 'vac_date', l: 'Date Given', t: 'date', min: 1, half: 1, req: 1 },
      { k: 'next_due', l: 'Next Schedule', t: 'date', min: 1, half: 1 }, { k: 'notes', l: 'Notes', t: 'area', ph: 'Optional notes' }],
    over: [['Pet', r => E(r.pet)], ['Given', r => E(r.vaccine)], ['Date', r => D(r.vac_date)]],
    pet: [['Given', r => E(r.vaccine)], ['Date', r => D(r.vac_date)], ['Next Due', r => D(r.next_due)]],
    all: [['Type', r => E(r.item_type || 'Vaccine')], ['Given', r => E(r.vaccine)], ['Date', r => D(r.vac_date)], ['Next Due', r => D(r.next_due)], ['Notes', r => clip(r.notes)]]
  },
  checkup: {
    name: 'Check-Up', form: 'Check-Up Record', card: 'Check-Up History', side: 'Previous Check-Ups', sub: 'Consultation details and clinical findings.', sideN: 2,
    fields: [{ k: 'checkup_date', l: 'Date of Consultation', t: 'date', min: 1, half: 1, req: 1 }, { k: 'vet', l: 'Veterinarian', t: 'vet', half: 1 },
      { k: 'chief_complaint', l: 'Chief Complaint', t: 'area', rows: 2, ph: 'Why the owner brought the pet in' }, { k: 'details', l: 'History / Other Details', t: 'area', rows: 2, ph: 'History, symptoms, notes (optional)' },
      { k: 'tests', l: 'Tests / Diagnostics Done', t: 'area', rows: 2, half: 1, ph: 'e.g. Blood test, X-ray, skin scraping' }, { k: 'test_results', l: 'Results', t: 'area', rows: 2, half: 1, ph: 'Results of the tests' },
      { k: 'findings', l: 'Clinical Findings', t: 'area', rows: 2, half: 1, ph: 'Examination findings' }, { k: 'diagnosis', l: 'Diagnosis', t: 'area', rows: 2, half: 1, ph: 'Diagnosis' },
      { k: 'prescription', l: 'Prescription', t: 'area', rows: 3, ph: 'Medicines, dose and how long' },
      { k: 'next_step', l: 'Next Step', t: 'step', flow: 1 }, { k: 'followup_date', l: 'Follow-up Date (optional)', t: 'date', min: 1, half: 1, flow: 1 },
      { k: 'followup_time', l: 'Next Check-Up Time', t: 'time', half: 1, flow: 1, nostore: 1 }, { k: 'followup_purpose', l: 'Purpose of Follow-up', ph: 'e.g. Recheck wound, repeat blood test', flow: 1 }],
    over: [['Pet', r => E(r.pet)], ['Reason', r => clip(r.chief_complaint || r.details)], ['Date', r => D(r.checkup_date)]],
    pet: [['Date', r => D(r.checkup_date)], ['Complaint', r => clip(r.chief_complaint || r.details, 28)], ['Diagnosis', r => clip(r.diagnosis || r.findings, 28)], ['Vet', r => E(r.vet || '-')]],
    all: [['Date', r => D(r.checkup_date)], ['Vet', r => E(r.vet || '-')], ['Chief Complaint', r => clip(r.chief_complaint || r.details, 24)], ['Tests', r => clip(r.tests, 20)], ['Results', r => clip(r.test_results, 20)], ['Diagnosis', r => clip(r.diagnosis || r.findings, 24)], ['Prescription', r => clip(r.prescription, 24)], ['Follow-up', r => r.followup_date ? D(r.followup_date) + (r.followup_purpose ? ' (' + E(r.followup_purpose) + ')' : '') : '-']]
  },
  confinement: {
    name: 'Confinement', form: 'Confinement Record', card: 'Confinement Records', side: 'Confinement History', sub: 'Admissions, discharges and confinement status.', sideN: 3,
    fields: [{ k: 'admitted', l: 'Admission Date', t: 'date', min: 1, half: 1, req: 1 }, { k: 'discharged', l: 'Discharge Date', t: 'date', min: 1, half: 1 },
      { k: 'status', l: 'Confinement Status', t: 'status', half: 1 }, { k: 'outcome', l: 'Outcome', t: 'outcome', half: 1 }, { k: 'reason', l: 'Reason for Confinement', ph: 'Reason' },
      { k: 'treatment', l: 'Treatment', t: 'area', ph: 'Treatment given, medications...' }, { k: 'notes', l: 'Notes', t: 'area', ph: 'Other relevant notes' }],
    over: [['Pet', r => E(r.pet)], ['Status', r => badge(r.status)], ['Admitted', r => D(r.admitted)]],
    pet: [['Admitted', r => D(r.admitted)], ['Discharged', r => D(r.discharged)], ['Status', r => badge(r.status)]],
    all: [['Admitted', r => D(r.admitted)], ['Discharged', r => D(r.discharged)], ['Status', r => badge(r.status)], ['Outcome', r => outBadge(r.outcome)], ['Reason', r => clip(r.reason, 30)], ['Treatment', r => clip(r.treatment, 30)], ['Notes', r => clip(r.notes, 30)]]
  },
  surgery: {
    name: 'Surgery', form: 'Surgery Record', card: 'Surgery History', side: 'Surgical History', sub: 'Procedures performed and surgical notes.', sideN: 2,
    fields: [{ k: 'procedure_name', l: 'Type of Surgery', ph: 'e.g. Neutering, Spay, Wound repair', req: 1 }, { k: 'surgery_date', l: 'Surgery Date', t: 'date', min: 1, half: 1, req: 1 },
      { k: 'vet', l: 'Veterinarian', t: 'vet', half: 1 }, { k: 'outcome', l: 'Outcome', t: 'outcome', half: 1 }, { k: 'findings', l: 'Findings', t: 'area', ph: 'Relevant findings' }, { k: 'notes', l: 'Procedure Notes', t: 'area', ph: 'Procedure notes, post-op instructions...' }],
    over: [['Pet', r => E(r.pet)], ['Procedure', r => E(r.procedure_name)], ['Date', r => D(r.surgery_date)]],
    pet: [['Procedure', r => E(r.procedure_name)], ['Date', r => D(r.surgery_date)], ['Vet', r => E(r.vet || '-')]],
    all: [['Procedure', r => E(r.procedure_name)], ['Date', r => D(r.surgery_date)], ['Vet', r => E(r.vet || '-')], ['Outcome', r => outBadge(r.outcome)], ['Findings', r => clip(r.findings)], ['Procedure Notes', r => clip(r.notes)]]
  }
};
const tableHTML = (cols, rows, extra, click) => `<table><thead><tr>${cols.map(c => `<th>${c[0]}</th>`).join('')}${extra ? '<th></th>' : ''}</tr></thead><tbody>` +
  (rows.length ? rows.map((r, i) => `<tr${click ? ` class="click" data-i="${i}" title="Click to view details"` : ''}>${cols.map(c => `<td>${c[1](r)}</td>`).join('')}${extra ? `<td>${extra(r)}</td>` : ''}</tr>`).join('')
    : `<tr><td colspan="${cols.length + (extra ? 1 : 0)}" class="empty">No records yet.</td></tr>`) + '</tbody></table>';

// puts a table in el; if type is given, clicking a row opens the full record
function renderTable(el, cols, rows, type, extra) {
  el.innerHTML = tableHTML(cols, rows, extra, !!type);
  if (type) $$('tr[data-i]', el).forEach(tr => tr.onclick = e => { if (!e.target.closest('a')) showRecord(type, rows[tr.dataset.i]); });
}
function showRecord(type, r, readonly) {
  const S = SVC[type], dk = (S.fields.find(f => f.t === 'date') || {}).k, ro = readonly || (typeof ROLE !== 'undefined' && (ROLE !== 'vet' || (typeof CAN_EDIT_REC !== 'undefined' && !CAN_EDIT_REC)));   // only vets edit records (and only while VET_CAN_EDIT_RECORDS is true)
  const d = document.createElement('dialog');
  d.innerHTML = `<h3>${S.name} record</h3><p class="muted" style="margin:0">Pet: ${E(r.pet)}${r.client ? ' &middot; ' + E(r.client) : ''}</p>
    <p style="margin:.4rem 0 0"><b>Visit date: ${D(r[dk])}</b>${r.recorded_at ? ` <small class="muted">&middot; recorded ${D(String(r.recorded_at).slice(0, 10))}${r.recorded_by ? ' by ' + E(r.recorded_by) : ''}</small>` : ''}${r.edited_by ? `<br><small class="muted">Edited by ${E(r.edited_by)}${r.edited_at ? ' on ' + D(String(r.edited_at).slice(0, 10)) : ''}</small>` : ''}</p>
    <dl>${S.fields.filter(f => !f.nostore && f.k !== dk).map(f => `<dt>${f.l}</dt><dd>${E(f.t === 'date' ? D(r[f.k]) : r[f.k] || '-')}</dd>`).join('')}</dl>
    <div class="actions">${ro ? '' : `<a class="btn ghost" href="service_form.php?type=${type}&id=${r.id}">Edit</a>`}<button class="btn" data-x>Close</button></div>`;
  document.body.append(d); d.showModal();
  $('[data-x]', d).onclick = () => d.close(); d.onclose = () => d.remove();
}

function fieldHTML(f, val, noMin) {
  const v = E(val ?? ''), ph = E(f.ph || '');
  const inp = f.t === 'area' ? `<textarea name="${f.k}" rows="${f.rows || 3}" placeholder="${ph}">${v}</textarea>`
    : f.t === 'vet' ? `<select name="${f.k}"><option value="">Select veterinarian</option>${VETS.map(x => `<option ${x === (val === undefined ? ME_NAME : val) ? 'selected' : ''}>${E(x)}</option>`).join('')}</select>`
    : f.t === 'step' ? `<select name="${f.k}">${[['None', 'None: done with check-up, no further need'], ['Confinement', 'Confinement'], ['Surgery', 'Surgery']].map(([v, l]) => `<option value="${v}" ${v === (val || 'None') ? 'selected' : ''}>${l}</option>`).join('')}</select>`
    : f.t === 'itemtype' ? `<select name="${f.k}">${ITEM_TYPES.map(x => `<option ${x === (val || 'Vaccine') ? 'selected' : ''}>${x}</option>`).join('')}</select>`
    : f.t === 'outcome' ? `<select name="${f.k}"><option value="">${f.k === 'outcome' ? 'Not recorded yet' : ''}</option>${['Survived', 'Died'].map(x => `<option ${x === val ? 'selected' : ''}>${x}</option>`).join('')}</select>`
    : f.t === 'status' ? `<select name="${f.k}"><option>Admitted</option><option ${val === 'Discharged' ? 'selected' : ''}>Discharged</option></select>`
    : `<input name="${f.k}" type="${f.t || 'text'}" value="${v}" placeholder="${ph}" ${f.req ? 'required' : ''}${f.min && !noMin ? ' min="' + today() + '"' : ''}>`;
  return `<label>${f.l}${inp}</label>`;
}
function fieldsHTML(fields, data = {}, noMin = false) {
  let h = '', i = 0;
  while (i < fields.length) {
    const f = fields[i], g = fields[i + 1];
    if (f.half && g?.half) { h += `<div class="fr">${fieldHTML(f, data[f.k], noMin)}${fieldHTML(g, data[g.k], noMin)}</div>`; i += 2; }
    else { h += fieldHTML(f, data[f.k], noMin); i++; }
  }
  return h;
}

async function loadTable(el, cols, url, type, extra) {
  try { renderTable(el, cols, await api(url), type, extra); }
  catch (x) { el.innerHTML = `<p class="err">Could not load records: ${E(x.message)}</p>`; }
}

const fmtDay = d => new Date(d + 'T00:00').toLocaleDateString('en', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });

const roleName = r => ({ client: 'Client', staff: 'Staff', vet: 'Vet', admin: 'Admin' }[r] || r);

// Product / medicine picker (Billing and New Sale): set a quantity with - / +, then press Done to add everything to the bill.
function productPicker(onAdd, onDone) {
  const d = document.createElement('dialog'), pend = {};   // name -> { price, qty }
  d.innerHTML = `<h3>Add product / medicine</h3><input id="pq" placeholder="Search products..." autocomplete="off"><div class="plist" id="plist"></div>
    <details><summary>Not in the list? Add a new product</summary><div class="form"><div class="fr"><label>Name<input id="pn"></label><label>Price (\u20B1)<input id="pp" type="number" min="0" step="0.01"></label></div>
    <button type="button" class="btn ghost" id="padd">Save product</button><p class="err" id="perr"></p></div></details>
    <div class="ptotal"><span>To add: <b id="pcount">0 items</b></span><b id="ptot">${peso(0)}</b></div>
    <div class="actions"><button type="button" class="btn plain" data-x>Cancel</button><button type="button" class="btn" id="pdone">Done</button></div>`;
  document.body.append(d); d.showModal(); d.onclose = () => d.remove(); $('[data-x]', d).onclick = () => d.close();
  let t;
  const sums = () => {
    const l = Object.values(pend).filter(x => x.qty > 0), n = l.reduce((s, x) => s + x.qty, 0);
    $('#pcount', d).textContent = n + (n === 1 ? ' item' : ' items'); $('#ptot', d).textContent = peso(l.reduce((s, x) => s + x.qty * x.price, 0));
  };
  const load = async () => {
    const rows = await api('/api/products?q=' + encodeURIComponent($('#pq', d).value.trim()));
    $('#plist', d).innerHTML = rows.length ? rows.map((p, i) => { const q = pend[p.name] ? pend[p.name].qty : 0;
      return `<div class="prow"><span>${E(p.name)}<small>${peso(p.price)} each</small></span>
        <div class="qty"><button type="button" data-m="${i}" aria-label="Less">&minus;</button><b id="qty${i}">${q}</b><button type="button" data-p="${i}" aria-label="More">+</button></div>
        <b class="pa" id="amt${i}">${q ? peso(q * p.price) : ''}</b></div>`; }).join('') : '<p class="muted">No products found.</p>';
    const set = (i, dq) => {
      const p = rows[i], e = pend[p.name] || (pend[p.name] = { id: p.id, price: +p.price, qty: 0 });
      e.qty = Math.max(0, e.qty + dq); $('#qty' + i, d).textContent = e.qty; $('#amt' + i, d).textContent = e.qty ? peso(e.qty * e.price) : ''; sums();
    };
    $$('[data-p]', d).forEach(b => b.onclick = () => set(+b.dataset.p, 1));
    $$('[data-m]', d).forEach(b => b.onclick = () => set(+b.dataset.m, -1));
  };
  $('#pq', d).oninput = () => { clearTimeout(t); t = setTimeout(load, 200); };
  $('#padd', d).onclick = async () => {
    try {
      const p = await api('/api/products', { name: $('#pn', d).value, price: $('#pp', d).value || 0 });
      pend[p.name] = { id: p.id, price: +p.price, qty: (pend[p.name] ? pend[p.name].qty : 0) + 1 };
      $('#pn', d).value = ''; $('#pp', d).value = ''; $('#perr', d).textContent = ''; $('#pq', d).value = p.name; d.querySelector('details').open = false; sums(); load();
    } catch (x) { $('#perr', d).textContent = x.message; }
  };
  $('#pdone', d).onclick = () => {
    Object.entries(pend).filter(([, v]) => v.qty > 0).forEach(([name, v]) => onAdd({ item: name, qty: v.qty, price: v.price, product_id: v.id }));
    onDone?.(); d.close();
  };
  load();
}

// Appointment popup. Pending: review and approve. Everyone: check in, start the record, reschedule or cancel (who may do what is decided on the server).
const APPT_TYPE = { 'Vaccination': 'vaccination', 'Check-Up': 'checkup', 'Confinement': 'confinement', 'Surgery': 'surgery' };
const CANCEL_REASONS = { staff: ['Pet owner asked to cancel', 'Pet owner cannot be reached', 'Veterinarian unavailable', 'Clinic closed / emergency', 'Booked by mistake', 'Other'],
  vet: ['Emergency case', 'Veterinarian unavailable / ill', 'Other'], client: ['I cannot make it', 'My pet is feeling better', 'Booked by mistake', 'Found a different time', 'Other'] };
function manageAppt(a, date, reload) {
  const clinic = typeof ROLE !== 'undefined' && (ROLE === 'staff' || ROLE === 'vet');
  const open = a.status !== 'Completed' && a.status !== 'Cancelled', cancelled = a.status === 'Cancelled';
  const arrived = a.checked_in_at ? `<dt>Arrived</dt><dd>${E(a.checked_in_at.slice(11, 16))}${a.room ? ', ' + E(a.room) : ''}</dd>` : '';
  const why = cancelled ? `<dt>Cancelled</dt><dd>${E(a.cancelled_by || '')}${a.cancel_reason ? ': ' + E(a.cancel_reason) : ''}</dd>` : '';
  const info = `<dl><dt>Client</dt><dd>${E(a.client)}</dd><dt>Pet</dt><dd>${E(a.pet)}</dd>
    <dt>Service</dt><dd>${E(a.service)}${a.vet ? ' with ' + E(a.vet) : ' <span class="muted">(no vet assigned yet)</span>'}</dd>
    <dt>When</dt><dd>${fmtDate(date)}, ${+a.is_queue ? 'any time (first come, first served)' : fmtTime(a.time)} (${E(a.branch || '-')})</dd>${+a.queue_no ? `<dt>Queue number</dt><dd>${a.queue_no}</dd>` : ''}
    <dt>Requested</dt><dd>${a.source === 'Online' ? 'Online, by the pet owner' : a.source === 'Walk-in' ? 'Walk-in' : 'At the clinic'}</dd>${arrived}${why}`;
  const isToday = date === today();
  const checkin = clinic && isToday && !a.checked_in_at && a.status !== 'Completed' && (!cancelled || a.cancelled_by === 'System')
    && ROLE === 'staff' ? `<a class="btn ghost" href="checkin.php?appt=${a.id}">${cancelled ? 'Check in as walk-in' : 'Check in'}</a>` : '';
  const canMove = clinic && ROLE === 'staff' && open, canCancel = clinic && open && !a.started_at && (ROLE === 'staff' || a.vet === ME_NAME);
  const canDelete = clinic && ROLE === 'staff' && (a.status === 'Pending' || cancelled);
  const btns = (canMove ? '<button type="button" class="btn ghost" id="mv">Reschedule</button>' : '') + (canCancel ? '<button type="button" class="btn danger" id="cx">Cancel appointment</button>' : '') + (canDelete ? '<button type="button" class="btn plain" id="del">Delete</button>' : '');
  const wire = d => {
    if ($('#del', d)) $('#del', d).onclick = async () => { if (confirm('Delete this appointment permanently? (Cancelling keeps a record; deleting does not.)')) { await api('/api/appointments/' + a.id, { delete: 1 }); d.close(); reload?.(); } };
    if ($('#cx', d)) $('#cx', d).onclick = () => { d.close(); cancelDialog({ summary: `${a.pet} (${a.client}): ${a.service}, ${fmtDate(date)} ${+a.is_queue ? '' : fmtTime(a.time)}`, reasons: CANCEL_REASONS[ROLE],
      note: 'The pet owner and the others involved are notified automatically.', submit: r => api('/api/appointments/' + a.id, { cancel: 1, reason: r }), done: reload }); };
    if ($('#mv', d)) $('#mv', d).onclick = () => { d.close(); rescheduleDialog({ summary: `${a.pet} (${a.client}): ${a.service}, now ${fmtDate(date)} ${+a.is_queue ? '' : fmtTime(a.time)}`, date, queue: !!+a.is_queue,
      slots: dt => api(`/api/schedule/slots?date=${dt}&branch=${encodeURIComponent(a.branch || '')}&appt=${a.id}`),
      submit: (dt, t) => api('/api/appointments/' + a.id, { reschedule: 1, date: dt, time: t }), done: reload }); };
  };
  if (a.status === 'Pending') {   // approve it: the pet owner then sees it as approved
    const d = dialog(`<h3>Appointment details</h3>${info}</dl>
      <label>Notes<textarea name="reason" placeholder="No notes">${E(a.reason)}</textarea></label>
      <label>Status<select name="status"><option selected>Pending</option><option>Confirmed</option></select></label>
      <p class="muted" style="margin:0">Choose Confirmed and save to approve this appointment. The pet owner will see it as approved.</p>
      <div class="actions" style="justify-content:flex-start">${checkin}${btns}</div>`, async f => { await api('/api/appointments/' + a.id, f); reload?.(); });
    wire(d); return;
  }
  const rec = `service_form.php?type=${APPT_TYPE[a.service]}&pet_id=${a.pet_id}&appt=${a.id}`;
  const start = clinic && a.checked_in_at && a.status !== 'Completed' && a.status !== 'Cancelled' ? `<a class="btn" href="charge.php?appt=${a.id}">${ROLE === 'vet' ? 'Charge sheet / Done' : 'Charge sheet'}</a>` : '';
  const after = a.status === 'Completed' && clinic ? (ROLE === 'vet' ? (+a.record_done ? '' : `<a class="btn" href="${rec}">Write record</a>`) + `<a class="btn ghost" href="charge.php?appt=${a.id}">Charge sheet</a>`
    : a.bill_id ? (a.bill_status === 'Paid' ? `<a class="btn ghost" href="receipt.php?id=${a.bill_id}">Billing statement</a>` : `<a class="btn" href="pay.php?id=${a.bill_id}">Take payment</a>`) : '') : '';
  const bill = after;
  const d = document.createElement('dialog');
  d.innerHTML = `<h3>Appointment details</h3>${info}<dt>Status</dt><dd>${badge(a.status)}</dd><dt>Notes</dt><dd>${E(a.reason || 'No notes')}</dd></dl>
    <div class="actions">${btns}<button type="button" class="btn ghost" data-x>Close</button>${checkin}${start}${bill}</div>`;
  document.body.append(d); d.showModal(); d.onclose = () => d.remove();
  $('[data-x]', d).onclick = () => d.close(); wire(d);
}

// ---- time-slot buttons shared by every booking screen ----
const WHY = { past: 'Passed', soon: 'Too soon', late: 'Closed', full: 'Full' };
function drawSlots(el, r, onPick, showVet) {
  el.innerHTML = r.range ? '<span class="muted">Please pick a date from today up to 30 days ahead.</span>' : r.closed ? '<span class="muted">The clinic is closed on that day. Please pick another date.</span>'
    : r.slots.length ? r.slots.map(s => `<button type="button" class="slot" data-t="${s.time}" ${s.ok ? '' : 'disabled'}>${fmtTime(s.time)}<small>${s.ok ? (showVet && s.vet ? E(s.vet.replace(/^Dr\.\s*/, '')) : '') : (WHY[s.why] || 'Full')}</small></button>`).join('')
    : '<span class="muted">No times available on that date.</span>';
  if (r.note) el.innerHTML += `<p class="muted" style="flex-basis:100%;margin:.25rem 0 0">${E(r.note)}</p>`;
  $$('.slot', el).forEach(b => b.onclick = () => { $$('.slot', el).forEach(x => x.classList.remove('on')); b.classList.add('on'); onPick(b.dataset.t); });
}
function showSuggestions(box, list, pick) {   // "nearest available times" after a clash
  box.hidden = false;
  box.innerHTML = '<b>Nearest available times:</b> ' + list.map(s => `<button type="button" class="slot" data-d="${s.date}" data-t="${s.time}">${E(fmtDay(s.date))}, ${fmtTime(s.time)}${s.vet && ROLE !== 'client' ? '<small>' + E(s.vet) + '</small>' : ''}</button>`).join(' ');
  $$('[data-d]', box).forEach(b => b.onclick = () => pick(b.dataset.d, b.dataset.t));
}
function rescheduleDialog(o) {
  const d = document.createElement('dialog');
  d.innerHTML = `<form class="form"><h3>Reschedule appointment</h3><p class="muted" style="margin:0">${E(o.summary)}</p>
    ${o.note ? `<p class="devnote" style="margin:0">${E(o.note)}</p>` : ''}
    <label>New date<input type="date" id="rd"></label>${o.queue ? '<p class="muted" style="margin:0">Check-ups have no set time. Choose the day; the owner comes any time that day and is seen first come, first served.</p>' : '<div class="field"><span class="lbl">Available times</span><div class="slots" id="rs"></div></div>'}
    <div class="sugbox" id="rsug" hidden></div><p class="err"></p>
    <div class="actions"><button type="button" class="btn plain" data-x>Keep current time</button><button class="btn">Reschedule</button></div></form>`;
  document.body.append(d); d.showModal(); d.onclose = () => d.remove();
  const rd = $('#rd', d); rd.min = today();
  if (o.maxDays) { const m = new Date(); m.setDate(m.getDate() + o.maxDays); rd.max = m.toLocaleDateString('en-CA'); }
  rd.value = o.date && o.date >= today() ? o.date : today();
  let time = '';
  const load = async () => { time = ''; $('#rsug', d).hidden = true; if (o.queue) return; try { drawSlots($('#rs', d), await o.slots(rd.value), t => time = t, ROLE !== 'client'); } catch (x) { $('.err', d).textContent = x.message; } };
  rd.onchange = load; load();
  $('[data-x]', d).onclick = () => d.close();
  $('form', d).onsubmit = async e => {
    e.preventDefault(); const err = $('.err', d); err.textContent = '';
    if (!time && !o.queue) { err.textContent = 'Pick one of the available times.'; return; }
    try { await o.submit(rd.value, o.queue ? '00:00' : time); d.close(); o.done?.(); }
    catch (x) { err.textContent = x.message; if (x.data?.suggestions) showSuggestions($('#rsug', d), x.data.suggestions, async (dt, t) => { rd.value = dt; await load(); const b = $(`.slot[data-t="${t}"]`, $('#rs', d)); if (b && !b.disabled) b.click(); }); }
  };
}
function cancelDialog(o) {
  dialog(`<h3>Cancel appointment</h3><p class="muted" style="margin:0">${E(o.summary)}</p>${o.note ? `<p class="devnote" style="margin:0">${E(o.note)}</p>` : ''}
    <label>Reason<select name="reason">${o.reasons.map(r => `<option>${E(r)}</option>`).join('')}</select></label>
    <label>More details (optional)<input name="more" placeholder="Anything we should know?"></label>`,
    async f => { await o.submit(f.more ? `${f.reason}: ${f.more}` : f.reason); o.done?.(); }, 'Cancel appointment', 'Keep appointment');
}

// ---- pet documents (birth certificate, vaccination card...) and the pet profile popup ----
function fileToDoc(file) {
  return new Promise((res, rej) => {
    if (file.type === 'application/pdf') {
      if (file.size > 2.5e6) return rej(new Error('That PDF is too large (limit 2.5 MB). Please use a smaller file or a photo of it.'));
      const fr = new FileReader(); fr.onload = () => res({ name: file.name, mime: file.type, data: fr.result }); fr.onerror = () => rej(new Error('Could not read that file.')); return fr.readAsDataURL(file);
    }
    if (!/^image\//.test(file.type)) return rej(new Error('Please choose a photo (JPG or PNG) or a PDF.'));
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, 1600 / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src); res({ name: file.name.replace(/\.[^.]+$/, '') + '.jpg', mime: 'image/jpeg', data: c.toDataURL('image/jpeg', 0.82) });
    };
    img.onerror = () => rej(new Error('That file is not a valid image.')); img.src = URL.createObjectURL(file);
  });
}
const DOC_TYPES = ['Birth certificate', 'Vaccination card', 'Medical history', 'Pedigree / registration', 'Other'];
async function openDoc(petId, id) {
  const r = await api(`/api/pets/${petId}/documents/${id}`), b = await (await fetch(r.data)).blob();
  window.open(URL.createObjectURL(b), '_blank');
}
const missingOf = p => [!p.breed && 'breed', !p.sex && 'sex', !p.birthdate && 'birthdate'].filter(Boolean);
const petAge = bd => { if (!bd) return ''; const m = Math.max(0, Math.floor((Date.now() - new Date(bd + 'T00:00')) / 2629800000)); return m < 12 ? m + ' mo' : Math.floor(m / 12) + ' yr' + (Math.floor(m / 12) > 1 ? 's' : ''); };
// "Complete details" + "Upload documents" block; used inside the check-in confirmation and the pet profile popup.
function detailsFormHTML(p, id) {
  return `<div class="form" id="${id}"><div class="fr"><label>Breed<input name="breed" value="${E(p.breed || '')}" placeholder="e.g. Shih Tzu"></label>
      <label>Sex<select name="sex"><option value="">Select</option>${['Male', 'Female'].map(s => `<option ${p.sex === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
      <label>Birthdate<input name="birthdate" type="date" max="${today()}" value="${E(p.birthdate || '')}"></label></div>
    <div class="btns" style="margin:0"><button type="button" class="btn" data-save>Save details</button></div><p class="err" data-derr></p></div>`;
}
function docFormHTML(id) {
  return `<div class="form" id="${id}"><div class="fr"><label>Document type<select name="doc_type">${DOC_TYPES.map(t => `<option>${t}</option>`).join('')}</select></label>
      <label>File (photo or PDF)<input name="file" type="file" accept="image/*,application/pdf"></label></div>
    <div class="btns" style="margin:0"><button type="button" class="btn ghost" data-up>Upload document</button></div><p class="err" data-uerr></p></div>`;
}
function bindDetails(root, p, after) {
  const save = $('[data-save]', root); if (!save) return;
  save.onclick = async () => {
    const q = n => $(`[name=${n}]`, root).value; $('[data-derr]', root).textContent = '';
    try { await api('/api/pets/' + p.id, { name: p.name, species: p.species, breed: q('breed'), sex: q('sex'), birthdate: q('birthdate') }); after?.(); }
    catch (x) { $('[data-derr]', root).textContent = x.message; }
  };
}
function bindDocs(root, petId, after) {
  const up = $('[data-up]', root); if (!up) return;
  up.onclick = async () => {
    const f = $('[name=file]', root).files[0], err = $('[data-uerr]', root); err.textContent = '';
    if (!f) { err.textContent = 'Choose a file first.'; return; }
    up.disabled = true;
    try { const doc = await fileToDoc(f); await api(`/api/pets/${petId}/documents`, { ...doc, doc_type: $('[name=doc_type]', root).value }); after?.(); }
    catch (x) { err.textContent = x.message; up.disabled = false; }
  };
}
async function petProfileDialog(petId, opt = {}) {
  const d = document.createElement('dialog'); d.className = 'wide';
  d.innerHTML = '<p class="muted">Loading pet profile...</p>'; document.body.append(d); d.showModal();
  d.onclose = () => { d.remove(); opt.onClose?.(); };
  const render = async () => {
    const r = await api(`/api/pets/${petId}/profile`), p = r.pet, miss = missingOf(p), mini = (rows, cols) => rows.length
      ? `<table><tbody>${rows.map(x => `<tr>${cols.map(c => `<td>${c(x)}</td>`).join('')}</tr>`).join('')}</tbody></table>` : '<p class="muted" style="margin:0">None yet.</p>';
    d.innerHTML = `<div class="pphead"><div class="ph sm" style="${p.photo ? `background-image:url(${p.photo})` : ''}">${p.photo ? '' : E(p.name[0])}</div>
        <div style="flex:1"><h3 style="margin:0">${E(p.name)} <span class="tag">${E(p.species || '')}</span> ${r.confined ? '<span class="badge">Confined</span>' : ''} ${miss.length ? '<span class="badge p">Details incomplete</span>' : ''}</h3>
        <p class="muted" style="margin:.1rem 0 0">Owner: <a class="link" href="client.php?id=${p.client_id}">${E(r.client.name)}</a>${r.client.phone ? ' &middot; ' + E(r.client.phone) : ''}${+r.client.balance > 0 ? ` <span class="owes">Owes ${peso(r.client.balance)}</span>` : ''}</p></div></div>
      <dl class="ppdl"><div><dt>Breed</dt><dd>${E(p.breed || '-')}</dd></div><div><dt>Sex</dt><dd>${E(p.sex || '-')}</dd></div><div><dt>Birthdate</dt><dd>${p.birthdate ? D(p.birthdate) + ' (' + petAge(p.birthdate) + ')' : '-'}</dd></div></dl>
      <details class="blk" ${miss.length ? 'open' : ''}><summary>${miss.length ? `Complete pet details (missing: ${miss.join(', ')})` : 'Edit pet details'}</summary>${detailsFormHTML(p, 'pd')}</details>
      <h4>Documents</h4>${r.documents.length ? `<ul class="doclist">${r.documents.map(x => `<li><span><b>${E(x.doc_type)}</b> <small>${E(x.name)} &middot; ${D(x.created_at.slice(0, 10))}</small></span><button type="button" class="btn ghost sm" data-doc="${x.id}">View</button></li>`).join('')}</ul>` : '<p class="muted" style="margin:0 0 .5rem">No documents uploaded yet.</p>'}
      <details class="blk"><summary>Upload a document (birth certificate, vaccination card...)</summary>${docFormHTML('pu')}</details>
      <div class="ppcols"><div><h4>Vaccinations</h4>${mini(r.vaccination, [x => E(x.vaccine), x => D(x.vac_date)])}</div><div><h4>Check-ups</h4>${mini(r.checkup, [x => clip(x.details, 28), x => D(x.checkup_date)])}</div></div>
      <div class="actions"><button type="button" class="btn plain" data-x>Close</button>${r.next_appt ? `<span class="muted" style="margin-right:auto">Next visit: ${E(fmtDay(r.next_appt.appt_date))}, ${fmtTime(r.next_appt.time)} (${E(r.next_appt.service)})</span>` : ''}
        <button type="button" class="btn ghost" data-surg>Schedule surgery</button><a class="btn" href="pet.php?id=${p.id}">Open full profile</a></div>`;
    $('[data-x]', d).onclick = () => d.close();
    $$('[data-doc]', d).forEach(b => b.onclick = () => openDoc(petId, b.dataset.doc).catch(x => alert(x.message)));
    bindDetails($('#pd', d), p, render); bindDocs($('#pu', d), petId, render);
    $('[data-surg]', d).onclick = () => surgeryDialog({ pet_id: petId, label: `${p.name} (${r.client.name})`, branch: ME_BRANCH });
  };
  try { await render(); } catch (x) { d.innerHTML = `<p class="err">${E(x.message)}</p><div class="actions"><button class="btn" data-x>Close</button></div>`; $('[data-x]', d).onclick = () => d.close(); }
  return d;
}

// ---- schedule a surgery: shows which days a surgery-capable vet is free, then the free times ----
async function surgeryDialog(o) {
  const d = document.createElement('dialog'); d.className = 'wide';
  d.innerHTML = `<form class="form"><h3>Schedule surgery</h3><p class="muted" style="margin:0">${E(o.label)}</p>
    <div class="fr"><label>Branch<select id="sb" disabled><option selected>${E(MAIN_BRANCH)}</option></select></label><label>Surgeon<select id="sv"></select></label></div>
    <div class="field"><span class="lbl">Days when a vet is on duty and free</span><div class="daycards" id="sdays"></div></div>
    <div id="spick" hidden><label>Date<input type="date" id="sd"></label>
      <div class="field"><span class="lbl">Available times (surgery takes ${SVC_MIN.Surgery} minutes)</span><div class="slots" id="sslots"></div></div>
      <label>Procedure / reason<input id="sp" value="${E(o.reason || '')}" placeholder="e.g. Fracture repair"></label></div>
    <p class="err"></p><div class="actions"><button type="button" class="btn plain" data-x>${E(o.skipLabel || 'Close')}</button><button class="btn" id="sgo" disabled>${o.collect ? 'Use this time' : 'Schedule surgery'}</button></div></form>`;
  document.body.append(d); d.showModal();
  let time = '', fin = false;
  d.onclose = () => { d.remove(); if (!fin) { fin = true; o.done?.(null); } };
  const surgeons = () => VETINFO.filter(v => v.branch === $('#sb', d).value);   // every vet can do surgery
  let want = o.vet || '';   // the deciding vet is offered first (kept selected when he is on the list)
  const fillVets = () => { $('#sv', d).innerHTML = '<option value="">Any available surgeon</option>' + surgeons().map(v => `<option ${v.name === want ? 'selected' : ''}>${E(v.name)}</option>`).join(''); want = ''; };
  const loadSlots = async () => {
    time = ''; $('#sgo', d).disabled = true;
    drawSlots($('#sslots', d), await api(`/api/schedule/slots?date=${$('#sd', d).value}&branch=${encodeURIComponent($('#sb', d).value)}&service=Surgery&vet=${encodeURIComponent($('#sv', d).value)}`), t => { time = t; $('#sgo', d).disabled = false; }, true);
  };
  const loadDays = async () => {
    fillVets(); $('#spick', d).hidden = true; time = ''; $('#sgo', d).disabled = true;
    const days = await api(`/api/schedule/days?service=Surgery&branch=${encodeURIComponent($('#sb', d).value)}&vet=${encodeURIComponent($('#sv', d).value)}`);
    $('#sdays', d).innerHTML = days.length ? days.map(x => `<button type="button" class="daycard" data-d="${x.date}"><b>${E(fmtDay(x.date))}</b><span>${E(x.vets.join(', '))}</span><small>${x.slots} free time${x.slots === 1 ? '' : 's'}, from ${fmtTime(x.first)}</small></button>`).join('') : '<p class="muted" style="margin:0">No free surgery times in the next few weeks.</p>';
    $$('.daycard', d).forEach(b => b.onclick = async () => { $$('.daycard', d).forEach(x => x.classList.remove('on')); b.classList.add('on'); $('#sd', d).value = b.dataset.d; $('#spick', d).hidden = false; await loadSlots(); });
  };
  $('#sd', d).min = today(); $('#sd', d).onchange = loadSlots; $('#sb', d).onchange = loadDays; $('#sv', d).onchange = loadDays;
  $('[data-x]', d).onclick = () => d.close();
  $('form', d).onsubmit = async e => {
    e.preventDefault(); const err = $('.err', d); err.textContent = '';
    if (!time) { err.textContent = 'Pick one of the available times.'; return; }
    if (o.collect) { fin = true; const v = { date: $('#sd', d).value, time, vet: $('#sv', d).value, reason: $('#sp', d).value }; d.close(); o.collect(v); return; }   // the caller books it (used at Done)
    try {
      const r = await api('/api/appointments', { pet_id: o.pet_id, service: 'Surgery', date: $('#sd', d).value, time, vet: $('#sv', d).value, branch: $('#sb', d).value, reason: 'Surgery' + ($('#sp', d).value ? ': ' + $('#sp', d).value : ''), confirmed: 1 });
      fin = true; d.close(); alert(`Surgery scheduled for ${fmtDay($('#sd', d).value)} at ${fmtTime(time)}${r.vet ? ' with ' + r.vet : ''}. The pet owner and the surgeon were notified.`); o.done?.(r);
    } catch (x) { err.textContent = x.message; if (x.data?.suggestions) { $('#sd', d).value = x.data.suggestions[0].date; await loadSlots(); } }
  };
  loadDays();
}

// Page numbers + Prev/Next for lists that show 10 at a time.
function pager(r, page, go, info, box) {
  const pages = Math.max(1, Math.ceil(r.total / r.per));
  info.textContent = r.total ? `Showing ${(page - 1) * r.per + 1}-${Math.min(page * r.per, r.total)} of ${r.total}` : '';
  const win = [...new Set([1, page - 1, page, page + 1, pages])].filter(n => n >= 1 && n <= pages).sort((a, b) => a - b);
  box.innerHTML = `<button data-p="${page - 1}" ${page < 2 ? 'disabled' : ''}>&lsaquo; Prev</button>` +
    win.map((n, i) => (i && n - win[i - 1] > 1 ? '<span>...</span>' : '') + `<button data-p="${n}" class="${n === page ? 'on' : ''}">${n}</button>`).join('') +
    `<button data-p="${page + 1}" ${page >= pages ? 'disabled' : ''}>Next &rsaquo;</button>`;
  $$('button', box).forEach(b => b.onclick = () => go(+b.dataset.p));
}

// Notification bell: polls for new online appointment requests, shows a badge and plays a chime.
let actx;
document.addEventListener('click', () => { try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); if (actx.state === 'suspended') actx.resume(); } catch (e) {} });
function chime() {
  try {
    if (!actx) return; const t = actx.currentTime;
    [880, 1318].forEach((f, i) => {
      const o = actx.createOscillator(), g = actx.createGain(), s = t + i * 0.2;
      o.type = 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, s);
      g.gain.exponentialRampToValueAtTime(0.3, s + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, s + 0.6);
      o.connect(g); g.connect(actx.destination); o.start(s); o.stop(s + 0.65);
    });
  } catch (e) {}
}
// Notification bell: every role. Polls the server (which also runs the automatic late / cancel / reminder rules), badges unread items, chimes and shows a toast on new ones.
function toast(title, body) {
  const t = document.createElement('div'); t.className = 'toast'; t.innerHTML = `<b>${E(title)}</b>${body ? `<span>${E(body)}</span>` : ''}`;
  document.body.append(t); setTimeout(() => t.classList.add('show'), 30); setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 7000);
}
const ago = s => { const m = Math.max(0, Math.round((Date.now() - new Date(s.replace(' ', 'T'))) / 60000)); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : D(s.slice(0, 10)); };
function initBell() {
  const bell = $('#bell'); if (!bell) return;
  const menu = $('#bellMenu'), badgeEl = $('#bellN');
  let known = null, rows = [], unread = 0;
  const draw = () => {
    badgeEl.textContent = unread > 99 ? '99+' : unread; badgeEl.hidden = !unread;
    menu.innerHTML = `<div class="bm-h"><span>Notifications</span>${unread ? '<button type="button" class="link" id="bmAll">Mark all as read</button>' : ''}</div><div class="bm-list">` + (rows.length ? rows.map(r =>
      `<a class="bm-i t-${E(r.type)} ${r.read_at ? '' : 'new'}" href="${E(r.link || '#')}" data-id="${r.id}"><b>${E(r.title)}</b>${r.body ? `<span>${E(r.body)}</span>` : ''}<small>${ago(r.created_at)}</small></a>`).join('')
      : '<p class="empty" style="margin:0">No notifications yet.</p>') + '</div>';
    if ($('#bmAll', menu)) $('#bmAll', menu).onclick = async e => { e.stopPropagation(); await api('/api/auth/notifications/read', {}); poll(); };
    $$('.bm-i', menu).forEach(a => a.onclick = async e => { e.preventDefault(); try { await api('/api/auth/notifications/read', { id: +a.dataset.id }); } catch (x) {} const h = a.getAttribute('href'); if (h && h !== '#') location = h; else poll(); });
  };
  const poll = async () => {
    try {
      const r = await api('/api/auth/notifications'); rows = r.rows; unread = r.unread;
      if (known !== null && r.max_id > known) { chime(); const n = rows.find(x => +x.id > known && !x.read_at); if (n) toast(n.title, n.body); }
      known = Math.max(known || 0, r.max_id); draw();
    } catch (e) {}
  };
  bell.onclick = e => { e.stopPropagation(); menu.hidden = !menu.hidden; };
  document.addEventListener('click', e => { if (!e.target.closest('.bellwrap')) menu.hidden = true; });
  poll(); setInterval(poll, 15000);
}

// Crop to a square and shrink so photos stay small (stored in the database).
function resizeImage(file, size = 256) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas'), m = Math.min(img.width, img.height); c.width = c.height = size;
      c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, size, size);
      URL.revokeObjectURL(img.src); res(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => rej(new Error('That file is not a valid image.'));
    img.src = URL.createObjectURL(file);
  });
}

// Wide picture for the public homepage (keeps the shape, max 1000 px wide, JPEG)
function resizeWide(file, maxW = 1000) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, maxW / img.width), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(img.src); res(c.toDataURL('image/jpeg', 0.8));
    };
    img.onerror = () => rej(new Error('That file is not a valid image.'));
    img.src = URL.createObjectURL(file);
  });
}

// ---- Update 17: (1) sign out after IDLE_MIN minutes with no click, key press or touch (IDLE_LOGOUT_MINUTES in config.php, 0 = off);
// (2) a show / hide eye on every password box; (3) the "signed out for being idle" notice on the login page ----
var LAST_ACT = Date.now();
(function () {
  const mark = () => { LAST_ACT = Date.now(); try { localStorage.setItem('gv_act', String(LAST_ACT)); } catch (e) {} };
  ['click', 'keydown', 'mousemove', 'touchstart', 'scroll'].forEach(ev => addEventListener(ev, () => { if (Date.now() - LAST_ACT > 5000) mark(); }, { passive: true }));
  addEventListener('storage', e => { if (e.key === 'gv_act') LAST_ACT = Math.max(LAST_ACT, +e.newValue || 0); });
  setInterval(async () => {
    const m = typeof IDLE_MIN === 'number' ? IDLE_MIN : 0;
    if (!m || Date.now() - LAST_ACT < m * 60000) return;
    try { await fetch('auth_api.php/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch (e) {}
    location = 'login.php?idle=1';
  }, 15000);
  const EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.9 10.9 0 0 1 12 19c-7 0-11-7-11-7a19.8 19.8 0 0 1 5.06-5.94M9.9 4.24A10.7 10.7 0 0 1 12 4c7 0 11 7 11 7a19.9 19.9 0 0 1-3.17 4.19M14.12 14.12a3 3 0 1 1-4.24-4.24"/><path d="M1 1l22 22"/></svg>';
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('input[type=password]').forEach(inp => {
      if (inp.parentElement.classList.contains('pw')) return;
      const w = document.createElement('span'); w.className = 'pw'; inp.parentNode.insertBefore(w, inp); w.appendChild(inp);
      const b = document.createElement('button'); b.type = 'button'; b.className = 'eye'; b.setAttribute('aria-label', 'Show password'); b.title = 'Show password'; b.innerHTML = EYE; w.appendChild(b);
      b.onclick = () => { const show = inp.type === 'password'; inp.type = show ? 'text' : 'password'; b.innerHTML = show ? EYE_OFF : EYE; const t = show ? 'Hide password' : 'Show password'; b.setAttribute('aria-label', t); b.title = t; inp.focus(); };
    });
    if (/[?&]idle=1/.test(location.search)) { const e = document.querySelector('form .err'); if (e) e.textContent = 'You were signed out because the page was left idle. Please sign in again.'; }
  });
})();

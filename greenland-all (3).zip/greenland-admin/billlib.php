<?php
// ===== Bills and payments (Update 12) =====
// A vet fills a CHARGE SHEET (a Draft bill) for each patient. Pressing Done turns it into an Unpaid bill for the front desk, frees the vet and room,
// and makes the visit a Pending record. The front desk takes payment (split lines allowed). What is still unpaid is the customer's balance.
const PAY_METHODS = ['Cash', 'GCash', 'Card', 'Check'];
const ONLINE_PAY_METHODS = ['GCash'];   // Update 15: payments that arrive online (shown separately on Sales and the Daily Sales Sheet); add e.g. 'Bank transfer' if the clinic starts taking it
const FEE_NAMES = ['Vaccination' => 'Vaccination', 'Check-Up' => 'Check-up Fee', 'Confinement' => 'Confinement', 'Surgery' => 'Surgery'];
function money(float $n): string { return '₱' . number_format($n, 2); }
function r2($n): float { return round((float)$n, 2); }

// ---------- bills ----------
function bill_items(int $saleId): array {
    return q('SELECT i.id, i.item, i.qty, i.unit_price price, i.product_id
              FROM sale_items i WHERE i.sale_id=? ORDER BY i.id', [$saleId])->fetchAll();
}
function bill_payments(int $saleId): array {
    return q('SELECT id, method, amount, received, ref, bank, check_no, check_date, check_status, pay_group, taken_by, created_at FROM sale_payments WHERE sale_id=? ORDER BY id', [$saleId])->fetchAll();
}
// total, paid, status and the summary payment method of a bill (never touches a Draft's status)
function bill_recalc(int $saleId): array {
    $s = q('SELECT * FROM sales WHERE id=?', [$saleId])->fetch(); if (!$s) fail('Bill not found.', null, 404);
    $total = r2(q('SELECT COALESCE(SUM(qty*unit_price),0) FROM sale_items WHERE sale_id=?', [$saleId])->fetchColumn());
    $paid = r2(q("SELECT COALESCE(SUM(amount),0) FROM sale_payments WHERE sale_id=? AND NOT (method='Check' AND check_status='Bounced')", [$saleId])->fetchColumn());
    $methods = q("SELECT DISTINCT method FROM sale_payments WHERE sale_id=? AND NOT (method='Check' AND check_status='Bounced')", [$saleId])->fetchAll(PDO::FETCH_COLUMN);
    $status = $s['status'];
    if ($status !== 'Draft' && $status !== 'Transferred') $status = ($paid >= $total - 0.004) ? 'Paid' : ($paid > 0 ? 'Partially paid' : 'Unpaid');
    q('UPDATE sales SET total=?, paid=?, status=?, payment=? WHERE id=?', [$total, $paid, $status, count($methods) > 1 ? 'Mixed' : ($methods[0] ?? 'Unpaid'), $saleId]);
    return ['total' => $total, 'paid' => $paid, 'status' => $status, 'balance' => max(0, r2($total - $paid))];
}
function client_balance(int $clientId): float {
    return r2(q("SELECT COALESCE(SUM(total-paid),0) FROM sales WHERE client_id=? AND status IN ('Unpaid','Partially paid')", [$clientId])->fetchColumn());
}
function clean_bill_items(array $items): array {
    $out = [];
    foreach ($items as $i) {
        $name = trim((string)($i['item'] ?? '')); if ($name === '') continue;
        $qty = (int)($i['qty'] ?? 0); $price = r2($i['price'] ?? 0);
        if ($qty < 1 || $qty > 999) fail('Check the quantity of ' . $name . '.');
        if ($price < 0) fail('The price of ' . $name . ' cannot be negative.');
        $out[] = ['id' => (int)($i['id'] ?? 0), 'item' => mb_substr($name, 0, 150), 'qty' => $qty, 'price' => $price, 'product_id' => !empty($i['product_id']) ? (int)$i['product_id'] : null];
    }
    return $out;
}
// Replace the items of a bill. Draft: free to edit. Unpaid / partly paid: front desk edits (the vet is told). Paid: locked.
function bill_save(int $saleId, array $items, array $actor, bool $desk = false): array {
    $s = q('SELECT * FROM sales WHERE id=?', [$saleId])->fetch(); if (!$s) fail('Bill not found.', null, 404);
    if ($s['status'] === 'Paid') fail('This bill is already paid and can no longer be changed.');
    if ($s['status'] === 'Transferred') fail('This bill was added to another bill (bill #' . (int)$s['transferred_to'] . ') and can no longer be changed.');
    $items = clean_bill_items($items); if (!$items) fail('Add at least one item.');
    $old = array_column(q('SELECT id, item, qty, unit_price, product_id FROM sale_items WHERE sale_id=?', [$saleId])->fetchAll(), null, 'id');
    $keep = []; $changes = [];
    $db = db(); $db->beginTransaction();
    foreach ($items as $it) {
        if ($it['id'] && isset($old[$it['id']])) {
            $o = $old[$it['id']]; $keep[$it['id']] = 1;
            if ((int)$o['qty'] !== $it['qty'] || r2($o['unit_price']) !== $it['price']) $changes[] = $it['item'] . ': ' . $o['qty'] . ' x ' . money((float)$o['unit_price']) . ' to ' . $it['qty'] . ' x ' . money($it['price']);
            q('UPDATE sale_items SET item=?, qty=?, unit_price=? WHERE id=?', [$it['item'], $it['qty'], $it['price'], $it['id']]);
        } else {
            q('INSERT INTO sale_items(sale_id,item,qty,unit_price,product_id) VALUES(?,?,?,?,?)', [$saleId, $it['item'], $it['qty'], $it['price'], $it['product_id']]);
            $changes[] = 'added ' . $it['qty'] . ' x ' . $it['item'];
        }
    }
    foreach ($old as $id => $o) if (!isset($keep[$id])) {   // removed from the bill
        q('DELETE FROM sale_items WHERE id=?', [$id]); $changes[] = 'removed ' . $o['item'];
    }
    $sum = bill_recalc($saleId);
    if ($s['status'] !== 'Draft' && $sum['total'] < $sum['paid'] - 0.004) { $db->rollBack(); fail('The new total (' . money($sum['total']) . ') is lower than what was already paid (' . money($sum['paid']) . ').'); }
    if ($desk && $s['status'] !== 'Draft' && $changes) {
        q('UPDATE sales SET desk_changed=1 WHERE id=?', [$saleId]);
        $ap = $s['appt_id'] ? appt_rows([(int)$s['appt_id']]) : [];
        $pet = $ap ? $ap[0]['pet'] : 'a patient';
        if ($ap && $ap[0]['vet']) notify_vet($ap[0]['vet'], 'info', 'Bill changed by the front desk', $pet . ': ' . implode('; ', array_slice($changes, 0, 3)) . '.', 'index.php', (int)$actor['id']);
        log_act((int)$actor['id'], 'Changed a bill', '#' . $saleId . ' (' . $pet . '): ' . implode('; ', $changes));
    }
    $db->commit();
    return $sum;
}
// The Draft bill (charge sheet) of an appointment; created with the scheduled service fee the first time it is opened.
function bill_draft(int $apptId, array $actor): array {
    $s = q('SELECT * FROM sales WHERE appt_id=? ORDER BY id DESC LIMIT 1', [$apptId])->fetch();
    if ($s) return $s;
    $rows = appt_rows([$apptId]); if (!$rows) fail('Appointment not found.', null, 404); $a = $rows[0];
    $cl = (int)$a['client_id'];
    $db = db(); $db->beginTransaction();
    q("INSERT INTO sales(sale_date,client_id,pet_id,payment,total,branch,served_by,status,paid,appt_id) VALUES(?,?,?,?,?,?,?,'Draft',0,?)",
      [$a['appt_date'], $cl, (int)$a['pet_id'], 'Unpaid', 0, $a['branch'], $actor['name'], $apptId]);
    $sid = (int)$db->lastInsertId();
    q('INSERT INTO sale_items(sale_id,item,qty,unit_price,product_id) VALUES(?,?,?,?,NULL)', [$sid, FEE_NAMES[$a['service']] ?? $a['service'], 1, (float)(SERVICE_FEES[$a['service']] ?? 0)]);
    bill_recalc($sid); $db->commit();
    return q('SELECT * FROM sales WHERE id=?', [$sid])->fetch();
}
// A sale made at the desk (no visit): becomes an Unpaid bill straight away.
function bill_create(?int $clientId, ?int $petId, array $items, string $branch, array $actor, string $date): int {
    $items = clean_bill_items($items); if (!$items) fail('Add at least one item.');
    $db = db(); $db->beginTransaction();
    q("INSERT INTO sales(sale_date,client_id,pet_id,payment,total,branch,served_by,status,paid,prepared_by,ready_at) VALUES(?,?,?,?,0,?,?,'Unpaid',0,?,NOW())", [$date, $clientId ?: null, $petId ?: null, 'Unpaid', $branch, $actor['name'], $actor['name']]);
    $sid = (int)$db->lastInsertId();
    foreach ($items as $i) q('INSERT INTO sale_items(sale_id,item,qty,unit_price,product_id) VALUES(?,?,?,?,?)', [$sid, $i['item'], $i['qty'], $i['price'], $i['product_id']]);
    bill_recalc($sid); $db->commit();
    log_act((int)$actor['id'], 'Created a bill', '#' . $sid);
    return $sid;
}

// ---------- Done: the vet (or the front desk) finishes a visit ----------
function appt_done(int $id, array $actor, string $role, ?array $next = null): array {
    $rows = appt_rows([$id]); if (!$rows) fail('Appointment not found.', null, 404); $a = $rows[0];
    if ($a['status'] === 'Cancelled') fail('This appointment was cancelled.');
    if ($a['status'] === 'Completed') { $d = q('SELECT done_by, done_at FROM appointments WHERE id=?', [$id])->fetch(); return ['already' => true, 'by' => $d['done_by'], 'at' => $d['done_at']]; }
    if (!$a['checked_in_at']) fail('Check the patient in first, then press Done.');
    $branch = (string)$a['branch']; $by = $role === 'staff' ? $actor['name'] . ' (front desk)' : $actor['name'];
    $nx = next_step_check($a, $next, $id);   // "What happens next?": checked BEFORE anything changes, so a mistake leaves the visit open
    $res = with_queue_lock($branch, function () use ($id, $actor, $a, $by, $role) {
        $cur = q('SELECT status FROM appointments WHERE id=?', [$id])->fetchColumn();
        if ($cur === 'Completed') return ['already' => true];
        $draft = bill_draft($id, $actor);
        $prepared = $role === 'vet' ? $actor['name'] : ($a['vet'] ?: $actor['name']);
        $db = db(); $db->beginTransaction();
        if ($draft['status'] === 'Draft') q("UPDATE sales SET status='Unpaid', ready_at=NOW(), prepared_by=? WHERE id=?", [$prepared, $draft['id']]);
        $sum = bill_recalc((int)$draft['id']);
        q("UPDATE appointments SET status='Completed', done_at=NOW(), done_by=?, started_at=COALESCE(started_at, called_at, checked_in_at) WHERE id=?", [$by, $id]);
        $db->commit();
        return ['sale_id' => (int)$draft['id'], 'total' => $sum['total']];
    });
    if (!empty($res['already'])) return $res;
    $extra = $nx ? next_step_apply($a, $nx, $actor, (int)$res['sale_id']) : [];   // before the queue moves, so a vet who is going to operate stays reserved
    queue_advance($branch);   // the vet and the room are free: call the next patient
    log_act((int)$actor['id'], 'Marked a visit done', $a['pet'] . ' (' . $a['client'] . '): ' . $a['service'] . ', ' . money((float)$res['total']) . ($nx ? ' | next: ' . $extra['summary'] : ''));
    if (!empty($extra['carried'])) {
        notify_role('staff', $branch, 'done', 'Visit done: ' . $a['pet'], $a['client'] . ' · ' . $a['service'] . ' · ' . money((float)$res['total']) . ' was added to the ' . strtolower($extra['carried_to']) . ' bill (nothing to collect now).', 'bills.php', (int)$actor['id']);
        notify_owner((int)$a['client_id'], 'done', 'Visit finished', $a['pet'] . "'s " . strtolower($a['service']) . ' is done. ' . $extra['owner'], 'appointments.php');
    } else {
        notify_role('staff', $branch, 'done', 'Ready for billing: ' . $a['pet'], $a['client'] . ' · ' . $a['service'] . ' · ' . money((float)$res['total']) . ($role === 'vet' ? ' · done by ' . $actor['name'] : ''), 'bills.php', (int)$actor['id']);
        notify_owner((int)$a['client_id'], 'done', 'Visit finished', $a['pet'] . "'s " . strtolower($a['service']) . ' is done. ' . ($extra['owner'] ?? '') . ' Please see the front desk for the bill.', 'appointments.php');
    }
    if ($role === 'staff' && $a['vet']) notify_vet($a['vet'], 'info', 'Visit marked done by the front desk', $a['pet'] . ' (' . $a['service'] . '). Please complete the record when you can.', 'index.php', (int)$actor['id']);
    return ['ok' => true, 'sale_id' => $res['sale_id'], 'total' => $res['total'], 'next' => $extra, 'carried' => !empty($extra['carried'])];
}

// ---------- payments ----------
// Pay one or more bills of one client with one or more payment lines (split payments). The money goes to the oldest bills first.
function bill_pay(array $saleIds, array $lines, array $actor): array {
    $saleIds = array_values(array_unique(array_map('intval', $saleIds))); if (!$saleIds) fail('Choose the bill to pay.');
    $in = implode(',', $saleIds);
    $bills = q("SELECT id, client_id, total, paid, status, sale_date FROM sales WHERE id IN ($in) ORDER BY sale_date, id")->fetchAll();
    if (count($bills) !== count($saleIds)) fail('A bill was not found.');
    $clients = array_unique(array_map(fn($b) => (int)$b['client_id'], $bills)); if (count($clients) > 1) fail('Choose bills of one client at a time.');
    foreach ($bills as $b) if (!in_array($b['status'], ['Unpaid', 'Partially paid'], true)) fail($b['status'] === 'Paid' ? 'Bill #' . $b['id'] . ' is already paid.' : 'Bill #' . $b['id'] . ' is not ready for payment yet.');
    $due = array_sum(array_map(fn($b) => r2($b['total'] - $b['paid']), $bills));
    if (!$lines || count($lines) > 8) fail('Add a payment line.');
    $clean = []; $sum = 0;
    foreach ($lines as $l) {
        $m = $l['method'] ?? ''; $amt = r2($l['amount'] ?? 0);
        if (!in_array($m, PAY_METHODS, true)) fail('Choose how the customer is paying.');
        if ($amt <= 0) fail('Enter an amount for each payment line.');
        $row = ['method' => $m, 'amount' => $amt, 'received' => null, 'ref' => null, 'bank' => null, 'check_no' => null, 'check_date' => null, 'check_status' => null];
        if ($m === 'Cash') { $row['received'] = r2($l['received'] ?? $amt); if ($row['received'] < $amt) fail('The cash received is less than the amount.'); }
        if ($m === 'GCash' || $m === 'Card') { $row['ref'] = trim((string)($l['ref'] ?? '')); if ($row['ref'] === '') fail($m === 'GCash' ? 'Enter the GCash reference number.' : 'Enter the last 4 digits or approval code of the card.'); }
        if ($m === 'Check') {
            $row['bank'] = trim((string)($l['bank'] ?? '')); $row['check_no'] = trim((string)($l['check_no'] ?? '')); $row['check_date'] = (string)($l['check_date'] ?? '');
            if ($row['bank'] === '' || $row['check_no'] === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $row['check_date'])) fail('Enter the bank, check number and check date.');
            $row['check_status'] = 'Pending clearing';
        }
        $clean[] = $row; $sum += $amt;
    }
    $sum = r2($sum);
    if ($sum > $due + 0.004) fail('The payment (' . money($sum) . ') is more than the balance (' . money($due) . ').');
    if (!$clients[0] && $sum < $due - 0.004) fail('A sale with no client must be paid in full.');
    $group = bin2hex(random_bytes(8)); $left = array_map(fn($b) => r2($b['total'] - $b['paid']), $bills);
    $db = db(); $db->beginTransaction();
    foreach ($clean as $row) {
        $amt = $row['amount']; $first = true;
        foreach ($bills as $k => $b) {
            if ($amt <= 0.004) break; if ($left[$k] <= 0.004) continue;
            $take = min($amt, $left[$k]); $left[$k] = r2($left[$k] - $take); $amt = r2($amt - $take);
            q('INSERT INTO sale_payments(sale_id,method,amount,received,ref,bank,check_no,check_date,check_status,pay_group,taken_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
              [$b['id'], $row['method'], $take, $first ? $row['received'] : null, $row['ref'], $row['bank'], $row['check_no'], $row['check_date'], $row['check_status'], $group, $actor['name']]);
            $first = false;
        }
    }
    foreach ($bills as $b) bill_recalc((int)$b['id']);
    $db->commit();
    $cname = $clients[0] ? q('SELECT name FROM clients WHERE id=?', [$clients[0]])->fetchColumn() : 'walk-in customer';
    log_act((int)$actor['id'], 'Took a payment', money($sum) . ' from ' . $cname . ' (' . implode(', ', array_unique(array_column($clean, 'method'))) . ') for bill ' . implode(', ', array_map(fn($b) => '#' . $b['id'], $bills)));
    $bal = $clients[0] ? client_balance((int)$clients[0]) : 0.0;
    return ['ok' => true, 'ids' => $saleIds, 'group' => $group, 'paid' => $sum, 'balance' => $bal];
}
function bill_check_status(int $paymentId, string $status, array $actor): void {
    if (!in_array($status, ['Cleared', 'Bounced'], true)) fail('Choose Cleared or Bounced.');
    $p = q("SELECT p.*, s.branch, s.client_id FROM sale_payments p JOIN sales s ON s.id=p.sale_id WHERE p.id=? AND p.method='Check'", [$paymentId])->fetch();
    if (!$p) fail('Check payment not found.', null, 404);
    if ($p['check_status'] === $status) return;
    if ($p['check_status'] === 'Bounced') fail('A bounced check cannot be changed. Take a new payment instead.');
    q('UPDATE sale_payments SET check_status=? WHERE id=?', [$status, $paymentId]);
    bill_recalc((int)$p['sale_id']);
    log_act((int)$actor['id'], $status === 'Bounced' ? 'Marked a check as bounced' : 'Marked a check as cleared', 'check ' . $p['check_no'] . ' (' . $p['bank'] . '), ' . money((float)$p['amount']) . ', bill #' . $p['sale_id']);
    if ($status === 'Bounced') {
        notify_role('staff', (string)$p['branch'], 'cancel', 'Check bounced', 'Check ' . $p['check_no'] . ' (' . $p['bank'] . ') for ' . money((float)$p['amount']) . ' bounced. The balance is due again on bill #' . $p['sale_id'] . '.', 'bills.php', (int)$actor['id']);
        notify_role('admin', null, 'cancel', 'Check bounced', 'Check ' . $p['check_no'] . ' for ' . money((float)$p['amount']) . ' (bill #' . $p['sale_id'] . ').', 'reports.php');
        if ($p['client_id']) notify_owner((int)$p['client_id'], 'info', 'Your check could not be cleared', 'A balance of ' . money((float)$p['amount']) . ' is due again. Please contact the clinic.', 'index.php');
    }
}

// =====================================================================================================
// Update 13: "What happens next?" at Done, confinement stays, the surgery room and Taytay referrals
// At Done the vet says: goes home (optional follow-up day) / confine now / surgery (now or another day). The write-up (the record) is separate and can wait.
// Confinement and surgery happen only at MAIN_BRANCH. A Taytay patient is referred: it is created at the main branch with a "Referred from Taytay" tag.
// =====================================================================================================
function branch_address(string $b): string { return defined('BRANCH_INFO') && isset(BRANCH_INFO[$b]['address']) ? BRANCH_INFO[$b]['address'] : $b . ' branch'; }

// ---------- the surgery room and the vets who are free right now ----------
function surgery_now_state(int $ignoreApptId = 0): array {
    $br = MAIN_BRANCH; $today = date('Y-m-d'); $now = now_min(); $len = svc_len('Surgery');
    $rows = queue_rows($br, $today);
    $active = array_filter($rows, fn($a) => (int)$a['id'] !== $ignoreApptId && $a['checked_in_at'] && $a['called_at'] && $a['status'] !== 'Completed');
    $busyR = array_filter(array_column($active, 'room')); $busyV = array_filter(array_column($active, 'vet'));
    $soonRoom = null; $soonVet = [];   // a booked visit that starts within the length of a surgery holds the room or the vet
    foreach ($rows as $a) {
        if ((int)$a['id'] === $ignoreApptId || $a['checked_in_at'] || $a['is_queue'] || in_array($a['status'], ['Completed', 'Cancelled'], true)) continue;
        $st = tmin($a['t']); if ($st >= $now + $len || $st + svc_len($a['service']) <= $now) continue;
        if ($a['service'] === 'Surgery' && $soonRoom === null) $soonRoom = $a['t'];
        if ($a['vet']) $soonVet[$a['vet']] = $a['t'];
    }
    $room = null; $why = null;
    foreach (SURGERY_ROOMS as $r) if (!in_array($r, $busyR, true)) { $room = $r; break; }
    if (!$room) { $o = null; foreach ($active as $a) if (in_array($a['room'], SURGERY_ROOMS, true)) { $o = $a; break; } $why = 'The surgery room is in use' . ($o ? ' (' . $o['pet'] . ', ' . $o['vet'] . ')' : '') . '. Pick a time instead.'; }
    elseif ($soonRoom !== null) { $room = null; $why = 'A surgery is booked at ' . hm12($soonRoom) . ', so the surgery room is held. Pick a time instead.'; }
    $pool = array_column(vet_pool($br, $today), 'name');
    $free = array_values(array_filter($pool, fn($n) => !in_array($n, $busyV, true) && !isset($soonVet[$n])));
    return ['room' => $room, 'why' => $why, 'vets' => $free, 'on_duty' => $pool];
}

// ---------- the decision at Done ----------
function next_step_check(array $a, ?array $n, int $apptId): ?array {
    if (!$n || empty($n['type'])) return null;
    if (!in_array($a['service'], ['Check-Up', 'Surgery'], true)) return null;
    $t = (string)$n['type'];
    if (!in_array($t, ['home', 'confine', 'surgery', 'refer'], true)) fail('Choose what happens next.');
    $out = ['type' => $t, 'bill' => (($n['bill'] ?? 'now') === 'carry' && !in_array($t, ['home', 'refer'], true)) ? 'carry' : 'now', 'reason' => mb_substr(trim((string)($n['reason'] ?? '')), 0, 200)];
    if ($t === 'home') {
        $d = trim((string)($n['followup_date'] ?? ''));
        if ($d !== '') {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) fail('Check the follow-up date.', 'followup_date');
            if ($d < date('Y-m-d')) fail('The follow-up date has already passed.', 'followup_date');
        }
        $out['followup_date'] = $d !== '' ? $d : null;
        $out['followup_purpose'] = mb_substr(trim((string)($n['followup_purpose'] ?? '')), 0, 150);
    } elseif ($t === 'refer') {   // Taytay is a wellness branch: X-ray and other tests are done at the main branch
        if ($a['service'] !== 'Check-Up' || $a['branch'] === MAIN_BRANCH) fail('Only a check-up at the ' . (BRANCHES[1] ?? 'Taytay') . ' branch is referred to ' . MAIN_BRANCH . ' for tests.');
        $test = (string)($n['test'] ?? ''); if (!in_array($test, REFERRAL_REASONS, true)) fail('Choose what the pet is referred for.', 'test');
        $d = trim((string)($n['date'] ?? '')) ?: date('Y-m-d');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) || $d < date('Y-m-d')) fail('Check the date for the referral.', 'date');
        $out['test'] = $test; $out['date'] = $d;
    } elseif ($t === 'surgery') {
        if ($a['service'] !== 'Check-Up') fail('After a surgery the pet goes home or is confined.');
        $mode = ($n['mode'] ?? 'later') === 'now' ? 'now' : 'later'; $vet = nul($n['vet'] ?? null);
        if ($mode === 'now' && $a['branch'] !== MAIN_BRANCH) fail('Surgery is done at the ' . MAIN_BRANCH . ' branch, so it needs a date and time there.');
        if ($mode === 'now') {
            $st = surgery_now_state($apptId);
            if (!$st['room']) fail($st['why'] ?: 'The surgery room is not free right now. Pick a time instead.');
            if (!$st['vets']) fail('No vet is free for surgery right now. Pick a time instead.');
            if ($vet && !in_array($vet, $st['vets'], true)) fail($vet . ' is not free right now. Choose another surgeon or pick a time.', 'vet');
            $out['vet'] = $vet ?: (in_array($a['vet'], $st['vets'], true) ? $a['vet'] : $st['vets'][0]); $out['room'] = $st['room'];
        } else {
            $date = (string)($n['date'] ?? ''); $time = (string)($n['time'] ?? '');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !preg_match('/^\d{2}:\d{2}$/', $time)) fail('Choose the surgery date and time.', 'time');
            $al = pick_chain($date, $time, MAIN_BRANCH, [['svc' => 'Surgery', 'concern' => null]], $vet);   // hours, clashes, the surgery room and who is on duty
            $out['date'] = $date; $out['time'] = mtime($al[0]['start']); $out['vet'] = $al[0]['vet'] ?: $vet;
        }
        $out['mode'] = $mode;
    }
    return $out;
}
function next_step_apply(array $a, array $nx, array $actor, int $saleId): array {
    $pid = (int)$a['pet_id']; $cid = (int)$a['client_id']; $out = ['type' => $nx['type'], 'carried' => false, 'owner' => ''];
    if ($nx['type'] === 'home') {
        q('UPDATE appointments SET next_step=?, followup_date=?, followup_purpose=? WHERE id=?', ['None', $nx['followup_date'], $nx['followup_purpose'] !== '' ? $nx['followup_purpose'] : null, $a['id']]);
        $out['summary'] = 'goes home';
        if ($nx['followup_date']) {
            $d = $nx['followup_date']; for ($i = 0; $i < 14 && queue_day_problem($d, false); $i++) $d = date('Y-m-d', strtotime("$d +1 day"));   // a closed day moves to the next open day
            $dupe = q("SELECT 1 FROM appointments WHERE pet_id=? AND appt_date=? AND branch=? AND is_queue=1 AND status<>'Cancelled' LIMIT 1", [$pid, $d, $a['branch']])->fetch();
            if (!queue_day_problem($d, false) && !$dupe) {
                [, $fd] = register_queue($pid, $d, (string)$a['branch'], null, $nx['followup_purpose'] !== '' ? 'Follow-up: ' . $nx['followup_purpose'] : 'Follow-up check-up', 'Confirmed', null, 'Vet', true);
                q('UPDATE appointments SET followup_date=? WHERE id=?', [$fd, $a['id']]);
                $out['followup'] = $fd; $out['summary'] .= ', follow-up ' . $fd;
                notify_owner($cid, 'booked', 'Follow-up check-up scheduled', $a['pet'] . ': ' . date('D, M j', strtotime($fd)) . ' (' . $a['branch'] . '). Come any time that day; first come, first served.', 'appointments.php');
            }
        }
        return $out;
    }
    if ($nx['type'] === 'refer') {
        $why = $nx['test'] . ($nx['reason'] !== '' ? ' (' . $nx['reason'] . ')' : '');
        q('UPDATE appointments SET next_step=?, referral_reason=? WHERE id=?', ['None', mb_substr($why, 0, 200), $a['id']]);
        $d = $nx['date']; for ($i = 0; $i < 14 && queue_day_problem($d, false); $i++) $d = date('Y-m-d', strtotime("$d +1 day"));
        $dupe = q("SELECT 1 FROM appointments WHERE pet_id=? AND appt_date=? AND branch=? AND is_queue=1 AND status<>'Cancelled' LIMIT 1", [$pid, $d, MAIN_BRANCH])->fetch();
        if (!$dupe && !queue_day_problem($d, false)) {
            [$rid, $d] = register_queue($pid, $d, MAIN_BRANCH, null, 'Referred from ' . $a['branch'] . ': ' . $why, 'Confirmed', null, 'Vet', true);
            q('UPDATE appointments SET referred_from=?, from_appt_id=? WHERE id=?', [$a['branch'], $a['id'], $rid]);
        }
        $out += ['summary' => 'referred to ' . MAIN_BRANCH . ' for ' . $why . ' on ' . $d, 'referral_date' => $d, 'test' => $nx['test']];
        $out['owner'] = $a['pet'] . ' is referred to our ' . MAIN_BRANCH . ' branch (' . branch_address(MAIN_BRANCH) . ') for ' . strtolower($why) . ' on ' . date('D, M j', strtotime($d)) . '. You are on the check-up list for that day: come any time and show your QR code.';
        notify_role('staff', MAIN_BRANCH, 'booked', 'Referral from ' . $a['branch'] . ': ' . $nx['test'], $a['pet'] . ' (' . $a['client'] . ') is coming on ' . date('D, M j', strtotime($d)) . ' · ' . $why . ' · referred by ' . ($a['vet'] ?: $actor['name']), 'appointments.php?date=' . $d, (int)$actor['id']);
        notify_role('vet', MAIN_BRANCH, 'booked', 'Referral from ' . $a['branch'] . ': ' . $nx['test'], $a['pet'] . ' (' . $a['client'] . ') · ' . $why, 'index.php', (int)$actor['id']);
        return $out;
    }
    $referred = $a['branch'] !== MAIN_BRANCH ? (string)$a['branch'] : null;
    if ($nx['type'] === 'confine') {
        q('UPDATE appointments SET next_step=? WHERE id=?', ['Confinement', $a['id']]);
        $cid2 = conf_admit($a, $actor, $nx['reason'], $referred);
        $c = conf_row($cid2); $to = (int)$c['sale_id'];
        $out += ['conf_id' => $cid2, 'summary' => 'confined' . ($referred ? ' (referred from ' . $referred . ' to ' . MAIN_BRANCH . ')' : '')];
        $out['owner'] = $referred ? 'Confinement is done at our ' . MAIN_BRANCH . ' branch (' . branch_address(MAIN_BRANCH) . '). Please bring ' . $a['pet'] . ' there as soon as possible.' : $a['pet'] . ' is now confined with us. We will keep you updated.';
        $label = 'Confinement';
    } else {
        q('UPDATE appointments SET next_step=? WHERE id=?', ['Surgery', $a['id']]);
        $sid = surgery_book($a, $nx, $actor, $referred);
        $when = $nx['mode'] === 'now' ? 'now (today)' : date('D, M j', strtotime($nx['date'])) . ' at ' . hm12($nx['time']);
        $out += ['surgery_appt_id' => $sid, 'summary' => 'surgery ' . $when . ' with ' . ($nx['vet'] ?: 'the next free vet') . ($referred ? ' (referred from ' . $referred . ')' : '')];
        $out['owner'] = $nx['mode'] === 'now' ? $a['pet'] . ' is going into surgery now.' : 'Surgery is scheduled for ' . $when . ' at our ' . MAIN_BRANCH . ' branch (' . branch_address(MAIN_BRANCH) . ').';
        $bd = bill_draft($sid, $actor); $to = (int)$bd['id']; $label = 'Surgery';
    }
    if ($nx['bill'] === 'carry' && bill_carry($saleId, $to, $actor, $label)) { $out['carried'] = true; $out['carried_to'] = $label; $out['owner'] .= ' The check-up charges were added to the ' . strtolower($label) . ' bill, so there is nothing to pay today.'; }
    return $out;
}
// The check-up bill is closed as 'Transferred' and its total becomes one line on the confinement / surgery bill (logged).
function bill_carry(int $fromSale, int $toSale, array $actor, string $label): bool {
    $f = q('SELECT * FROM sales WHERE id=?', [$fromSale])->fetch(); $t = q('SELECT id, status FROM sales WHERE id=?', [$toSale])->fetch();
    if (!$f || !$t || $f['status'] !== 'Unpaid' || (float)$f['paid'] > 0.004 || (float)$f['total'] <= 0) return false;
    $svc = $f['appt_id'] ? (string)q('SELECT service FROM appointments WHERE id=?', [$f['appt_id']])->fetchColumn() : 'Visit';
    $line = $svc . ' charges (bill #' . $f['id'] . ', ' . ($f['branch'] ?: '') . ', ' . date('M j', strtotime($f['sale_date'])) . ')';
    q('INSERT INTO sale_items(sale_id,item,qty,unit_price,product_id) VALUES(?,?,?,?,NULL)', [$toSale, mb_substr($line, 0, 150), 1, r2($f['total'])]);
    q("UPDATE sales SET status='Transferred', transferred_to=?, note=? WHERE id=?", [$toSale, mb_substr('Added to bill #' . $toSale . ' (' . strtolower($label) . ')', 0, 250), $fromSale]);
    bill_recalc($toSale);
    log_act((int)$actor['id'], 'Moved a bill into another bill', 'bill #' . $fromSale . ' (' . money((float)$f['total']) . ') added to bill #' . $toSale . ' (' . strtolower($label) . ')');
    return true;
}

// ---------- surgery ----------
// Books the surgery at the main branch: right now (checked in, surgery room, surgeon) or at a chosen date and time.
function surgery_book(array $a, array $nx, array $actor, ?string $referred): int {
    $reason = 'Surgery' . ($nx['reason'] !== '' ? ': ' . $nx['reason'] : ''); $now = $nx['mode'] === 'now';
    $row = with_queue_lock(MAIN_BRANCH, function () use ($a, $nx, $reason, $now, $referred) {
        if ($now) {   // look again under the lock: the room and the vet must still be free
            $st = surgery_now_state((int)$a['id']);
            if (!$st['room'] || !in_array($nx['vet'], $st['vets'], true)) fail('The surgery room or the surgeon was just taken. Please choose again.', null, 409);
            q("INSERT INTO appointments(pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,checked_in_at,called_at,room,from_appt_id,referred_from) VALUES(?,CURDATE(),?,'Surgery',?,?,'Confirmed',?,'Vet',?,NOW(),NOW(),?,?,NULL)",
              [$a['pet_id'], mtime(now_min()) . ':00', $nx['vet'], MAIN_BRANCH, $reason, bin2hex(random_bytes(12)), $nx['room'], $a['id']]);
        } else {
            q("INSERT INTO appointments(pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,from_appt_id,referred_from) VALUES(?,?,?,'Surgery',?,?,'Confirmed',?,'Vet',?,?,?)",
              [$a['pet_id'], $nx['date'], $nx['time'] . ':00', $nx['vet'], MAIN_BRANCH, $reason, bin2hex(random_bytes(12)), $a['id'], $referred]);
        }
        return (int)db()->lastInsertId();
    });
    $when = $now ? 'now' : date('D, M j', strtotime($nx['date'])) . ' at ' . hm12($nx['time']);
    $what = $a['pet'] . ' (' . $a['client'] . ')';
    log_act((int)$actor['id'], 'Decided on a surgery', $what . ': ' . $when . ($nx['vet'] ? ' with ' . $nx['vet'] : '') . ($referred ? ', referred from ' . $referred : ''));
    if ($nx['vet']) notify_vet($nx['vet'], $now ? 'checkin' : 'booked', $now ? 'Surgery now: ' . $a['pet'] : 'Surgery scheduled', $what . ' · surgery ' . $when . (!empty($nx['room']) ? ' in ' . $nx['room'] : '') . '. ' . $nx['reason'], $now ? 'index.php' : 'appointments.php?date=' . ($nx['date'] ?? date('Y-m-d')), (int)$actor['id']);
    notify_role('staff', MAIN_BRANCH, 'booked', ($referred ? 'Referral from ' . $referred . ': surgery' : 'Surgery scheduled'), $what . ' · ' . $when . ($nx['vet'] ? ' with ' . $nx['vet'] : '') . ($referred ? '. The patient will arrive from ' . $referred . '; mark the arrival at check-in.' : ''), 'appointments.php' . ($now ? '' : '?date=' . $nx['date']), (int)$actor['id']);
    return $row;
}

// ---------- confinement ----------
function conf_row(int $id): ?array {
    return q("SELECT c.*, p.name pet, p.species, p.client_id, cl.name client, cl.phone FROM confinements c JOIN pets p ON p.id=c.pet_id JOIN clients cl ON cl.id=p.client_id WHERE c.id=?", [$id])->fetch() ?: null;
}
// Days stay counted by calendar day: the admission day counts, so same-day discharge is 1 day. The vet or front desk can overwrite the number (logged).
function conf_days(array $c, ?string $today = null): array {
    $end = !empty($c['discharged']) ? $c['discharged'] : ($today ?? date('Y-m-d'));
    $auto = max(1, (int)(new DateTime($c['admitted']))->diff(new DateTime($end))->format('%r%a') + 1);
    $ov = isset($c['days_override']) && $c['days_override'] !== null && $c['days_override'] !== '' ? (int)$c['days_override'] : null;
    return ['days' => $ov ?: $auto, 'auto' => $auto, 'override' => $ov !== null];
}
function conf_branch(array $c): string { return (string)($c['branch'] ?: MAIN_BRANCH); }
// The running bill: a Draft until discharge. Its first line is the daily rate x days; the vet adds medicines and other charges as the stay goes on.
function conf_ensure_sale(array $c, array $actor): int {
    $sid = (int)($c['sale_id'] ?? 0);
    if ($sid && q('SELECT 1 FROM sales WHERE id=?', [$sid])->fetch()) return $sid;
    $rate = $c['daily_rate'] !== null && $c['daily_rate'] !== '' ? (float)$c['daily_rate'] : (float)CONFINEMENT_DAILY_RATE;
    $d = conf_days($c);
    $db = db(); $db->beginTransaction();
    q("INSERT INTO sales(sale_date,client_id,pet_id,payment,total,branch,served_by,status,paid,service) VALUES(?,?,?,?,0,?,?,'Draft',0,'Confinement')", [$c['admitted'], $c['client_id'], $c['pet_id'], 'Unpaid', conf_branch($c), $actor['name']]);
    $sid = (int)$db->lastInsertId();
    q('INSERT INTO sale_items(sale_id,item,qty,unit_price,product_id) VALUES(?,?,?,?,NULL)', [$sid, 'Confinement (per day)', $d['days'], $rate]);
    $iid = (int)$db->lastInsertId();
    q('UPDATE confinements SET sale_id=?, rate_item_id=?, daily_rate=COALESCE(daily_rate,?) WHERE id=?', [$sid, $iid, $rate, $c['id']]);
    bill_recalc($sid); $db->commit();
    return $sid;
}
// Keep the day count on the bill current while the pet is admitted. Returns the refreshed confinement row.
function conf_sync_bill(int $id, array $actor): array {
    $c = conf_row($id); if (!$c) fail('Confinement not found.', null, 404);
    $sid = conf_ensure_sale($c, $actor); $c = conf_row($id);
    $sale = q('SELECT status FROM sales WHERE id=?', [$sid])->fetch();
    if ($c['status'] === 'Admitted' && $sale && $sale['status'] === 'Draft') {
        $d = conf_days($c); $iid = (int)$c['rate_item_id'];
        $ok = $iid ? q('SELECT 1 FROM sale_items WHERE id=? AND sale_id=?', [$iid, $sid])->fetch() : null;
        if ($ok) q('UPDATE sale_items SET qty=? WHERE id=?', [$d['days'], $iid]);
        else {
            q('INSERT INTO sale_items(sale_id,item,qty,unit_price,product_id) VALUES(?,?,?,?,NULL)', [$sid, 'Confinement (per day)', $d['days'], (float)($c['daily_rate'] ?: CONFINEMENT_DAILY_RATE)]);
            q('UPDATE confinements SET rate_item_id=? WHERE id=?', [(int)db()->lastInsertId(), $id]);
        }
        bill_recalc($sid);
    }
    return conf_row($id);
}
// Admit a patient right after a visit: created at the main branch; a Taytay patient is "Referred from Taytay" until the front desk marks the arrival.
function conf_admit(array $a, array $actor, string $reason, ?string $referred): int {
    $vet = $a['vet'] ?: $actor['name'];
    q("INSERT INTO confinements(pet_id,admitted,status,reason,recorded_at,recorded_by,branch,vet,from_appt_id,admitted_at,daily_rate,referred_from,arrived_at) VALUES(?,CURDATE(),'Admitted',?,NOW(),?,?,?,?,NOW(),?,?,?)",
      [$a['pet_id'], $reason !== '' ? $reason : null, $actor['name'], MAIN_BRANCH, $vet, $a['id'], CONFINEMENT_DAILY_RATE, $referred, $referred ? null : date('Y-m-d H:i:s')]);
    $id = (int)db()->lastInsertId(); $c = conf_row($id); $c['vet'] = $vet; conf_ensure_sale($c, $actor);
    $what = $a['pet'] . ' (' . $a['client'] . ')';
    log_act((int)$actor['id'], 'Confined a patient', $what . ($referred ? ', referred from ' . $referred . ' to ' . MAIN_BRANCH : ''));
    notify_role('staff', MAIN_BRANCH, 'booked', $referred ? 'Referral from ' . $referred . ': confinement' : 'New confined patient', $what . ($referred ? ' is on the way from ' . $referred . '. Mark the arrival when the owner brings the pet.' : ' was just confined by ' . $vet . '.'), 'confined.php', (int)$actor['id']);
    notify_role('vet', MAIN_BRANCH, 'booked', $referred ? 'Referral from ' . $referred . ': confinement' : 'New confined patient', $what . ($reason !== '' ? ' · ' . $reason : '') . ($referred ? ' · decided by ' . $vet : ''), 'confined.php', (int)$actor['id']);
    return $id;
}
function conf_discharge(int $id, array $actor, ?string $followup, ?string $outcome = null): array {
    $c = conf_row($id); if (!$c) fail('Confinement not found.', null, 404);
    if ($c['status'] !== 'Admitted') fail('This patient was already discharged.');
    if ($c['referred_from'] && !$c['arrived_at']) fail('This patient has not arrived at ' . MAIN_BRANCH . ' yet. The front desk marks the arrival first.');
    if (!in_array($outcome, ['Survived', 'Died'], true)) fail('Choose whether ' . $c['pet'] . ' survived or died.', 'outcome');
    if ($outcome === 'Died') $followup = null;
    if ($followup !== null && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $followup) || $followup < date('Y-m-d'))) fail('Check the follow-up date.', 'followup_date');
    $c = conf_sync_bill($id, $actor);   // the final day count up to today
    $db = db(); $db->beginTransaction();
    q("UPDATE confinements SET status='Discharged', discharged=CURDATE(), discharged_at=NOW(), outcome=? WHERE id=?", [$outcome, $id]);
    q("UPDATE sales SET status='Unpaid', ready_at=NOW(), prepared_by=? WHERE id=? AND status='Draft'", [$actor['name'], $c['sale_id']]);
    $sum = bill_recalc((int)$c['sale_id']);
    $db->commit();
    $d = conf_days(conf_row($id)); $what = $c['pet'] . ' (' . $c['client'] . ')';
    log_act((int)$actor['id'], 'Discharged a patient', $what . ': ' . $outcome . ', ' . $d['days'] . ' day(s), ' . money((float)$sum['total']));
    $fd = null;
    if ($followup) {
        $d2 = $followup; for ($i = 0; $i < 14 && queue_day_problem($d2, false); $i++) $d2 = date('Y-m-d', strtotime("$d2 +1 day"));
        $dupe = q("SELECT 1 FROM appointments WHERE pet_id=? AND appt_date=? AND branch=? AND is_queue=1 AND status<>'Cancelled' LIMIT 1", [$c['pet_id'], $d2, conf_branch($c)])->fetch();
        if (!queue_day_problem($d2, false) && !$dupe) { [, $fd] = register_queue((int)$c['pet_id'], $d2, conf_branch($c), null, 'Follow-up after confinement', 'Confirmed', null, 'Vet', true); }
    }
    notify_role('staff', conf_branch($c), 'done', 'Discharged, ready for billing: ' . $c['pet'], $c['client'] . ' · ' . $d['days'] . ' day(s) · ' . money((float)$sum['total']), 'bills.php', (int)$actor['id']);
    if ($outcome === 'Died') notify_owner((int)$c['client_id'], 'done', 'About ' . $c['pet'], 'We are very sorry to tell you that ' . $c['pet'] . ' did not survive. Our clinic will help you with the next steps. Please see the front desk.', 'appointments.php');
    else notify_owner((int)$c['client_id'], 'done', $c['pet'] . ' can go home', $c['pet'] . ' is discharged after ' . $d['days'] . ' day' . ($d['days'] === 1 ? '' : 's') . '. Please see the front desk for the bill.' . ($fd ? ' A follow-up check-up is set for ' . date('D, M j', strtotime($fd)) . '.' : ''), 'appointments.php');
    return ['ok' => true, 'sale_id' => (int)$c['sale_id'], 'total' => $sum['total'], 'days' => $d['days'], 'followup' => $fd, 'outcome' => $outcome];
}

// ===== Money summary for the Sales pages (Update 19): staff and admin both use this =====
// $from / $to are Y-m-d dates (inclusive), $branch '' = every branch. Bounced checks never count as money received; Draft and Transferred bills are not counted as billed.
function sales_summary(string $from, string $to, string $branch = ''): array {
    $online = "'" . implode("','", array_map(fn($m) => str_replace("'", '', $m), ONLINE_PAY_METHODS)) . "'";
    $bs = $branch !== '' ? ' AND s.branch=?' : ''; $bp = $branch !== '' ? [$branch] : [];
    $ok = "NOT (sp.method='Check' AND sp.check_status='Bounced')";
    $days = max(1, min(92, (int)((strtotime($to) - strtotime($from)) / 86400) + 1));
    $to = date('Y-m-d', strtotime($from . ' +' . ($days - 1) . ' days'));
    $col = function (string $f, string $t) use ($online, $ok, $bs, $bp) {
        return q("SELECT COALESCE(SUM(sp.amount),0) total, COALESCE(SUM(CASE WHEN sp.method IN ($online) THEN sp.amount ELSE 0 END),0) online
            FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id WHERE DATE(sp.created_at) BETWEEN ? AND ? AND $ok$bs", array_merge([$f, $t], $bp))->fetch();
    };
    $now = $col($from, $to);
    $pTo = date('Y-m-d', strtotime($from . ' -1 day')); $pFrom = date('Y-m-d', strtotime($pTo . ' -' . ($days - 1) . ' days'));
    $prev = $col($pFrom, $pTo);
    $bill = q("SELECT COUNT(*) n, COALESCE(SUM(s.total),0) billed, COALESCE(SUM(s.paid),0) paid_on_them FROM sales s WHERE s.sale_date BETWEEN ? AND ? AND s.status NOT IN ('Draft','Transferred')$bs", array_merge([$from, $to], $bp))->fetch();
    $items = (int)q("SELECT COALESCE(SUM(i.qty),0) FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE s.sale_date BETWEEN ? AND ? AND s.status NOT IN ('Draft','Transferred')$bs", array_merge([$from, $to], $bp))->fetchColumn();
    $per = array_column(q("SELECT DATE(sp.created_at) d, SUM(sp.amount) amt FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id WHERE DATE(sp.created_at) BETWEEN ? AND ? AND $ok$bs GROUP BY DATE(sp.created_at)", array_merge([$from, $to], $bp))->fetchAll(), 'amt', 'd');
    $series = []; for ($i = 0; $i < $days; $i++) { $d = date('Y-m-d', strtotime($from . " +$i days")); $series[] = ['d' => $d, 'amt' => r2($per[$d] ?? 0)]; }
    $methods = q("SELECT sp.method, SUM(sp.amount) amt, COUNT(*) n FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id WHERE DATE(sp.created_at) BETWEEN ? AND ? AND $ok$bs GROUP BY sp.method ORDER BY amt DESC", array_merge([$from, $to], $bp))->fetchAll();
    // unpaid balances are as of today, whatever period is chosen
    $owed = q("SELECT COALESCE(SUM(s.total-s.paid),0) owed, COUNT(DISTINCT s.client_id) clients, COUNT(*) bills FROM sales s WHERE s.status IN ('Unpaid','Partially paid')$bs", $bp)->fetch();
    $bk = ['0-30' => 0.0, '31-60' => 0.0, '60+' => 0.0];
    foreach (q("SELECT DATEDIFF(CURDATE(), s.sale_date) age, s.total-s.paid bal FROM sales s WHERE s.status IN ('Unpaid','Partially paid')$bs", $bp)->fetchAll() as $r) $bk[$r['age'] <= 30 ? '0-30' : ($r['age'] <= 60 ? '31-60' : '60+')] += (float)$r['bal'];
    $who = q("SELECT c.id, c.name, c.phone, SUM(s.total-s.paid) owed, COUNT(*) bills, DATEDIFF(CURDATE(), MIN(s.sale_date)) age
        FROM sales s JOIN clients c ON c.id=s.client_id WHERE s.status IN ('Unpaid','Partially paid')$bs GROUP BY c.id, c.name, c.phone HAVING owed > 0.004 ORDER BY MIN(s.sale_date), c.name LIMIT 8", $bp)->fetchAll();
    $chk = q("SELECT COUNT(*) n, COALESCE(SUM(sp.amount),0) amt FROM sale_payments sp JOIN sales s ON s.id=sp.sale_id WHERE sp.method='Check' AND sp.check_status='Pending clearing'$bs", $bp)->fetch();
    return ['from' => $from, 'to' => $to, 'days' => $days, 'branch' => $branch,
        'collected' => r2($now['total']), 'online' => r2($now['online']), 'clinic' => r2($now['total'] - $now['online']), 'prev_collected' => r2($prev['total']), 'prev_from' => $pFrom, 'prev_to' => $pTo,
        'bills' => (int)$bill['n'], 'billed' => r2($bill['billed']), 'items' => $items, 'series' => $series, 'methods' => array_map(fn($m) => ['method' => $m['method'], 'amt' => r2($m['amt']), 'n' => (int)$m['n']], $methods),
        'owed' => r2($owed['owed']), 'owed_clients' => (int)$owed['clients'], 'owed_bills' => (int)$owed['bills'], 'ageing' => array_map('r2', $bk), 'who' => array_map(fn($w) => ['id' => (int)$w['id'], 'name' => $w['name'], 'phone' => $w['phone'], 'owed' => r2($w['owed']), 'bills' => (int)$w['bills'], 'age' => (int)$w['age']], $who),
        'checks_n' => (int)$chk['n'], 'checks_amt' => r2($chk['amt']), 'online_methods' => ONLINE_PAY_METHODS];
}
// list of bills for the Sales history (shared by staff and admin): filters by text, date range, branch and status
function sales_list(array $get, int $per = 12): array {
    $s = ltrim(trim($get['q'] ?? ''), '#'); $from = $get['from'] ?? ''; $to = $get['to'] ?? ''; $br = $get['branch'] ?? ''; $st = $get['status'] ?? '';
    $ok = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$d);
    $w = ["s.status<>'Draft'"]; $a = [];
    if ($ok($from)) { $w[] = 's.sale_date>=?'; $a[] = $from; } if ($ok($to)) { $w[] = 's.sale_date<=?'; $a[] = $to; }
    if (in_array($br, BRANCHES, true)) { $w[] = 's.branch=?'; $a[] = $br; }
    if (in_array($st, ['Unpaid', 'Partially paid', 'Paid', 'Transferred'], true)) { $w[] = 's.status=?'; $a[] = $st; }
    if ($s !== '') { $w[] = '(s.id=? OR c.name LIKE ? OR p.name LIKE ? OR EXISTS(SELECT 1 FROM sale_items i WHERE i.sale_id=s.id AND i.item LIKE ?))'; array_push($a, (int)$s, "%$s%", "%$s%", "%$s%"); }
    $W = implode(' AND ', $w); $page = max(1, (int)($get['page'] ?? 1)); $off = ($page - 1) * $per;
    $total = (int)q("SELECT COUNT(*) FROM sales s LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN pets p ON p.id=s.pet_id WHERE $W", $a)->fetchColumn();
    $rows = q("SELECT s.id, s.sale_date, s.branch, s.total, s.paid, s.status, c.name client, p.name pet,
        (SELECT GROUP_CONCAT(item SEPARATOR ', ') FROM sale_items WHERE sale_id=s.id) items,
        (SELECT COALESCE(SUM(qty),0) FROM sale_items WHERE sale_id=s.id) qty
        FROM sales s LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN pets p ON p.id=s.pet_id WHERE $W ORDER BY s.sale_date DESC, s.id DESC LIMIT $per OFFSET $off", $a)->fetchAll();
    return compact('rows', 'total', 'page', 'per');
}
function sales_range(array $get): array {
    $ok = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$d) && strtotime($d) !== false;
    $to = $ok($get['to'] ?? '') ? $get['to'] : date('Y-m-d'); $from = $ok($get['from'] ?? '') ? $get['from'] : $to;
    if ($from > $to) [$from, $to] = [$to, $from];
    $branch = in_array($get['branch'] ?? '', BRANCHES, true) ? $get['branch'] : '';
    return [$from, $to, $branch];
}

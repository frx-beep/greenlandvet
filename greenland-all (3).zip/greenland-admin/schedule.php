<?php
// ===== Scheduling v3 =====
// Check-ups and vaccinations are a first-come-first-served QUEUE (a day registration, no times); surgeries and confinements keep booked times.
// Which services are queue services is set by QUEUE_SERVICES in config.php.
// Vets rotate: only vets who are ON DUTY (daily roster) take patients. Every vet does every service. Plain rules and logic only: no AI.
function tmin(string $t): int { $p = explode(':', substr($t, 0, 5)); return (int)$p[0] * 60 + (int)($p[1] ?? 0); }
function mtime(int $m): string { return sprintf('%02d:%02d', intdiv($m, 60), $m % 60); }
function svc_len(string $s): int { return SERVICE_MINUTES[$s] ?? SLOT_MINUTES; }
function is_closed(string $date): bool { return in_array((int)date('w', strtotime($date)), CLOSED_DAYS, true); }
function now_min(): int { return tmin(date('H:i')); }
function hm12(string $t): string { return date('g:i A', strtotime($t)); }
function is_queue_svc(string $svc): bool { return in_array($svc, QUEUE_SERVICES, true); }
function sev_min(?string $s): int { return SEVERITY_MINUTES[$s] ?? SEVERITY_MINUTES['Routine']; }
function queue_open_today(): bool { return now_min() < tmin(QUEUE_LAST_ARRIVAL); }   // new check-ups are accepted until this time

// ---------- vets and the duty roster ----------
// Who is on duty at a branch on a date: [{id,name,on,source}] (source: set = chosen for that day, default = weekly pattern, auto = no pattern so every vet is in).
function duty_list(string $branch, string $date): array {
    $vets = q("SELECT id, name FROM accounts WHERE role='vet' AND status='Active' AND branch=? ORDER BY name", [$branch])->fetchAll();
    try {
        $set = array_column(q('SELECT account_id, on_duty FROM vet_duty WHERE duty_date=?', [$date])->fetchAll(), 'on_duty', 'account_id');
        $def = []; foreach (q('SELECT account_id, weekday FROM vet_duty_default')->fetchAll() as $r) $def[$r['account_id']][(int)$r['weekday']] = true;
    } catch (PDOException $e) { $set = []; $def = []; }   // database not upgraded yet: everyone is in
    $wd = (int)date('w', strtotime($date)); $out = [];
    foreach ($vets as $v) {
        $id = (int)$v['id'];
        if (array_key_exists($id, $set)) { $on = (bool)$set[$id]; $src = 'set'; }
        elseif (!empty($def[$id])) { $on = isset($def[$id][$wd]); $src = 'default'; }
        else { $on = true; $src = 'auto'; }
        $out[] = ['id' => $id, 'name' => $v['name'], 'on' => $on, 'source' => $src];
    }
    return $out;
}
// Active vets at a branch who are on duty on $date.
function vet_pool(string $branch, string $date): array {
    return array_values(array_map(fn($v) => ['id' => $v['id'], 'name' => $v['name']], array_filter(duty_list($branch, $date), fn($v) => $v['on'])));
}
// Every vet does every service. Names of the vets who may take it (kept as a function so callers stay simple).
function vets_for(array $pool, string $svc = '', ?string $concern = null): array { return array_column($pool, 'name'); }
function eligible_vets(string $branch, string $svc = '', ?string $concern = null, ?string $date = null): array { return vets_for(vet_pool($branch, $date ?? date('Y-m-d'))); }

// ---------- the day's bookings ----------
function day_appts(string $date, string $branch, array $ignore = []): array {
    $rows = q("SELECT id, vet, service, TIME_FORMAT(appt_time,'%H:%i') t FROM appointments WHERE appt_date=? AND (branch=? OR branch IS NULL) AND status<>'Cancelled' AND is_queue=0", [$date, $branch])->fetchAll();
    return $ignore ? array_values(array_filter($rows, fn($a) => !in_array((int)$a['id'], $ignore, true))) : $rows;
}

// Place a chain of services back to back from $start (minutes). Returns [{start,end,vet}] or null when any step cannot be placed.
// A step needs: an eligible vet who is free for its whole length, and a free room (never more overlapping visits than rooms).
function chain_alloc(array $appts, array $pool, array $items, int $start, ?string $vet = null): ?array {
    $cur = $start; $out = [];
    foreach ($items as $it) {
        $e = $cur + svc_len($it['svc']);
        $busy = []; $loose = 0; $conc = 0; $concS = 0; $isSurg = $it['svc'] === 'Surgery';
        foreach ($appts as $a) {
            $as = tmin($a['t']); $ae = $as + svc_len($a['service']);
            if ($as < $e && $ae > $cur) { $conc++; if ($a['service'] === 'Surgery') $concS++; if ($a['vet']) $busy[$a['vet']] = true; else $loose++; }
        }
        $concE = $conc - $concS;   // visits that need an exam room (surgeries use the separate surgery room)
        if (!$pool) {   // no vet accounts yet: simple number of bookings per slot
            if ($conc >= DEFAULT_CAPACITY) return null;
            $pick = null;
        } else {
            if ($isSurg ? $concS >= count(SURGERY_ROOMS) : $concE >= count(ROOMS)) return null;   // the room this service needs is taken at that time
            $cand = vets_for($pool);
            if ($vet) $cand = array_values(array_filter($cand, fn($n) => $n === $vet));
            $free = array_values(array_filter($cand, fn($n) => empty($busy[$n])));
            if (!$vet) $free = array_slice($free, 0, max(0, count($free) - $loose));   // unassigned visits will need a vet too
            if (!$free) return null;
            $load = array_count_values(array_filter(array_column($appts, 'vet')));   // spread the day: fewest bookings first
            usort($free, fn($a, $b) => ($load[$a] ?? 0) <=> ($load[$b] ?? 0) ?: strcmp($a, $b));
            $pick = $free[0];
        }
        $out[] = ['start' => $cur, 'end' => $e, 'vet' => $pick, 'svc' => $it['svc']];
        $appts[] = ['id' => 0, 'vet' => $pick, 'service' => $it['svc'], 't' => mtime($cur)];
        $cur = $e;
    }
    return $out;
}
function chain_len(array $items): int { return array_sum(array_map(fn($i) => svc_len($i['svc']), $items)); }
function clean_items(array $items): array {   // [{svc, concern}] with only valid services (concern is always empty now: no specializations)
    $out = [];
    foreach ($items as $i) { $sv = $i['svc'] ?? ($i['service'] ?? ''); if (in_array($sv, SERVICES, true)) $out[] = ['svc' => $sv, 'concern' => null]; }
    return $out;
}

// The slot grid for a day: every start time, and whether the whole chain fits.
function chain_slots(string $date, string $branch, array $items, ?string $vet = null, array $ignore = [], bool $online = false): array {
    if (is_closed($date) || !$items) return [];
    $appts = day_appts($date, $branch, $ignore); $pool = vet_pool($branch, $date);
    $today = $date === date('Y-m-d'); $now = $today ? now_min() : -1;
    $minStart = $today ? ($online ? $now + ONLINE_LEAD_MINUTES : $now + 1) : -1;
    $latest = $online ? tmin(CLINIC_CLOSE) - ONLINE_CLOSE_BUFFER : PHP_INT_MAX;
    $total = chain_len($items); $out = [];
    for ($m = tmin(CLINIC_OPEN); $m + $total <= tmin(CLINIC_CLOSE); $m += SLOT_MINUTES) {
        $why = null; $al = null;
        if ($m <= $now && $today) $why = 'past';
        elseif ($m < $minStart) $why = 'soon';
        elseif ($m > $latest) $why = 'late';
        else { $al = chain_alloc($appts, $pool, $items, $m, $vet); if (!$al) $why = 'full'; }
        $out[] = ['time' => mtime($m), 'ok' => $why === null, 'why' => $why, 'past' => $why === 'past', 'vet' => $al[0]['vet'] ?? null];
    }
    return $out;
}
function day_slots(string $date, string $branch, string $svc, ?string $vet = null, array $ignore = [], ?string $concern = null, bool $online = false): array {
    return chain_slots($date, $branch, [['svc' => $svc, 'concern' => $concern]], $vet, $ignore, $online);
}
// the free times closest to what was asked for (same day first, then the following days)
function chain_suggest(string $date, string $time, string $branch, array $items, ?string $vet, int $n = 4, ?string $maxDate = null, bool $online = false, array $ignore = []): array {
    $target = tmin($time); $out = [];
    for ($d = 0; $d < 21 && count($out) < $n; $d++) {
        $day = date('Y-m-d', strtotime("$date +$d day"));
        if ($maxDate && $day > $maxDate) break;
        $c = array_values(array_filter(chain_slots($day, $branch, $items, $vet, $ignore, $online), fn($s) => $s['ok']));
        usort($c, fn($a, $b) => abs(tmin($a['time']) - $target) <=> abs(tmin($b['time']) - $target));
        foreach ($c as $s) { $out[] = ['date' => $day, 'time' => $s['time'], 'vet' => $s['vet']]; if (count($out) >= $n) break; }
        $target = tmin(CLINIC_OPEN);   // following days: earliest first
    }
    return $out;
}
// book as asked if free, otherwise the nearest free time (follow-up check-ups). Returns [date, time, vet].
function auto_chain(string $date, string $time, string $branch, array $items, ?string $vet = null): array {
    foreach (chain_slots($date, $branch, $items, $vet) as $s) if ($s['time'] === $time && $s['ok']) return [$date, $time, $s['vet']];
    $sug = chain_suggest($date, $time, $branch, $items, $vet, 1);
    return $sug ? [$sug[0]['date'], $sug[0]['time'], $sug[0]['vet']] : [$date, $time, null];
}

// Validate a booking and return its placement [{start,end,vet,svc}]. Fails with a clear message, and with nearest times when the slot is taken.
function pick_chain(string $date, string $time, string $branch, array $items, ?string $vet = null, array $ignore = [], ?string $maxDate = null, bool $online = false): array {
    if (!$items) fail('Choose at least one service.', 'service');
    if ($date < date('Y-m-d')) fail('That date has already passed. Please choose today or a later date.', 'date');
    if ($maxDate && $date > $maxDate) fail('Appointments can only be booked up to 30 days ahead.', 'date');
    if (is_closed($date)) fail('The clinic is closed on that day. Please pick another date.', 'date');
    $s = tmin($time); $total = chain_len($items);
    if ($s < tmin(CLINIC_OPEN) || $s + $total > tmin(CLINIC_CLOSE)) fail('That time is outside clinic hours (' . hm12(CLINIC_OPEN) . ' to ' . hm12(CLINIC_CLOSE) . ')' . (count($items) > 1 ? ' for ' . $total . ' minutes of services.' : '.'), 'time');
    if (($s - tmin(CLINIC_OPEN)) % SLOT_MINUTES !== 0) fail('Please choose one of the listed time slots.', 'time');
    $today = $date === date('Y-m-d');
    if ($today && $s <= now_min()) fail('That time has already passed today. Please choose a later time.', 'time');
    $sug = fn() => chain_suggest($date, $time, $branch, $items, $vet, 4, $maxDate, $online, $ignore);
    if ($online && $today && $s < now_min() + ONLINE_LEAD_MINUTES)
        send(['error' => 'Online bookings for today need at least ' . ONLINE_LEAD_MINUTES . ' minutes\' notice so you have time to travel. Here are the nearest times.', 'field' => 'time', 'suggestions' => $sug()], 409);
    if ($online && $s > tmin(CLINIC_CLOSE) - ONLINE_CLOSE_BUFFER)
        send(['error' => 'Online bookings stop ' . ONLINE_CLOSE_BUFFER . ' minutes before closing (' . hm12(CLINIC_CLOSE) . '). Here are the nearest times, including the next day.', 'field' => 'time', 'suggestions' => $sug()], 409);
    $pool = vet_pool($branch, $date);
    if ($vet && $pool && !in_array($vet, array_column($pool, 'name'), true)) fail("$vet is not on duty at the $branch branch on that day.", 'vet');
    $al = chain_alloc(day_appts($date, $branch, $ignore), $pool, $items, $s, $vet);
    if (!$al) {
        $why = $vet ? "$vet is not free for the whole visit at that time." : (count($items) > 1 ? 'There is no free vet or room for all of these services starting at that time.' : 'That time is fully booked (no free vet or room).');
        send(['error' => $why . ' Here are the nearest available times.', 'field' => 'time', 'suggestions' => $sug()], 409);
    }
    return $al;
}
// single service helper used by older callers: returns the vet to assign (null if there are no vet accounts)
function pick_slot(string $date, string $time, string $branch, string $svc, ?string $vet, array $ignore = [], ?string $maxDate = null, ?string $concern = null, bool $online = false): ?string {
    return pick_chain($date, $time, $branch, [['svc' => $svc, 'concern' => $concern]], $vet, $ignore, $maxDate, $online)[0]['vet'];
}

// Days (from $from) on which a service can be done, with the vets who are free. Used to plan surgery after a check-up.
function free_days(string $svc, string $branch, string $from, int $nDays = 7, ?string $concern = null, ?string $vet = null): array {
    $out = [];
    for ($d = 0; $d < 30 && count($out) < $nDays; $d++) {
        $day = date('Y-m-d', strtotime("$from +$d day"));
        if (is_closed($day)) continue;
        $slots = array_values(array_filter(day_slots($day, $branch, $svc, $vet, [], $concern), fn($s) => $s['ok']));
        if (!$slots) continue;
        $vs = [];   // every vet with at least one free slot that day
        $appts = day_appts($day, $branch); $pool = vet_pool($branch, $day);
        foreach ($slots as $s) foreach (vets_for($pool) as $n) {
            if (isset($vs[$n])) continue;
            if (chain_alloc($appts, $pool, [['svc' => $svc, 'concern' => $concern]], tmin($s['time']), $n)) $vs[$n] = true;
        }
        $out[] = ['date' => $day, 'slots' => count($slots), 'first' => $slots[0]['time'], 'vets' => array_keys($vs)];
    }
    return $out;
}

// ---------- the queue: first come, first served ----------
// A patient is called only when BOTH an on-duty vet and a room are free. Vets and rooms are released when the visit is marked Done, not on a timer.
// Order: emergencies first (staff move them up with a reason), then earliest arrival. The server handles one check-in at a time per branch (named lock),
// so two patients arriving together can never be given the same room or vet.
function queue_lock(string $branch): bool { return (int)q('SELECT GET_LOCK(?, 5)', ['gv_q_' . $branch])->fetchColumn() === 1; }
function queue_unlock(string $branch): void { try { q('SELECT RELEASE_LOCK(?)', ['gv_q_' . $branch]); } catch (Throwable $e) {} }
function with_queue_lock(string $branch, callable $fn) {
    static $held = [];   // already holding this branch's lock in this request: just run (nested calls are safe)
    if (!empty($held[$branch])) return $fn();
    if (!queue_lock($branch)) fail('The queue is busy for a moment. Please try again.', null, 503);
    $held[$branch] = true;
    try { return $fn(); } finally { $held[$branch] = false; queue_unlock($branch); }
}
// Pure planner (unit-tested): who gets which vet and room next.
// $waiting: [{id, vet (preferred or null), priority, arrived (sortable), no}], $freeVets: names (null entries = no vet accounts), $freeRooms: names, $load: vet => visits today.
function queue_plan(array $waiting, array $freeVets, array $freeRooms, array $load = []): array {
    usort($waiting, fn($a, $b) => [-(int)($a['priority'] ?? 0), (string)$a['arrived'], (int)($a['no'] ?? 0), (int)$a['id']] <=> [-(int)($b['priority'] ?? 0), (string)$b['arrived'], (int)($b['no'] ?? 0), (int)$b['id']]);
    $out = [];
    foreach ($waiting as $w) {
        if (!$freeVets || !$freeRooms) break;                       // FIFO: nobody jumps the line, so stop when the first patient cannot be placed
        $vi = null;
        if (!empty($w['vet'])) { $k = array_search($w['vet'], $freeVets, true); if ($k !== false) $vi = $k; }
        if ($vi === null) {   // the free vet who has seen the fewest patients today
            $best = null;
            foreach ($freeVets as $k => $n) { $l = $load[$n] ?? 0; if ($best === null || $l < $best[0] || ($l === $best[0] && strcmp((string)$n, (string)$freeVets[$best[1]]) < 0)) $best = [$l, $k]; }
            $vi = $best[1];
        }
        $vet = $freeVets[$vi]; array_splice($freeVets, $vi, 1);
        $room = array_shift($freeRooms);
        $out[] = ['id' => (int)$w['id'], 'vet' => $vet, 'room' => $room];
    }
    return $out;
}
function queue_rows(string $branch, string $date): array {
    return q("SELECT a.id, a.vet, a.room, a.service, a.status, a.is_queue, a.queue_no, a.severity, a.priority, a.priority_reason, a.checked_in_at, a.called_at, a.started_at, a.group_token, a.source,
        TIME_FORMAT(a.appt_time,'%H:%i') t, p.id pet_id, p.name pet, p.species, c.id client_id, c.name client
        FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id WHERE a.appt_date=? AND a.branch=? AND a.status<>'Cancelled' ORDER BY a.checked_in_at, a.id", [$date, $branch])->fetchAll();
}
// One pet, one place in the line: if the same pet is registered for two queue services on the same day (for example a check-up and a vaccination),
// the first row leads and the others are "companions" seen in the same visit (same vet and room, same queue number). Returns [leaders, companions by leader id].
function queue_split(array $waiting): array {
    $lead = []; $comp = []; $seen = [];
    foreach ($waiting as $a) { $k = $a['pet_id']; if (isset($seen[$k])) $comp[$seen[$k]][] = $a; else { $seen[$k] = (int)$a['id']; $lead[] = $a; } }
    return [$lead, $comp];
}
// Call the next waiting patients while a vet AND a room are free. Call after every check-in, Done, cancellation or duty change. Returns the assignments.
function queue_advance(string $branch): array { return with_queue_lock($branch, fn() => queue_advance_run($branch)); }
function queue_advance_run(string $branch): array {
    $today = date('Y-m-d'); $rows = queue_rows($branch, $today);
    $active = array_filter($rows, fn($a) => $a['checked_in_at'] && $a['called_at'] && $a['status'] !== 'Completed');
    $waiting = array_values(array_filter($rows, fn($a) => $a['checked_in_at'] && !$a['called_at'] && $a['is_queue'] && $a['status'] !== 'Completed'));
    if (!$waiting) return [];
    [$waiting, $comp] = queue_split($waiting);
    $busyV = array_filter(array_column($active, 'vet')); $busyR = array_filter(array_column($active, 'room'));
    $pool = array_column(vet_pool($branch, $today), 'name'); $hasVets = (int)q("SELECT COUNT(*) FROM accounts WHERE role='vet' AND status='Active' AND branch=?", [$branch])->fetchColumn() > 0;
    $freeRooms = array_values(array_diff(ROOMS, $busyR));
    $freeVets = $hasVets ? array_values(array_diff($pool, $busyV)) : array_fill(0, count($freeRooms), null);
    $load = array_column(q("SELECT vet, COUNT(*) n FROM appointments WHERE appt_date=? AND branch=? AND called_at IS NOT NULL AND vet IS NOT NULL GROUP BY vet", [$today, $branch])->fetchAll(), 'n', 'vet');
    $plan = queue_plan(array_map(fn($a) => ['id' => $a['id'], 'vet' => $a['vet'], 'priority' => $a['priority'], 'arrived' => $a['checked_in_at'], 'no' => $a['queue_no']], $waiting), $freeVets, $freeRooms, $load);
    $by = array_column($rows, null, 'id');
    foreach ($plan as $p) {
        $u = q('UPDATE appointments SET vet=?, room=?, called_at=NOW() WHERE id=? AND called_at IS NULL', [$p['vet'], $p['room'], $p['id']]);
        if ($u->rowCount() < 1) continue;
        foreach ($comp[$p['id']] ?? [] as $c) q('UPDATE appointments SET vet=?, room=?, called_at=NOW() WHERE id=? AND called_at IS NULL', [$p['vet'], $p['room'], $c['id']]);   // same visit
        $a = $by[$p['id']];
        if ($p['vet']) notify_vet($p['vet'], 'checkin', 'Next patient: ' . $a['pet'], $a['pet'] . ' (' . $a['client'] . ') ' . $a['service'] . ' in ' . $p['room'] . '.', 'index.php');
        notify_owner((int)$a['client_id'], 'checkin', "It's your turn", $a['pet'] . ' will be seen' . ($p['vet'] ? ' by ' . $p['vet'] : '') . '. Please go to ' . $p['room'] . '.', 'appointments.php');
    }
    return $plan;
}
// Staff chose a specific vet and/or room for a patient (the vet or room must be free, or already this patient's). Returns an error text or null.
function queue_assign(int $id, ?string $vet, ?string $room, string $branch): ?string {
    $today = date('Y-m-d'); $rows = queue_rows($branch, $today); $me = null;
    foreach ($rows as $a) if ((int)$a['id'] === $id) $me = $a;
    if (!$me || !$me['checked_in_at']) return 'Check the patient in first.';
    $others = array_filter($rows, fn($a) => (int)$a['id'] !== $id && $a['checked_in_at'] && $a['called_at'] && $a['status'] !== 'Completed');
    if ($vet) {
        if (!in_array($vet, array_column(vet_pool($branch, $today), 'name'), true)) return "$vet is not on duty at the $branch branch today.";
        foreach ($others as $o) if ($o['vet'] === $vet) return "$vet is with {$o['pet']} right now.";
    }
    if ($room) {
        if (!in_array($room, ROOMS, true)) return 'Unknown room.';
        foreach ($others as $o) if ($o['room'] === $room) return "$room is occupied by {$o['pet']}.";
    }
    q('UPDATE appointments SET vet=COALESCE(?, vet), room=COALESCE(?, room), called_at=COALESCE(called_at, NOW()) WHERE id=?', [$vet, $room, $id]);
    return null;
}
// How long the patient being seen is expected to take: [low, high] minutes remaining.
// Expected length of one visit in minutes: vaccinations are quick (SERVICE_MINUTES), check-ups depend on how serious the case is.
function queue_len(array $a): int { return $a['service'] === 'Vaccination' ? svc_len('Vaccination') : sev_min($a['severity'] ?? null); }
function visit_remaining(array $a, int $now): array {
    $len = queue_len($a);
    $start = tmin(substr($a['started_at'] ?: $a['called_at'] ?: date('Y-m-d H:i:s'), 11, 5));
    $lo = max(0, (int)round($start + $len * 0.75) - $now); $hi = max($lo + 10, (int)round($start + $len * 1.25) - $now);
    return [$lo, $hi];
}
function queue_wait_text(?array $w): string {   // "about 30 to 60 minutes"
    if (!$w) return 'not available';
    if ($w[1] <= 5) return 'you are next';
    $r = fn($m) => (int)(round($m / 5) * 5);
    return 'about ' . $r(max($w[0], 5)) . ' to ' . $r($w[1]) . ' minutes';
}

// ---------- today's board: vets, rooms and the waiting queue ----------
function board(string $branch): array {
    $today = date('Y-m-d'); $now = now_min();
    $duty = duty_list($branch, $today); $rows = queue_rows($branch, $today);
    $active = array_values(array_filter($rows, fn($a) => $a['checked_in_at'] && $a['called_at'] && $a['status'] !== 'Completed'));
    $vets = []; $freeAt = [];   // vet => [low, high] minutes until free
    foreach ($duty as $v) {
        $cur = null; foreach ($active as $a) if ($a['vet'] === $v['name']) { $cur = $a; break; }
        $rem = $cur ? visit_remaining($cur, $now) : [0, 0];
        if ($v['on']) $freeAt[$v['name']] = $rem;
        $vets[] = ['id' => $v['id'], 'name' => $v['name'], 'on' => $v['on'], 'source' => $v['source'], 'status' => !$v['on'] ? 'off' : ($cur ? 'busy' : 'free'),
            'patient' => $cur ? $cur['pet'] . ' (' . $cur['service'] . ')' : null, 'appt_id' => $cur ? (int)$cur['id'] : null, 'since' => $cur ? substr($cur['called_at'], 11, 5) : null,
            'until' => ($cur && $v['on']) ? mtime($now + $rem[1]) : null];
    }
    $roomFree = [];
    $rooms = [];
    foreach (ROOMS as $r) {
        $occ = null; foreach ($active as $a) if ($a['room'] === $r) { $occ = $a; break; }
        $roomFree[$r] = $occ ? visit_remaining($occ, $now) : [0, 0];
        $rooms[] = ['name' => $r, 'free' => !$occ, 'pet' => $occ['pet'] ?? null, 'species' => $occ['species'] ?? null, 'client' => $occ['client'] ?? null, 'vet' => $occ['vet'] ?? null, 'appt_id' => $occ ? (int)$occ['id'] : null,
            'since' => $occ ? substr($occ['called_at'], 11, 5) : null, 'with_vet' => $occ ? (bool)$occ['started_at'] : false];
    }
    // the waiting list with an estimate for each patient: simulate the next free vet and room in turn
    $waiting = array_values(array_filter($rows, fn($a) => $a['checked_in_at'] && !$a['called_at'] && $a['is_queue'] && $a['status'] !== 'Completed'));
    usort($waiting, fn($a, $b) => [-(int)$a['priority'], $a['checked_in_at'], (int)$a['queue_no'], $a['id']] <=> [-(int)$b['priority'], $b['checked_in_at'], (int)$b['queue_no'], $b['id']]);
    [$waiting, $compBy] = queue_split($waiting);
    $queue = []; $pos = 0; $vf = $freeAt; $rf = $roomFree; $noVets = !$duty;   // no vet accounts at all: only rooms limit the line
    foreach ($waiting as $a) {
        $pos++; $len = queue_len($a); $svcs = [$a['service']]; $w = null;
        foreach ($compBy[(int)$a['id']] ?? [] as $c) { $len += queue_len($c); $svcs[] = $c['service']; }   // the same pet's other service is done in the same visit
        if ($noVets || $vf) {   // nobody on duty means no estimate
            $vn = null; if (!$noVets) { uasort($vf, fn($x, $y) => $x[1] <=> $y[1]); $vn = array_key_first($vf); }
            uasort($rf, fn($x, $y) => $x[1] <=> $y[1]); $rn = array_key_first($rf);
            if (($noVets || $vn !== null) && $rn !== null) {
                $lo = max($noVets ? 0 : $vf[$vn][0], $rf[$rn][0]); $hi = max($noVets ? 0 : $vf[$vn][1], $rf[$rn][1]); $w = [$lo, $hi];
                if (!$noVets) $vf[$vn] = [$hi + (int)round($len * .75), $hi + (int)round($len * 1.25)];
                $rf[$rn] = [$hi + (int)round($len * .75), $hi + (int)round($len * 1.25)];
            }
        }
        $queue[] = ['id' => (int)$a['id'], 'no' => (int)$a['queue_no'], 'pos' => $pos, 'pet' => $a['pet'], 'species' => $a['species'], 'client' => $a['client'], 'service' => implode(' + ', $svcs), 'severity' => $a['severity'] ?: 'Routine',
            'priority' => (int)$a['priority'], 'priority_reason' => $a['priority_reason'], 'arrived' => substr($a['checked_in_at'], 11, 5), 'wait' => $w, 'wait_text' => queue_wait_text($w), 'source' => $a['source']];
    }
    $in = [];   // patients being seen
    foreach ($active as $a) $in[] = ['id' => (int)$a['id'], 'pet' => $a['pet'], 'species' => $a['species'], 'client' => $a['client'], 'service' => $a['service'], 'vet' => $a['vet'], 'room' => $a['room'], 'severity' => $a['severity'] ?: null, 'no' => $a['queue_no'] ? (int)$a['queue_no'] : null, 'since' => substr($a['called_at'], 11, 5), 'is_queue' => (int)$a['is_queue']];
    $surg = [];   // the surgery room (main branch only): free, or who is in it
    if ($branch === MAIN_BRANCH) foreach (SURGERY_ROOMS as $sr) {
        $occ = null; foreach ($active as $a) if ($a['room'] === $sr) { $occ = $a; break; }
        $next = null; foreach ($rows as $a) if ($a['service'] === 'Surgery' && !$a['checked_in_at'] && !in_array($a['status'], ['Completed', 'Cancelled'], true)) { $next = $a['t']; break; }
        $surg[] = ['name' => $sr, 'free' => !$occ, 'pet' => $occ['pet'] ?? null, 'vet' => $occ['vet'] ?? null, 'appt_id' => $occ ? (int)$occ['id'] : null, 'since' => $occ ? substr($occ['called_at'], 11, 5) : null, 'next' => $next];
    }
    $confined = 0; try { $confined = (int)q("SELECT COUNT(*) FROM confinements WHERE status='Admitted' AND COALESCE(branch,?)=?", [MAIN_BRANCH, $branch])->fetchColumn(); } catch (PDOException $e) {}
    $expected = count(array_filter($rows, fn($a) => !$a['checked_in_at'] && !in_array($a['status'], ['Completed', 'Cancelled'], true)));
    $due = array_values(array_map(fn($a) => ['id' => (int)$a['id'], 'pet' => $a['pet'], 'client' => $a['client'], 'service' => $a['service'], 'time' => $a['t'], 'is_queue' => (int)$a['is_queue']],
        array_filter($rows, fn($a) => !$a['checked_in_at'] && !in_array($a['status'], ['Completed', 'Cancelled'], true))));
    return ['vets' => $vets, 'rooms' => $rooms, 'surgery' => $surg, 'confined' => $confined, 'queue' => $queue, 'inroom' => $in, 'expected' => $expected, 'due' => $due, 'now' => mtime($now), 'queue_open' => queue_open_today(), 'last_arrival' => QUEUE_LAST_ARRIVAL, 'on_duty' => count($freeAt), 'min_vets' => MIN_VETS_ON_DUTY[$branch] ?? 1];
}
// A patient's own place in line (for the pet owner): state waiting | called | done | none
function queue_position(int $apptId): array {
    $r = q('SELECT id, branch, appt_date, checked_in_at, called_at, room, vet, status, queue_no, is_queue, service FROM appointments WHERE id=?', [$apptId])->fetch();
    if (!$r || $r['appt_date'] !== date('Y-m-d') || !$r['checked_in_at'] || in_array($r['status'], ['Completed', 'Cancelled'], true)) return ['state' => 'none'];
    if ($r['called_at']) return ['state' => 'called', 'room' => $r['room'], 'vet' => $r['vet']];
    $lead = (int)q("SELECT a.id FROM appointments a WHERE a.pet_id=(SELECT pet_id FROM appointments WHERE id=?) AND a.appt_date=? AND a.branch=? AND a.is_queue=1 AND a.checked_in_at IS NOT NULL AND a.called_at IS NULL AND a.status NOT IN ('Cancelled','Completed') ORDER BY a.id LIMIT 1", [$apptId, $r['appt_date'], $r['branch']])->fetchColumn();   // a companion service follows the pet's first row
    if ($lead) $apptId = $lead;
    foreach (board((string)$r['branch'])['queue'] as $x) if ($x['id'] === $apptId) return ['state' => 'waiting', 'pos' => $x['pos'], 'ahead' => $x['pos'] - 1, 'wait_text' => $x['wait_text'], 'no' => $x['no']];
    return ['state' => 'none'];
}

// ---------- who may cancel or change an appointment ----------
// Pet owner: only their own, not yet arrived, at least OWNER_CANCEL_HOURS before it starts; max MAX_RESCHEDULES reschedules.
// Staff: any appointment that has not been completed, any time, with a reason (the owner is told).
// Vet: only appointments assigned to them that have not started, with a reason (the owner and the front desk are told).
// System: not arrived after LATE_CANCEL_MINUTES -> cancelled automatically (the visit can still be converted to a walk-in at check-in).
function owner_can_change(array $a, bool $reschedule = false): ?string {
    if (in_array($a['status'], ['Completed', 'Cancelled'], true)) return 'This appointment is already ' . strtolower($a['status']) . '.';
    if (!empty($a['checked_in_at']) || !empty($a['started_at'])) return 'You have already checked in, so it can no longer be changed online.';
    if (!empty($a['is_queue'])) return ($reschedule && (int)($a['reschedule_count'] ?? 0) >= MAX_RESCHEDULES) ? 'This visit was already moved ' . MAX_RESCHEDULES . ' times. Please call the clinic.' : null;   // a day registration can be changed until the patient arrives
    $start = strtotime($a['appt_date'] . ' ' . substr($a['time'] ?? $a['appt_time'], 0, 5));
    if ($start - time() < OWNER_CANCEL_HOURS * 3600) return 'Online changes close ' . OWNER_CANCEL_HOURS . ' hours before the appointment. Please call the clinic.';
    if ($reschedule && (int)($a['reschedule_count'] ?? 0) >= MAX_RESCHEDULES) return 'This appointment was already rescheduled ' . MAX_RESCHEDULES . ' times. Please call the clinic.';
    return null;
}
function staff_can_change(array $a): ?string {
    if ($a['status'] === 'Completed') return 'This appointment is already completed.';
    if ($a['status'] === 'Cancelled') return 'This appointment is already cancelled.';
    return null;
}
function vet_can_cancel(array $a, array $me): ?string {
    if ($a['status'] === 'Completed' || $a['status'] === 'Cancelled') return 'This appointment is already ' . strtolower($a['status']) . '.';
    if (($a['vet'] ?? null) !== $me['name']) return 'You can only cancel appointments assigned to you.';
    if (!empty($a['started_at'])) return 'This visit has already started.';
    return null;
}
// ids of an appointment and the other items booked together with it
function appt_group_ids(int $id): array {
    $r = q('SELECT id, group_token FROM appointments WHERE id=?', [$id])->fetch();
    if (!$r) return [];
    if (!$r['group_token']) return [(int)$r['id']];
    return array_map('intval', q("SELECT id FROM appointments WHERE group_token=? AND status NOT IN ('Completed','Cancelled') ORDER BY appt_time, id", [$r['group_token']])->fetchAll(PDO::FETCH_COLUMN));
}
function appt_rows(array $ids): array {
    if (!$ids) return [];
    $in = implode(',', array_map('intval', $ids));
    return q("SELECT a.id, a.pet_id, a.appt_date, TIME_FORMAT(a.appt_time,'%H:%i') time, a.service, a.vet, a.branch, a.status, a.source, a.concern, a.reschedule_count, a.checked_in_at, a.started_at, a.group_token, a.is_queue, a.queue_no, a.severity, a.called_at, a.done_at, a.room,
              p.name pet, p.species, c.id client_id, c.name client FROM appointments a JOIN pets p ON p.id=a.pet_id JOIN clients c ON c.id=p.client_id WHERE a.id IN ($in) ORDER BY a.appt_time, a.id")->fetchAll();
}
function appt_summary(array $rows): string {
    return implode(', ', array_map(fn($r) => $r['pet'] . ' (' . $r['service'] . ')', $rows));
}
function appt_when(array $r): string { return date('D, M j', strtotime($r['appt_date'])) . (!empty($r['is_queue']) ? ' (any time, first come first served)' : ' at ' . hm12($r['time'])); }

// Can a queue registration (check-up or vaccination) be made for this day? (open day, not in the past, within the booking window, not after the daily cutoff when it is today)
function queue_check_day(string $date, string $branch, ?string $maxDate = null): void {
    if ($date < date('Y-m-d')) fail('That date has already passed. Please choose today or a later date.', 'date');
    if ($maxDate && $date > $maxDate) fail('Appointments can only be booked up to 30 days ahead.', 'date');
    if (is_closed($date)) fail('The clinic is closed on that day. Please pick another date.', 'date');
    if ($date === date('Y-m-d') && !queue_open_today()) fail('Check-ups and vaccinations for today closed at ' . hm12(QUEUE_LAST_ARRIVAL) . '. Please choose another day.', 'date');
}
// Cancel appointments. $by: Owner | Staff | Vet | System. Frees the slots (cancelled bookings are ignored by scheduling) and tells everyone concerned.
function appt_cancel(array $ids, string $by, string $reason, ?array $actor = null): void {
    $rows = array_values(array_filter(appt_rows($ids), fn($r) => !in_array($r['status'], ['Completed', 'Cancelled'], true)));
    if (!$rows) return;
    foreach ($rows as $r) q("UPDATE appointments SET status='Cancelled', cancelled_at=NOW(), cancel_reason=?, cancelled_by=? WHERE id=?", [substr($reason, 0, 160), $by, $r['id']]);
    $first = $rows[0]; $what = appt_summary($rows); $when = appt_when($first);
    $actorId = $actor['id'] ?? null; $branch = $first['branch'];
    $acts = ['Owner' => 'Cancelled an appointment', 'Staff' => 'Cancelled an appointment', 'Vet' => 'Cancelled an appointment', 'System' => 'Appointment auto-cancelled (late)'];
    $detail = "$what, $when. Reason: $reason";
    if ($actorId) log_act((int)$actorId, $acts[$by] ?? 'Cancelled an appointment', $detail);
    else { $o = owner_ids((int)$first['client_id']); if ($o) log_act($o[0], $acts[$by], $detail); }
    $title = $by === 'System' ? 'Appointment cancelled: not arrived' : 'Appointment cancelled';
    $ownerBody = "$what on $when. $reason";
    if ($by === 'System' && array_filter($rows, fn($r) => !empty($r['is_queue']) && $r['service'] === 'Vaccination')) {   // a missed vaccination day: invite them to pick another one
        $title = 'You missed your vaccination day';
        $ownerBody = "$what was registered for $when, but we did not see you before closing. Please register again for any open day. No time is needed, just come any time that day and show your QR code.";
    }
    if ($by !== 'Owner') notify_owner((int)$first['client_id'], 'cancel', $title, $ownerBody, 'request.php');
    if ($by !== 'Staff') notify_role('staff', $branch, 'cancel', $title, "$what, $when. " . ($by === 'Owner' ? 'Cancelled by the pet owner. ' : '') . $reason, 'appointments.php?date=' . $first['appt_date'], $actorId);
    if ($by !== 'Vet') foreach (array_unique(array_filter(array_column($rows, 'vet'))) as $v) notify_vet($v, 'cancel', $title, "$what, $when. $reason", 'appointments.php?date=' . $first['appt_date'], $actorId);
    else notify_role('staff', $branch, 'cancel', 'A vet cancelled an appointment', "$what, $when. $reason. Please reschedule it with the owner.", 'appointments.php?date=' . $first['appt_date'], $actorId);
    if (array_filter($rows, fn($r) => !empty($r['checked_in_at']))) queue_advance((string)$branch);   // a room and a vet were freed
}
// Move a booking (all items booked together) to a new start time. Re-runs vet/room routing. $online applies the pet-owner buffers.
function appt_reschedule(int $id, string $date, string $time, string $by, ?array $actor = null, ?string $maxDate = null, bool $online = false): array {
    $ids = appt_group_ids($id); $rows = appt_rows($ids);
    if (!$rows) fail('Appointment not found.', null, 404);
    if ($rows[0]['is_queue']) {   // a queue registration (check-up or vaccination) has no time: only the day changes
        queue_check_day($date, (string)$rows[0]['branch'], $maxDate);
        foreach ($rows as $r) q('UPDATE appointments SET appt_date=?, reminded=0, reschedule_count=reschedule_count+1 WHERE id=?', [$date, $r['id']]);
    } else {
        $items = array_map(fn($r) => ['svc' => $r['service'], 'concern' => null], $rows);
        $al = pick_chain($date, $time, (string)$rows[0]['branch'], $items, null, $ids, $maxDate, $online);
        foreach ($rows as $i => $r)
            q('UPDATE appointments SET appt_date=?, appt_time=?, vet=?, late_alerted=0, reminded=0, reschedule_count=reschedule_count+1 WHERE id=?', [$date, mtime($al[$i]['start']), $al[$i]['vet'] ?? $r['vet'], $r['id']]);
    }
    $new = appt_rows($ids); $what = appt_summary($new); $when = appt_when($new[0]); $oldWhen = appt_when($rows[0]); $branch = $new[0]['branch'];
    $actorId = $actor['id'] ?? null;
    $detail = "$what: $oldWhen to $when";
    if ($actorId) log_act((int)$actorId, 'Rescheduled an appointment', $detail);
    if ($by !== 'Owner') notify_owner((int)$new[0]['client_id'], 'resched', 'Appointment rescheduled', "$what moved from $oldWhen to $when.", 'appointments.php');
    else notify_owner((int)$new[0]['client_id'], 'resched', 'You rescheduled your appointment', "$what is now $when.", 'appointments.php');
    notify_role('staff', $branch, 'resched', 'Appointment rescheduled', "$what: $oldWhen to $when" . ($by === 'Owner' ? ' (by the pet owner)' : ''), 'appointments.php?date=' . $date, $actorId);
    foreach (array_unique(array_filter(array_column($new, 'vet'))) as $v) notify_vet($v, 'resched', 'Appointment rescheduled', "$what: now $when", 'appointments.php?date=' . $date, $actorId);
    return $new;
}

// ---------- queue registrations (check-ups; used by bookings, follow-ups and the "What happens next?" step) ----------
function queue_day_problem(string $d, bool $override): ?string {
    if ($d < date('Y-m-d')) return 'That date has already passed.';
    if (is_closed($d)) return 'The clinic is closed on that day.';
    if ($d === date('Y-m-d') && !queue_open_today() && !$override) return 'Check-ups and vaccinations for today closed at ' . hm12(QUEUE_LAST_ARRIVAL) . '.';
    return null;
}
// A queue registration is for a day (no time). Returns [id, date]. $service is Check-Up (follow-ups, referrals) unless another queue service is given. $moveOn: if the day is closed, use the next open day.
function register_queue(int $pid, string $date, string $branch, ?string $vet, ?string $reason, string $status, ?string $group, string $source, bool $moveOn = false, bool $override = false, string $service = 'Check-Up'): array {
    $d = $date;
    for ($i = 0; $i < 14 && ($prob = queue_day_problem($d, $override)); $i++) { if (!$moveOn) fail($prob . ' Please choose another day.', 'date'); $d = date('Y-m-d', strtotime("$d +1 day")); }
    if (queue_day_problem($d, $override)) fail('No open day was found for the ' . strtolower($service) . '.', 'date');
    if (q("SELECT 1 FROM appointments WHERE pet_id=? AND appt_date=? AND branch=? AND is_queue=1 AND service=? AND status<>'Cancelled' LIMIT 1", [$pid, $d, $branch, $service])->fetch()) fail('This pet is already registered for this service on ' . date('D, M j', strtotime($d)) . ' at the ' . $branch . ' branch.', 'pet_id');
    q("INSERT INTO appointments(pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,group_token,is_queue) VALUES(?,?,'00:00:00',?,?,?,?,?,?,?,?,1)",
      [$pid, $d, $service, $vet, $branch, $status, $reason, $source, bin2hex(random_bytes(12)), $group]);
    return [(int)db()->lastInsertId(), $d];
}

// ---------- automatic rules ----------
// Timed visits (surgery, confinement): late alert, auto-cancel, 2-hour reminder.
// Queue registrations (check-up, vaccination): a reminder on the day, and they expire at closing time if the owner never came
// (a missed vaccination day also tells the owner to register for another open day).
// Everyone: a daily reminder to vets about records still to complete, and the queue is nudged so nobody is left waiting while a vet and room are free.
// Runs at most once every 30 seconds (called whenever any signed-in page asks for its notifications).
function maintenance(): void {
    try {
        q("INSERT IGNORE INTO cms_content(k,v) VALUES('maint_ts','0')");
        $nowTs = time();
        $u = q("UPDATE cms_content SET v=? WHERE k='maint_ts' AND CAST(v AS UNSIGNED) < ?", [(string)$nowTs, $nowTs - 30]);
        if ($u->rowCount() < 1) return;
        $stamp = "TIMESTAMP(a.appt_date, a.appt_time)";
        // 1) late alert (timed visits only)
        $late = q("SELECT a.id FROM appointments a WHERE a.is_queue=0 AND a.status IN ('Pending','Confirmed') AND a.checked_in_at IS NULL AND a.late_alerted=0
                   AND $stamp <= NOW() - INTERVAL " . (int)LATE_ALERT_MINUTES . " MINUTE AND $stamp > NOW() - INTERVAL " . (int)LATE_CANCEL_MINUTES . " MINUTE")->fetchAll(PDO::FETCH_COLUMN);
        $seen = [];
        foreach ($late as $id) {
            q('UPDATE appointments SET late_alerted=1 WHERE id=?', [$id]);
            $ids = appt_group_ids((int)$id); $rows = appt_rows($ids); if (!$rows) continue;
            $key = $rows[0]['group_token'] ?: 'i' . $id; if (isset($seen[$key])) continue; $seen[$key] = 1;
            $r = $rows[0]; $what = appt_summary($rows);
            notify_owner((int)$r['client_id'], 'late', 'You are running late', "$what was due at " . hm12($r['time']) . ". We will hold your slot for " . (LATE_CANCEL_MINUTES - LATE_ALERT_MINUTES) . " more minutes, then it is released. Call us if you need more time.", 'appointments.php');
            notify_role('staff', $r['branch'], 'late', 'Patient is late', "$what was due at " . hm12($r['time']) . ' (' . $r['client'] . ').', 'appointments.php?date=' . $r['appt_date']);
            foreach (array_unique(array_filter(array_column($rows, 'vet'))) as $v) notify_vet($v, 'late', 'Patient is late', "$what was due at " . hm12($r['time']) . '.', 'appointments.php?date=' . $r['appt_date']);
        }
        // 2) auto-cancel timed visits (also anything from earlier days that never arrived)
        $gone = q("SELECT a.id FROM appointments a WHERE a.is_queue=0 AND a.status IN ('Pending','Confirmed') AND a.checked_in_at IS NULL AND $stamp <= NOW() - INTERVAL " . (int)LATE_CANCEL_MINUTES . " MINUTE")->fetchAll(PDO::FETCH_COLUMN);
        $done = [];
        foreach ($gone as $id) {
            if (isset($done[$id])) continue;
            $ids = appt_group_ids((int)$id); foreach ($ids as $i) $done[$i] = 1;
            $rows = appt_rows($ids); $pend = $rows && $rows[0]['status'] === 'Pending';
            appt_cancel($ids, 'System', $pend ? 'Not approved or attended before the appointment time' : 'Did not arrive within ' . LATE_CANCEL_MINUTES . ' minutes of the appointment time');
        }
        // 2b) queue registrations (check-up, vaccination) that never came expire at closing time
        $exp = q("SELECT a.id FROM appointments a WHERE a.is_queue=1 AND a.status IN ('Pending','Confirmed') AND a.checked_in_at IS NULL AND (a.appt_date < CURDATE() OR (a.appt_date = CURDATE() AND CURTIME() > ?))", [CLINIC_CLOSE . ':00'])->fetchAll(PDO::FETCH_COLUMN);
        foreach ($exp as $id) {
            if (isset($done[$id])) continue;
            $ids = appt_group_ids((int)$id); foreach ($ids as $i) $done[$i] = 1;
            appt_cancel($ids, 'System', 'Did not come on the day');
        }
        // 3) reminders: timed visits 2 hours before; queue days in the morning
        $rem = q("SELECT a.id FROM appointments a WHERE a.is_queue=0 AND a.status='Confirmed' AND a.checked_in_at IS NULL AND a.reminded=0 AND $stamp > NOW() AND $stamp <= NOW() + INTERVAL 120 MINUTE")->fetchAll(PDO::FETCH_COLUMN);
        $seenR = [];
        foreach ($rem as $id) {
            if (isset($seenR[$id])) continue;
            $ids = appt_group_ids((int)$id); foreach ($ids as $i) $seenR[$i] = 1;
            $rows = appt_rows($ids); if (!$rows) continue;
            foreach ($ids as $i) q('UPDATE appointments SET reminded=1 WHERE id=?', [$i]);
            $r = $rows[0];
            notify_owner((int)$r['client_id'], 'remind', 'Appointment reminder', appt_summary($rows) . ' at ' . hm12($r['time']) . ' (' . $r['branch'] . ' branch). Please show your QR code when you arrive.', 'appointments.php');
        }
        if (now_min() >= tmin(CLINIC_OPEN)) {
            $dq = q("SELECT a.id FROM appointments a WHERE a.is_queue=1 AND a.status='Confirmed' AND a.checked_in_at IS NULL AND a.reminded=0 AND a.appt_date=CURDATE()")->fetchAll(PDO::FETCH_COLUMN);
            $seenQ = [];
            foreach ($dq as $id) {
                if (isset($seenQ[$id])) continue;
                $ids = appt_group_ids((int)$id); foreach ($ids as $i) $seenQ[$i] = 1;
                $rows = appt_rows($ids); if (!$rows) continue;
                foreach ($ids as $i) q('UPDATE appointments SET reminded=1 WHERE id=?', [$i]);
                notify_owner((int)$rows[0]['client_id'], 'remind', 'Your visit is today', appt_summary($rows) . ': come any time before ' . hm12(QUEUE_LAST_ARRIVAL) . ' (' . $rows[0]['branch'] . ' branch). It is first come, first served, so please show your QR code when you arrive.', 'appointments.php');
            }
        }
        // 4) once a day: remind each vet about records from earlier days that are still to be completed
        $k = 'recrem_' . date('Y-m-d');
        if (q("INSERT IGNORE INTO cms_content(k,v) VALUES(?, '1')", [$k])->rowCount() > 0) {
            $pend = q("SELECT vet, COUNT(*) n FROM appointments WHERE status='Completed' AND record_done=0 AND done_at IS NOT NULL AND DATE(done_at) < CURDATE() AND vet IS NOT NULL GROUP BY vet")->fetchAll();
            foreach ($pend as $r) notify_vet((string)$r['vet'], 'info', 'Records to complete', 'You have ' . (int)$r['n'] . ' visit(s) from earlier days without a finished record.', 'index.php');
        }
        // 5) never leave a patient waiting while a vet and a room are free
        foreach (BRANCHES as $br) queue_advance($br);
    } catch (Throwable $e) { /* database not upgraded yet or a transient error: try again next time */ }
}

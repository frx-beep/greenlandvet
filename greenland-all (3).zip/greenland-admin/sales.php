<?php require 'layout.php'; top('Sales', 'l', 'Admin Console > Sales and money'); require 'sales_view.php'; bottom(); ?>

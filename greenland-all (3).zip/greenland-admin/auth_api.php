<?php
require 'authlib.php';
$in   = json_decode(file_get_contents('php://input'), true) ?? [];
$path = trim($_SERVER['PATH_INFO'] ?? '', '/');
$post = $_SERVER['REQUEST_METHOD'] === 'POST';
$label = LOGIN_BY === 'email' ? 'email address' : 'username';

if ($post && $path === 'login') {
    $ident = strtolower(trim($in['identity'] ?? '')); $pw = $in['password'] ?? '';
    if (NEEDS_BRANCH && !in_array($in['branch'] ?? '', BRANCHES)) fail('Please select your branch.', 'branch');
    if ($ident === '') fail("Please enter your $label.", 'identity');
    if ($pw === '') fail('Please enter your password.', 'password');
    $a = q('SELECT * FROM accounts WHERE role=? AND LOWER(' . (LOGIN_BY === 'email' ? 'email' : 'username') . ')=?', [APP_ROLE, $ident])->fetch();
    if (!$a) fail("No account found with that $label.", 'identity');
    if (NEEDS_BRANCH && $a['branch'] !== $in['branch']) fail('This account is not registered at the ' . $in['branch'] . ' branch.', 'branch');
    if (!password_verify($pw, $a['password'])) fail('Incorrect password. Please try again.', 'password');
    if ($a['status'] !== 'Active') fail('This account has been disabled. Please contact the clinic.', 'identity');
    session_regenerate_id(true);
    $_SESSION = ['pending' => (int)$a['id']];
    issue_code((int)$a['id']);
    send(['next' => 'verify.php']);
}
if (!$post && $path === 'verify_info') {
    if (empty($_SESSION['pending'])) fail('Your session expired. Please log in again.', null, 401);
    $v = q('SELECT TIMESTAMPDIFF(SECOND,NOW(),expires_at) s FROM verifications WHERE account_id=?', [$_SESSION['pending']])->fetch();
    send(['seconds_left' => max(0, (int)($v['s'] ?? 0))]);
}
if ($post && $path === 'verify') {
    $id = (int)($_SESSION['pending'] ?? 0);
    if (!$id) fail('Your session expired. Please log in again.');
    $v = q('SELECT *, expires_at > NOW() AS live FROM verifications WHERE account_id=?', [$id])->fetch();
    if (!$v || !$v['live']) fail('This code has expired. Please request a new one.');
    if ((int)$v['attempts'] >= 5) fail('Too many wrong attempts. Please request a new code.');
    if (!hash_equals($v['code_hash'], hash('sha256', trim($in['code'] ?? '') . $id))) {
        q('UPDATE verifications SET attempts=attempts+1 WHERE id=?', [$v['id']]);
        fail('Incorrect code. ' . (4 - (int)$v['attempts']) . ' attempt(s) left.');
    }
    q('DELETE FROM verifications WHERE account_id=?', [$id]);
    $a = q('SELECT * FROM accounts WHERE id=?', [$id])->fetch();
    if (APP_ROLE === 'client') finalize_registration($a);
    session_regenerate_id(true); $_SESSION = ['uid' => $id];
    q('UPDATE accounts SET last_login=NOW() WHERE id=?', [$id]); log_act($id, 'Logged in');
    send(['next' => $a['must_change'] ? 'change_password.php' : HOME]);
}
if ($post && $path === 'resend') {
    $id = (int)($_SESSION['pending'] ?? 0);
    if (!$id) fail('Your session expired. Please log in again.');
    issue_code($id);
    send(['seconds_left' => 600, 'dev_code' => DEV_SHOW_CODE ? ($_SESSION['dev_code'] ?? null) : null]);
}
if ($post && $path === 'register' && APP_ROLE === 'client') {   // pet owners can sign up online
    $name = trim($in['name'] ?? ''); $email = strtolower(trim($in['email'] ?? '')); $user = trim($in['username'] ?? ''); $pw = $in['password'] ?? '';
    if ($name === '') fail('Please enter your full name.', 'name');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Please enter a valid email address. We will email a code to it.', 'email');
    if (!preg_match('/^[A-Za-z0-9._-]{3,30}$/', $user)) fail('Username must be 3-30 characters: letters, numbers, dots, dashes or underscores.', 'username');
    if (strlen($pw) < 8) fail('Password must be at least 8 characters.', 'password');
    if ($pw !== ($in['confirm'] ?? '')) fail('The two passwords do not match.', 'confirm');
    $br = in_array($in['branch'] ?? '', BRANCHES) ? $in['branch'] : BRANCHES[0];
    q("DELETE FROM accounts WHERE role='client' AND email_verified=0 AND created_at < DATE_SUB(NOW(), INTERVAL 2 DAY)");   // clear abandoned sign-ups
    q("DELETE FROM accounts WHERE role='client' AND email_verified=0 AND (LOWER(email)=? OR LOWER(username)=?)", [$email, strtolower($user)]);   // retry after not finishing
    if (q('SELECT 1 FROM accounts WHERE LOWER(username)=?', [strtolower($user)])->fetch()) fail('That username is already taken.', 'username');
    if (q("SELECT 1 FROM accounts WHERE role='client' AND LOWER(email)=?", [$email])->fetch()) fail('An account with that email already exists. Please sign in, or use "Forgot password?".', 'email');
    q("INSERT INTO accounts(role,name,email,username,password,phone,address,branch,must_change,email_verified) VALUES('client',?,?,?,?,?,?,?,0,0)",
      [$name, $email, $user, password_hash($pw, PASSWORD_DEFAULT), nul($in['phone'] ?? null), nul($in['address'] ?? null), $br]);
    $id = (int)db()->lastInsertId();
    session_regenerate_id(true); $_SESSION = ['pending' => $id];
    issue_code($id);
    send(['next' => 'verify.php']);
}
if (!$post && $path === 'notifications') {   // the bell: this account's notifications (also runs the automatic late/cancel/reminder rules)
    $a = require_login(true); maintenance();
    try {
        $rows = q('SELECT id,type,title,body,link,read_at,created_at FROM notifications WHERE account_id=? ORDER BY id DESC LIMIT 25', [$a['id']])->fetchAll();
        $unread = (int)q('SELECT COUNT(*) FROM notifications WHERE account_id=? AND read_at IS NULL', [$a['id']])->fetchColumn();
    } catch (PDOException $e) { $rows = []; $unread = 0; }   // database not upgraded yet
    send(['rows' => $rows, 'unread' => $unread, 'max_id' => $rows ? (int)$rows[0]['id'] : 0]);
}
if ($post && $path === 'notifications/read') {
    $a = require_login(true);
    try {
        if (!empty($in['id'])) q('UPDATE notifications SET read_at=NOW() WHERE id=? AND account_id=? AND read_at IS NULL', [(int)$in['id'], $a['id']]);
        else q('UPDATE notifications SET read_at=NOW() WHERE account_id=? AND read_at IS NULL', [$a['id']]);
    } catch (PDOException $e) {}
    send(['ok' => 1]);
}
if ($post && $path === 'logout') { session_destroy(); send(['ok' => 1]); }
if (!$post && $path === 'me') { $a = require_login(true); send(['name' => $a['name'], 'role' => $a['role'], 'branch' => $a['branch'], 'email' => $a['email'], 'photo' => $a['photo'] ?? null]); }
if ($post && $path === 'change') {
    $a = require_login(true); $pw = $in['password'] ?? '';
    if (strlen($pw) < 8) fail('Password must be at least 8 characters.', 'password');
    if ($pw !== ($in['confirm'] ?? '')) fail('The two passwords do not match.', 'confirm');
    q('UPDATE accounts SET password=?, must_change=0 WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $a['id']]);
    log_act((int)$a['id'], 'Password changed'); send(['next' => HOME]);
}
if ($post && $path === 'forgot') {
    $em = strtolower(trim($in['identity'] ?? ($in['email'] ?? '')));
    if ($em === '') fail('Enter your username or email address.', 'identity');
    $a = q("SELECT * FROM accounts WHERE role=? AND (LOWER(email)=? OR LOWER(username)=?) AND status='Active'", [APP_ROLE, $em, $em])->fetch(); $link = null;
    if ($a) {
        $t = bin2hex(random_bytes(24));
        q('INSERT INTO password_resets(account_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))', [$a['id'], hash('sha256', $t)]);
        $link = SITE_URLS[APP_ROLE] . 'reset.php?token=' . $t;
        mail_to($a['email'], 'Reset your Greenland Veterinary Clinic password', "Hello {$a['name']},\n\nUse this link to set a new password (valid for 1 hour):\n$link\n\nIf you did not ask for this, ignore this email.");
    }
    send(['ok' => 1, 'link' => DEV_SHOW_CODE ? $link : null]);
}
if ($post && $path === 'reset') {
    $pw = $in['password'] ?? '';
    $r = q('SELECT * FROM password_resets WHERE token_hash=? AND expires_at > NOW()', [hash('sha256', $in['token'] ?? '')])->fetch();
    if (!$r) fail('This reset link is invalid or has expired.');
    if (strlen($pw) < 8) fail('Password must be at least 8 characters.', 'password');
    if ($pw !== ($in['confirm'] ?? '')) fail('The two passwords do not match.', 'confirm');
    q('UPDATE accounts SET password=?, must_change=0 WHERE id=? AND role=?', [password_hash($pw, PASSWORD_DEFAULT), $r['account_id'], APP_ROLE]);
    q('DELETE FROM password_resets WHERE account_id=?', [$r['account_id']]);
    log_act((int)$r['account_id'], 'Password reset'); send(['ok' => 1]);
}
if ($post && $path === 'setup' && APP_ROLE === 'admin') {   // creates the very first admin, only while none exists
    if (q("SELECT 1 FROM accounts WHERE role='admin'")->fetch()) fail('An admin account already exists.');
    $n = trim($in['name'] ?? ''); $e = strtolower(trim($in['email'] ?? '')); $u = trim($in['username'] ?? ''); $p = $in['password'] ?? '';
    if (!$n || !filter_var($e, FILTER_VALIDATE_EMAIL) || !$u || strlen($p) < 8) fail('Fill in every field. Password needs 8+ characters.');
    q("INSERT INTO accounts(role,name,email,username,password) VALUES('admin',?,?,?,?)", [$n, $e, $u, password_hash($p, PASSWORD_DEFAULT)]);
    send(['ok' => 1]);
}
send(['error' => 'Not found'], 404);

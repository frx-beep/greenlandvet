<?php require 'layout.php'; top('Account Details', 'a', 'Accounts'); ?>
<a class="btn plain" href="accounts.php" style="margin-bottom:1rem">&larr; Back to Accounts</a>
<div class="row3" style="grid-template-columns:1.4fr 1fr">
  <div class="card"><h2>Account Information</h2><dl id="info"></dl></div>
  <div><div class="card"><h2>Account Actions</h2><div class="btns"><a class="btn" id="edit">Edit Profile</a><a class="btn ghost" id="reset">Reset Password</a><a class="btn danger" id="dis">Disable Account</a></div>
    <p class="muted">Resetting a password lets the user sign in with a new one. Disabling blocks sign-in but keeps all records.</p></div>
  <div class="card"><h2>Recent Activity</h2><table><thead><tr><th>Activity</th><th>Date</th></tr></thead><tbody id="act"></tbody></table></div></div>
</div>
<script>
const id = param('id');
api('/api/accounts/' + id).then(a => {
  $('#crumb').textContent = 'Accounts > ' + a.name;
  $('#info').innerHTML = [['Name', a.name], ['Role', roleName(a.role) + (a.role === 'client' ? ' (Pet Owner)' : '')], ['Email / Username', a.email + ' / ' + a.username],
    ['Branch', a.branch], ['Contact Number', a.phone], ...(a.role === 'client' ? [['Address', a.address]] : []), ['Date Created', fmtDate(a.created_at.slice(0, 10))], ['Last Login', a.last_login ? new Date(a.last_login.replace(' ', 'T')).toLocaleString('en', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : 'Never'],
    ['Status', a.status + (a.disabled_reason ? ' (' + a.disabled_reason + ')' : '')]].map(([k, v]) => `<dt>${k}</dt><dd>${E(v || '-')}</dd>`).join('');
  $('#edit').href = 'account_edit.php?id=' + id; $('#reset').href = 'account_reset.php?id=' + id; $('#dis').href = 'account_disable.php?id=' + id;
  if (a.status !== 'Active') { $('#dis').textContent = 'Enable Account'; $('#dis').className = 'btn ghost'; }
  $('#act').innerHTML = a.activity.length ? a.activity.map(x => `<tr><td>${E(x.action)}${x.detail ? '<br><small class="muted">' + E(x.detail) + '</small>' : ''}</td><td>${fmtDate(x.created_at.slice(0, 10))}</td></tr>`).join('') : '<tr><td colspan="2" class="empty">No activity yet.</td></tr>';
}).catch(x => $('#info').innerHTML = `<p class="err">${E(x.message)}</p>`);
</script>
<?php bottom(); ?>

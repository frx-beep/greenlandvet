<?php
ob_start();   // hold back stray output (a BOM in config.php, PHP warnings) so JSON replies and sessions keep working
require_once __DIR__ . '/config.php';
date_default_timezone_set('Asia/Manila');
session_name('gv_' . APP_ROLE);          // separate cookie per app, so all four can be open in one browser
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
        $pdo->exec("SET time_zone='+08:00'");
    }
    return $pdo;
}
function q(string $sql, array $a = []) { $s = db()->prepare($sql); $s->execute($a); return $s; }
function nul($v) { $v = is_string($v) ? trim($v) : $v; return $v === '' ? null : $v; }
function send($d, int $c = 200) {
    $stray = trim(strip_tags((string)ob_get_contents()));
    while (ob_get_level()) ob_end_clean();
    if ($stray !== '' && DEV_SHOW_CODE && is_array($d)) $d['_debug'] = substr($stray, 0, 500);   // testing aid only
    header('Content-Type: application/json'); http_response_code($c); echo json_encode($d); exit;
}
function fail(string $m, ?string $field = null, int $c = 400) { send(['error' => $m, 'field' => $field], $c); }
function log_act(int $id, string $act, ?string $detail = null): void {
    try { q('INSERT INTO activity_log(account_id,action,detail) VALUES(?,?,?)', [$id, $act, $detail === null ? null : substr($detail, 0, 250)]); }
    catch (PDOException $e) { q('INSERT INTO activity_log(account_id,action) VALUES(?,?)', [$id, $act]); }   // database not upgraded yet
}
function photo_value($ph): ?string {   // '' removes the photo; otherwise it must be a small JPEG data URL (the browser shrinks it)
    $ph = (string)$ph; if ($ph === '') return null;
    if (strpos($ph, 'data:image/jpeg;base64,') !== 0 || strlen($ph) > 400000 || base64_decode(substr($ph, 23), true) === false) fail('That photo could not be used. Please choose a smaller image.', 'photo');
    return $ph;
}
function mail_to(string $to, string $subject, string $body): bool {
    return @mail($to, $subject, $body, 'From: Greenland Veterinary Clinic <' . MAIL_FROM . '>');
}
function mask_email(string $e): string {
    [$u, $d] = array_pad(explode('@', $e, 2), 2, '');
    return substr($u, 0, APP_ROLE === 'client' ? 1 : 2) . '****@' . $d;
}
function vets(): array { return q("SELECT name FROM accounts WHERE role='vet' AND status='Active' ORDER BY name")->fetchAll(PDO::FETCH_COLUMN); }
function vet_info(): array { return q("SELECT name, branch FROM accounts WHERE role='vet' AND status='Active' ORDER BY name")->fetchAll(); }

function current_account(): ?array {
    static $a = false;
    if ($a === false) {
        $a = null;
        if (!empty($_SESSION['uid'])) {
            // Update 17: idle sign-out. A page load or a request from an active user refreshes the clock; background polling from an idle tab (X-Idle of 60 s or more) does not.
            $lim = (defined('IDLE_LOGOUT_MINUTES') ? (int)IDLE_LOGOUT_MINUTES : 0) * 60; $now = time();
            if ($lim > 0 && $now - (int)($_SESSION['last_act'] ?? $now) > $lim) { $_SESSION = []; $GLOBALS['idle_out'] = true; }
            else {
                if ($lim > 0 && (int)($_SERVER['HTTP_X_IDLE'] ?? 0) < 60) $_SESSION['last_act'] = $now;
                $a = q('SELECT * FROM accounts WHERE id=? AND role=?', [$_SESSION['uid'], APP_ROLE])->fetch() ?: null;
            }
        }
    }
    return $a;
}
function require_login(bool $json = false): array {
    $a = current_account();
    if (!$a || $a['status'] !== 'Active') { if ($json) send(['error' => 'Please log in', 'idle' => !empty($GLOBALS['idle_out'])], 401); header('Location: login.php' . (!empty($GLOBALS['idle_out']) ? '?idle=1' : '')); exit; }
    if ($a['must_change'] && !$json && basename($_SERVER['SCRIPT_NAME']) !== 'change_password.php') { header('Location: change_password.php'); exit; }
    return $a;
}
function issue_code(int $id): void {
    $code = sprintf('%06d', random_int(0, 999999));
    q('DELETE FROM verifications WHERE account_id=?', [$id]);
    q('INSERT INTO verifications(account_id,code_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL 10 MINUTE))', [$id, hash('sha256', $code . $id)]);
    $a = q('SELECT email,name FROM accounts WHERE id=?', [$id])->fetch();
    mail_to($a['email'], 'Your Greenland Veterinary Clinic verification code',
        "Hello {$a['name']},\n\nYour verification code is $code. It expires in 10 minutes.\n\nIf you did not try to sign in, you can ignore this email.");
    log_act($id, 'Verification code sent');
    if (DEV_SHOW_CODE) $_SESSION['dev_code'] = $code;
}

// ---------- Update 15: look-and-feel switches (set in config.php; all optional) ----------
function ui_on(): bool { return defined('UI_UPGRADE') && UI_UPGRADE && is_file(__DIR__ . '/ui14.css'); }
function ui_dark(): bool { return ui_on() && defined('UI_DARK_MODE') && UI_DARK_MODE && is_file(__DIR__ . '/ui14-dark.css'); }
function ui_ns(): bool { return ui_on() && APP_ROLE === 'staff' && defined('UI_NOW_SERVING') && UI_NOW_SERVING; }
function ui_head(): void {
    if (!ui_on()) return;
    if (ui_dark()) { ?><script>try{if(localStorage.getItem('gv_theme')==='dark')document.documentElement.dataset.theme='dark'}catch(e){}</script>
<?php } ?><link rel="stylesheet" href="ui14.css?v=<?= filemtime(__DIR__ . '/ui14.css') ?>">
<?php if (ui_dark()) { ?><link rel="stylesheet" href="ui14-dark.css?v=<?= filemtime(__DIR__ . '/ui14-dark.css') ?>">
<?php } ?><script>window.UI14_CFG = { dark: <?= ui_dark() ? 'true' : 'false' ?>, ns: <?= ui_ns() ? 'true' : 'false' ?> };</script><script src="ui14.js?v=<?= filemtime(__DIR__ . '/ui14.js') ?>"></script>
<?php }
// a friendly dog and cat for the login page (our own simple drawing)
const LOGIN_ART = '<div class="loginart" aria-hidden="true"><svg viewBox="0 0 320 170" xmlns="http://www.w3.org/2000/svg"><g fill="#e6f4f1"><ellipse cx="50" cy="92" rx="17" ry="36" transform="rotate(14 50 92)"/><ellipse cx="150" cy="92" rx="17" ry="36" transform="rotate(-14 150 92)"/><ellipse cx="100" cy="98" rx="47" ry="50"/><path d="M172 78 182 28l28 28zM268 78 258 28l-28 28z"/><ellipse cx="220" cy="102" rx="52" ry="47"/></g><g fill="#c7e6e0"><ellipse cx="100" cy="120" rx="24" ry="17"/><ellipse cx="220" cy="118" rx="22" ry="14"/></g><g fill="#0a4a45"><circle cx="84" cy="88" r="5"/><circle cx="116" cy="88" r="5"/><ellipse cx="100" cy="111" rx="9" ry="6.500"/><circle cx="203" cy="98" r="5"/><circle cx="237" cy="98" r="5"/><path d="M213 112h14l-7 8z"/></g><g stroke="#0a4a45" stroke-width="2.500" stroke-linecap="round" fill="none"><path d="M100 117v9M92 130q8 6 16 0"/><path d="M196 114l-30-6M196 120l-30 4M244 114l30-6M244 120l30 4M220 120q-6 8-12 4M220 120q6 8 12 4"/></g></svg></div>';

function auth_open(string $title): void {
    $split = AUTH_LAYOUT === 'split'; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> - Greenland Veterinary Clinic</title>
<link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>"><script src="app.js?v=<?= filemtime(__DIR__ . '/app.js') ?>"></script><?php ui_head(); ?></head>
<body class="<?= $split ? 'auth' : 'authc' ?>">
<?php if (APP_ROLE === 'client'): ?><a class="backbtn" href="index.php"><span aria-hidden="true">&larr;</span> Back to website</a><?php endif; ?>
<?php if ($split): ?><section class="brandpanel"><div class="logobox"><img src="logo.png" alt="Greenland Veterinary Clinic"></div><h2><?= BRAND_H2 ?></h2><p><?= BRAND_P ?></p><?php if (defined('BRAND_LIST')) echo BRAND_LIST; ?><?php if (ui_on()) echo LOGIN_ART; ?></section><?php endif; ?>
<section class="authwrap"><div class="authcard"><?php if (!$split): ?><img class="clogo" src="logo.png" alt="Greenland Veterinary Clinic"><?php endif;
}
function auth_close(): void { ?></div></section></body></html><?php }


// ---------- notifications (every role has a bell) ----------
function notify(?int $accountId, string $type, string $title, ?string $body = null, ?string $link = null): void {
    if (!$accountId) return;
    try { q('INSERT INTO notifications(account_id,type,title,body,link) VALUES(?,?,?,?,?)', [$accountId, $type, substr($title, 0, 150), $body === null ? null : substr($body, 0, 255), $link]); }
    catch (PDOException $e) { /* database not upgraded yet */ }
}
function owner_ids(int $clientId): array { return array_map('intval', q("SELECT id FROM accounts WHERE client_id=? AND role='client' AND status='Active'", [$clientId])->fetchAll(PDO::FETCH_COLUMN)); }
function notify_owner(int $clientId, string $type, string $title, ?string $body = null, ?string $link = null): void {
    foreach (owner_ids($clientId) as $id) notify($id, $type, $title, $body, $link);
    if (isset(MESSAGE_TYPES[$type])) owner_message($clientId, $type, $title, $body);   // reminders, late and lapsed schedules also go out by email / SMS
}

// ---------- Update 14: messages to owners (email now, SMS when a service is connected) ----------
// Only these notification types are also sent outside the app. The wording follows the clinic's own template.
const MESSAGE_TYPES = ['remind' => 'reminder', 'late' => 'late schedule', 'cancel' => 'lapsed schedule'];
function owner_contacts(int $clientId): array {
    $emails = []; $phones = [];
    try {
        $c = q('SELECT name, email, phone FROM clients WHERE id=?', [$clientId])->fetch(); if (!$c) return ['name' => '', 'emails' => [], 'phones' => []];
        if (!empty($c['email'])) $emails[] = strtolower(trim($c['email'])); if (!empty($c['phone'])) $phones[] = $c['phone'];
        foreach (q("SELECT email, phone FROM accounts WHERE client_id=? AND role='client' AND status='Active'", [$clientId])->fetchAll() as $a) { if (!empty($a['email'])) $emails[] = strtolower(trim($a['email'])); if (!empty($a['phone'])) $phones[] = $a['phone']; }
    } catch (PDOException $e) { return ['name' => '', 'emails' => [], 'phones' => []]; }
    $phones = array_values(array_unique(array_filter(array_map(fn($p) => preg_replace('/[^0-9+]/', '', (string)$p), $phones), fn($p) => strlen($p) >= 10)));
    return ['name' => (string)$c['name'], 'emails' => array_values(array_unique(array_filter($emails, fn($e) => filter_var($e, FILTER_VALIDATE_EMAIL)))), 'phones' => $phones];
}
function owner_message_text(string $name, string $type, string $body): string {
    $first = trim(explode(' ', trim($name))[0] ?? '');
    $lead = ['remind' => 'this is to inform you that your pet is scheduled: ', 'late' => 'this is to inform you that your pet\'s schedule has not started yet: ', 'cancel' => 'this is to inform you that your pet\'s schedule was cancelled or has lapsed: '][$type] ?? 'this is to inform you: ';
    $open = defined('CLINIC_OPEN') ? date('g:i A', strtotime(CLINIC_OPEN)) . ' to ' . date('g:i A', strtotime(CLINIC_CLOSE)) : '';
    return 'Hi' . ($first !== '' ? ' ' . $first : '') . ', ' . $lead . trim((string)$body) . "\n"
        . ($open !== '' ? 'We are open from ' . $open . ', Monday to Saturday.' . "\n" : '')
        . 'From Greenland Veterinary Care Center. This is an automated message. Do not reply. If you have concerns, message us at ' . (defined('CLINIC_MESSAGE_CONTACT') ? CLINIC_MESSAGE_CONTACT : 'the clinic') . '.';
}
// Sends one SMS through the chosen service. Returns [ok, error]. Nothing is sent until SMS_ENABLED is true and a provider is set in config.php.
function sms_send(string $to, string $text): array {
    if (!defined('SMS_ENABLED') || !SMS_ENABLED || SMS_PROVIDER === '') return [false, 'SMS service not connected yet'];
    if (SMS_PROVIDER === 'semaphore') {   // Semaphore (Philippines). Untested here: check with a test number first.
        $ctx = stream_context_create(['http' => ['method' => 'POST', 'timeout' => 8, 'ignore_errors' => true, 'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query(['apikey' => SMS_API_KEY, 'number' => $to, 'message' => $text, 'sendername' => SMS_SENDER])]]);
        $res = @file_get_contents('https://api.semaphore.co/api/v4/messages', false, $ctx);
        if ($res === false) return [false, 'Could not reach the SMS service'];
        $j = json_decode($res, true); return (is_array($j) && isset($j[0]['message_id'])) ? [true, ''] : [false, mb_substr((string)$res, 0, 200)];
    }
    return [false, 'Unknown SMS provider: ' . SMS_PROVIDER];
}
function owner_message(int $clientId, string $type, string $title, ?string $body): void {
    try {
        $c = owner_contacts($clientId); $text = owner_message_text($c['name'], $type, (string)$body); $ch = defined('OWNER_MESSAGE_CHANNELS') ? OWNER_MESSAGE_CHANNELS : ['email'];
        $log = fn($channel, $to, $status, $err) => q('INSERT INTO message_outbox(client_id,channel,to_addr,kind,body,status,error,sent_at) VALUES(?,?,?,?,?,?,?,' . ($status === 'Sent' ? 'NOW()' : 'NULL') . ')', [$clientId, $channel, $to, $type, $text, $status, $err !== '' ? substr($err, 0, 250) : null]);
        if (in_array('email', $ch, true)) foreach ($c['emails'] as $e) { $ok = mail_to($e, 'Greenland Veterinary Care Center: ' . $title, $text); $log('email', $e, $ok ? 'Sent' : 'Failed', $ok ? '' : 'The mail server is not set up on this computer'); }
        if (in_array('sms', $ch, true)) foreach ($c['phones'] as $ph) { [$ok, $err] = sms_send($ph, $text); $log('sms', $ph, $ok ? 'Sent' : 'Queued', $ok ? '' : $err); }
    } catch (Throwable $e) { /* a message problem must never stop the clinic's work (database not upgraded yet, no mail server...) */ }
}
// everyone with a role (optionally only at one branch), except the person who did the action
function notify_role(string $role, ?string $branch, string $type, string $title, ?string $body = null, ?string $link = null, ?int $exceptId = null): void {
    $rows = $branch !== null && $role !== 'admin'
        ? q("SELECT id FROM accounts WHERE role=? AND status='Active' AND (branch=? OR branch IS NULL)", [$role, $branch])->fetchAll(PDO::FETCH_COLUMN)
        : q("SELECT id FROM accounts WHERE role=? AND status='Active'", [$role])->fetchAll(PDO::FETCH_COLUMN);
    foreach ($rows as $id) if ((int)$id !== (int)$exceptId) notify((int)$id, $type, $title, $body, $link);
}
function notify_vet(?string $vetName, string $type, string $title, ?string $body = null, ?string $link = null, ?int $exceptId = null): void {
    if (!$vetName) return;
    foreach (q("SELECT id FROM accounts WHERE role='vet' AND name=? AND status='Active'", [$vetName])->fetchAll(PDO::FETCH_COLUMN) as $id) if ((int)$id !== (int)$exceptId) notify((int)$id, $type, $title, $body, $link);
}

// ---------- page content managed by the admin (homepage banners, promos) ----------
function cms(): array {
    static $c = null;
    if ($c === null) { try { $c = array_column(q('SELECT k, v FROM cms_content')->fetchAll(), 'v', 'k'); } catch (PDOException $e) { $c = []; } }
    return $c;
}
function cms_items(bool $onlyActive = true): array {
    try { return q('SELECT * FROM cms_items' . ($onlyActive ? ' WHERE active=1' : '') . ' ORDER BY sort_order, id')->fetchAll(); } catch (PDOException $e) { return []; }
}

require_once __DIR__ . '/schedule.php';
require_once __DIR__ . '/billlib.php';

// After the emailed code proves the email of a new online sign-up: link to the clinic's existing client record
// (same email, no account yet) or create a new client record from what the owner typed.
function finalize_registration(array $a): void {
    if ($a['role'] !== 'client' || $a['email_verified']) return;
    $cid = (int)$a['client_id']; $note = 'Linked to an existing client record';
    if (!$cid) {
        $c = q('SELECT c.id FROM clients c WHERE LOWER(c.email)=? AND NOT EXISTS (SELECT 1 FROM accounts x WHERE x.client_id=c.id) LIMIT 1', [strtolower($a['email'])])->fetch();
        if ($c) $cid = (int)$c['id'];
        else {
            q('INSERT INTO clients(name,address,email,phone,branch) VALUES(?,?,?,?,?)', [$a['name'], $a['address'], $a['email'], $a['phone'], $a['branch']]);
            $cid = (int)db()->lastInsertId(); $note = 'New client record created';
        }
    }
    q('UPDATE accounts SET client_id=?, email_verified=1 WHERE id=?', [$cid, $a['id']]);
    log_act((int)$a['id'], 'Registered online', $note);
    notify_role('admin', null, 'account', 'New pet owner registered', $a['name'] . ' (' . $a['username'] . ') signed up online.', 'accounts.php');
    notify_role('staff', $a['branch'] ?: null, 'account', 'New pet owner registered', $a['name'] . ' signed up online.' . ($note === 'New client record created' ? ' A new client record was created.' : ' Linked to an existing client record.'), 'clients.php');
    notify($a['id'], 'info', 'Welcome to Greenland Veterinary Clinic', 'Your account is ready. Add your pets and request an appointment any time.', 'pets.php');
}

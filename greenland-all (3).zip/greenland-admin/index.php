<?php require 'layout.php'; top('Dashboard', 'd', 'Admin Console > Overview'); ?>
<div class="statgrid">
  <div class="card"><h2>Total Accounts</h2><div class="big" id="s0">-</div></div><div class="card"><h2>Clients</h2><div class="big" id="s1">-</div></div>
  <div class="card"><h2>Staff</h2><div class="big" id="s2">-</div></div><div class="card"><h2>Veterinarians</h2><div class="big" id="s3">-</div></div>
  <div class="card"><h2>Disabled</h2><div class="big" id="s4">-</div></div>
</div>
<div class="statgrid" style="margin-top:1rem">
  <div class="card"><h2>Unpaid balances</h2><div class="big" id="s5">-</div><small class="muted">Both branches</small></div>
  <div class="card"><h2>Records not yet written</h2><div class="big" id="s7">-</div><small class="muted">Finished check-ups waiting for the vet's findings</small></div>
</div>
<div class="row3" style="grid-template-columns:2.2fr 1fr">
  <div class="card"><div class="hd"><h2>Recent Activity</h2><a class="btn plain sm" href="activity.php">Audit log</a></div>
    <table><thead><tr><th>Account</th><th>Role</th><th>Activity</th><th>Date</th></tr></thead><tbody id="act"></tbody></table></div>
  <div class="card"><h2>Quick Actions</h2><div class="btns"><a class="btn ghost" href="accounts.php">View All Accounts</a><a class="btn ghost" href="reports.php">Reports &amp; Analytics</a><a class="btn ghost" href="cms.php">Page Management</a><a class="btn" href="account_new.php">+ Create Account</a></div>
    <p class="muted">Reset passwords or disable accounts from each account's page.</p></div>
</div>
<script>
api('/api/stats').then(r => {
  ['total', 'client', 'staff', 'vet', 'disabled'].forEach((k, i) => $('#s' + i).textContent = r[k]);
  $('#s5').textContent = peso(r.owed); $('#s7').textContent = r.pending_records;
  $('#act').innerHTML = r.activity.length ? r.activity.map(a => `<tr><td>${E(a.name)}</td><td>${roleName(a.role)}</td><td>${E(a.action)}${a.detail ? ' <small class="muted">' + E(a.detail) + '</small>' : ''}</td><td>${fmtDate(a.created_at.slice(0, 10))}</td></tr>`).join('') : '<tr><td colspan="4" class="empty">No activity yet.</td></tr>';
});
</script>
<?php bottom(); ?>

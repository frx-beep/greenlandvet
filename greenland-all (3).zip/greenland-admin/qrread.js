// qrread.js: reads a QR code out of a picture (an uploaded or saved screenshot), fully offline. Versions 1-10, every error-correction level.
// QRRead.decode({data, width, height})  ->  the text, or null.   (data = RGBA pixels, like canvas getImageData)
const QRRead = (() => {
  // ---- Galois field 256 ----
  const EXP = new Uint8Array(512), LOG = new Uint8Array(256);
  for (let i = 0, x = 1; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11D; }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  const gmul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0), gdiv = (a, b) => (a ? EXP[(LOG[a] + 255 - LOG[b]) % 255] : 0);

  // ---- tables (version 1-10): [ec codewords per block, [[blocks, data codewords per block], ...]] ----
  const BLOCKS = {
    L: [null, [7, [[1, 19]]], [10, [[1, 34]]], [15, [[1, 55]]], [20, [[1, 80]]], [26, [[1, 108]]], [18, [[2, 68]]], [20, [[2, 78]]], [24, [[2, 97]]], [30, [[2, 116]]], [18, [[2, 68], [2, 69]]]],
    M: [null, [10, [[1, 16]]], [16, [[1, 28]]], [26, [[1, 44]]], [18, [[2, 32]]], [24, [[2, 43]]], [16, [[4, 27]]], [18, [[4, 31]]], [22, [[2, 38], [2, 39]]], [22, [[3, 36], [2, 37]]], [26, [[4, 43], [1, 44]]]],
    Q: [null, [13, [[1, 13]]], [22, [[1, 22]]], [18, [[2, 17]]], [26, [[2, 24]]], [18, [[2, 15], [2, 16]]], [24, [[4, 19]]], [18, [[2, 14], [4, 15]]], [22, [[4, 18], [2, 19]]], [20, [[4, 16], [4, 17]]], [24, [[6, 19], [2, 20]]]],
    H: [null, [17, [[1, 9]]], [28, [[1, 16]]], [22, [[2, 13]]], [16, [[4, 9]]], [22, [[2, 11], [2, 12]]], [28, [[4, 15]]], [26, [[4, 13], [1, 14]]], [26, [[4, 14], [2, 15]]], [24, [[4, 12], [4, 13]]], [28, [[6, 15], [2, 16]]]]
  };
  const ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];
  const LEVEL = { 1: 'L', 0: 'M', 3: 'Q', 2: 'H' };

  // ---- format information (15 bits, BCH protected) ----
  const FORMATS = [];
  for (let d = 0; d < 32; d++) { let v = d << 10; for (let i = 14; i >= 10; i--) if ((v >> i) & 1) v ^= 0x537 << (i - 10); FORMATS.push([((d << 10) | v) ^ 0x5412, d]); }
  const pop = x => { let n = 0; while (x) { n += x & 1; x >>= 1; } return n; };
  function readFormat(bits) {
    let best = null, bd = 99;
    for (const [w, d] of FORMATS) { const k = pop(w ^ bits); if (k < bd) { bd = k; best = d; } }
    return bd <= 3 ? { level: LEVEL[best >> 3], mask: best & 7 } : null;
  }

  // ---- Reed-Solomon: fix up to ec/2 wrong codewords in a block ----
  function rsFix(cw, ec) {
    const n = cw.length, S = new Array(ec).fill(0); let bad = false;
    for (let j = 0; j < ec; j++) { let s = 0; for (let k = 0; k < n; k++) s = gmul(s, EXP[j]) ^ cw[k]; S[j] = s; if (s) bad = true; }
    if (!bad) return true;
    let C = [1], B = [1], L = 0, m = 1, b = 1;
    for (let i = 0; i < ec; i++) {
      let d = S[i]; for (let k = 1; k <= L; k++) if (C[k]) d ^= gmul(C[k], S[i - k]);
      if (!d) { m++; continue; }
      const T = C.slice(), f = gdiv(d, b); while (C.length < B.length + m) C.push(0);
      for (let k = 0; k < B.length; k++) C[k + m] ^= gmul(f, B[k]);
      if (2 * L <= i) { L = i + 1 - L; B = T; b = d; m = 1; } else m++;
    }
    while (C.length && C[C.length - 1] === 0) C.pop();
    if (L > ec / 2 || C.length - 1 !== L) return false;
    const omega = new Array(ec).fill(0);
    for (let i = 0; i < ec; i++) for (let k = 0; k <= i && k < C.length; k++) omega[i] ^= gmul(C[k], S[i - k]);
    const fixes = [];
    for (let p = 0; p < n; p++) {
      const xi = EXP[(255 - p) % 255]; let v = 0, pw = 1;   // Lambda(alpha^-p)
      for (let k = 0; k < C.length; k++) { v ^= gmul(C[k], pw); pw = gmul(pw, xi); }
      if (v) continue;
      let num = 0; pw = 1; for (let k = 0; k < omega.length; k++) { num ^= gmul(omega[k], pw); pw = gmul(pw, xi); }
      let den = 0; pw = 1; for (let k = 1; k < C.length; k += 2) { den ^= gmul(C[k], pw); pw = gmul(pw, gmul(xi, xi)); }
      if (!den) return false;
      fixes.push([n - 1 - p, gmul(EXP[p % 255], gdiv(num, den))]);
    }
    if (fixes.length !== L) return false;
    for (const [i, e] of fixes) cw[i] ^= e;
    return true;
  }

  // ---- which modules are fixed patterns (not data) ----
  function functionMask(ver) {
    const n = ver * 4 + 17, f = Array.from({ length: n }, () => new Uint8Array(n));
    const box = (r0, c0, r1, c1) => { for (let r = Math.max(0, r0); r <= Math.min(n - 1, r1); r++) for (let c = Math.max(0, c0); c <= Math.min(n - 1, c1); c++) f[r][c] = 1; };
    box(0, 0, 8, 8); box(0, n - 8, 8, n - 1); box(n - 8, 0, n - 1, 8);
    for (let i = 0; i < n; i++) { f[6][i] = 1; f[i][6] = 1; }
    const a = ALIGN[ver];
    for (let i = 0; i < a.length; i++) for (let j = 0; j < a.length; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === a.length - 1) || (i === a.length - 1 && j === 0)) continue;
      box(a[i] - 2, a[j] - 2, a[i] + 2, a[j] + 2);
    }
    if (ver >= 7) { box(0, n - 11, 5, n - 9); box(n - 11, 0, n - 9, 5); }
    return f;
  }
  const MASKS = [(i, j) => (i + j) % 2 === 0, (i, j) => i % 2 === 0, (i, j) => j % 3 === 0, (i, j) => (i + j) % 3 === 0, (i, j) => (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0,
    (i, j) => ((i * j) % 2) + ((i * j) % 3) === 0, (i, j) => (((i * j) % 2) + ((i * j) % 3)) % 2 === 0, (i, j) => (((i + j) % 2) + ((i * j) % 3)) % 2 === 0];

  // ---- turn a grid of modules (true = dark) into text ----
  function decodeGrid(g, n) {
    const ver = (n - 17) / 4;
    if (!Number.isInteger(ver) || ver < 1 || ver > 10) return null;
    const bit = (x, y) => (g[y][x] ? 1 : 0);
    let b1 = 0; for (let i = 0; i < 6; i++) b1 = (b1 << 1) | bit(i, 8);
    b1 = (b1 << 1) | bit(7, 8); b1 = (b1 << 1) | bit(8, 8); b1 = (b1 << 1) | bit(8, 7); for (let j = 5; j >= 0; j--) b1 = (b1 << 1) | bit(8, j);
    let b2 = 0; for (let j = n - 1; j >= n - 7; j--) b2 = (b2 << 1) | bit(8, j); for (let i = n - 8; i < n; i++) b2 = (b2 << 1) | bit(i, 8);
    const fmt = readFormat(b1) || readFormat(b2); if (!fmt) return null;
    const fm = functionMask(ver), mask = MASKS[fmt.mask], bytes = []; let cur = 0, nb = 0, up = true;
    for (let j = n - 1; j > 0; j -= 2) {
      if (j === 6) j--;
      for (let k = 0; k < n; k++) {
        const i = up ? n - 1 - k : k;
        for (let c = 0; c < 2; c++) {
          const x = j - c; if (fm[i][x]) continue;
          cur = (cur << 1) | (bit(x, i) ^ (mask(i, x) ? 1 : 0)); if (++nb === 8) { bytes.push(cur); cur = 0; nb = 0; }
        }
      }
      up = !up;
    }
    const [ec, groups] = BLOCKS[fmt.level][ver], blocks = [];
    for (const [cnt, dl] of groups) for (let k = 0; k < cnt; k++) blocks.push({ dl, cw: [] });
    const maxD = Math.max(...blocks.map(b => b.dl)); let p = 0;
    for (let i = 0; i < maxD; i++) for (const b of blocks) if (i < b.dl) b.cw.push(bytes[p++]);
    for (let i = 0; i < ec; i++) for (const b of blocks) b.cw.push(bytes[p++]);
    const data = [];
    for (const b of blocks) { if (b.cw.some(v => v === undefined) || !rsFix(b.cw, ec)) return null; data.push(...b.cw.slice(0, b.dl)); }
    return parse(data, ver);
  }
  function parse(data, ver) {
    const bits = []; for (const v of data) for (let i = 7; i >= 0; i--) bits.push((v >> i) & 1);
    let p = 0; const take = k => { let v = 0; for (let i = 0; i < k; i++) v = (v << 1) | (bits[p++] || 0); return v; };
    const ALN = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:'; let out = '';
    while (p + 4 <= bits.length) {
      const mode = take(4); if (mode === 0) break;
      if (mode === 4) { const n = take(ver < 10 ? 8 : 16), arr = []; for (let i = 0; i < n; i++) arr.push(take(8)); out += new TextDecoder().decode(new Uint8Array(arr)); }
      else if (mode === 2) { let n = take(ver < 10 ? 9 : 11); while (n >= 2) { const v = take(11); out += ALN[Math.floor(v / 45)] + ALN[v % 45]; n -= 2; } if (n) out += ALN[take(6)]; }
      else if (mode === 1) { let n = take(ver < 10 ? 10 : 12); while (n >= 3) { out += String(take(10)).padStart(3, '0'); n -= 3; } if (n === 2) out += String(take(7)).padStart(2, '0'); else if (n === 1) out += String(take(4)); }
      else return out || null;
    }
    return out || null;
  }

  // ---- find the three corner squares ----
  function binarize(rgba, w, h, invert) {
    const gray = new Uint8Array(w * h), hist = new Array(256).fill(0);
    for (let i = 0; i < w * h; i++) { const g = (rgba[i * 4] * 299 + rgba[i * 4 + 1] * 587 + rgba[i * 4 + 2] * 114) / 1000 | 0; gray[i] = g; hist[g]++; }
    let sum = 0; for (let t = 0; t < 256; t++) sum += t * hist[t];
    let wB = 0, sB = 0, best = 0, thr = 127;
    for (let t = 0; t < 256; t++) { wB += hist[t]; if (!wB) continue; const wF = w * h - wB; if (!wF) break; sB += t * hist[t]; const mB = sB / wB, mF = (sum - sB) / wF, v = wB * wF * (mB - mF) * (mB - mF); if (v > best) { best = v; thr = t; } }
    const bw = new Uint8Array(w * h); for (let i = 0; i < w * h; i++) bw[i] = (gray[i] <= thr) !== !!invert ? 1 : 0;
    return bw;
  }
  const near = (a, m) => Math.abs(a - m) <= m * 0.6;
  function ratioOk(c) { const t = c[0] + c[1] + c[2] + c[3] + c[4]; if (t < 7) return 0; const m = t / 7; return near(c[0], m) && near(c[1], m) && near(c[2], 3 * m) && near(c[3], m) && near(c[4], m) ? m : 0; }
  function crossV(bw, w, h, x, y) {   // vertical check through (x,y); returns [centre y, module size] or null
    const c = [0, 0, 0, 0, 0]; let i = y;
    while (i >= 0 && bw[i * w + x]) { c[2]++; i--; } if (i < 0) return null;
    while (i >= 0 && !bw[i * w + x]) { c[1]++; i--; } if (i < 0) return null;
    while (i >= 0 && bw[i * w + x]) { c[0]++; i--; }
    i = y + 1; while (i < h && bw[i * w + x]) { c[2]++; i++; } if (i >= h) return null;
    while (i < h && !bw[i * w + x]) { c[3]++; i++; } if (i >= h) return null;
    while (i < h && bw[i * w + x]) { c[4]++; i++; }
    const m = ratioOk(c); if (!m) return null;
    return [y, m];
  }
  function findFinders(bw, w, h) {
    const cl = [];
    for (let y = 0; y < h; y++) {
      const runs = []; let x = 0;
      while (x < w) { const v = bw[y * w + x], s = x; while (x < w && bw[y * w + x] === v) x++; runs.push([v, x - s, s]); }
      for (let i = 0; i + 4 < runs.length; i++) {
        if (!runs[i][0]) continue;
        const c = [runs[i][1], runs[i + 1][1], runs[i + 2][1], runs[i + 3][1], runs[i + 4][1]], mh = ratioOk(c); if (!mh) continue;
        const cx = Math.floor(runs[i + 2][2] + runs[i + 2][1] / 2);
        // vertical: measure the extent of the centre run around (cx, y)
        let up = y; while (up > 0 && bw[(up - 1) * w + cx]) up--; let dn = y; while (dn < h - 1 && bw[(dn + 1) * w + cx]) dn++;
        const cy = (up + dn) / 2 + 0.5, mv = crossV(bw, w, h, cx, Math.round((up + dn) / 2)); if (!mv) continue;
        const px = runs[i + 2][2] + runs[i + 2][1] / 2, m = (mh + mv[1]) / 2;
        const hit = cl.find(k => Math.abs(k.x - px) < m * 2 && Math.abs(k.y - cy) < m * 2 && Math.abs(k.m - m) < m);
        if (hit) { hit.x = (hit.x * hit.n + px) / (hit.n + 1); hit.y = (hit.y * hit.n + cy) / (hit.n + 1); hit.m = (hit.m * hit.n + m) / (hit.n + 1); hit.n++; }
        else cl.push({ x: px, y: cy, m, n: 1 });
      }
    }
    return cl.filter(k => k.n >= 2).sort((a, b) => b.n - a.n).slice(0, 9);
  }
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  function triples(f) {
    const out = [];
    for (let i = 0; i < f.length; i++) for (let j = i + 1; j < f.length; j++) for (let k = j + 1; k < f.length; k++) {
      const t = [f[i], f[j], f[k]];
      for (let a = 0; a < 3; a++) {
        const A = t[a], B = t[(a + 1) % 3], C = t[(a + 2) % 3], ab = dist(A, B), ac = dist(A, C);
        if (Math.abs(ab - ac) > 0.25 * Math.max(ab, ac)) continue;
        const dot = ((B.x - A.x) * (C.x - A.x) + (B.y - A.y) * (C.y - A.y)) / (ab * ac); if (Math.abs(dot) > 0.35) continue;
        const ms = [A.m, B.m, C.m]; if (Math.max(...ms) > 1.5 * Math.min(...ms)) continue;
        let TR = B, BL = C; if ((B.x - A.x) * (C.y - A.y) - (B.y - A.y) * (C.x - A.x) < 0) { TR = C; BL = B; }
        out.push({ TL: A, TR, BL, score: A.n + B.n + C.n });
      }
    }
    return out.sort((a, b) => b.score - a.score);
  }

  function tryTriple(bw, w, h, t) {
    const m = (t.TL.m + t.TR.m + t.BL.m) / 3, d0 = (dist(t.TL, t.TR) + dist(t.TL, t.BL)) / 2 / m + 7;
    const cands = new Set();
    for (const d of [Math.round((d0 - 17) / 4) * 4 + 17, Math.floor((d0 - 17) / 4) * 4 + 17, Math.ceil((d0 - 17) / 4) * 4 + 17]) if (d >= 21 && d <= 57) cands.add(d);
    for (const n of cands) {
      const ux = (t.TR.x - t.TL.x) / (n - 7), uy = (t.TR.y - t.TL.y) / (n - 7), vx = (t.BL.x - t.TL.x) / (n - 7), vy = (t.BL.y - t.TL.y) / (n - 7);
      const px = (x, y) => { x = Math.round(x - 0.5); y = Math.round(y - 0.5); return x < 0 || y < 0 || x >= w || y >= h ? 0 : bw[y * w + x]; };
      const g = [];
      for (let r = 0; r < n; r++) { const row = []; for (let c = 0; c < n; c++) {
        const cx = t.TL.x + (c - 3) * ux + (r - 3) * vx, cy = t.TL.y + (c - 3) * uy + (r - 3) * vy;
        const s = px(cx, cy) * 2 + px(cx + 0.3 * ux, cy + 0.3 * uy) + px(cx - 0.3 * ux, cy - 0.3 * uy) + px(cx + 0.3 * vx, cy + 0.3 * vy) + px(cx - 0.3 * vx, cy - 0.3 * vy);
        row.push(s >= 3.5); } g.push(row); }
      try { const txt = decodeGrid(g, n); if (txt) return txt; } catch (e) {}
    }
    return null;
  }

  function decode({ data, width, height }) {
    let w = width, h = height, rgba = data;
    const k = Math.floor(Math.max(w, h) / 1400);
    if (k >= 2) {   // very large picture: average k x k blocks so it is quicker
      const nw = Math.floor(w / k), nh = Math.floor(h / k), out = new Uint8ClampedArray(nw * nh * 4);
      for (let y = 0; y < nh; y++) for (let x = 0; x < nw; x++) for (let c = 0; c < 3; c++) { let s = 0; for (let dy = 0; dy < k; dy++) for (let dx = 0; dx < k; dx++) s += rgba[((y * k + dy) * w + x * k + dx) * 4 + c]; out[(y * nw + x) * 4 + c] = s / (k * k); }
      rgba = out; w = nw; h = nh;
    }
    for (const inv of [false, true]) {
      const bw = binarize(rgba, w, h, inv), f = findFinders(bw, w, h);
      if (f.length < 3) continue;
      for (const t of triples(f).slice(0, 12)) { const txt = tryTriple(bw, w, h, t); if (txt) return txt; }
    }
    return null;
  }
  return { decode };
})();

<?php require 'layout.php'; top('Products', 'p', 'Admin Console > Products'); ?>
<div class="toolbar"><input id="q" placeholder="Search products and medicines..." style="flex:1"><button class="btn" id="new" type="button">+ New Product</button></div>
<div class="card"><table><thead><tr><th>Product / Medicine</th><th>Price</th><th>Status</th><th></th></tr></thead><tbody id="rows"></tbody></table>
  <div class="pager"><span id="info"></span><div id="pages"></div></div></div>
<p class="muted">Vets add these to a charge sheet and the front desk bills them. A hidden product no longer shows up in their list.</p>
<script>
let page = 1, t, rows = [];
async function load() {
  const r = await api(`/api/products?page=${page}&q=${encodeURIComponent($('#q').value.trim())}`); rows = r.rows;
  $('#rows').innerHTML = rows.length ? rows.map((p, i) => `<tr><td>${E(p.name)}</td><td>${peso(p.price)}</td><td><span class="badge ${+p.active ? '' : 'g'}">${+p.active ? 'Available' : 'Hidden'}</span></td>
    <td><button type="button" class="link" data-i="${i}">Edit</button></td></tr>`).join('') : '<tr><td colspan="4" class="empty">No products found.</td></tr>';
  $$('[data-i]').forEach(b => b.onclick = () => form(rows[b.dataset.i]));
  pager(r, page, n => { page = n; load(); }, $('#info'), $('#pages'));
}
function form(p) {
  dialog(`<h3>${p ? 'Edit product' : 'New product'}</h3><label>Name<input name="name" value="${E(p?.name)}"></label>
    <label>Price (₱)<input name="price" type="number" min="0" step="0.01" value="${p ? p.price : ''}"></label>
    ${p ? `<label class="chk"><input type="checkbox" name="active" value="1" ${+p.active ? 'checked' : ''}> Available in billing</label>` : ''}`,
    async f => { await api(p ? '/api/products/' + p.id : '/api/products', { name: f.name, price: f.price, active: f.active || '' }); load(); });
}
$('#new').onclick = () => form(null);
$('#q').oninput = () => { clearTimeout(t); t = setTimeout(() => { page = 1; load(); }, 250); };
load();
</script>
<?php bottom(); ?>

# Greenland Veterinary Clinic: Functional and Non-Functional Requirements

Companion to `Greenland_Vet_System_Documentation.md`. This list reflects the system as of **Update 20**.

**Status key:** ✅ built · ⚠️ partly built · 🔲 not built yet (open question or planned)
**Source key:** **INT** = said by the client in the interview · **ADV** = from the adviser or the team · **DES** = a design decision of the team

> About the name "smart scheduling": the system is **rule-based** (no AI, no learning). Check-ups and vaccinations are a first-come-first-served **queue**; only surgery is booked by time and checked against slots, rooms and on-duty vets. Check-ups are a first-come-first-served **queue**, because the client said fixed check-up appointments do not work in a veterinary clinic. A fitting name is **"Rule-Based Queue and Scheduling System"**. If "smart scheduling" is kept, define it in the paper as the automatic allocation of rooms and vets and the estimated waiting time, not as fitting patients into chosen time slots.

---

## 1. Scope and users

| Actor | App | Purpose |
|---|---|---|
| Pet owner (client) | Customer app | Register, add pets, register for a check-up or vaccination day, show a QR code, follow the queue, see records, bills and balance |
| Secretary / front desk (staff) | Staff app | Register walk-ins, scan arrivals, run the queue, set who is on duty, take payments, print billing statements, read records |
| Veterinarian | Vet app (tablet) | See today's patients, build the charge sheet, press Done, decide what happens next, write records |
| Administrator | Admin app | Accounts, reports, products and prices, audit log, homepage content |

Both branches (Cainta and Taytay) use one shared database, so records are visible to both. Cainta is the main branch (confinement, major check-ups, surgery, X-ray). Taytay is a wellness branch (mostly vaccination).

---

## 2. Functional requirements

### 2.1 Accounts and access
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-001 | Four separate apps (customer, staff, vet, admin); each accepts only its own role | ADV/DES | ✅ |
| FR-002 | Sign-in with a username (or email for the customer) and a 6-digit code sent by email | DES | ✅ |
| FR-003 | Pet owners can register online; the clinic completes the pet's details when they arrive | INT | ✅ |
| FR-004 | Staff can create an account and records for walk-in owners who have none | INT | ✅ |
| FR-005 | Admin can create, edit, disable and reset accounts | DES | ✅ |
| FR-006 | Every inner page has a **Back** link | INT | ✅ |

### 2.2 Clients and pets
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-010 | Store owner details (name, phone, email, address) and pets (name, species, breed, sex, birth date, photo) | DES | ✅ |
| FR-011 | Pet age is based on the birth date given by the owner (copied from the vaccination card); no birth certificate is required | INT | ✅ |
| FR-012 | Upload pet documents (vaccination card and others) | DES | ✅ |
| FR-013 | Search clients and pets by name, pet or phone | DES | ✅ |

### 2.3 Scheduling, queue and QR check-in
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-020 | Check-ups and vaccinations are **first come, first served** for the whole day, in one shared line; the owner registers a day, not a time | INT | ✅ |
| FR-021 | A vaccination takes **15 minutes** (used only for the waiting estimate). It has no booked time: it is a day registration in the same queue as check-ups (Update 20) | INT | ✅ |
| FR-022 | Clinic hours are **9:00 AM to 5:00 PM**, Monday to Saturday; the last check-up can join the queue at 5:00 PM | INT | ✅ |
| FR-023 | Owners get a QR code; scanning it at arrival shows pet, owner, phone, service and date and gives a **queue number** | INT | ✅ |
| FR-024 | A patient is called only when an on-duty vet and a free room are available; rooms and vets are freed when the visit is marked Done | DES | ✅ |
| FR-025 | The order is strict first come, first served; the only exception is an **emergency** moved up by staff with a logged reason | INT | ✅ |
| FR-026 | The vet is not chosen automatically in advance: whichever vet is free takes the next patient; the secretary can note who took the patient | INT | ✅ |
| FR-027 | All vets can do all services (no specializations) | INT | ✅ |
| FR-028 | A **duty roster** (a weekly pattern plus daily changes) says which vets are on duty; only on-duty vets get patients | INT | ✅ |
| FR-029 | The roster warns when fewer vets are on duty than the branch's minimum (**Cainta 2, Taytay 1**) | INT | ✅ |
| FR-030 | Estimated waiting time from the number of patients ahead, the severity (Routine / Moderate / Severe) and the vets on duty | INT/DES | ✅ |
| FR-031 | A check-up takes at least 1 hour and a severe case 2 to 3 hours (used for estimates only, never for the order) | INT | ✅ |
| FR-032 | A schedule that was not kept **lapses** automatically and is removed; the owner is told and can book again; a late arrival becomes a walk-in | INT | ✅ |
| FR-033 | Late alerts (10 minutes) and auto-cancel (60 minutes) for **timed visits (surgery)**. Day registrations (check-up, vaccination) have no late alert: they expire at closing time and the owner is asked to pick another day | INT/DES | ✅ |
| FR-034 | Owners can cancel, or move a day registration to another open day (no time), until they arrive, within set limits | DES | ✅ |
| FR-035 | Online booking is limited to vaccination and check-up; **customers cannot book surgery or confinement**: the vet advises them and the staff or the vet arranges them | INT | ✅ |
| FR-036 | Vaccination slot limit per time slot | DES | not needed since Update 20 (vaccinations are no longer booked into slots; the queue and the rooms limit how many are seen at once) |
| FR-037 | Move a severe case to another room while patients are in rooms | INT (open) | 🔲 |
| FR-038 | An owner who does not come on the registered day: the registration **expires at closing**, the owner is sent a *missed vaccination day* message and can register again for any open day | INT/DES | ✅ |
| FR-039 | A pet may be registered for a check-up and a vaccination on the same day: one visit, one queue number; several pets of one owner each take their own place | INT | ✅ |
| FR-104 | The front desk sees a **Now serving** card on the dashboard (rooms with queue number, pet, owner, vet; next in line with estimated waits) and a small panel on other pages that announces whose turn it is now | DES | ✅ (mock renders only) |
| FR-105 | The staff calendar shows today and one coloured dot per service booked on each day; the staff dashboard compares today's patients and collections with the same weekday last week | DES | ✅ |

### 2.4 Charge sheet, Done and billing
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-040 | The vet's tablet shows a **charge sheet** per patient, prefilled with the fee (**Check-up Fee** for check-ups), with medicines and services added, a running total and a **Show customer** view | INT | ✅ |
| FR-041 | **Done** shows a confirmation summary; then the room and vet are freed and the bill goes to the front desk | INT | ✅ |
| FR-042 | Done is automatic: no pencil-booking → confirmed → arrived → done clicking; pressing it twice is harmless | INT | ✅ |
| FR-043 | The secretary can mark a visit done and fill in the charges if the vet forgets | INT | ✅ |
| FR-044 | The front desk can edit an unpaid bill; the change is marked, logged and the vet is told | DES | ✅ |
| FR-045 | Payment methods: **cash, GCash, card and check**; a bill can be paid with **split payments** (for example GCash plus cash) | INT | ✅ |
| FR-046 | An owner may leave with a balance; balances are shown at check-in, billing and the owner's portal, can be paid later, and are listed with their age | INT | ✅ |
| FR-047 | Checks: pending clearing → cleared, or bounced (the balance is due again and the front desk and admin are alerted) | INT | ✅ |
| FR-048 | The printout is a **Billing Statement**, ends with **"This is not an official receipt"**, uses the clinic name as text (no logo) and prints on a normal A4 printer | INT | ✅ |
| FR-049 | A **Daily Sales Sheet** for the end of the shift: bills (owner, pet, service, total), money collected by method, payment lines and everyone scheduled that day, printable | INT | ✅ |
| FR-050 | Prices can be changed by the admin | INT | ✅ |
| FR-051 | Stock per branch (deduction, restock, low-stock alerts, history) | DES | 🔲 Removed in Update 18 (not in the paper; the product list keeps name and price only) |
| FR-052 | Who prepared the bill (vet) and who took the payment (staff) are kept | DES | ✅ |

### 2.5 Confinement, surgery and referrals
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-060 | At Done the vet decides **what happens next**: goes home (optional follow-up and its purpose), confine now, surgery now or on another day, or refer for tests | INT/DES | ✅ |
| FR-061 | Confinement starts immediately, has a running bill (a daily rate plus medicines and treatments) paid at discharge, and a **Confined** list for vets and staff | INT/DES | ✅ |
| FR-062 | Surgery has its own room (one at a time), its own charge sheet and any free on-duty Cainta vet | INT/DES | ✅ |
| FR-063 | Taytay does not confine or operate: a Taytay vet **refers** the patient to Cainta; the owner and Cainta are told | INT | ✅ |
| FR-064 | A Taytay vet can **refer a patient to Cainta for X-ray, ultrasound or laboratory tests**; the pet is put on Cainta's list for the chosen day | INT | ✅ |
| FR-065 | The check-up bill can be paid now or added to the confinement / surgery bill | DES | ✅ |
| FR-066 | A confinement or surgery records the **outcome: survived or died**; Discharge asks for it | INT | ✅ |
| FR-067 | The real daily confinement rate, deposits and the number of surgery rooms | INT (open) | 🔲 placeholders in `config.php` |

### 2.6 Medical records
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-070 | A record always shows the **visit date**, never the date it was typed; the typing date is kept as secondary information | INT | ✅ |
| FR-071 | Records can be written later (end of the shift); a finished visit without findings is a **Pending record** with reminders to the vet | INT | ✅ |
| FR-072 | Editing a record changes it in place (no duplicate copies); every edit is logged and shown as "Edited by" | INT | ✅ |
| FR-073 | The **check-up record** shows at one glance: chief complaint, tests done, results, diagnosis, prescription, follow-up date and the purpose of the follow-up | INT | ✅ |
| FR-074 | Fields are plain typed text, with a calendar for dates, to avoid clicking | INT | ✅ |
| FR-075 | A **vaccination visit can hold several items** (vaccine, deworming, tick and flea, other), each with its own next schedule, with an "add another" control | INT | ✅ |
| FR-076 | Every vet can see every patient and every record (vets cover for each other); both branches share the records | INT | ✅ |
| FR-077 | The secretary can read records (read-only) and can note who attended a schedule | INT | ✅ |
| FR-078 | A **Back** option between the charge sheet and the record form so the vet does not start over | INT | ✅ |
| FR-079 | A per-pet timeline of all visits | INT | ✅ |
| FR-080 | Editing another vet's record is on hold pending the client; the switch is `VET_CAN_EDIT_RECORDS` | INT (open) | ⚠️ |
| FR-106 | A pet's records can be shown as a **timeline** with an icon for each kind of visit (vaccination, check-up, confinement, surgery), or as a table | DES | ✅ |

### 2.7 Notifications and messages
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-090 | In-app notifications for every role, with a sound for the front desk | DES | ✅ |
| FR-091 | Reminders, late alerts and lapsed/cancelled schedules are sent by **email** in the clinic's wording ("this is an automated message, do not reply, message us at …") | INT | ✅ (needs a mail server) |
| FR-092 | The same messages by **SMS** | INT | ⚠️ built and switched off until an SMS service is chosen |
| FR-093 | Every message sent is recorded (channel, recipient, status) | DES | ✅ |
| FR-094 | The owner is told when a record is ready, when a pet is referred, confined or discharged | DES | ✅ |

### 2.7a Public website and sales split (Update 16)
- FR-W1 The customer site shall open on a public front page (banner, services, how it works, promos, About, branches, footer) before login.
- FR-W2 Admin shall edit the banner, promo strip, items on sale, services heading and intro, About text and footer note in Page Management.
- FR-W3 The staff dashboard shall not show customers' outstanding balances or the ready-for-billing count.
- FR-W4 Sales and the Daily sheet shall show money collected online (GCash) separately from money collected in the clinic.
- FR-W5 Dark mode shall be available in all four apps and remembered per browser.
- FR-W6 Owners shall see the prescription on each check-up record.
- FR-W7 The customer app shall sign the owner out after 30 minutes without activity; the staff, vet and admin apps shall not sign users out for being idle.
- FR-W8 The website shall show whether the clinic is open now.
- FR-W10 The staff dashboard shall show no money; every money figure (collected, online vs clinic, billed, payment methods, unpaid balances, sales history) shall be on the Sales page, which the admin app also has (read only).
- FR-W11 All four apps shall fit any screen size: a fluid text scale, a slide-out menu and stacked layouts on tablets and phones, and a login page that works at every size.
- FR-W9 (Not built, removed in Update 18) An online Pet Shop with orders for pickup or delivery is left for a later phase.

### 2.8 Administration and reports
| ID | Requirement | Source | Status |
|---|---|---|---|
| FR-100 | Reports and analytics (sales by method, visits, balances), excluding drafts and transferred bills | DES | ✅ |
| FR-101 | Audit log of admin actions, bill changes, payments and record edits | DES | ✅ |
| FR-102 | Homepage content and promos managed in the admin app | DES | ✅ |
| FR-103 | Someone covers payments on the **secretary's day off (Thursday)** | INT (open) | 🔲 ask the client |
| FR-107 | Reports include the busiest days of the week and the vaccinations coming due in the next 14 days, besides the existing charts | DES | ✅ |

---

## 3. Non-functional requirements

Targets marked "not measured" are goals; they have not been tested with real users or a real server.

### 3.1 Usability
- NFR-U0 (Update 16) Base text is about 15 to 18 px depending on screen width; large text only for headline figures.
| ID | Requirement | Status |
|---|---|---|
| NFR-001 | The vet app works on a **tablet**: large touch targets and a large **Done** button | ✅ |
| NFR-002 | Fast data entry: typed text instead of many clicks, minimal required fields, a Back option on every inner page | ✅ |
| NFR-003 | Text and controls are sized to be readable but not oversized; sizes scale with the screen (about 14 to 17 px base) | ✅ |
| NFR-004 | Layout follows the Figma design, the teal palette and the clinic's logo | ✅ |
| NFR-005 | The pages work on a phone, tablet and desktop browser (responsive) | ✅ (checked with mock renders only) |
| NFR-006 | Errors and confirmations are written in plain language and name the field at fault | ✅ |
| NFR-007 | Printing fits an A4 page and is large enough to read | ✅ |
| NFR-063 | Pet avatars and one shared set of status colours (waiting, in a room, done, confined, emergency, referred) in all four apps, so a status is read the same everywhere | ✅ |
| NFR-064 | A **dark mode** for the staff and vet apps, remembered per browser | ✅ (mock renders only) |
| NFR-065 | Look-and-feel additions can be switched off one by one in `config.php` without a database change | ✅ |

### 3.2 Performance
| ID | Requirement | Status |
|---|---|---|
| NFR-010 | Ordinary pages respond within about 2 seconds for one clinic's data volume | not measured |
| NFR-011 | The queue board refreshes by itself without reloading the page | ✅ |
| NFR-012 | Lists are paged (10 to 12 per page) | ✅ |
| NFR-013 | QR scanning with a webcam reads a code in about a second | not measured |

### 3.3 Reliability and data integrity
| ID | Requirement | Status |
|---|---|---|
| NFR-020 | Two patients scanned at the same moment are handled one at a time (a per-branch MySQL lock) | ✅ |
| NFR-021 | Pressing **Done** twice, or paying twice, never doubles anything (idempotent) | ✅ |
| NFR-022 | Money and records use database transactions where several tables change together | ✅ |
| NFR-023 | Records keep the visit date separately from the date typed | ✅ |
| NFR-024 | A failure to send an email or SMS never stops the clinic's work | ✅ |
| NFR-025 | A backup of the database is made by the clinic or the administrator (for example the XAMPP/phpMyAdmin export) | 🔲 procedure to be written |

### 3.4 Security and privacy
| ID | Requirement | Status |
|---|---|---|
| NFR-030 | Passwords are hashed; all queries are prepared statements; output is HTML-escaped | ✅ |
| NFR-031 | Two-step sign-in with an expiring, attempt-limited code; the session is regenerated at login | ✅ |
| NFR-032 | Every API request checks the role on the server; customers see only their own data | ✅ |
| NFR-033 | Payments are validated on the server (methods, amounts, check details, no overpayment) | ✅ |
| NFR-034 | Uploads (photos, documents) are validated for type and size | ✅ |
| NFR-035 | An audit log records who did what and when | ✅ |
| NFR-036 | Use HTTPS, real SMTP and remove the testing code display (`DEV_SHOW_CODE`) before going live | 🔲 deployment step |
| NFR-037 | Online registration has a CAPTCHA and rate limiting | 🔲 not built |

### 3.5 Maintainability and portability
| ID | Requirement | Status |
|---|---|---|
| NFR-040 | Plain PHP 8, MySQL/MariaDB and plain HTML/CSS/JavaScript, no frameworks; runs on XAMPP | ✅ |
| NFR-041 | Clinic rules (hours, slot length, minimum vets, fees, rates, rooms, messages) are constants in `config.php`, not buried in code | ✅ |
| NFR-042 | Shared logic (queue, billing, authentication) lives in one set of shared files copied to all four apps | ✅ |
| NFR-043 | The database is upgraded by one script (`upgrade_from_previous.sql`) that can be run again safely | ✅ |
| NFR-044 | The system is documented, with a change log | ✅ |

### 3.6 Compatibility and constraints
| ID | Requirement | Status |
|---|---|---|
| NFR-050 | Works in current Chrome, Edge and Firefox; the QR webcam needs HTTPS or localhost | ✅ (Chrome checked only) |
| NFR-051 | Time zone is Philippine time (UTC+8) | ✅ |
| NFR-052 | **No AI**: scheduling, estimates and routing are rules the team can explain | ✅ |
| NFR-053 | Currency is the Philippine peso | ✅ |
| NFR-054 | Staff and vet stay separate apps (adviser's decision) | ✅ |

### 3.7 Availability and scalability
| ID | Requirement | Status |
|---|---|---|
| NFR-060 | Handles two branches, about 4 vets and a few staff accounts at once | ✅ by design, not load-tested |
| NFR-061 | Another branch, room or surgery room can be added by editing settings | ⚠️ rooms and surgery rooms yes; a new branch also needs accounts and settings |
| NFR-062 | Timed automations (late alerts, expiry, reminders) run while some signed-in page is open | ✅ (limitation: nothing runs when no page is open) |

---

## 4. What the client said, and where it went

| What the client said (interview) | Requirement | Status |
|---|---|---|
| Services take 10 to 15 minutes for a vaccine; a check-up is at least 1 hour, severe up to 3 hours | FR-021, FR-030, FR-031 | ✅ |
| Check-ups are first come, first served; "schedule", not "appointment"; emergencies go first | FR-020, FR-025 | ✅ |
| Owners may come from 9 AM to 5 PM | FR-022 | ✅ |
| Only vaccines should be by appointment; check-ups are walk-in | FR-020, FR-021 | ✅ |
| 2 vets a day (sometimes 3); 6 to 8 helpers who only hold the animals | FR-028, FR-029 | ✅ (helpers have no accounts) |
| All vets can do everything; no specialization | FR-027 | ✅ |
| Taytay is wellness and vaccines only; one vet and one assistant; Cainta does confinement, major check-ups, surgery | FR-029, FR-063 | ✅ |
| Taytay transfers X-ray cases to Cainta | FR-064 | ✅ |
| The vet who is free takes the next patient; the secretary notes who | FR-026 | ✅ |
| Every vet needs access to every patient; both branches share records | FR-076 | ✅ |
| The secretary registers walk-ins; she is at the desk; she is off on Thursdays | FR-004, FR-103 | ✅ / 🔲 |
| Check-up form: chief complaint, tests, results, prescription, follow-up and its purpose, all visible at once | FR-073, FR-074 | ✅ |
| Editing must not create a new copy each time | FR-072 | ✅ |
| A missed schedule must lapse so it is not mixed with the real visit | FR-032 | ✅ |
| A vaccine visit may include deworming and tick treatment, each with its own schedule | FR-075 | ✅ |
| Confinement and surgery records need survived or died | FR-066 | ✅ |
| Reminders for late or lapsed schedules, by SMS or email, in their wording | FR-091, FR-092 | ✅ email / ⚠️ SMS |
| Billing: a billing statement, not a sales receipt, with "not official receipt" | FR-048 | ✅ |
| Split payments, credit, cash, card, check | FR-045, FR-046 | ✅ |
| The secretary's end-of-shift list of sales and everyone scheduled | FR-049 | ✅ |
| Print on an ordinary A4 printer; the clinic name as text; "check-up fee" and "consultation fee" are the same | FR-048, FR-040 | ✅ |
| Records must keep the visit date even when typed three days later | FR-070 | ✅ |
| Done should be automatic, vets are in a hurry and do not want many clicks | FR-042, NFR-002 | ✅ |
| A back option from billing to the check-up form | FR-078 | ✅ |
| Vets keep paper notes and write records at the end of the shift | FR-071 | ✅ |
| Pricing is not final and can change | FR-050 | ✅ |

## 5. Open items for the client

1. The real **daily confinement rate**, how days are counted and whether a **deposit** is taken.
2. How many **surgery rooms** there are.
3. Who takes payments on the **secretary's Thursday off**.
4. Whether a vaccination should use an exam room (today it takes a vet and a room like any visit).
5. Whether a vet may **edit another vet's record**.
6. Moving a severe case to another room while the rooms are full.
7. Which **SMS service** to use (the system is ready to connect one).

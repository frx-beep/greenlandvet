# Greenland Veterinary Clinic: shared database + setup guide
The staff, vet, customer and admin apps all use this ONE database, so everything stays connected.

## 1. Create the database (XAMPP)
1. Start Apache and MySQL in XAMPP.
2. Open http://localhost/phpmyadmin > Import > choose `schema.sql` > Import.
3. Optional sample clients, pets, records and products for testing: import `demo_data.sql` the same way. Skip it for the real clinic.
4. **Test accounts (optional):** import `demo_accounts.sql` after the schema. It creates an admin, two staff, six vets (with a weekly duty rotation), two pet owners with pets, today's queue and vaccination appointments, products (name and price), and one old unpaid bill so balances can be tried. Every password is `Demo@1234`; the logins and quick tests are in `DEMO_ACCOUNTS.md`. Skip it for the real clinic.
5. ALREADY imported the earlier version? Easiest while testing: delete the `greenland_vet` database in phpMyAdmin and import `schema.sql` again. To keep your data instead, import `upgrade_from_previous.sql` (**required for Updates 12 and 13**: queue numbers, duty roster, charge sheets and bills, split payments, balances, record dates and edit history, and for Update 13 the confinement, surgery-referral and bill-transfer columns). It is safe to run again.

## 2. Install the apps
Unzip each app and put the folders in C:\xampp\htdocs :  `greenland-admin`, `greenland-staff`, `greenland-vet`, `greenland-customer`

## 3. Create the first admin
Open http://localhost/greenland-admin/setup.php and create the admin (use a real email: it receives the sign-in codes). The page closes itself afterwards.

## 4. Create accounts (Admin app)
Sign in at http://localhost/greenland-admin/login.php > Accounts > + Create Account.
- Staff (front desk) and Vet accounts sign in with BRANCH + USERNAME + password. Vets have no specialty or surgery setting: every vet does every service. Who is on duty each day is planned by the front desk in the staff app (Duty roster).
- Pet owners can also **register online** on the customer site (they confirm their email with a code). Client accounts sign in with USERNAME + password. The account is linked to the client record with the same email (created in the staff app), so the owner sees their own pets automatically. A sign-in code is still emailed to the client's email.
- Everyone enters a 6-digit code at every sign-in and picks a new password the first time.

## Links
Customer: http://localhost/greenland-customer/   Staff: /greenland-staff/login.php   Vet: /greenland-vet/login.php   Admin: /greenland-admin/login.php

## Going live later
- Each app has its own domain: put the real database login in each app's config.php and update SITE_URLS.
- All sites must reach the same database (same hosting plan, or a host that allows remote MySQL).
- Set DEV_SHOW_CODE to false in every config.php and set up real email (SMTP).
- Edit SERVICE_FEES in the staff AND vet config.php to the clinic's real fees (the charge sheet starts from the service fee).
- In api.php (staff and vet apps): `STAFF_CAN_EDIT_RECORDS` is false (staff read records only) and every vet may edit records (all edits are logged).

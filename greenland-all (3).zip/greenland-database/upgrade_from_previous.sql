-- Run this if you already imported an earlier version and want to keep your data. Safe to run more than once. (XAMPP's MariaDB supports it.)
-- Easier alternative while testing: delete the greenland_vet database in phpMyAdmin and import the new schema.sql again.
USE greenland_vet;
ALTER TABLE accounts MODIFY role ENUM('client','staff','vet','admin') NOT NULL;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS phone VARCHAR(40) NULL, ADD COLUMN IF NOT EXISTS photo MEDIUMTEXT NULL,
  ADD COLUMN IF NOT EXISTS can_operate TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS specialty VARCHAR(200) NULL;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS email_verified TINYINT(1) NOT NULL DEFAULT 1, ADD COLUMN IF NOT EXISTS address VARCHAR(255) NULL;
ALTER TABLE checkups ADD COLUMN IF NOT EXISTS next_step VARCHAR(20) NOT NULL DEFAULT 'None', ADD COLUMN IF NOT EXISTS followup_date DATE NULL;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS pet_id INT NULL;
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL, price DECIMAL(10,2) NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1, UNIQUE KEY uq_product (name)) ENGINE=InnoDB;
ALTER TABLE activity_log ADD COLUMN IF NOT EXISTS detail VARCHAR(255) NULL;
ALTER TABLE pets ADD COLUMN IF NOT EXISTS photo MEDIUMTEXT NULL;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS qr_token CHAR(24) NULL, ADD COLUMN IF NOT EXISTS checked_in_at DATETIME NULL, ADD COLUMN IF NOT EXISTS room VARCHAR(40) NULL;
ALTER TABLE appointments ADD UNIQUE INDEX IF NOT EXISTS uq_qr (qr_token);

-- ---- Update 11 ----
ALTER TABLE accounts MODIFY specialty VARCHAR(200) NULL;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS group_token CHAR(24) NULL, ADD COLUMN IF NOT EXISTS concern VARCHAR(40) NULL, ADD COLUMN IF NOT EXISTS started_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS late_alerted TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS reminded TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS cancelled_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS cancel_reason VARCHAR(160) NULL, ADD COLUMN IF NOT EXISTS cancelled_by VARCHAR(20) NULL, ADD COLUMN IF NOT EXISTS reschedule_count TINYINT NOT NULL DEFAULT 0;
ALTER TABLE appointments ADD INDEX IF NOT EXISTS idx_group (group_token);
CREATE TABLE IF NOT EXISTS pet_documents (
  id INT AUTO_INCREMENT PRIMARY KEY, pet_id INT NOT NULL, doc_type VARCHAR(40) NOT NULL, name VARCHAR(150) NOT NULL, mime VARCHAR(60) NOT NULL,
  data MEDIUMTEXT NOT NULL, uploaded_by VARCHAR(120), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY, account_id INT NOT NULL, type VARCHAR(30) NOT NULL DEFAULT 'info', title VARCHAR(150) NOT NULL, body VARCHAR(255) NULL, link VARCHAR(200) NULL,
  read_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX (account_id, read_at),
  FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS vet_off (
  id INT AUTO_INCREMENT PRIMARY KEY, account_id INT NOT NULL, off_date DATE NOT NULL, note VARCHAR(120) NULL, UNIQUE KEY uq_off (account_id, off_date),
  FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS cms_content (k VARCHAR(60) PRIMARY KEY, v MEDIUMTEXT) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS cms_items (
  id INT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(20) NOT NULL DEFAULT 'promo', title VARCHAR(120) NOT NULL, description VARCHAR(400) NULL,
  price DECIMAL(10,2) NULL, old_price DECIMAL(10,2) NULL, image MEDIUMTEXT NULL, active TINYINT(1) NOT NULL DEFAULT 1, sort_order INT NOT NULL DEFAULT 0) ENGINE=InnoDB;

-- ---- Update 12: queue, duty roster, charge sheets and bills, split payments, balances, record dates ----
-- Appointments: check-ups become a first-come-first-served queue (no time); every visit records who marked it done.
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS is_queue TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS queue_no INT NULL, ADD COLUMN IF NOT EXISTS severity VARCHAR(10) NULL,
  ADD COLUMN IF NOT EXISTS priority TINYINT NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS called_at DATETIME NULL, ADD COLUMN IF NOT EXISTS done_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS done_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS record_done TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS priority_reason VARCHAR(120) NULL;
UPDATE appointments SET record_done=1 WHERE status='Completed' AND done_at IS NULL;   -- visits finished before Update 12 already have their records
-- Who is on duty (vets rotate; at least 2 per branch per day). No rows = every vet at the branch is on duty.
CREATE TABLE IF NOT EXISTS vet_duty (
  id INT AUTO_INCREMENT PRIMARY KEY, account_id INT NOT NULL, duty_date DATE NOT NULL, on_duty TINYINT(1) NOT NULL DEFAULT 1, UNIQUE KEY uq_duty (account_id, duty_date),
  FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS vet_duty_default (
  account_id INT NOT NULL, weekday TINYINT NOT NULL, PRIMARY KEY (account_id, weekday),
  FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE) ENGINE=InnoDB;
INSERT IGNORE INTO vet_duty (account_id, duty_date, on_duty) SELECT account_id, off_date, 0 FROM vet_off;   -- earlier "not in today" days
-- Bills: a draft charge sheet (vet) becomes Unpaid when the vet presses Done; payments (several lines, split) bring it to Paid.
ALTER TABLE sales ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'Paid', ADD COLUMN IF NOT EXISTS paid DECIMAL(10,2) NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS appt_id INT NULL,
  ADD COLUMN IF NOT EXISTS prepared_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS ready_at DATETIME NULL, ADD COLUMN IF NOT EXISTS desk_changed TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN IF NOT EXISTS note VARCHAR(255) NULL;
ALTER TABLE sales ADD INDEX IF NOT EXISTS idx_sales_client (client_id), ADD INDEX IF NOT EXISTS idx_sales_appt (appt_id), ADD INDEX IF NOT EXISTS idx_sales_status (status);
ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS product_id INT NULL;
CREATE TABLE IF NOT EXISTS sale_payments (
  id INT AUTO_INCREMENT PRIMARY KEY, sale_id INT NOT NULL, method VARCHAR(10) NOT NULL, amount DECIMAL(10,2) NOT NULL, received DECIMAL(10,2) NULL,
  ref VARCHAR(60) NULL, bank VARCHAR(60) NULL, check_no VARCHAR(40) NULL, check_date DATE NULL, check_status VARCHAR(20) NULL,
  pay_group CHAR(16) NULL, taken_by VARCHAR(120) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX (pay_group),
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE) ENGINE=InnoDB;
UPDATE sales SET paid=total WHERE status='Paid' AND paid=0 AND total>0;
INSERT INTO sale_payments (sale_id, method, amount, received, taken_by, created_at, pay_group)
  SELECT s.id, s.payment, s.total, s.total, s.served_by, s.created_at, CONCAT('legacy', LPAD(s.id, 10, '0')) FROM sales s
  WHERE s.status='Paid' AND s.payment IN ('Cash','GCash','Card') AND NOT EXISTS (SELECT 1 FROM sale_payments x WHERE x.sale_id=s.id);
-- Records: the VISIT date is the main date; when the record was typed is kept separately. Edits are logged.
ALTER TABLE vaccinations ADD COLUMN IF NOT EXISTS appt_id INT NULL, ADD COLUMN IF NOT EXISTS recorded_at DATETIME NULL, ADD COLUMN IF NOT EXISTS recorded_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_at DATETIME NULL;
ALTER TABLE checkups ADD COLUMN IF NOT EXISTS appt_id INT NULL, ADD COLUMN IF NOT EXISTS recorded_at DATETIME NULL, ADD COLUMN IF NOT EXISTS recorded_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_at DATETIME NULL;
ALTER TABLE confinements ADD COLUMN IF NOT EXISTS appt_id INT NULL, ADD COLUMN IF NOT EXISTS recorded_at DATETIME NULL, ADD COLUMN IF NOT EXISTS recorded_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_at DATETIME NULL;
ALTER TABLE surgeries ADD COLUMN IF NOT EXISTS appt_id INT NULL, ADD COLUMN IF NOT EXISTS recorded_at DATETIME NULL, ADD COLUMN IF NOT EXISTS recorded_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_by VARCHAR(120) NULL, ADD COLUMN IF NOT EXISTS edited_at DATETIME NULL;
CREATE TABLE IF NOT EXISTS record_edits (
  id INT AUTO_INCREMENT PRIMARY KEY, rtype VARCHAR(20) NOT NULL, record_id INT NOT NULL, edited_by VARCHAR(120) NOT NULL, changes TEXT NOT NULL, edited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX (rtype, record_id)) ENGINE=InnoDB;

-- ---- Update 13: "What happens next?" at Done, confinement stays, surgery room, Taytay referrals ----
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS next_step VARCHAR(20) NULL, ADD COLUMN IF NOT EXISTS followup_date DATE NULL, ADD COLUMN IF NOT EXISTS from_appt_id INT NULL, ADD COLUMN IF NOT EXISTS referred_from VARCHAR(40) NULL;
ALTER TABLE confinements ADD COLUMN IF NOT EXISTS branch VARCHAR(40) NULL, ADD COLUMN IF NOT EXISTS vet VARCHAR(60) NULL, ADD COLUMN IF NOT EXISTS from_appt_id INT NULL, ADD COLUMN IF NOT EXISTS admitted_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS discharged_at DATETIME NULL, ADD COLUMN IF NOT EXISTS daily_rate DECIMAL(10,2) NULL, ADD COLUMN IF NOT EXISTS days_override INT NULL, ADD COLUMN IF NOT EXISTS sale_id INT NULL,
  ADD COLUMN IF NOT EXISTS rate_item_id INT NULL, ADD COLUMN IF NOT EXISTS referred_from VARCHAR(40) NULL, ADD COLUMN IF NOT EXISTS arrived_at DATETIME NULL;
ALTER TABLE confinements ADD INDEX IF NOT EXISTS idx_conf_status (status);
-- a running confinement bill is a Draft sale until discharge; a check-up bill added to it is closed as 'Transferred'
ALTER TABLE sales ADD COLUMN IF NOT EXISTS service VARCHAR(40) NULL, ADD COLUMN IF NOT EXISTS transferred_to INT NULL;

-- ===== Update 14 =====
-- vaccination visits can hold several items (vaccine, deworming, tick and flea...), one row each with its own next schedule
ALTER TABLE vaccinations ADD COLUMN IF NOT EXISTS item_type VARCHAR(30) NOT NULL DEFAULT 'Vaccine';
-- the check-up record shows these at one glance
ALTER TABLE checkups ADD COLUMN IF NOT EXISTS chief_complaint TEXT NULL, ADD COLUMN IF NOT EXISTS tests TEXT NULL, ADD COLUMN IF NOT EXISTS test_results TEXT NULL,
  ADD COLUMN IF NOT EXISTS diagnosis TEXT NULL, ADD COLUMN IF NOT EXISTS prescription TEXT NULL, ADD COLUMN IF NOT EXISTS followup_purpose VARCHAR(150) NULL;
-- survived or died
ALTER TABLE confinements ADD COLUMN IF NOT EXISTS outcome VARCHAR(12) NULL;
ALTER TABLE surgeries ADD COLUMN IF NOT EXISTS outcome VARCHAR(12) NULL;
-- purpose of the follow-up and the Taytay -> Cainta referral for X-ray / tests (decided at Done)
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS followup_purpose VARCHAR(150) NULL, ADD COLUMN IF NOT EXISTS referral_reason VARCHAR(200) NULL;
-- every email / SMS sent to an owner (SMS waits here as 'Queued' until an SMS service is connected)
CREATE TABLE IF NOT EXISTS message_outbox (
  id INT AUTO_INCREMENT PRIMARY KEY, client_id INT NULL, channel VARCHAR(10) NOT NULL, to_addr VARCHAR(150) NOT NULL, kind VARCHAR(30) NOT NULL,
  body TEXT NOT NULL, status VARCHAR(12) NOT NULL DEFAULT 'Queued', error VARCHAR(255) NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, sent_at DATETIME NULL,
  INDEX idx_out_status (status), INDEX idx_out_client (client_id)) ENGINE=InnoDB;

-- ===== Update 20 =====
-- Vaccinations are now first come, first served (a day registration, no booked time), like check-ups.
-- Convert vaccinations that are still ahead (not yet arrived) into day registrations. Safe to run more than once.
UPDATE appointments SET is_queue=1, appt_time='00:00:00', vet=NULL, late_alerted=0, reminded=0
 WHERE service='Vaccination' AND is_queue=0 AND status IN ('Pending','Confirmed') AND checked_in_at IS NULL AND appt_date >= CURDATE();
-- To go back to booked times for vaccinations, remove 'Vaccination' from QUEUE_SERVICES in config.php.

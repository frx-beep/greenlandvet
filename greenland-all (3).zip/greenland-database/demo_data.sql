-- OPTIONAL sample data for testing. Import AFTER schema.sql. No accounts are included: create them in the Admin app.
USE greenland_vet;
INSERT INTO clients (id,name,address,email,phone,branch) VALUES
 (1,'Erik Taduran','12 Sampaguita St., Pasig City','erik@email.com','0917 000 0001','Cainta'),
 (2,'Jose Reyes','45 Rizal Ave., Cainta, Rizal','jose@email.com','0917 000 0002','Taytay'),
 (3,'Ana Cruz','8 Mabini St., Taytay, Rizal','ana@email.com','0917 000 0003','Cainta'),
 (4,'Paolo Lim','21 Bonifacio St., Cainta, Rizal','paolo@email.com','0917 000 0004','Cainta'),
 (5,'Grace Tan','90 Mayon St., Taytay, Rizal','grace@email.com','0917 000 0005','Taytay');
INSERT INTO pets (id,client_id,name,species,breed,sex,birthdate) VALUES
 (1,1,'Bruno','Dog','Labrador Retriever','Male','2021-03-12'),(2,1,'Luna','Cat','Persian','Female','2022-08-03'),
 (3,2,'Milo','Dog','Shih Tzu','Male','2020-05-20'),(4,3,'Coco','Cat','Puspin','Female','2023-01-15'),(5,4,'Max','Dog','Beagle','Male','2019-11-02');
INSERT INTO vaccinations (pet_id,vaccine,vac_date,next_due) VALUES
 (1,'Anti-Rabies','2026-03-10','2027-03-10'),(1,'5-in-1 (DHPP)','2026-03-10','2027-03-10'),(1,'Bordetella','2026-09-02','2027-09-02'),
 (2,'FVRCP','2025-12-10','2026-12-10'),(3,'5-in-1 (DHPP)','2026-10-28','2027-10-28');
INSERT INTO checkups (pet_id,checkup_date,vet,details,findings) VALUES
 (1,'2026-10-14','Dr. Reyes','Routine wellness exam','Healthy, normal weight'),(1,'2026-06-03','Dr. Lim','Skin irritation','Mild dermatitis, topical given'),
 (1,'2026-03-10','Dr. Reyes','Annual check-up','No issues');
INSERT INTO confinements (pet_id,admitted,discharged,status,reason,treatment) VALUES (1,'2026-06-05','2026-06-08','Discharged','Observation','IV fluids');
INSERT INTO surgeries (pet_id,procedure_name,surgery_date,vet) VALUES (1,'Neutering','2025-07-20','Dr. Lim'),(1,'Dental scaling','2025-01-08','Dr. Reyes');
INSERT INTO appointments (pet_id,appt_date,appt_time,service,vet,branch,status,reason,source) VALUES
 (1,CURDATE(),'09:00','Vaccination','Dr. Reyes','Cainta','Confirmed','Anti-Rabies booster','Staff'),
 (3,CURDATE(),'09:30','Check-Up','Dr. Lim','Taytay','Confirmed','Wellness exam','Staff'),
 (4,CURDATE(),'13:00','Vaccination','Dr. Reyes','Cainta','Pending','Booster','Staff'),
 (2,DATE_ADD(CURDATE(),INTERVAL 12 DAY),'14:30','Check-Up','Dr. Lim','Taytay','Pending','Sneezing','Online');
INSERT INTO sales (id,sale_date,payment,total,branch,served_by,status,paid) VALUES (1001,CURDATE(),'Cash',1150.00,'Cainta','Demo','Paid',1150.00),(1002,CURDATE(),'GCash',1800.00,'Cainta','Demo','Paid',1800.00);
INSERT INTO sale_payments (sale_id,method,amount,received,ref,taken_by,pay_group) VALUES (1001,'Cash',1150.00,1150.00,NULL,'Demo','demo-1001'),(1002,'GCash',1800.00,1800.00,'GC-0000001','Demo','demo-1002');
INSERT INTO sale_items (sale_id,item,qty,unit_price) VALUES (1001,'Heartgard Plus (11-25 kg)',2,450),(1001,'Vitamin Syrup 60ml',1,250),(1002,'Dog Food 5kg',1,1800);
INSERT IGNORE INTO products (name,price) VALUES ('Heartgard Plus (11-25 kg)',450),('Vitamin Syrup 60ml',250),('Dog Food 5kg',1800),('Flea & Tick Spray',420),('Amoxicillin 250mg (per tablet)',35),('Deworming Tablet',160),('Cat Litter 10L',380);

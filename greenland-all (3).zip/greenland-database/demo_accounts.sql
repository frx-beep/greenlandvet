-- Greenland Veterinary Clinic: DEMO ACCOUNTS for testing the queue, duty roster, charge sheets, billing and notifications.
-- Import AFTER schema.sql (or upgrade_from_previous.sql). Safe to import more than once. Do NOT use on the real clinic's live database.
-- Every account below has the password:  Demo@1234   (it can be changed in each app's profile page).
USE greenland_vet;

INSERT IGNORE INTO clients (id,name,address,email,phone,branch) VALUES
 (101,'Maria Santos','12 Rizal Ave, Cainta, Rizal','maria.santos@example.com','0917 111 2222','Cainta'),
 (102,'Juan Dela Cruz','45 E. Rodriguez, Taytay, Rizal','juan.delacruz@example.com','0918 333 4444','Taytay');
INSERT IGNORE INTO pets (id,client_id,name,species,breed,sex,birthdate) VALUES
 (101,101,'Bruno','Dog',NULL,NULL,NULL),                       -- incomplete on purpose: shows the "complete pet details" prompt at check-in
 (102,101,'Mochi','Cat','Puspin','Female','2022-03-14'),
 (103,102,'Kiko','Dog','Shih Tzu','Male','2021-08-02');

INSERT IGNORE INTO accounts (role,name,email,username,password,branch,must_change,email_verified,client_id) VALUES
 ('admin','Demo Admin','admin@greenlandvet.test','admin.demo','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.',NULL,0,1,NULL),
 ('staff','Ana Reyes (Front Desk)','staff.cainta@greenlandvet.test','staff.cainta','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Cainta',0,1,NULL),
 ('staff','Ben Lim (Front Desk)','staff.taytay@greenlandvet.test','staff.taytay','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Taytay',0,1,NULL),
 ('vet','Dr. Gian Santos','gian@greenlandvet.test','dr.gian','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Cainta',0,1,NULL),
 ('vet','Dr. Mae Villanueva','mae@greenlandvet.test','dr.mae','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Cainta',0,1,NULL),
 ('vet','Dr. Paolo Cruz','paolo@greenlandvet.test','dr.paolo','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Cainta',0,1,NULL),
 ('vet','Dr. Lea Navarro','lea@greenlandvet.test','dr.lea','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Cainta',0,1,NULL),
 ('vet','Dr. Ken Ramos','ken@greenlandvet.test','dr.ken','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Taytay',0,1,NULL),
 ('vet','Dr. Ana Lopez','ana@greenlandvet.test','dr.ana','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Taytay',0,1,NULL),
 ('client','Maria Santos','maria.santos@example.com','maria.santos','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Cainta',0,1,101),
 ('client','Juan Dela Cruz','juan.delacruz@example.com','juan.delacruz','$2y$10$DE41mbjaHiw.oWhWEgIG9eNG88CcRhGD271pZ20BRQXeOUiL8Otq.','Taytay',0,1,102);

-- Weekly duty pattern at Cainta (4 vets rotate, 2 to 3 on duty every day Mon-Sat). Taytay has 2 vets and no pattern, so both are on duty every day.
-- weekday: 0 = Sunday ... 6 = Saturday.
INSERT IGNORE INTO vet_duty_default (account_id, weekday)
  SELECT a.id, w.d FROM accounts a JOIN (
    SELECT 'dr.gian' u, 1 d UNION SELECT 'dr.gian',2 UNION SELECT 'dr.gian',4 UNION SELECT 'dr.gian',6
    UNION SELECT 'dr.mae',1 UNION SELECT 'dr.mae',3 UNION SELECT 'dr.mae',5
    UNION SELECT 'dr.paolo',2 UNION SELECT 'dr.paolo',3 UNION SELECT 'dr.paolo',5 UNION SELECT 'dr.paolo',6
    UNION SELECT 'dr.lea',1 UNION SELECT 'dr.lea',4 UNION SELECT 'dr.lea',5 UNION SELECT 'dr.lea',6) w ON w.u=a.username;

-- Products (vets add them to charge sheets, the front desk bills them). Safe to import more than once.
INSERT IGNORE INTO products (name,price) VALUES ('Heartgard Plus (11-25 kg)',450),('Vitamin Syrup 60ml',250),('Dog Food 5kg',1800),('Flea & Tick Spray',420),('Amoxicillin 250mg (per tablet)',35),('Deworming Tablet',160),('Cat Litter 10L',380);

-- A few appointments for TODAY (or the next open day if today is Sunday).
-- Check-ups are first come, first served (is_queue = 1, no time: they get a queue number when the QR code is scanned at arrival). Vaccinations are queue registrations too (Update 20). Only surgery and confinement keep a booked time.
SET @d = IF(DAYOFWEEK(CURDATE())=1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), CURDATE());
-- Make sure four vets are on duty today so the queue can be tried whatever the weekday is.
INSERT IGNORE INTO vet_duty (account_id, duty_date, on_duty) SELECT id, @d, 1 FROM accounts WHERE username IN ('dr.gian','dr.mae','dr.ken','dr.ana');
INSERT IGNORE INTO appointments (pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,is_queue) VALUES
 (101,@d,'00:00:00','Check-Up',NULL,'Cainta','Confirmed','Itchy skin and loss of appetite','Online','a1b2c3d4e5f60718293a4b5c',1),
 (102,@d,'00:00:00','Vaccination',NULL,'Cainta','Confirmed','Annual booster','Online','b2c3d4e5f60718293a4b5c6d',1),
 (103,@d,'00:00:00','Check-Up',NULL,'Taytay','Confirmed','Skin rash','Online','c3d4e5f60718293a4b5c6d7e',1);

-- An old unpaid bill so the "Owes" badge, Balances list and statement can be tried: Juan owes 800 from 20 days ago (bill of 1,000: Check-up 500 + 2 Deworming 320 + Vitamin 180, 200 paid in cash).
INSERT IGNORE INTO sales (id,sale_date,client_id,pet_id,payment,total,branch,served_by,status,paid,prepared_by,ready_at,created_at) VALUES
 (9001,DATE_SUB(CURDATE(),INTERVAL 20 DAY),102,103,'Unpaid',1000.00,'Taytay','Ben Lim (Front Desk)','Partially paid',200.00,'Dr. Ken Ramos',DATE_SUB(NOW(),INTERVAL 20 DAY),DATE_SUB(NOW(),INTERVAL 20 DAY));
INSERT IGNORE INTO sale_items (id,sale_id,item,qty,unit_price,product_id) VALUES
 (90001,9001,'Check-up Fee',1,500.00,NULL),(90002,9001,'Deworming Tablet',2,160.00,NULL),(90003,9001,'Vitamin Syrup 60ml',1,180.00,NULL);
INSERT IGNORE INTO sale_payments (id,sale_id,method,amount,received,taken_by,pay_group,created_at) VALUES
 (90001,9001,'Cash',200.00,200.00,'Ben Lim (Front Desk)','demo000000000001',DATE_SUB(NOW(),INTERVAL 20 DAY));
-- Update 13: a Taytay patient referred to Cainta for confinement (not arrived yet), so the Confined page and the "Mark arrived" step can be tried.
INSERT INTO confinements (pet_id,admitted,status,reason,recorded_at,recorded_by,branch,vet,admitted_at,daily_rate,referred_from,arrived_at)
  SELECT p.id, CURDATE(), 'Admitted', 'Referred for observation (demo)', NOW(), 'Demo', 'Cainta', (SELECT name FROM accounts WHERE role='vet' AND branch='Taytay' ORDER BY id LIMIT 1), NOW(), 800, 'Taytay', NULL
  FROM pets p WHERE p.client_id=102 AND NOT EXISTS (SELECT 1 FROM confinements c WHERE c.pet_id=p.id AND c.status='Admitted') ORDER BY p.id LIMIT 1;

<?php require 'layout.php'; top('My Patients', 'd'); ?>
<div id="duty"></div>
<div class="kpis tab">
  <div class="card kp"><span id="ic1"></span><h2>Patients today</h2><div class="big" id="cnt">0</div><span class="muted" id="cntS"></span></div>
  <div class="card kp"><span id="ic2"></span><h2>Confined</h2><div class="big" id="conf">0</div><span class="muted" id="surgS"></span><div class="btns"><a class="btn ghost" href="confined.php">Confined patients</a></div></div>
  <div class="card kp" id="pendCard"><span id="ic3"></span><h2>Records to complete</h2><div class="big" id="pend">0</div><span class="muted">Visits you finished whose findings are not typed yet.</span><div class="btns"><a class="btn ghost" href="general.php?type=pending&mine=1">Open the list</a></div></div>
</div>
<div class="card"><div class="hd"><h2>My patients</h2><small class="muted" id="wait"></small></div><div id="pts"></div></div>
<script>
let R = null;
$('#crumb').textContent = new Date().toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
const sevc = s => s ? `<span class="sevc ${E(s.toLowerCase())}">${E(s)}</span>` : '';
function state(r) {
  if (r.status === 'Completed') return '<span class="badge g">Done</span>';
  if (r.started_at) return '<span class="badge">With you</span>';
  if (r.called_at) return '<span class="badge p">Called: ' + E(r.room || '') + '</span>';
  return '<span class="badge p">Arrived</span>';
}
function bill(r) {
  if (!r.bill_status || r.bill_status === 'Draft') return '';
  return `<span class="badge ${r.bill_status === 'Paid' || r.bill_status === 'Transferred' ? 'g' : 'x'}">${E(r.bill_status)}${r.bill_total ? ' &middot; ' + peso(r.bill_total) : ''}</span>`;
}
function card(r) {
  const done = r.status === 'Completed', needRec = done && !+r.record_done;
  const sk = done ? 'done' : +r.priority ? 'emerg' : r.referred_from ? 'ref' : (r.called_at || r.started_at) ? 'room' : 'wait';
  return `<div class="pt ${done ? 'dn' : ''}${stc(sk)}"><div class="pt-n">${+r.is_queue ? (r.queue_no ? '#' + r.queue_no : '&bull;') : fmtTime(r.time)}</div>${pav(r.pet, r.species, null)}
    <div class="pt-b"><h3>${E(r.pet)} ${sevc(r.severity)} ${r.referred_from ? `<span class="tag">Referred from ${E(r.referred_from)}</span>` : ''}</h3><p>${E(r.client)} &middot; ${E(r.service)}${r.room ? ' &middot; ' + E(r.room) : ''}${r.called_at ? ' &middot; since ' + fmtTime(r.called_at.slice(11, 16)) : ''}</p>
      <p>${state(r)} ${bill(r)} ${+r.owes > 0 ? `<span class="owes">Owes ${peso(r.owes)}</span>` : ''} ${needRec ? '<span class="badge p">Pending record</span>' : done && +r.record_done ? '<span class="badge g">Record saved</span>' : ''}</p></div>
    <div class="pt-a">${done ? (needRec ? `<a class="btn big" href="service_form.php?type=${APPT_TYPE[r.service]}&pet_id=${r.pet_id}&appt=${r.id}">Write record</a>` : '') + `<a class="btn plain big" href="charge.php?appt=${r.id}">View sheet</a>`
      : `<a class="btn big" href="charge.php?appt=${r.id}">Charge sheet / Done</a>`}</div></div>`;
}
async function load() {
  try { R = await api('/api/mypatients'); } catch (x) { $('#pts').innerHTML = `<p class="err">${E(x.message)}</p>`; return; }
  const open = R.rows.filter(r => r.status !== 'Completed').length;
  $('#cnt').textContent = R.rows.length; $('#cntS').textContent = open ? open + ' still to finish' : R.rows.length ? 'all finished' : 'nobody assigned yet';
  $('#conf').textContent = R.confined; $('#surgS').textContent = (R.surgery || []).map(r => r.free ? r.name + ' is free' : r.name + ': ' + r.pet).join(' · ') || 'staying with us';
  $('#pend').textContent = R.pending_records; $('#pendCard').classList.toggle('alert', R.pending_records > 0);
  $('#wait').textContent = R.waiting ? R.waiting + ' waiting in the queue' : 'Nobody waiting in the queue';
  $('#duty').innerHTML = R.on_duty ? '' : `<p class="devnote strip">You are marked as <b>not on duty</b> today, so no new patients are sent to you. <button type="button" class="link" id="imin">I am in today</button></p>`;
  if ($('#imin')) $('#imin').onclick = async () => { try { await api('/api/duty', { vet_id: <?= (int)(current_account()['id'] ?? 0) ?>, date: today(), on: true }); load(); } catch (x) { alert(x.message); } };
  $('#pts').innerHTML = R.rows.length ? R.rows.map(card).join('') : '<p class="muted" style="margin:0">No patients assigned to you yet. When the front desk checks a patient in and a room is free, the next patient in line appears here (you also get a notification).</p>';
}
if (window.UI14) { $('#ic1').outerHTML = uic('users'); $('#ic2').outerHTML = uic('bed'); $('#ic3').outerHTML = uic('stethoscope'); } else ['#ic1', '#ic2', '#ic3'].forEach(i => $(i).remove());
load(); setInterval(load, 15000);
</script>
<?php bottom(); ?>

<?php require 'layout.php'; top('My Pets', 'p'); ?>
<script src="qr.js?v=<?= filemtime(__DIR__ . '/qr.js') ?>"></script>
<div class="card welcome"><div><h2 id="hello">Welcome back</h2><p class="muted" style="margin:.2rem 0 0">Your pets' records and upcoming visits are here.</p></div><div class="nextbox" id="next"></div></div>
<div class="card owes-b" id="owe" hidden style="margin-top:1rem"></div>
<div class="card devnote" id="conf" hidden style="margin-top:1rem"></div>
<div class="hd" style="margin-top:1.5rem"><h2>My Pets</h2><button type="button" class="btn sm" id="addpet">+ Add Pet</button></div><div class="petgrid" id="pets"></div>
<input type="file" id="pfile" accept="image/*" hidden>
<script>
let target = null;
async function load() {
  try {
    const [me, r] = await Promise.all([api('/api/auth/me'), api('/api/pets')]);
    $('#hello').textContent = 'Welcome back, ' + me.name.split(' ')[0];
    const n = r.next; $('#owe').hidden = !(r.balance > 0); if (r.balance > 0) $('#owe').innerHTML = `<b>You have an unpaid balance of ${peso(r.balance)}.</b> <span class="muted">Please settle it at the front desk on your next visit.</span>`;
    $('#next').innerHTML = '<small>Next Appointment</small>' + (n ? `<div><b>${E(fmtDay(n.appt_date))}, ${+n.is_queue ? 'any time' : fmtTime(n.time)}</b></div><div>${E(n.pet)}: ${E(n.service)}</div><small>Greenland Vet, ${E(n.branch)}</small> ${badge(n.status)} <button type="button" class="btn ghost sm" id="nq">Show QR</button> <a class="link" href="appointments.php">View all</a>`
      : '<div>No upcoming appointments</div><a class="link" href="request.php">+ Request one</a>');
    if (n) $('#nq').onclick = () => qrDialog(n);
    $('#pets').innerHTML = r.pets.length ? r.pets.map(p => `<div class="card petcard">
      ${p.photo ? `<div class="ph" style="background-image:url(${p.photo})"></div>` : '<div class="ph">Pet photo</div>'}<div><h3>${E(p.name)}</h3>
      <p class="muted">${E([p.species, p.breed].filter(Boolean).join(' \u00B7 '))}</p><p class="muted">${E([p.birthdate ? 'Born ' + fmtDate(p.birthdate) : '', p.sex].filter(Boolean).join(' \u00B7 '))}</p>
      <span class="badge ${p.vacc.ok ? '' : 'p'}">${E(p.vacc.text)}</span>${missingOf(p).length ? ` <span class="badge p" title="Missing: ${E(missingOf(p).join(', '))}. The clinic will complete these at check-in.">Details incomplete</span>` : ''}
      <div style="margin-top:.6rem;display:flex;gap:.5rem;flex-wrap:wrap"><a class="btn ghost sm" href="pet_records.php?id=${p.id}">View Records</a><button type="button" class="btn plain sm" data-ph="${p.id}">${p.photo ? 'Change photo' : 'Add photo'}</button></div></div></div>`).join('')
      : '<p class="muted">No pets are registered under your account yet. Please contact the clinic.</p>';
    $$('[data-ph]').forEach(b => b.onclick = () => { target = b.dataset.ph; $('#pfile').click(); });
  } catch (x) { $('#pets').innerHTML = `<p class="err">${E(x.message)}</p>`; }
}
$('#pfile').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f || !target) return;
  try { await api(`/api/pets/${target}/photo`, { photo: await resizeImage(f) }); load(); } catch (x) { alert(x.message); }
};
$('#addpet').onclick = () => dialog(`<h3>Add a pet</h3><label>Pet's name<input name="name"></label>
  <div class="fr"><label>Species<select name="species"><option>Dog</option><option>Cat</option></select></label><label>Sex<select name="sex"><option value="">Not sure</option><option>Male</option><option>Female</option></select></label></div>
  <div class="fr"><label>Breed (optional)<input name="breed"></label><label>Birthdate (optional)<input type="date" name="birthdate" max="${today()}"></label></div>
  <p class="muted" style="margin:0">You can leave details blank. The clinic completes them when you visit.</p>`, async f => { await api('/api/pets', f); load(); });
api('/api/confined').then(l => { const c = $('#conf'); c.hidden = !l.length; c.innerHTML = l.map(x => `<b>${E(x.pet)} is staying at the clinic</b> since ${E(fmtDay(x.since))} (${x.days} day${x.days === 1 ? '' : 's'}, ${E(x.branch)} branch).${x.referred_from && !x.arrived ? ` Please bring ${E(x.pet)} to the ${E(x.branch)} branch: ${E(x.address)}.` : ''}`).join('<br>'); }).catch(() => {});
load();
</script>
<?php bottom(); ?>

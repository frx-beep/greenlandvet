<?php require 'layout.php'; top('Pet Records', 'p', 'My Pets'); ?>
<a class="btn plain" href="pets.php" style="margin-bottom:1rem">&larr; My Pets</a>
<div class="card petbar"><div class="ph">Pet photo</div><div><h2 id="pn"></h2><p class="muted" id="pl" style="margin:.2rem 0 .5rem"></p><span class="pill" id="own"></span></div><span class="badge g">Read-only view</span></div>
<div class="stackc" id="g" style="margin-top:1.25rem"></div>
<script>
(async () => {
  try {
    const r = await api('/api/pets/' + param('id')), p = r.pet;
    $('#crumb').textContent = 'My Pets > ' + p.name; $('#pn').textContent = p.name;
    if (p.photo) { const ph = $('.ph'); ph.style.backgroundImage = `url(${p.photo})`; ph.textContent = ''; }
    $('#pl').textContent = [[p.species, p.breed].filter(Boolean).join(' \u00B7 '), p.sex, p.birthdate ? 'Born ' + fmtDate(p.birthdate) : ''].filter(Boolean).join(' \u00B7 ');
    $('#own').textContent = 'Owner: ' + p.client;
    // Update 17: owners also see the prescription (full text) on each check-up
    SVC.checkup.pet = [...SVC.checkup.pet.slice(0, 3), ['Prescription', r => '<span style="white-space:pre-wrap">' + E(r.prescription || '-') + '</span>'], ...SVC.checkup.pet.slice(3)];
    $('#g').innerHTML = Object.entries(SVC).map(([t, s]) => `<div class="card"><h2>${s.card}</h2><div id="t-${t}"></div></div>`).join('');
    Object.entries(SVC).forEach(([t, s]) => renderTable($('#t-' + t), s.pet, r[t]));
  } catch (x) { $('#g').innerHTML = `<p class="err">${E(x.message)}</p>`; }
})();
</script>
<?php bottom(); ?>

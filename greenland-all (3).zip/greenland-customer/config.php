<?php
// ================= Greenland Veterinary Clinic: Customer app =================
// ---- Database: ALL apps must point at the SAME database ----
const DB_HOST = 'localhost';
const DB_NAME = 'greenland_vet';
const DB_USER = 'root';
const DB_PASS = 'yuro4567';

// ---- Email (sign-in codes, password resets) ----
const MAIL_FROM = 'no-reply@greenlandvet.com';
const DEV_SHOW_CODE = true;   // TESTING ONLY: shows sign-in codes/links on screen because email isn't set up. Set to false when real email works.

// ---- Where each app lives (used in emailed links). Change these when you get your real domains. ----
const SITE_URLS = [
    'client' => 'http://localhost/greenland-customer/',
    'staff'  => 'http://localhost/greenland-staff/',
    'vet'    => 'http://localhost/greenland-vet/',
    'admin'  => 'http://localhost/greenland-admin/',
];

// ---- Smart scheduling: clinic hours, slots, services and rooms ----
const CLINIC_OPEN = '09:00';
const CLINIC_CLOSE = '17:00';
const SLOT_MINUTES = 15;                 // vaccinations take 10 to 15 minutes, so booked times are every 15 minutes
const CLOSED_DAYS = [0];                 // 0 = Sunday (the clinic is open Mon-Sat)
const DEFAULT_CAPACITY = 2;              // bookings per time slot while no vet accounts exist yet
const SERVICE_MINUTES = ['Vaccination' => 15, 'Check-Up' => 45, 'Confinement' => 30, 'Surgery' => 60];
const ROOMS = ['Room 1', 'Room 2', 'Room 3'];

// ---- Booking policies and notification timing (EDIT TO THE CLINIC'S RULES) ----
const ONLINE_LEAD_MINUTES = 60;    // travel-time buffer: online bookings for today must start at least this long from now
const ONLINE_CLOSE_BUFFER = 60;    // online bookings may not start within this long of closing time (they move to the next day)
const LATE_ALERT_MINUTES  = 10;    // TIMED bookings only (vaccination etc.): patient not arrived after this long -> late alert to owner, staff and vet
const LATE_CANCEL_MINUTES = 60;    // TIMED bookings only (surgery): patient not arrived after this long (about an hour) -> auto-cancelled and the slot freed
const OWNER_CANCEL_HOURS  = 2;     // pet owners can cancel/reschedule online until this long before the appointment
const MAX_RESCHEDULES     = 2;     // times an owner may reschedule one appointment online
const MAX_BOOKING_ITEMS   = 6;     // pets/services in one booking

// ---- Update 12: queue (first come, first served), duty roster and fees (EDIT TO THE CLINIC'S RULES) ----
const QUEUE_SERVICES = ['Vaccination', 'Check-Up'];   // first come, first served: a day registration, no booked time (Update 20). Remove 'Vaccination' to go back to booked times. Surgery and confinement keep booked times.
const SEVERITY_MINUTES = ['Routine' => 60, 'Moderate' => 90, 'Severe' => 150];   // used only to ESTIMATE waiting time, never to change the order
const QUEUE_LAST_ARRIVAL = '17:00';             // last time a new check-up can join the queue (everyone already waiting is still seen)
// Default professional fees pre-filled on the vet's charge sheet (the vet can change them per visit). EDIT TO THE CLINIC'S REAL FEES.
const SERVICE_FEES = ['Vaccination' => 300, 'Check-Up' => 500, 'Confinement' => 1500, 'Surgery' => 3000];

// ---- Update 13: confinement and surgery (EDIT TO THE CLINIC'S RULES) ----
const MAIN_BRANCH = 'Cainta';                    // confinement and surgery happen only at this branch. Taytay refers its patients here.
const CONFINEMENT_DAILY_RATE = 800;              // PLACEHOLDER (pesos per calendar day). The admission day counts; same-day discharge = 1 day. Replace with the clinic's real rate.
const SURGERY_ROOMS = ['Surgery Room'];          // one surgery at a time per room. Add a name here if the clinic gets another surgery room.

// ---- Update 14 (EDIT TO THE CLINIC'S RULES) ----
const MIN_VETS_ON_DUTY = ['Cainta' => 2, 'Taytay' => 1];   // the roster warns when fewer vets than this are on duty (Taytay is a small wellness branch: 1 vet, 1 assistant)
const REFERRAL_REASONS = ['X-ray', 'Ultrasound', 'Laboratory tests', 'Other diagnostics'];   // Taytay sends these cases to the main branch
const SMS_ENABLED = false;          // set true once an SMS service is chosen (see sms_send() in authlib.php)
const SMS_PROVIDER = '';            // name of the chosen SMS service, e.g. 'semaphore'
const SMS_API_KEY = '';
const SMS_SENDER = 'GREENLAND';
const OWNER_MESSAGE_CHANNELS = ['email'];   // add 'sms' once SMS_ENABLED is true
const CLINIC_MESSAGE_CONTACT = 'our Facebook page or call the clinic';   // used in the owner messages ("message us at ...")

// ---- This app (you normally don't need to change anything below) ----
const APP_ROLE = 'client';           // client | staff | vet | admin
const APP_NAME = 'Customer';
const LOGIN_BY = 'username';       // sign in with 'username' or 'email'
const NEEDS_BRANCH = false;
const AUTH_LAYOUT = 'split';
const LOGIN_TITLE = 'Pet Owner Login';
const LOGIN_SUB = "View your pets' records and appointments.";
const BRAND_H2 = 'Welcome to Greenland Veterinary Clinic';
const BRAND_P = 'Pet Owner Portal';
const BRAND_LIST = '<ul class="bl"><li>See your pets\' records and vaccine dates</li><li>Request appointments from home</li><li>Get reminders by email</li></ul>';
const HOME = 'pets.php';
const PORTAL_LABEL = 'Pet Owner Portal';
const HAS_SEARCH = false;
const SEARCH_PH = '';
const SEARCH_ACTION = '';
const SHOW_BRANCH = false;
const HAS_BELL = true;          // notification bell (every role)
const PROFILE_URL = 'profile.php';   // page opened by clicking the round avatar
const NAV = ['p' => ['pets.php', 'My Pets'], 's' => ['services.php', 'Services']] + ['a' => ['appointments.php', 'Appointments'], 'c' => ['contact.php', 'Contact'], 'm' => ['profile.php', 'My Profile']];
const BRANCHES = ['Cainta', 'Taytay'];
const SERVICES = ['Vaccination', 'Check-Up', 'Confinement', 'Surgery'];
const BRANCH_INFO = [
    'Cainta' => ['main' => true, 'address' => '3rd Floor, Rublou-Brookside, Ortigas Ave. Ext. Cor. Sunset Drive, Cainta, Rizal', 'phone' => '0969 270 6737 / 7000 9080', 'hours' => 'Mon–Sat · 9:00 AM – 5:00 PM'],
    'Taytay' => ['address' => '63 E. Rodriguez, San Isidro, Taytay, Rizal', 'phone' => '0985 424 1557', 'hours' => 'Mon–Sat · 9:00 AM – 5:00 PM'],
];

// Services pet owners can request online. Confinement and surgery are decided by the veterinarian.
const REQUESTABLE = ['Vaccination', 'Check-Up'];
const FACEBOOK = '@greenlandveterinarycarecenter';
const CONTACT_EMAIL = 'greenlandvetcarecenter@gmail.com';

// ---- Update 15: look and feel. Each switch can be turned off on its own; false puts the old look back. ----
const UI_UPGRADE = true;        // pet avatars, status colours, KPI icons and trends, calendar dots, pet timeline, login polish, report charts
const UI_DARK_MODE = true;        // moon / sun button in the top bar (staff and vet apps only)
const UI_NOW_SERVING = false;     // staff app: "Now serving" card on the dashboard and a small panel on the other pages (queue number, pet, room, who is next)
const IDLE_LOGOUT_MINUTES = 30;   // Update 17: sign out after this many minutes without a click, key press or touch (0 = never)

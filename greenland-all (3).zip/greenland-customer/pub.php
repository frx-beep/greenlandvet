<?php
require_once __DIR__ . '/authlib.php';
function pub_top(string $title, bool $wide = false): void { $in = current_account() !== null; $GLOBALS['pub_wide'] = $wide; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> - Greenland Veterinary Clinic</title>
<link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>"><script src="app.js?v=<?= filemtime(__DIR__ . '/app.js') ?>"></script><?php ui_head(); ?></head>
<body style="display:block" class="site">
<nav class="pubnav"><a class="brandt" href="index.php"><img src="logo.png" alt="Greenland Veterinary Clinic"></a>
  <a class="nl" href="index.php">Home</a><a class="nl" href="index.php#services">Services</a><a class="nl" href="index.php#how">How it works</a><a class="nl" href="index.php#about">About</a><a class="nl" href="index.php#branches">Branches</a><a class="nl" href="contact.php">Contact</a>
  <?php if (!$in): ?><a class="nl" href="register.php">Register</a><?php endif; ?>
  <a class="btn" href="<?= $in ? 'pets.php' : 'login.php' ?>"><?= $in ? 'My Portal' : 'Pet Owner Login' ?></a></nav>
<?php if (!$wide): ?><main class="pubmain"><?php endif; ?>
<?php }
function pub_bottom(): void { $c = cms(); $wide = !empty($GLOBALS['pub_wide']); if (!$wide) echo '</main>'; ?>
<footer class="sitefoot"><div class="sf-in">
  <div><img class="sf-logo" src="logo.png" alt="Greenland Veterinary Clinic"><p><?= h(trim($c['footer_text'] ?? '') ?: 'Caring for your pets at our Cainta and Taytay branches.') ?></p></div>
  <div><h4>Visit</h4><?php foreach (BRANCH_INFO as $n => $b): ?><p><b><?= h($n) ?></b><br><?= h($b['address']) ?><br><?= h($b['phone']) ?></p><?php endforeach; ?></div>
  <div><h4>Hours</h4><p>Monday to Saturday<br><?= h(date('g:i A', strtotime(CLINIC_OPEN)) . ' to ' . date('g:i A', strtotime(CLINIC_CLOSE))) ?></p><h4>Online</h4><p>Facebook: <?= h(FACEBOOK) ?><br><?= h(CONTACT_EMAIL) ?></p></div>
  <div><h4>Pet owners</h4><p><a href="login.php">Login</a><br><a href="register.php">Create an account</a><br><a href="contact.php">Contact us</a></p></div>
</div><div class="sf-copy">&copy; <?= date('Y') ?> Greenland Veterinary Clinic</div></footer></body></html><?php }
function svc_icon(string $n): string {
    $p = ['Vaccination' => '<path d="m18 2 4 4"/><path d="m17 7 3-3"/><path d="M19 9 8.7 19.3a2 2 0 0 1-2.8 0l-1.2-1.2a2 2 0 0 1 0-2.8L15 5"/><path d="m9 11 4 4"/><path d="m5 19-3 3"/><path d="m14 4 6 6"/>',
        'Check-Up' => '<path d="M11 2v2"/><path d="M5 2v2"/><path d="M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1"/><path d="M8 15a6 6 0 0 0 12 0v-3"/><circle cx="20" cy="10" r="2"/>',
        'Confinement' => '<path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8"/><path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4"/><path d="M12 4v6"/><path d="M2 18h20"/>',
        'Surgery' => '<path d="M3 21l7-7"/><path d="M9 15l3-3"/><path d="M12 12c3-1 6-4 9-9-5 3-8 6-9 9z"/>',
        'user' => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>', 'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        'qr' => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h3M20 17v4"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 'pin' => '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>', 'phone' => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>'];
    return '<svg viewBox="0 0 24 24" aria-hidden="true">' . ($p[$n] ?? '') . '</svg>';
}
const SITE_ART = '<svg viewBox="0 0 320 170" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g fill="#e6f4f1"><ellipse cx="50" cy="92" rx="17" ry="36" transform="rotate(14 50 92)"/><ellipse cx="150" cy="92" rx="17" ry="36" transform="rotate(-14 150 92)"/><ellipse cx="100" cy="98" rx="47" ry="50"/><path d="M172 78 182 28l28 28zM268 78 258 28l-28 28z"/><ellipse cx="220" cy="102" rx="52" ry="47"/></g><g fill="#c7e6e0"><ellipse cx="100" cy="120" rx="24" ry="17"/><ellipse cx="220" cy="118" rx="22" ry="14"/></g><g fill="#0a4a45"><circle cx="84" cy="88" r="5"/><circle cx="116" cy="88" r="5"/><ellipse cx="100" cy="111" rx="9" ry="6.5"/><circle cx="203" cy="98" r="5"/><circle cx="237" cy="98" r="5"/><path d="M213 112h14l-7 8z"/></g><g stroke="#0a4a45" stroke-width="2.5" stroke-linecap="round" fill="none"><path d="M100 117v9M92 130q8 6 16 0"/><path d="M196 114l-30-6M196 120l-30 4M244 114l30-6M244 120l30 4M220 120q-6 8-12 4M220 120q6 8 12 4"/></g></svg>';
function branch_cards(bool $contact = false): void {
    foreach (BRANCH_INFO as $name => $b) { ?>
  <div class="card"><h3><?= $name ?> Branch<?= !empty($b['main']) && $contact ? ' <span class="badge">Main Branch</span>' : '' ?></h3>
    <?php if ($contact): ?><dl><dt>Contact Number</dt><dd><?= $b['phone'] ?></dd><dt>Address</dt><dd><?= $b['address'] ?></dd></dl>
    <?php else: ?><p style="margin:.2rem 0"><?= $b['address'] ?></p><p class="muted" style="margin:0"><?= $b['hours'] ?> &middot; <?= $b['phone'] ?></p><?php endif; ?></div>
<?php } }

// ---- content the admin manages in Page Management (Update 11) ----
// Update 17: is the clinic open right now? Uses CLINIC_OPEN, CLINIC_CLOSE and CLOSED_DAYS from config.php (Manila time).
function open_status(): array {
    $fmt = fn(string $t) => date('g:i A', strtotime("2000-01-01 $t"));
    $now = date('H:i'); $w = (int)date('w'); $closed = defined('CLOSED_DAYS') ? CLOSED_DAYS : [];
    if (!in_array($w, $closed, true) && $now >= CLINIC_OPEN && $now < CLINIC_CLOSE) return [true, 'Closes today at ' . $fmt(CLINIC_CLOSE)];
    if (!in_array($w, $closed, true) && $now < CLINIC_OPEN) return [false, 'Opens today at ' . $fmt(CLINIC_OPEN)];
    for ($i = 1; $i <= 7; $i++) { $d = ($w + $i) % 7; if (!in_array($d, $closed, true)) return [false, 'Opens ' . ($i === 1 ? 'tomorrow' : date('l', strtotime("+$i day"))) . ' at ' . $fmt(CLINIC_OPEN)]; }
    return [false, 'Closed'];
}
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES); }
function cms_promo(): void { $c = cms(); if (!empty($c['promo_on']) && trim($c['promo_text'] ?? '') !== '') echo '<div class="promo">' . h($c['promo_text']) . '</div>'; }
function cms_offers(string $kind = 'promo', string $title = ''): void {
    $rows = array_values(array_filter(cms_items(), fn($i) => $i['kind'] === $kind)); if (!$rows) return;
    if ($title !== '') echo '<h2 style="margin-top:1.5rem">' . h($title) . '</h2>'; ?>
<div class="offers"><?php foreach ($rows as $i): ?>
  <div class="card offer"><?php if ($i['image']): ?><img src="<?= h($i['image']) ?>" alt=""><?php endif; ?>
    <div class="ob"><h3><?= h($i['title']) ?></h3><?php if ($i['description']): ?><p class="muted" style="margin:.2rem 0 .5rem"><?= h($i['description']) ?></p><?php endif; ?>
    <?php if ($i['price'] !== null): ?><div class="price"><b>&#8369; <?= number_format((float)$i['price'], 2) ?></b><?php if ($i['old_price'] !== null && (float)$i['old_price'] > (float)$i['price']): ?><s>&#8369; <?= number_format((float)$i['old_price'], 2) ?></s><?php endif; ?></div><?php endif; ?></div></div>
<?php endforeach; ?></div>
<?php }

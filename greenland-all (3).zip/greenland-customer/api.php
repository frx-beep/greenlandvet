<?php
require 'authlib.php';
$me   = require_login(true);
$in   = json_decode(file_get_contents('php://input'), true) ?? [];
$path = trim($_SERVER['PATH_INFO'] ?? '', '/');
$p    = explode('/', $path);
$post = $_SERVER['REQUEST_METHOD'] === 'POST';
$cid  = (int)$me['client_id'];
if (!$cid) fail('Your account is not linked to a client record yet. Please contact the clinic.', null, 403);

function vacc_status(int $pid): array {   // looks at the latest dose of each vaccine
    $r = q('SELECT v.vaccine, v.next_due FROM vaccinations v WHERE v.pet_id=? AND v.next_due IS NOT NULL
            AND v.vac_date=(SELECT MAX(v2.vac_date) FROM vaccinations v2 WHERE v2.pet_id=v.pet_id AND v2.vaccine=v.vaccine) ORDER BY v.next_due', [$pid])->fetchAll();
    if (!$r) return ['text' => 'Nothing recorded yet', 'ok' => true];
    $d = $r[0]['next_due']; $now = date('Y-m-d');
    if ($d < $now) return ['text' => 'Overdue: ' . $r[0]['vaccine'], 'ok' => false];
    if ($d <= date('Y-m-d', strtotime('+90 days'))) return ['text' => 'Next due ' . date('M Y', strtotime($d)), 'ok' => false];
    return ['text' => 'Vaccines up to date', 'ok' => true];
}

function ensure_tokens(int $cid): void {   // appointments made before QR codes existed get one the first time they are listed
    foreach (q('SELECT a.id FROM appointments a JOIN pets x ON x.id=a.pet_id WHERE x.client_id=? AND a.qr_token IS NULL AND a.appt_date>=CURDATE()', [$cid])->fetchAll(PDO::FETCH_COLUMN) as $aid)
        q('UPDATE appointments SET qr_token=? WHERE id=?', [bin2hex(random_bytes(12)), $aid]);
}
if (!$post && $path === 'pets') {
    ensure_tokens($cid);
    $pets = q('SELECT * FROM pets WHERE client_id=? ORDER BY name', [$cid])->fetchAll();
    foreach ($pets as &$x) $x['vacc'] = vacc_status((int)$x['id']);
    unset($x);
    $next = q("SELECT a.id, a.qr_token, a.appt_date, TIME_FORMAT(a.appt_time,'%H:%i') time, a.is_queue, a.service, a.branch, a.status, x.name pet FROM appointments a JOIN pets x ON x.id=a.pet_id
               WHERE x.client_id=? AND a.appt_date>=CURDATE() AND a.status IN ('Pending','Confirmed') ORDER BY a.appt_date, a.appt_time LIMIT 1", [$cid])->fetch() ?: null;
    send(['pets' => $pets, 'next' => $next, 'balance' => client_balance($cid)]);
}
if (!$post && $p[0] === 'pets' && count($p) === 2) {   // read-only records, only for the owner's own pets
    $pet = q('SELECT x.*, c.name client FROM pets x JOIN clients c ON c.id=x.client_id WHERE x.id=? AND x.client_id=?', [$p[1], $cid])->fetch();
    if (!$pet) send(['error' => 'Pet not found'], 404);
    $get = fn($t, $o) => q("SELECT * FROM $t WHERE pet_id=? ORDER BY $o DESC, id DESC", [$p[1]])->fetchAll();
    send(['pet' => $pet, 'vaccination' => $get('vaccinations', 'vac_date'), 'checkup' => $get('checkups', 'checkup_date'),
          'confinement' => $get('confinements', 'admitted'), 'surgery' => $get('surgeries', 'surgery_date')]);
}
function req_items(array $src): array {   // timed services asked for: items=[{svc}] (JSON) or service=; online requests are limited to REQUESTABLE services. Check-ups are a day registration (no time slots).
    $raw = !empty($src['items']) ? (json_decode((string)$src['items'], true) ?: []) : [['svc' => $src['service'] ?? REQUESTABLE[0]]];
    return array_values(array_filter(clean_items($raw), fn($i) => in_array($i['svc'], REQUESTABLE, true) && !is_queue_svc($i['svc'])));
}
const MAX_DAYS_AHEAD = 30;
if (!$post && $path === 'schedule/slots') {   // smart scheduling: which start times are free for everything in this booking
    $d = $_GET['date'] ?? ''; if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) fail('Choose a date.', 'date');
    $br = in_array($_GET['branch'] ?? '', BRANCHES) ? $_GET['branch'] : BRANCHES[0];
    $items = req_items($_GET); $ign = [];
    if (!empty($_GET['appt'])) {   // rescheduling one of my own bookings
        $rows = appt_rows(appt_group_ids((int)$_GET['appt']));
        if ($rows && (int)$rows[0]['client_id'] === $cid) { $ign = array_map(fn($r) => (int)$r['id'], $rows); $items = array_values(array_filter(array_map(fn($r) => ['svc' => $r['service'], 'concern' => null], $rows), fn($i) => !is_queue_svc($i['svc']))); $br = (string)$rows[0]['branch']; }
    }
    $ok = $d >= date('Y-m-d') && $d <= date('Y-m-d', strtotime('+' . MAX_DAYS_AHEAD . ' days'));
    $slots = $ok && $items ? chain_slots($d, $br, $items, null, $ign, true) : [];
    $note = null;
    if ($ok && $d === date('Y-m-d') && $slots && !array_filter($slots, fn($s) => $s['ok'])) $note = 'No more online times today (we need ' . ONLINE_LEAD_MINUTES . ' minutes\' notice and stop online bookings ' . ONLINE_CLOSE_BUFFER . ' minutes before closing). Please pick tomorrow or a later day.';
    send(['slots' => $slots, 'closed' => is_closed($d), 'range' => !$ok, 'note' => $note, 'minutes' => chain_len($items)]);
}
if (!$post && $path === 'balance') {   // what I owe the clinic (unpaid bills, both branches)
    $bills = q("SELECT s.id, s.sale_date, s.total, s.paid, s.total-s.paid balance, s.branch, (SELECT GROUP_CONCAT(i.item SEPARATOR ', ') FROM sale_items i WHERE i.sale_id=s.id) items FROM sales s WHERE s.client_id=? AND s.status IN ('Unpaid','Partially paid') ORDER BY s.sale_date, s.id", [$cid])->fetchAll();
    send(['balance' => client_balance($cid), 'bills' => $bills]);
}
if (!$post && $path === 'confined') {   // my pets that are staying at the clinic right now
    $conf = [];
    try {
        foreach (q("SELECT c.*, p.name pet FROM confinements c JOIN pets p ON p.id=c.pet_id WHERE p.client_id=? AND c.status='Admitted' ORDER BY c.admitted", [$cid])->fetchAll() as $c) {
            $d = conf_days($c); $conf[] = ['pet' => $c['pet'], 'since' => $c['admitted'], 'days' => $d['days'], 'branch' => conf_branch($c), 'referred_from' => $c['referred_from'], 'arrived' => (bool)$c['arrived_at'],
                'address' => branch_address(conf_branch($c))];
        }
    } catch (PDOException $e) {}
    send($conf);
}
if (!$post && $path === 'appointments') {
    ensure_tokens($cid);
    $base = "SELECT a.id, a.qr_token, a.vet, a.checked_in_at, a.started_at, a.room, a.appt_date, TIME_FORMAT(a.appt_time,'%H:%i') time, a.service, a.branch, a.status, a.group_token, a.is_queue, a.queue_no, a.called_at, a.done_at, a.reschedule_count, a.cancel_reason, a.cancelled_by, x.name pet
             FROM appointments a JOIN pets x ON x.id=a.pet_id WHERE x.client_id=? AND ";
    $up = q($base . "a.status IN ('Pending','Confirmed') AND a.appt_date>=CURDATE() ORDER BY a.appt_date, a.appt_time", [$cid])->fetchAll();
    foreach ($up as &$u) { $u['cant_cancel'] = owner_can_change($u); $u['cant_resched'] = owner_can_change($u, true); $u['queue'] = $u['appt_date'] === date('Y-m-d') && $u['checked_in_at'] ? queue_position((int)$u['id']) : null; }
    unset($u);
    send(['upcoming' => $up, 'past' => q($base . "NOT (a.status IN ('Pending','Confirmed') AND a.appt_date>=CURDATE()) ORDER BY a.appt_date DESC, a.appt_time DESC LIMIT 40", [$cid])->fetchAll(),
          'policy' => ['hours' => OWNER_CANCEL_HOURS, 'max_resched' => MAX_RESCHEDULES, 'last_arrival' => QUEUE_LAST_ARRIVAL], 'balance' => client_balance($cid)]);
}
if ($post && $path === 'appointments') {   // one or several pets and services in one booking; appears in the staff and vet apps as Pending. Check-ups: a day, no time.
    $list = !empty($in['items']) && is_array($in['items']) ? $in['items'] : [$in];
    if (count($list) > MAX_BOOKING_ITEMS) fail('You can book up to ' . MAX_BOOKING_ITEMS . ' services at once.');
    if (!in_array($in['branch'] ?? '', BRANCHES)) fail('Please choose a branch.', 'branch');
    if (empty($in['date'])) fail('Please choose a date.', 'date');
    $items = []; $slotPet = [];   // each service's pet: an existing pet id, or a new pet (name + species)
    foreach ($list as $n => $it) {
        $svc = $it['service'] ?? ''; if (!in_array($svc, REQUESTABLE, true)) fail('Online requests are for vaccinations and check-ups. Confinement and surgery cannot be booked online: your veterinarian advises them and the clinic arranges them.', 'service');
        $pet = q('SELECT id, name FROM pets WHERE id=? AND client_id=?', [(int)($it['pet_id'] ?? 0), $cid])->fetch();
        if ($pet) $slotPet[$n] = ['id' => (int)$pet['id'], 'name' => $pet['name']];
        elseif (trim($it['new_pet_name'] ?? '') !== '') {
            if (!in_array($it['new_pet_species'] ?? '', ['Dog', 'Cat'])) fail('Please choose Dog or Cat for the new pet.', 'new_pet_species');
            $slotPet[$n] = ['id' => 0, 'name' => trim($it['new_pet_name']), 'species' => $it['new_pet_species']];
        } else fail('Please choose one of your pets, or add a new one.', 'pet_id');
        $items[] = ['svc' => $svc, 'concern' => null];
    }
    $maxDate = date('Y-m-d', strtotime('+' . MAX_DAYS_AHEAD . ' days'));
    $timed = array_values(array_filter($items, fn($i) => !is_queue_svc($i['svc']))); $hasQ = count($timed) < count($items);
    if ($timed && empty($in['time'])) fail('Please pick one of the available times for the ' . strtolower($timed[0]['svc']) . '.', 'time');
    if ($hasQ) queue_check_day($in['date'], $in['branch'], $maxDate);
    $al = $timed ? pick_chain($in['date'], $in['time'], $in['branch'], $timed, null, [], $maxDate, true) : [];   // vaccinations etc.: checks hours, clashes, rooms and who is on duty; applies the online buffers
    $db = db(); $db->beginTransaction(); $ids = []; $newIds = []; $ti = 0;
    $gt = count($items) > 1 ? bin2hex(random_bytes(12)) : null;
    foreach ($items as $n => $it) {
        $pt = $slotPet[$n];
        if (!$pt['id']) {   // a new pet is created once, even if booked for two services
            $k = strtolower($pt['name']);
            if (!isset($newIds[$k])) { q('INSERT INTO pets(client_id,name,species) VALUES(?,?,?)', [$cid, $pt['name'], $pt['species']]); $newIds[$k] = (int)$db->lastInsertId(); log_act((int)$me['id'], 'Added a pet', $pt['name']); }
            $pt['id'] = $newIds[$k];
        }
        if (is_queue_svc($it['svc'])) {
            if (q("SELECT 1 FROM appointments WHERE pet_id=? AND appt_date=? AND branch=? AND is_queue=1 AND service=? AND status<>'Cancelled' LIMIT 1", [$pt['id'], $in['date'], $in['branch'], $it['svc']])->fetch()) { $db->rollBack(); fail($pt['name'] . ' is already registered for a ' . strtolower($it['svc']) . ' that day.', 'pet_id'); }
            q("INSERT INTO appointments(pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,group_token,is_queue) VALUES(?,?,'00:00:00',?,NULL,?,'Pending',?,'Online',?,?,1)",
              [$pt['id'], $in['date'], $it['svc'], $in['branch'], nul($in['reason'] ?? null), bin2hex(random_bytes(12)), $gt]);
        } else {
            q("INSERT INTO appointments(pet_id,appt_date,appt_time,service,vet,branch,status,reason,source,qr_token,group_token) VALUES(?,?,?,?,?,?,'Pending',?,'Online',?,?)",
              [$pt['id'], $in['date'], mtime($al[$ti]['start']), $it['svc'], $al[$ti]['vet'], $in['branch'], nul($in['reason'] ?? null), bin2hex(random_bytes(12)), $gt]); $ti++;
        }
        $ids[] = (int)$db->lastInsertId();
    }
    $db->commit();
    $rows = appt_rows($ids); $what = appt_summary($rows); $when = appt_when($rows[0]);
    log_act((int)$me['id'], 'Requested an appointment', "$what, $when");
    notify_role('staff', $in['branch'], 'request', 'New online appointment request', $me['name'] . ': ' . "$what, $when.", 'appointments.php?date=' . $in['date']);
    foreach (array_unique(array_filter(array_column($rows, 'vet'))) as $v) notify_vet($v, 'request', 'New appointment request for you', $me['name'] . ': ' . "$what, $when (waiting for approval).", 'appointments.php?date=' . $in['date']);
    notify($me['id'], 'booked', 'Request received', "$what, $when ({$in['branch']}). We will confirm it shortly." . ($hasQ ? ' Check-ups and vaccinations are first come, first served: come any time that day and show your QR code.' : ''), 'appointments.php');
    $first = $rows[0];
    send(['ok' => 1, 'appt' => ['id' => $first['id'], 'qr_token' => q('SELECT qr_token FROM appointments WHERE id=?', [$first['id']])->fetchColumn(), 'appt_date' => $in['date'], 'time' => $first['time'], 'is_queue' => (int)$first['is_queue'], 'service' => $first['service'], 'branch' => $in['branch'], 'pet' => $first['pet']],
          'items' => array_map(fn($r) => ['pet' => $r['pet'], 'service' => $r['service'], 'time' => $r['time'], 'is_queue' => (int)$r['is_queue'], 'vet' => $r['vet']], $rows)]);
}
// ---- cancel or reschedule my own booking (everything booked together moves together) ----
if ($post && $p[0] === 'appointments' && count($p) === 3 && ctype_digit($p[1]) && in_array($p[2], ['cancel', 'reschedule'], true)) {
    $rows = appt_rows([(int)$p[1]]);
    if (!$rows || (int)$rows[0]['client_id'] !== $cid) fail('Appointment not found.', null, 404);
    $a = $rows[0];
    if ($p[2] === 'cancel') {
        if ($why = owner_can_change($a)) fail($why);
        $reason = trim($in['reason'] ?? ''); if ($reason === '') fail('Please choose a reason.', 'reason');
        appt_cancel(appt_group_ids((int)$a['id']), 'Owner', $reason, $me); send(['ok' => 1]);
    }
    if ($why = owner_can_change($a, true)) fail($why);
    if (empty($in['date']) || (empty($in['time']) && !$a['is_queue'])) fail($a['is_queue'] ? 'Please choose a new date.' : 'Please choose a new date and time.', 'time');
    appt_reschedule((int)$a['id'], $in['date'], (string)($in['time'] ?? '00:00'), 'Owner', $me, date('Y-m-d', strtotime('+' . MAX_DAYS_AHEAD . ' days')), true); send(['ok' => 1]);
}
// ---- add a pet online: details can stay partial, the clinic completes them at check-in ----
if ($post && $path === 'pets') {
    $n = trim($in['name'] ?? ''); if ($n === '') fail("Please enter your pet's name.", 'name');
    if (!in_array($in['species'] ?? '', ['Dog', 'Cat'])) fail('Please choose Dog or Cat.', 'species');
    $bd = nul($in['birthdate'] ?? null); if ($bd && $bd > date('Y-m-d')) fail('Birthdate cannot be in the future.', 'birthdate');
    q('INSERT INTO pets(client_id,name,species,breed,sex,birthdate) VALUES(?,?,?,?,?,?)', [$cid, $n, $in['species'], nul($in['breed'] ?? null), in_array($in['sex'] ?? '', ['Male', 'Female']) ? $in['sex'] : null, $bd]);
    log_act((int)$me['id'], 'Added a pet', $n); send(['ok' => 1, 'id' => (int)db()->lastInsertId()]);
}
// ---- my profile, photo and pet photos ----
if (!$post && $path === 'profile') send(q('SELECT name, address, email, phone FROM clients WHERE id=?', [$cid])->fetch() + ['username' => $me['username'], 'photo' => $me['photo'] ?? null]);
if ($post && $path === 'profile') {
    $n = trim($in['name'] ?? ''); $em = strtolower(trim($in['email'] ?? ''));
    if ($n === '') fail('Please enter your name.', 'name');
    if (!filter_var($em, FILTER_VALIDATE_EMAIL)) fail('Please enter a valid email address.', 'email');
    if (q("SELECT 1 FROM accounts WHERE role='client' AND LOWER(email)=? AND id<>?", [$em, $me['id']])->fetch()) fail('That email is already used by another account.', 'email');
    q('UPDATE clients SET name=?, address=?, email=?, phone=? WHERE id=?', [$n, nul($in['address'] ?? null), $em, nul($in['phone'] ?? null), $cid]);
    q('UPDATE accounts SET name=?, email=? WHERE id=?', [$n, $em, $me['id']]);
    log_act((int)$me['id'], 'Updated profile'); send(['ok' => 1]);
}
if ($post && $path === 'profile/photo') {
    q('UPDATE accounts SET photo=? WHERE id=?', [photo_value($in['photo'] ?? ''), $me['id']]);
    log_act((int)$me['id'], 'Changed profile photo'); send(['ok' => 1]);
}
if ($post && $path === 'profile/password') {
    if (!password_verify($in['current'] ?? '', $me['password'])) fail('Your current password is incorrect.', 'current');
    $pw = $in['password'] ?? '';
    if (strlen($pw) < 8) fail('The new password needs at least 8 characters.', 'password');
    if ($pw !== ($in['confirm'] ?? '')) fail('The two passwords do not match.', 'confirm');
    q('UPDATE accounts SET password=?, must_change=0 WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $me['id']]);
    log_act((int)$me['id'], 'Password changed'); send(['ok' => 1]);
}
if ($post && $p[0] === 'pets' && count($p) === 3 && $p[2] === 'photo') {   // only the owner's own pets
    $pet = q('SELECT id, name FROM pets WHERE id=? AND client_id=?', [$p[1], $cid])->fetch();
    if (!$pet) fail('Pet not found.', null, 404);
    q('UPDATE pets SET photo=? WHERE id=?', [photo_value($in['photo'] ?? ''), $pet['id']]);
    log_act((int)$me['id'], 'Changed a pet photo', $pet['name']); send(['ok' => 1]);
}
send(['error' => 'Not found'], 404);

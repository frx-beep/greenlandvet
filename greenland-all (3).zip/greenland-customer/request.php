<?php require 'layout.php'; top('Request an Appointment', 'a', 'Appointments > Request'); ?>
<script src="qr.js?v=<?= filemtime(__DIR__ . '/qr.js') ?>"></script>
<div class="split" style="grid-template-columns:1.6fr 1fr">
<div class="card"><p class="muted" style="margin-top:0">Choose your pet(s) and what they need, then pick a date. <b>Check-ups and vaccinations are first come, first served</b>: pick the day and come any time that day (until <?= date('g:i A', strtotime(QUEUE_LAST_ARRIVAL)) ?>), then show your QR code at the front desk. The clinic will confirm your request. You can book from today up to 30 days ahead.</p>
  <form id="f" class="form" novalidate>
    <div class="field"><span class="lbl">Pets and services</span><div id="items" class="form"></div>
      <div class="btns" style="margin:.5rem 0 0"><button type="button" class="btn ghost sm" id="addItem">+ Add another pet or service</button></div></div>
    <label>Branch<select name="branch" id="br"><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select><small class="ferr" data-f="branch"></small></label>
    <label>Preferred Date<input type="date" name="date" id="date"><small class="ferr" data-f="date"></small></label>
    <div class="field" id="timeBox"><span class="lbl">Available times <span id="mins"></span></span><div class="slots" id="slots"></div><small class="ferr" data-f="time"></small></div>
    <p class="devnote" id="qnote" hidden></p>
    <input type="hidden" name="time" id="time">
    <label>Notes (optional)<textarea name="reason" placeholder="Tell us how we can help"></textarea></label>
    <div class="sugbox" id="sugs" hidden></div>
    <p class="err"></p>
    <div class="actions"><button class="btn">Submit Request</button><a class="btn plain" href="appointments.php">Cancel</a></div>
  </form></div>
<div class="card"><h2>How it works</h2>
  <p style="margin-top:0"><b>Check-up and vaccination (no time needed)</b><br><span class="muted">Register for a day and a branch. When you arrive, the front desk scans your QR code and gives you a queue number. You are called when a veterinarian and a room are free, in the order people arrived. A check-up usually takes about an hour (serious cases can take 2 to 3 hours); a vaccination usually takes about 15 minutes. Everyone waits in the same line, and emergencies may be moved up.</span></p>
  <p class="muted" style="margin-bottom:0;font-size:.85rem"><b>Cancel or change your day:</b> you can cancel, or move to another open day, until you arrive. If you do not come, your registration closes at <?= date('g:i A', strtotime(CLINIC_CLOSE)) ?> and we will message you so you can register for another open day.</p></div>
</div>
<script>
const MAXITEMS = <?= (int)MAX_BOOKING_ITEMS ?>, REQ = <?= json_encode(REQUESTABLE) ?>;
let pets = [], items = [];
const LAST = <?= json_encode(QUEUE_LAST_ARRIVAL) ?>, QSV = <?= json_encode(QUEUE_SERVICES) ?>, isQ = s => QSV.includes(s), allQ = () => items.length && items.every(i => isQ(i.svc));
const mx = new Date(); mx.setDate(mx.getDate() + 30);
$('#date').min = today(); $('#date').max = mx.toLocaleDateString('en-CA'); $('#date').value = today();
const newItem = () => ({ pet: pets.length === 1 ? String(pets[0].id) : pets.length ? '' : 'new', svc: param('service') && REQ.includes(param('service')) ? param('service') : REQ[0], npn: '', nps: 'Dog' });

function renderItems() {
  $('#items').innerHTML = items.map((it, i) => {
    return `<div class="item"><div class="fr"><label>Pet<select data-k="pet" data-i="${i}"><option value="">Select your pet</option>${pets.map(p => `<option value="${p.id}" ${String(p.id) === it.pet ? 'selected' : ''}>${E(p.name)}</option>`).join('')}<option value="new" ${it.pet === 'new' ? 'selected' : ''}>+ Add a new pet</option></select></label>
      <label>Service<select data-k="svc" data-i="${i}">${REQ.map(s => `<option ${s === it.svc ? 'selected' : ''}>${E(s)}</option>`).join('')}</select></label>
      ${items.length > 1 ? `<button type="button" class="btn plain sm rm" data-rm="${i}">Remove</button>` : ''}</div>
      ${it.pet === 'new' ? `<div class="fr" style="margin-top:.75rem"><label>New pet's name<input data-k="npn" data-i="${i}" value="${E(it.npn)}" placeholder="e.g. Bruno"></label><label>Species<select data-k="nps" data-i="${i}"><option ${it.nps === 'Dog' ? 'selected' : ''}>Dog</option><option ${it.nps === 'Cat' ? 'selected' : ''}>Cat</option></select></label></div>
        <small class="muted">Only the name and species are needed now. The clinic completes the rest (breed, birthdate, documents) when you arrive.</small>` : ''}
</div>`;
  }).join('');
  $('#addItem').disabled = items.length >= MAXITEMS;
  $$('#items [data-k]').forEach(el => { const ev = el.tagName === 'INPUT' ? 'oninput' : 'onchange'; el[ev] = () => { const it = items[+el.dataset.i]; it[el.dataset.k] = el.value;
    if (el.tagName === 'INPUT') return; renderItems(); loadSlots(); }; });
  $$('#items [data-rm]').forEach(b => b.onclick = () => { items.splice(+b.dataset.rm, 1); renderItems(); loadSlots(); });
  $('#timeBox').hidden = allQ();
  const closedToday = $('#date').value === today() && items.some(i => isQ(i.svc)) && (() => { const n = new Date(); return n.getHours() * 60 + n.getMinutes() >= +LAST.slice(0, 2) * 60 + +LAST.slice(3); })();
  $('#qnote').hidden = !items.some(i => isQ(i.svc)); $('#qnote').innerHTML = closedToday ? `New check-ups and vaccinations for today closed at ${fmtTime(LAST)}. Please choose another day.` : `Check-ups and vaccinations have <b>no set time</b>: come any time that day until ${fmtTime(LAST)}. You get your queue number at the front desk.`;
}
const itemsJson = () => JSON.stringify(items.filter(i => !isQ(i.svc)).map(i => ({ svc: i.svc })));
async function loadSlots() {
  $('#time').value = ''; $('#sugs').hidden = true;
  const d = $('#date').value; renderItems();
  if (allQ()) return;
  if (!d) return $('#slots').innerHTML = '<span class="muted">Choose a date first.</span>';
  const r = await api(`/api/schedule/slots?date=${d}&branch=${$('#br').value}&items=${encodeURIComponent(itemsJson())}`);
  $('#mins').textContent = r.minutes ? `(your visit takes about ${r.minutes} minutes)` : '';
  drawSlots($('#slots'), r, t => $('#time').value = t, false);
}
$('#addItem').onclick = () => { items.push(newItem()); renderItems(); loadSlots(); };
$('#date').onchange = loadSlots; $('#br').onchange = () => { renderItems(); loadSlots(); };
api('/api/pets').then(r => { pets = r.pets; items = [newItem()]; renderItems(); loadSlots(); });
bindForm('#f', async d => {
  if (!allQ() && !d.time) throw new Error('Please pick one of the available times.');
  for (const it of items) { if (!it.pet) throw new Error('Please choose a pet for every service.'); if (it.pet === 'new' && !it.npn.trim()) throw new Error("Please enter your new pet's name."); }
  const body = { items: items.map(i => ({ pet_id: i.pet === 'new' ? '' : i.pet, new_pet_name: i.pet === 'new' ? i.npn : '', new_pet_species: i.nps, service: i.svc })), branch: d.branch, date: d.date, time: allQ() ? '' : d.time, reason: d.reason };
  let r;
  try { r = await api('/api/appointments', body); }
  catch (x) { if (x.data && x.data.suggestions) { await loadSlots(); showSuggestions($('#sugs'), x.data.suggestions, async (dt, t) => { $('#date').value = dt; await loadSlots(); const b = $(`#slots .slot[data-t="${t}"]`); if (b && !b.disabled) b.click(); }); } throw x; }
  const dlg = qrDialog(r.appt);   // the QR code is ready right away: save it or find it again under Appointments
  if (r.items.length > 1) dlg.querySelector('dl').insertAdjacentHTML('beforeend', `<dt>Booked together</dt><dd>${r.items.map(x => `${E(x.pet)}: ${E(x.service)}${+x.is_queue ? ' (any time that day)' : ' at ' + fmtTime(x.time)}${x.vet ? ' with ' + E(x.vet) : ''}`).join('<br>')}</dd>`);
  dlg.addEventListener('close', () => location = 'appointments.php');
});
</script>
<?php bottom(); ?>

<?php require 'pub.php';
$in = current_account() !== null;
if ($in) { require 'layout.php'; top('Contact Us', 'c'); } else pub_top('Contact Us'); ?>
<?php if (!$in): ?><h1 style="margin-bottom:.25rem">Contact Us</h1><?php endif; ?>
<div class="hd"><p class="muted" style="margin:0">Reach either of our branches or message us online.</p><?php if ($in): ?><a class="btn" href="request.php">+ Request Appointment</a><?php endif; ?></div>
<div class="branchgrid"><?php branch_cards(true); ?></div>
<div class="card" style="margin-top:1.25rem"><h2>Find us online</h2><dl>
  <dt>Facebook</dt><dd><?= FACEBOOK ?></dd><dt>Email</dt><dd><?= CONTACT_EMAIL ?></dd></dl></div>
<?php if ($in) bottom(); else pub_bottom(); ?>

<?php require 'authlib.php'; if (current_account()) { header('Location: ' . HOME); exit; } auth_open('Create account'); ?>
<style>body.authc .authcard,body.auth .authcard{width:min(34rem,100%)}</style>
<h3>Create your account</h3>
<p class="muted">Book appointments online and see your pets' records. Only a few details are needed now. The clinic completes your pet's details when you arrive.</p>
<form id="f" class="form" novalidate>
  <label>Full Name<input name="name" autocomplete="name"><small class="ferr" data-f="name"></small></label>
  <div class="fr"><label>Email Address<input name="email" type="email" autocomplete="email"><small class="ferr" data-f="email"></small></label>
    <label>Contact Number (optional)<input name="phone" autocomplete="tel" placeholder="09XX XXX XXXX"></label></div>
  <div class="fr"><label>Username<input name="username" autocomplete="username"><small class="ferr" data-f="username"></small></label>
    <label>Preferred Branch<select name="branch"><?php foreach (BRANCHES as $b) echo "<option>$b</option>"; ?></select></label></div>
  <div class="fr"><label>Password (8+ characters)<input name="password" type="password" autocomplete="new-password"><small class="ferr" data-f="password"></small></label>
    <label>Confirm password<input name="confirm" type="password" autocomplete="new-password"><small class="ferr" data-f="confirm"></small></label></div>
  <label>Address (optional)<input name="address" autocomplete="street-address" placeholder="House no., street, barangay, city"></label>
  <p class="err"></p><button class="btn wide">Create account</button>
</form>
<p class="center muted" style="margin:.75rem 0 .25rem">We'll email a 6-digit code to confirm it's you.</p>
<p class="center muted" style="margin:0">Already have an account? <a class="link" href="login.php">Sign in</a></p>
<script>bindForm('#f', async d => { const r = await api('/api/auth/register', d); location = r.next; });</script>
<?php auth_close(); ?>

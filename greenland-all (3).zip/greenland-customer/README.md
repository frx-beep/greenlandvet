# Greenland Veterinary Clinic: Customer app
Part of a 4-app system (staff, vet, customer, admin) that shares ONE database (see greenland-database.zip).
1. Import the database first (greenland-database.zip > README.md).
2. Copy this folder into C:\xampp\htdocs (keep the folder name: greenland-customer).
3. Open http://localhost/greenland-customer/login.php
4. Accounts are created in the Admin app. Sign-in uses a 6-digit code; while email isn't set up the code is shown on the verify page (config.php: DEV_SHOW_CODE).

<?php require 'pub.php'; require 'layout.php'; top('Our Services', 's');
$S = ['Vaccination' => 'Keep your pet protected with core and optional vaccines. No booking time needed: register for a day, come any time, and you are seen in the order you arrive. Vaccinations are quick, usually about 15 minutes.', 'Check-Up' => 'Routine wellness exams and consultations with our veterinarians. No booking time needed: register for a day, come any time, and you are seen in the order you arrive.',
      'Confinement' => 'Safe, monitored care for pets that need to stay overnight.', 'Surgery' => 'Surgical procedures with careful pre- and post-operative care.'];
cms_promo(); ?>
<div class="hd"><p class="muted" style="margin:0">Here's what we offer at our Cainta and Taytay branches.</p><a class="btn" href="request.php">+ Request Appointment</a></div>
<div class="svcgrid"><?php foreach ($S as $n => $d): ?>
  <div class="card"><h2><?= $n ?></h2><p class="muted"><?= $d ?></p><div class="chips"><?php foreach (BRANCHES as $b) echo "<span class=\"badge\">$b</span>"; ?></div>
  <?php if (in_array($n, REQUESTABLE)): ?><a class="btn ghost" href="request.php?service=<?= urlencode($n) ?>">Request Appointment</a>
  <?php else: ?><p class="muted" style="margin:0">Recommended by your veterinarian after a check-up, so there's no need to request it online.</p><?php endif; ?></div>
<?php endforeach; ?></div>
<?php cms_offers('promo', trim(cms()['offers_title'] ?? '') ?: 'Promos & items on sale'); cms_offers('service', 'More from the clinic'); ?>
<?php bottom(); ?>

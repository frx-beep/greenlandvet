<?php require 'pub.php'; pub_top('Home', true); $c = cms(); $in = current_account() !== null;
$hero = $c['hero_image'] ?? ''; $hasImg = $hero && strpos($hero, 'data:image/jpeg;base64,') === 0;
$S = ['Vaccination' => 'Keep your pet protected with core and optional vaccines, given in about 15 minutes. No time to book: register for a day and come any time.', 'Check-Up' => 'Wellness exams and consultations. No time to book: register for a day, come any time, and you are seen in the order you arrive.',
      'Confinement' => 'Safe, monitored care for pets that need to stay with us, with daily updates from the vet.', 'Surgery' => 'Surgical procedures with careful before and after care at our main branch.'];
$open = date('g:i A', strtotime(CLINIC_OPEN)) . ' to ' . date('g:i A', strtotime(CLINIC_CLOSE)); ?>
<?php cms_promo(); ?>
<section class="hero2" <?php if ($hasImg): ?>style="background-image:linear-gradient(100deg,#0a4a45f5 38%,#0a4a4580),url(<?= h($hero) ?>);background-size:cover;background-position:center"<?php endif; ?>>
  <div class="wrap hero2-in">
    <div class="hero2-t"><span class="eyebrow">Cainta &middot; Taytay</span>
      <h1><?= h(trim($c['hero_title'] ?? '') ?: 'Greenland Veterinary Clinic') ?></h1>
      <p><?= h(trim($c['hero_text'] ?? '') ?: 'One clinic for both branches, caring for your pets, together.') ?></p>
      <div class="btns"><?php if ($in): ?><a class="btn big2" href="request.php">Request an appointment</a><a class="btn ghost big2" href="pets.php">My Portal</a>
        <?php else: ?><a class="btn big2" href="login.php">Pet Owner Login</a><a class="btn ghost big2" href="register.php">Create an account</a><?php endif; ?></div></div>
    <?php if (!$hasImg): ?><div class="hero2-art"><?= SITE_ART ?></div><?php endif; ?>
  </div>
</section>
<section class="strip"><div class="wrap strip-in">
  <?php [$isOpen, $openMsg] = open_status(); ?>
  <div><?= svc_icon('clock') ?><b>Open Monday to Saturday <em class="opn <?= $isOpen ? 'on' : 'off' ?>"><?= $isOpen ? 'Open now' : 'Closed now' ?></em></b><span><?= h($open) ?> &middot; <?= h($openMsg) ?></span></div>
  <div><?= svc_icon('pin') ?><b>Two branches</b><span>Cainta and Taytay</span></div>
  <div><?= svc_icon('calendar') ?><b>Book online</b><span>Request a visit from home</span></div>
  <div><?= svc_icon('qr') ?><b>QR check-in</b><span>Skip the paperwork at the desk</span></div>
</div></section>

<section class="sec" id="services"><div class="wrap">
  <h2 class="sec-h"><?= h(trim($c['services_title'] ?? '') ?: 'What we do') ?></h2>
  <p class="sec-p"><?= h(trim($c['services_text'] ?? '') ?: 'Everything your pet needs, from the first vaccine to surgery, under one roof.') ?></p>
  <div class="svc4"><?php foreach ($S as $n => $d): ?>
    <div class="svc"><span class="svc-ic"><?= svc_icon($n) ?></span><h3><?= $n ?></h3><p><?= $d ?></p>
      <?php if ($in && in_array($n, REQUESTABLE)): ?><a class="link" href="request.php?service=<?= urlencode($n) ?>">Request this &rsaquo;</a><?php elseif (!$in && in_array($n, REQUESTABLE)): ?><a class="link" href="login.php">Log in to book &rsaquo;</a><?php endif; ?></div>
  <?php endforeach; ?></div>
  <?php cms_offers('service', 'More from the clinic'); ?>
</div></section>

<section class="sec alt" id="how"><div class="wrap">
  <h2 class="sec-h">How it works</h2><p class="sec-p">Three steps from your couch to the exam room.</p>
  <div class="steps3">
    <div class="step"><span class="svc-ic"><?= svc_icon('user') ?></span><b>1. Create your account</b><p>Register your details and your pets once. We send a code to your email to confirm it is you.</p></div>
    <div class="step"><span class="svc-ic"><?= svc_icon('calendar') ?></span><b>2. Request a visit</b><p>Choose the branch, the service and the day. Check-ups and vaccinations are first come, first served: no time to book.</p></div>
    <div class="step"><span class="svc-ic"><?= svc_icon('qr') ?></span><b>3. Show your QR code</b><p>At the clinic the front desk scans it. You get a queue number and an estimated wait, and a message when it is your turn.</p></div>
  </div>
</div></section>

<?php $promos = array_filter(cms_items(), fn($i) => $i['kind'] === 'promo'); if ($promos): ?>
<section class="sec" id="promos"><div class="wrap"><?php cms_offers('promo', trim($c['offers_title'] ?? '') ?: 'Promos & items on sale'); ?></div></section>
<?php endif; ?>

<section class="sec <?= $promos ? 'alt' : '' ?>" id="about"><div class="wrap about2">
  <div><h2 class="sec-h" style="text-align:left"><?= h(trim($c['about_title'] ?? '') ?: 'About us') ?></h2>
    <p class="aboutp"><?= h(trim($c['about_text'] ?? '') ?: 'Greenland Veterinary Clinic looks after dogs, cats and other pets at our Cainta and Taytay branches. Our veterinarians share one record for every pet, so whichever branch you visit, the vet already knows your pet\'s history.') ?></p></div>
  <div class="facts"><div><b>2</b><span>branches</span></div><div><b>6</b><span>days a week</span></div><div><b>4</b><span>services</span></div></div>
</div></section>

<section class="sec" id="branches"><div class="wrap">
  <h2 class="sec-h">Our branches</h2><p class="sec-p">Visit either branch. Records are shared between them.</p>
  <div class="branchgrid"><?php foreach (BRANCH_INFO as $name => $b): ?>
    <div class="card bcard"><h3><?= h($name) ?> Branch<?= !empty($b['main']) ? ' <span class="badge">Main branch</span>' : '' ?></h3>
      <p><?= svc_icon('pin') ?><span><?= h($b['address']) ?></span></p><p><?= svc_icon('phone') ?><span><?= h($b['phone']) ?></span></p><p><?= svc_icon('clock') ?><span><?= h($b['hours']) ?></span></p>
      <a class="link" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($b['address']) ?>">Get directions &rsaquo;</a></div>
  <?php endforeach; ?></div>
</div></section>

<section class="cta"><div class="wrap cta-in"><div><h2>Ready to see us?</h2><p>Create an account to request a visit, see your pet's records and get reminders.</p></div>
  <div class="btns"><?php if ($in): ?><a class="btn big2" href="request.php">Request an appointment</a><?php else: ?><a class="btn big2" href="register.php">Create an account</a><a class="btn ghost big2" href="login.php">Pet Owner Login</a><?php endif; ?></div></div></section>
<?php pub_bottom(); ?>

<?php require 'layout.php'; top('My Appointments', 'a'); ?>
<script src="qr.js?v=<?= filemtime(__DIR__ . '/qr.js') ?>"></script>
<div class="hd"><span></span><a class="btn" href="request.php">+ Request Appointment</a></div>
<div class="card owes-b" id="owe" hidden></div>
<div class="card devnote" id="conf" hidden style="margin-top:1rem"></div>
<div class="card"><h2>Upcoming</h2><p class="muted" style="margin-top:0">Press <b>Show QR</b> on the day of your visit and show it to the front desk. <b>Check-ups and vaccinations</b> have no set time: come any time that day until <?= date('g:i A', strtotime(QUEUE_LAST_ARRIVAL)) ?> and you are seen in the order you arrive. You can cancel, or move to another open day, until you arrive (up to <?= (int)MAX_RESCHEDULES ?> changes per booking). If you do not come on your day, the registration closes at <?= date('g:i A', strtotime(CLINIC_CLOSE)) ?> and you can register again for any open day.</p>
  <table><thead><tr><th>Date</th><th>Time</th><th>Pet</th><th>Service</th><th>Branch</th><th>Status</th><th></th></tr></thead><tbody id="up"></tbody></table></div>
<div class="card"><h2>Past &amp; Cancelled</h2><table><thead><tr><th>Date</th><th>Pet</th><th>Service</th><th>Branch</th><th>Status</th></tr></thead><tbody id="past"></tbody></table></div>
<script>
let R;
function qState(a) {
  const q = a.queue; if (!a.checked_in_at) return '';
  if (q && q.state === 'waiting') return ` <span class="badge p">Waiting: ${q.ahead ? q.ahead + ' ahead of you' : 'you are next'}${q.wait_text ? ' &middot; ' + E(q.wait_text) : ''}</span>`;
  if (q && q.state === 'called') return ` <span class="badge">Called: ${E(q.room || '')}${q.vet ? ' with ' + E(q.vet) : ''}</span>`;
  return ` <span class="badge">Checked in${a.room ? ', ' + E(a.room) : ''}</span>`;
}
async function load() {
  try {
    R = await api('/api/appointments'); const r = R;
    const ob = $('#owe'); ob.hidden = !(r.balance > 0); if (r.balance > 0) ob.innerHTML = `<b>You have an unpaid balance of ${peso(r.balance)}.</b> <span class="muted">Please settle it at the front desk on your next visit. You can still book and be seen.</span>`;
    $('#up').innerHTML = r.upcoming.length ? r.upcoming.map((a, i) => `<tr><td>${E(fmtDay(a.appt_date))}</td><td>${+a.is_queue ? (a.queue_no && a.checked_in_at ? '<b>No. ' + a.queue_no + '</b>' : 'Any time') : fmtTime(a.time)}</td><td>${E(a.pet)}</td><td>${E(a.service)}</td><td>${E(a.branch || '-')}</td>
      <td>${badge(a.status)}${a.group_token ? ' <span class="badge g">Booked together</span>' : ''}${qState(a)}</td>
      <td class="acts"><button type="button" class="btn ghost sm" data-q="${i}">Show QR</button>
        <button type="button" class="btn ghost sm" data-rs="${i}" ${a.cant_resched ? 'disabled' : ''} title="${E(a.cant_resched || 'Pick a new date or time')}">Reschedule</button>
        <button type="button" class="btn danger sm" data-cx="${i}" ${a.cant_cancel ? 'disabled' : ''} title="${E(a.cant_cancel || 'Cancel this appointment')}">Cancel</button></td></tr>`).join('')
      : '<tr><td colspan="7" class="empty">No upcoming appointments. Use "+ Request Appointment" to book one.</td></tr>';
    $$('[data-q]').forEach(b => b.onclick = () => qrDialog(r.upcoming[b.dataset.q]));
    $$('[data-cx]').forEach(b => b.onclick = () => { const a = r.upcoming[b.dataset.cx], g = r.upcoming.filter(x => a.group_token && x.group_token === a.group_token);
      cancelDialog({ summary: (g.length > 1 ? g : [a]).map(x => `${x.pet}: ${x.service}`).join(', ') + ' on ' + fmtDay(a.appt_date) + (+a.is_queue ? '' : ', ' + fmtTime(a.time)), reasons: CANCEL_REASONS.client,
        note: g.length > 1 ? 'These were booked together, so they are all cancelled.' : null, submit: reason => api(`/api/appointments/${a.id}/cancel`, { reason }), done: load }); });
    $$('[data-rs]').forEach(b => b.onclick = () => { const a = r.upcoming[b.dataset.rs], g = r.upcoming.filter(x => a.group_token && x.group_token === a.group_token);
      rescheduleDialog({ summary: (g.length > 1 ? g : [a]).map(x => `${x.pet}: ${x.service}`).join(', ') + ', now ' + fmtDay(a.appt_date) + (+a.is_queue ? ' (any time)' : ' ' + fmtTime(a.time)), date: a.appt_date, maxDays: 30, queue: !!+a.is_queue,
        note: `You can reschedule this booking ${r.policy.max_resched - a.reschedule_count} more time(s).`,
        slots: dt => +a.is_queue ? Promise.resolve({ slots: [] }) : api(`/api/schedule/slots?date=${dt}&appt=${a.id}&branch=${encodeURIComponent(a.branch)}`), submit: (dt, t) => api(`/api/appointments/${a.id}/reschedule`, { date: dt, time: t }), done: load }); });
    $('#past').innerHTML = r.past.length ? r.past.map(a => `<tr><td>${fmtDate(a.appt_date)}</td><td>${E(a.pet)}</td><td>${E(a.service)}</td><td>${E(a.branch || '-')}</td><td>${badge(a.status)}${a.status === 'Cancelled' && a.cancel_reason ? `<br><small class="muted">${E(a.cancelled_by === 'System' ? 'Auto-cancelled: ' : '')}${E(a.cancel_reason)}</small>` : ''}</td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">No past visits yet.</td></tr>';
  } catch (x) { $('#up').innerHTML = `<tr><td colspan="7" class="err">${E(x.message)}</td></tr>`; }
}
api('/api/confined').then(l => { const c = $('#conf'); c.hidden = !l.length; c.innerHTML = l.map(x => `<b>${E(x.pet)} is staying at the clinic</b> since ${E(fmtDay(x.since))} (${x.days} day${x.days === 1 ? '' : 's'}, ${E(x.branch)} branch).${x.referred_from && !x.arrived ? ` Please bring ${E(x.pet)} to the ${E(x.branch)} branch: ${E(x.address)}.` : ''}`).join('<br>'); }).catch(() => {});
load();
</script>
<?php bottom(); ?>

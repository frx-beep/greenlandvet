<?php require 'layout.php'; top('My Profile', 'm'); ?>
<div class="split" style="grid-template-columns:1fr 2fr">
  <div class="card center"><div class="avatar big" id="pic"></div><h2 id="nm" style="margin:.75rem 0 0"></h2><p class="muted" style="margin:.2rem 0 1rem">Pet Owner</p>
    <input type="file" id="file" accept="image/*" hidden>
    <div class="btns" style="justify-content:center"><button type="button" class="btn ghost" id="chg">Change photo</button><button type="button" class="btn plain" id="rm">Remove</button></div>
    <p class="err" id="perr"></p></div>
  <div>
    <div class="card"><h2>My Information</h2>
      <form id="f" class="form" novalidate>
        <div class="fr"><label>Full Name<input name="name"><small class="ferr" data-f="name"></small></label><label>Contact Number<input name="phone" placeholder="09XX XXX XXXX"></label></div>
        <label>Email Address (your sign-in codes are sent here)<input name="email" type="email"><small class="ferr" data-f="email"></small></label>
        <label>Address<input name="address" placeholder="House no., street, barangay, city"></label>
        <label>Username<input id="un" disabled></label>
        <p class="muted" style="margin:0">Your username is set by the clinic. Changes to your details are saved right away.</p>
        <p class="err"></p><p class="okmsg" id="ok" hidden>Saved.</p>
        <div class="actions"><button class="btn">Save changes</button></div>
      </form></div>
    <div class="card"><h2>Change Password</h2>
      <form id="pf" class="form" novalidate>
        <label>Current password<input name="current" type="password" autocomplete="current-password"><small class="ferr" data-f="current"></small></label>
        <div class="fr"><label>New password (8+ characters)<input name="password" type="password" autocomplete="new-password"><small class="ferr" data-f="password"></small></label>
        <label>Confirm new password<input name="confirm" type="password" autocomplete="new-password"><small class="ferr" data-f="confirm"></small></label></div>
        <p class="err"></p><p class="okmsg" id="pok" hidden>Password changed.</p>
        <div class="actions"><button class="btn">Change password</button></div>
      </form></div>
  </div>
</div>
<script>
async function load() {
  const c = await api('/api/profile');
  $('#nm').textContent = c.name; $('#un').value = c.username;
  const p = $('#pic'); p.style.backgroundImage = c.photo ? `url(${c.photo})` : ''; p.textContent = c.photo ? '' : c.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const f = $('#f'); f.name.value = c.name; f.email.value = c.email || ''; f.phone.value = c.phone || ''; f.address.value = c.address || '';
  paintAvatar({ name: c.name, photo: c.photo });
}
async function savePhoto(photo) { try { $('#perr').textContent = ''; await api('/api/profile/photo', { photo }); load(); } catch (x) { $('#perr').textContent = x.message; } }
$('#chg').onclick = () => $('#file').click();
$('#rm').onclick = () => savePhoto('');
$('#file').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (!f) return; try { savePhoto(await resizeImage(f)); } catch (x) { $('#perr').textContent = x.message; } };
bindForm('#f', async d => { $('#ok').hidden = true; await api('/api/profile', d); $('#ok').hidden = false; load(); });
bindForm('#pf', async d => { $('#pok').hidden = true; await api('/api/profile/password', d); $('#pok').hidden = false; $('#pf').reset(); });
load().catch(x => $('#perr').textContent = x.message);
</script>
<?php bottom(); ?>

# Greenland Veterinary Clinic: Clinic Management System

Documentation for the thesis project. The system has four web apps (staff, vet, customer, admin) that share one MySQL database, so everything the clinic does stays connected.

> This file is updated with every change and always describes the whole system. The history is in the **Change log** at the end. Latest: **Update 20, vaccinations are now first come, first served (a day registration with no booked time), so only surgery keeps a booked time**. Before that: **Update 19, money moved to a rebuilt Sales page (staff and admin), no money on the dashboard, fluid text sizes and tablet / phone layouts**. Before that: **Update 18, the Pet Shop, Orders and stock were removed and idle sign-out is for the customer app only**. Before that: **Update 15, a look-and-feel upgrade (pet avatars, shared status colours, KPI icons and trends, calendar dots, "Now serving" card and panel for the front desk, pet timeline, dark mode, two more report charts, login polish; each can be switched off, section 21)**. Before that: **Update 14, built from the client interview: vaccinations take 15 minutes and booked times are every 15 minutes, clinic hours are 9:00 AM to 5:00 PM, Taytay needs only 1 vet on duty, one vaccination visit can hold several items (vaccine, deworming, tick and flea) each with its own next schedule, a fuller check-up record (chief complaint, tests, results, diagnosis, prescription, follow-up and its purpose), survived/died outcomes, a Taytay-to-Cainta referral for X-ray and other tests, the printout is now a Billing Statement ("not an official receipt") with a printable daily sales sheet, a Back link on every inner page, and email reminders in the clinic's wording with an SMS layer ready for when a service is connected.**

---

## 1. What the system solves

Digitalizing a paper process is not enough. The system was designed around specific problems:

| Problem in the current process | How the system answers it |
|---|---|
| Pet owners must come in just to get an account or an appointment | Owners **register online** (email confirmed by a code), add a pet with just a name and species, and register for a visit. The clinic completes the pet's details at check-in |
| Waiting for a "time" that the clinic cannot keep (a check-up can take one hour or three) | **Check-ups and vaccinations have no booked time (Update 20).** The owner registers for a day, arrives any time before 5:00 PM and is seen **first come, first served** in one shared line. A queue number and an estimated wait are shown |
| Patients assigned to a vet who is busy or not working that day | A **daily duty roster** (2 to 4 vets per branch rotate). A patient is called only when an **on-duty vet and a room are both free** |
| Surgery still needs a fixed time | Surgery (and confinement planning) is **arranged only by the staff or the vet** (customers cannot book it online) and keeps a **booked time** with the late alert (10 minutes) and auto-cancel (60 minutes). Vaccinations no longer do: they are a day registration in the same queue as check-ups |
| Slow counter check-in | **QR check-in**: the secretary scans the owner's QR; the visit is found instantly and the patient gets a queue number |
| The vet writes the bill on paper and the secretary retypes it | The vet fills a **charge sheet on a tablet** (medicines and services with prices), presses **Done**, and the secretary receives a ready bill |
| Payments are only cash and mistakes are hard to trace | **Split payments** (Cash, GCash, Card, Check), change calculation, receipts, check clearing (Pending, Cleared, Bounced) and a log of who changed what |
| Customers who cannot pay yet | A **balance** is tracked per customer, shown to staff, the vet (information only) and the owner, with ageing, statements and CSV. It never blocks service |
| Records scattered across paper files, written days later | One record per pet; each visit shows its **visit date**, can wait as a **Pending record** until the vet writes the findings, and is searchable in **General Records** by owner, pet or phone |
| No visibility for management | Admin account control, a filterable **audit log**, **Reports & Analytics** (money collected, outstanding balances, ageing), a product price list, and **Page Management** for the public homepage |
| Staff, vets and owners are not told what changed | **Notifications for every role** (bell, chime, toast) |
| Easy to forget vaccines and follow-ups | Next-vaccination dates are stored; a follow-up check-up is booked automatically on the calendar |

---

## 2. Architecture

```
 Customer site        Staff site         Vet site          Admin site
 (pet owners)     (front desk, payments)  (tablet)        (developer/admin)
      \                  |                  |                 /
       \                 |                  |                /
        +----------- one shared MySQL database (greenland_vet) -----------+
```

- Each site is a separate folder (and can be a separate domain). Each has its own `config.php`, login and session cookie, so a customer can never open a staff page.
- Technology: PHP 8 (PDO), MySQL/MariaDB, plain HTML/CSS/JavaScript. No frameworks.
- Roles live in one `accounts` table (`client`, `staff`, `vet`, `admin`). Each app only accepts its own role.
- The staff and vet apps share most pages and one `api.php`; what each role may do is decided on the server by `APP_ROLE`.
- Shared code (`schedule.php`, `billlib.php`, `authlib.php`, `layout.php`, `app.js`, `qr.js`, `qrread.js`, `style.css`) is the same in all four folders.

### Who does what

| Role | App | Main responsibilities |
|---|---|---|
| Pet owner (client) | Customer | View pets and records, register for a check-up or vaccination day, cancel or move to another day, show QR, see the live queue position and any unpaid balance, edit profile and pet photos |
| Staff (secretary at the front desk, with the receipt printer) | Staff | Register clients and pets, scan arrivals, run the queue, plan the duty roster, take payments and print receipts, follow customer balances, read General Records (read-only) |
| Veterinarian (tablet) | Vet | **My Patients** today, charge sheet with a running total, **Show customer** view, large **Done** button, write records (often at the end of the day), General Records with edit |
| Admin | Admin | Create/edit/disable accounts, reset passwords, audit log, products and prices, Page Management (CMS), Reports & Analytics, dashboard alerts |

All vets do all services. There are no specializations, no "can perform surgery" setting and no routing by specialty.

---

## 3. Setup (XAMPP)

1. Start **Apache** and **MySQL**.
2. phpMyAdmin → **Import** → `schema.sql` (creates the `greenland_vet` database). Optional: `demo_data.sql` for sample clients, pets, records and products.
   - Upgrading an older copy and keeping data: import `upgrade_from_previous.sql` (safe to run again). **Update 12 needs this upgrade (or a fresh `schema.sql`)**: it adds queue numbers, the duty roster, bills, split payments, balances, record dates and the edit history.
   - Optional test accounts: import `demo_accounts.sql` after the schema (or the upgrade). All accounts use the password `Demo@1234`; see **Demo accounts** in section 19.
3. Copy the app folders into `htdocs`: `greenland-admin`, `greenland-staff`, `greenland-vet`, `greenland-customer`.
4. The four `config.php` files already contain the team's MySQL password in `DB_PASS` (set once, so it does not have to be re-entered after each update). If your MySQL root password is different, change it in all four files; keep it the same in each.
5. Open `http://localhost/greenland-admin/setup.php` once and create the first admin (use a real email: it receives sign-in codes).
6. Sign in to the admin app → **Accounts → + Create Account** to create staff, vet and client accounts.

| App | Link |
|---|---|
| Customer | `http://localhost/greenland-customer/` |
| Staff | `http://localhost/greenland-staff/login.php` |
| Vet | `http://localhost/greenland-vet/login.php` |
| Admin | `http://localhost/greenland-admin/login.php` |

### Signing in

- Staff and vets: **branch + username + password**. Customers and admin: **username + password**.
- Every sign-in needs a **6-digit code sent to the account's email** (valid 10 minutes, 5 attempts). While email is not set up, `DEV_SHOW_CODE = true` shows the code on the verify page. Set it to `false` for real use.
- New accounts must choose their own password on first sign-in. Login errors say whether the username or the password is wrong, or whether the account is disabled.

### Online registration (pet owners)

1. On the customer site press **Create an account**: full name, email, username, password and preferred branch (contact number and address are optional).
2. The system emails a **6-digit code** to confirm the email. Until the code is entered the account is marked *Unverified* (Admin shows a tag).
3. When the code is accepted the owner is linked to the clinic's **existing client record with the same email** if staff already registered them (and that record has no account yet). Otherwise a new client record is created. The owner then sees their own pets.
4. An unfinished sign-up can be repeated with the same email or username, and unverified sign-ups are removed after 2 days.
5. Staff and admin can still create client accounts for owners who prefer to register at the clinic.

---

## 4. Features by app

### Staff app (front desk)
Menu: Dashboard, Clients, Appointments, **Queue**, **Confined**, **Billing**, **General Records**, Sales.
- **Dashboard:** KPIs (patients today, in the queue, confined, records still to finish; checks pending and records not yet written show only when there is something to do) and the calendar with the day's appointments. **No money is shown on the dashboard** (Update 19): the *Collected today* card and the *Billing* shortcut were removed, so nothing about money is visible on a screen a visitor could see. All the money figures are on the **Sales** page.
- **Sales (reformed in Update 19):** all the clinic's money in one place. Pick a period (*Today*, *Last 7 days*, *This month*, *Last month* or *Pick dates*) and a branch (own branch by default, or both). Cards: **Collected** (with up / down against the period before), **Collected online** (GCash), **Collected in clinic** (cash, card, checks), **Billed** (bills and items) and **Unpaid balances**. A **per-day bar chart**, a **payment-method breakdown** (with checks waiting to clear), an **Unpaid balances** panel (0 to 30 / 31 to 60 / over 60 days, and the customers who owe the longest, with *Open all balances*), and the **Sales history** (search by sale number, customer, pet or item; filter by status; balance column; click a row for the billing statement). Buttons for the Daily sheet and + New Sale.
- **Queue** (check-in page): scan or upload a QR, or search by owner, pet or phone; see the verification popup; give the queue number; the board with vets on duty, rooms and the waiting line (section 7).
- **Confined:** patients staying at the clinic with days so far and a running total; marks a patient referred from Taytay as **arrived**; can correct the number of days (logged). The queue board also shows the **Surgery Room** (section 12).
- **Duty roster:** who is on duty each day and each vet's weekly pattern (section 6).
- **Billing:** *Ready for billing* (bills sent by the vet), *Unpaid balances*, *Checks* and *All bills*; payment screen, receipts and printable statements (section 9).
- **General Records:** read-only view of every record of both branches (section 11).
- Clients and pets: list with search and pages, registration (optionally creating the client's portal account), profile with pets and recent records, a red **Owes ₱X** badge when the customer has an unpaid balance, pet profile popup and **Documents** card.
- Appointments: filters, 10 per page; approve, add notes, cancel (with a reason), reschedule (date only for check-ups) and delete (Pending or Cancelled only). New appointments for several pets and services at once.
- Sales (desk sales without a visit) with the product picker; they become a bill and are paid on the payment screen.
- **Daily sheet** (Sales → *Daily sheet*): the end-of-shift page for one day and branch: bills (owner, pet, service, items, total, paid), money collected by payment method, every payment line, and everyone scheduled or seen that day, with *Prepared by / Checked by* lines. It prints on A4 so the secretary can check the cash against the services.
- **Back** link at the top of every inner page of all four apps (returns to the previous page, or to the home page when there is none).
- The secretary **cannot write medical records** (`STAFF_CAN_EDIT_RECORDS = false` in `api.php`); she can mark a visit Done only as a fallback when the vet could not.

### Vet app (tablet)
Menu: **My Patients**, Queue, **Confined**, Appointments, Clients, General Records. Large, touch-friendly buttons.
- **My Patients today:** cards for the patients assigned to this vet (queue number or booked time, pet, owner, service, room, severity, state, bill status, "Owes" badge as information, Pending record badge). If the vet is marked not on duty, a banner offers **I am in today**.
- **Charge sheet:** starts with the service fee; the vet adds medicines and other services using large + and − buttons; the running total is always visible; changes save automatically.
- **Show customer:** a full-screen, large-print view of the items and the total to show the owner.
- **Done:** a large button with a confirmation summary (room and vet are freed, the bill goes to the front desk, the owner is told). After a check-up or a surgery it asks **What happens next?**: *Goes home* (optional follow-up day), *Confine now* or *Surgery* (section 12). Pressing it twice does nothing extra.
- **Confined:** the patients staying at the clinic; open the running charge sheet, write daily notes, change days, and **Discharge**.
- **Write record:** from the card or later in the day; the **visit date** comes from the visit, not from the day it is typed.
- No billing screen: the vet never takes payment.
- Can cancel only their own not-yet-started appointments, with a reason.

### Customer app
- **Pet records and prescriptions (Update 17):** owners see the **Prescription** on each check-up record. (The Pet Shop and My Orders pages added in Update 17 were **removed in Update 18**: the clinic does not need them yet.)
- **Public website (Update 16):** a real front page before login (banner, info strip, services, how it works, promos and items on sale, About, branches with map links, and a sign-up call to action), a Services page and a Contact page, all editable in Admin → Page Management. The login page is a split layout with a welcome panel and a *Back to the website* link; dark mode is available on every page.
- Public home page and contact page; online registration with email confirmation; login with username; forgot-password by email link.
- My Pets: **+ Add Pet** (a name and Dog/Cat are enough), photos, vaccine status, **next appointment with Show QR**, a **Details incomplete** badge, and an **unpaid balance banner** when the owner owes the clinic.
- **Request appointment** (vaccination or check-up only): choose pets and services, branch and date. For both only **the day is chosen** (no time) and a note explains "come any time that day until 5:00 PM, first come, first served". A pet can be registered for a check-up **and** a vaccination on the same day (one visit, one queue number, one wait); a second registration for the same service on the same day is refused. Several pets of one owner each take their own place. A "How it works" card explains the line, the cancel / change rule and what happens if the owner does not come.
- **Appointments:** Upcoming and Past. A check-up or vaccination shows "Any time", then its **queue number** after arrival, and **how many are ahead and the estimated wait**; the owner is told "It's your turn" and which room. Cancel, or move to another open day (date only, no time), **until arrival**.
- Read-only pet records, the Services page (the four services, promos from Page Management) and profile editing.

### Admin app
- Dashboard: account counts, **unpaid balances and records not yet written**, recent activity, shortcuts.
- Accounts: tabs for clients, staff and vets; search and filters; create, edit profile (vets need no extra settings), reset password, disable/enable.
- **Audit Log** with filters; **Sales** (Update 19, read only): the same money page as the staff app for both branches (collected, online vs clinic, billed, payment methods, per-day chart, unpaid balances, sales history); **Reports & Analytics** (section 13); **Page Management** (section 13).
- **Products:** add, edit the price, and hide or show a product. Vets add these to charge sheets and the front desk bills them. There is no quantity counting (removed in Update 18). **Page Management** edits the public homepage (banner, promos, about, footer).

---

## 5. Main workflows

**A. Online registration and registration for a visit.** Owner registers and confirms the email → adds a pet → Request Appointment → for a check-up or a vaccination picks the day and branch (no time) → a **QR code is shown immediately** (also under Appointments) → the front desk is notified. Registrations are accepted up to 30 days ahead and are confirmed on the day; unarrived registrations expire at closing time.

**B. Arrival.** The owner shows the QR → the secretary scans (or uploads) it → the **verification popup** shows who requested the visit, any **Owes ₱X** badge and what is incomplete → she completes pet details and documents if needed → **Check in**. A check-up gets the next **queue number** and joins the line; a timed visit goes straight to its vet and a free room. Simultaneous scans at the same branch are processed one at a time (a per-branch lock), so two patients never get the same vet or room.

**C. Being called.** The system calls the next patient (strict first come, first served) only when an **on-duty vet and a room are both free**. The owner's portal and the vet's bell say "Next patient: Bruno in Room 2". The room and vet are held until the vet presses **Done** (not by a timer).

**D. The visit.** The vet opens the patient on the tablet, which marks the patient as started, and the charge sheet (a draft bill prefilled with the service fee) is created. He adds medicines and services, can **Show customer**, and presses **Done**. The system then frees the vet and the room and calls the next patient, turns the bill into **Unpaid** under **Ready for billing** (the front desk bell chimes), notifies the owner, and makes the visit a **Pending record**. At **Done** the vet also says **what happens next** (goes home, confine now, surgery); the findings can still be written later.

**E. Payment.** The secretary opens the bill from *Ready for billing*, reviews the charges (any change is marked "changed by front desk", logged, and the vet is told), and takes payment with one or more lines (section 9). She prints the receipt.

**F. Records.** The vet writes the findings later in the day from **Pending records**; the visit becomes a **Completed** record with the visit date. Reminders appear on the vet's card, the staff dashboard and the admin dashboard while records are missing.

**G. Emergencies.** The secretary moves a case up the line with a **reason**. The move is logged and the admin is notified. Severity (Routine, Moderate, Severe) changes only the **waiting-time estimate**, never the order.

**H. Late and cancelled timed visits.** A surgery 10 minutes late: alert to the owner, staff and vet. After 60 minutes (about an hour) it is **auto-cancelled** and the slot is freed; a late arrival is checked in as a walk-in.

**I. Confinement and surgery.** The decision is made at Done, not when the record is written at the end of the day: *Confine now* admits the pet immediately (running bill, Confined list, owner told); *Surgery* either starts now in the surgery room or is booked for a later day and time. Taytay refers these patients to Cainta (section 12).

**J. Accounts.** Staff may create a client's portal account at registration, or admin creates any account. Admin can reset passwords, edit details and disable accounts.

---

## 6. Scheduling, the queue and the duty roster

### Check-ups: first come, first served
- A check-up is a **day registration**: `is_queue = 1`, no time (stored as `00:00:00` internally and shown as "Any time"). There is **no daily limit**.
- **Queue number** and arrival time are given when the QR is scanned. The order is strict first come, first served, with one exception: an **emergency** moved up by staff with a reason (`priority`, `priority_reason`).
- A patient is called only when an **on-duty vet and a free room** exist. The vet who gets the patient is the free vet who has seen the fewest patients that day (a preferred vet is used when free).
- If no vet or no room is free, nobody is called and the line simply waits (nobody jumps the line).
- **Last arrival 5:00 PM** (`QUEUE_LAST_ARRIVAL`; staff may override); everyone already waiting is still seen. Unarrived registrations **expire at closing**.
- **Same pet, two services:** a check-up and a vaccination for the same pet on the same day are one visit: they share one queue number, are called together (same vet and room, the estimate adds both lengths), and each keeps its own charge sheet and Done. Several pets of one owner are separate places in the line.
- **Estimates:** each check-up is assumed to last 60 (Routine), 90 (Moderate) or 150 (Severe) minutes (`SEVERITY_MINUTES`) and each **vaccination 15 minutes** (`SERVICE_MINUTES['Vaccination']`); the wait is shown as a range ("about 30 to 60 minutes"). They never change the order: **vaccinations and check-ups wait in the same line**, strictly by arrival, and only an **Emergency** (moved up by a person, with a reason) can go ahead. The check-in screen no longer asks "how serious" for a vaccination.
- All the queue logic is in one place (`queue_plan()` in `schedule.php`, a pure function) and is guarded by a per-branch MySQL named lock (`GET_LOCK('gv_q_<branch>')`).

### Timed services (surgery) and the queue services (Update 20)
| Setting | Default | Meaning |
|---|---|---|
| `CLINIC_OPEN` / `CLINIC_CLOSE` | 09:00 / 17:00 | Hours (9:00 AM to 5:00 PM, Mon–Sat, as the clinic said) |
| `QUEUE_SERVICES` | Vaccination, Check-Up | Services that are a **first come, first served day registration** (no time). Remove `'Vaccination'` to give vaccinations booked times again (Update 20) |
| `SLOT_MINUTES` | 15 | Slot size for the timed services |
| `CLOSED_DAYS` | `[0]` | Sunday closed |
| `SERVICE_MINUTES` | Vaccination 15, Check-Up 45, Confinement 30, Surgery 60 | How long a timed service blocks a vet; the **Vaccination** value is also the vaccination's length in the queue estimate |
| `ROOMS` | Room 1–3 | Exam rooms; at most this many visits at once |
| `SURGERY_ROOMS` | `['Surgery Room']` | The separate surgery room(s): one surgery at a time per room; a surgery uses no exam room |
| `MAIN_BRANCH` | Cainta | Confinement and surgery happen only here |
| `MIN_VETS_ON_DUTY` | Cainta 2, Taytay 1 | The roster and the Queue page warn when fewer vets than this are on duty (Taytay is a small wellness branch with 1 vet and 1 assistant) |
| `REFERRAL_REASONS` | X-ray, Ultrasound, Laboratory tests, Other diagnostics | What a Taytay vet can refer to Cainta (section 12) |
| `CONFINEMENT_DAILY_RATE` | 800 (placeholder) | Pesos per calendar day |
| `ONLINE_LEAD_MINUTES` / `ONLINE_CLOSE_BUFFER` | 60 / 60 | Online buffer before start and before closing (timed services only; not used by day registrations) |
| `MAX_BOOKING_ITEMS` | 6 | Pets or services in one booking |
| `LATE_ALERT_MINUTES` / `LATE_CANCEL_MINUTES` | 10 / 60 | Late alert and auto-cancel (**timed visits only**) |

- Surgery can only be booked at the main branch. A **confinement is not booked**: it starts when the vet decides it at Done.
- A time is free if at least one **on-duty** vet at that branch is free for the whole service and a room is free. A taken time returns the nearest free times.
- A booking with several pets or services is placed back to back in one transaction and cancelled or rescheduled together. A booking that mixes a check-up and a vaccination is split: the check-up has no time, the vaccination has its slot.
- Past times, closed days and (for owners) dates more than 30 days ahead are blocked on the form and again on the server.

### Duty roster
- Each branch has **2 to 4 vets** who rotate. The **Duty roster** page (staff app) shows Monday to Saturday for the week: tap a vet's cell to switch **In / Off** for that day, and set each vet's **weekly pattern** (the weekdays he normally works).
- Resolution for a vet on a date: a **day setting** wins; otherwise the **weekly pattern**; otherwise the vet is on duty (auto).
- The page warns when fewer than 2 vets are on duty. Only on-duty vets receive patients. A vet can also tap **I am in today** on the tablet.
- Changing the roster calls the queue again, so waiting patients are placed as soon as a vet becomes available. Visits already assigned to a vet who is switched off are moved to other vets where possible and the rest are flagged to staff.
- Tables: `vet_duty` (day settings) and `vet_duty_default` (weekly pattern). Earlier "not in today" days (`vet_off`) are carried over.

---

## 7. QR check-in and the Queue page

- Each appointment gets a random, unguessable token. The QR contains `GV:` plus that token only (no personal data). The owner can **Save to device** and reopen it under **Appointments → Show QR**.
- The secretary opens **Queue**, scans with the camera, uploads the saved picture (browser reader, then the built-in offline decoder `qrread.js`, then a CDN library) or searches the patient by owner, pet or phone.
- **Verification popup:** "QR code verified", who requested the visit, the pet, service and day, whether it was booked online, an **Owes ₱X** badge (information only), a warning when the visit is for another day or already cancelled, and **Not this person / Continue**.
- After check-in: a big **queue number**, the position and estimated wait, or "Called now" with the vet and room. Unfinished pet details can be completed and documents uploaded right there.
- **Board** (refreshes every 15 seconds): vets on duty and their state, rooms free or occupied, the waiting line (with severity, emergency marker and **Emergency** / **Severity** / assign buttons), patients in rooms, and late or auto-cancelled timed visits.
- Camera scanning needs `localhost` or HTTPS.

---

## 8. Booking policies, cancellations and notifications

### Cancellation and reschedule permissions

| Who | What they may do |
|---|---|
| **Pet owner** | Check-up or vaccination: cancel or move to another open day **until arrival** (date only, at most **2 reschedules**). Surgery and other timed visits: until **2 hours before**. Never after check-in |
| **Staff** | Cancel or reschedule **any** appointment that is not completed, with a reason; delete only Pending or Cancelled ones |
| **Vet** | Cancel only appointments **assigned to them** that have **not started**, with a reason |
| **System** | Auto-cancels a timed visit (surgery) 60 minutes late; expires unarrived check-up and vaccination registrations at closing. For a **missed vaccination day** the owner gets the message "You missed your vaccination day" asking them to register again for any open day (also sent by email, and by SMS when connected) |

All cancellations free the slot immediately and notify everyone concerned. Rules live in `config.php` (`OWNER_CANCEL_HOURS`, `MAX_RESCHEDULES`, `LATE_*`).

### Email and SMS to owners (Update 14)
Reminders, **late** alerts and **cancelled / lapsed** schedules are also sent to the owner outside the app, in the clinic's own wording: *"Hi <first name>, this is to inform you that your pet is scheduled: … We are open from 9:00 AM to 5:00 PM, Monday to Saturday. From Greenland Veterinary Care Center. This is an automated message. Do not reply. If you have concerns, message us at …"* (`owner_message_text()` in `authlib.php`).
- **Email** is sent now through PHP `mail()` (needs a mail server; see Limitations). **SMS** is built but **switched off**: set `SMS_ENABLED = true`, `SMS_PROVIDER` (an adapter for *semaphore* is included and has not been tested), `SMS_API_KEY`, `SMS_SENDER`, and add `'sms'` to `OWNER_MESSAGE_CHANNELS`.
- Every message is recorded in `message_outbox` (channel, recipient, text, status *Sent / Failed / Queued*, error). While SMS is off, SMS rows wait as *Queued*. A message problem never stops the clinic's work.
- Phone numbers come from the client and the owner's account; email addresses from the client and the owner's active accounts. `CLINIC_MESSAGE_CONTACT` is the "message us at …" line.

### Automatic timing
Late alerts, auto-cancel, reminders (2 hours before a timed visit; a "your visit is today" note for check-ups and vaccinations), expiry at closing and a "records to complete" reminder to vets run when any page polls for notifications (throttled to once every 30 seconds), so no background job is needed under XAMPP.

### Notification matrix (bell, chime and toast; polled every 15 seconds)

| Event | Owner | Staff (branch) | Vet | Admin |
|---|---|---|---|---|
| Online appointment requested | - | new request | assigned vet | - |
| Booked or scheduled by staff | yes | - | yes | - |
| Appointment approved | yes, "show your QR" | - | yes | - |
| Cancelled / rescheduled | yes | yes | assigned vet | - |
| Checked in | yes, with queue number | - | assigned vet: "Patient arrived" | - |
| **Called from the queue ("It's your turn")** | yes, with room | - | "Next patient: ..." | - |
| **Emergency moved up** | - | - | - | yes |
| Late alert / auto-cancel (timed) | yes | yes | yes | - |
| **Done pressed: "Ready for billing" (chime)** | "Visit finished, see the front desk" | yes | - | - |
| Done pressed by the front desk | - | - | "Please complete the record" | - |
| **Bill changed by the front desk** | - | - | yes | - |
| **Check bounced** | yes, balance due again | yes | - | yes |
| Records still missing | - | dashboard count | reminder | dashboard count |
| Vet marked off duty | "Your veterinarian changed" | lists visits still needing a vet | new vet: assigned | - |
| New online registration | - | yes | - | yes |
| **Confined now / referred from Taytay** | "is confined" or "please bring the pet to Cainta" | Cainta: new confined patient or incoming referral | Cainta vets | - |
| **Referred patient arrived** | - | - | deciding vet and Cainta vets | - |
| **Surgery decided** (now or scheduled) | yes, with date and place | Cainta | the surgeon | - |
| **Discharged** | "can go home" | "Ready for billing" | - | - |

---

## 9. Billing, payments, checks and balances

### Charge sheet (the vet) and bill (the front desk)
- Billing reuses `sales` and `sale_items` (the bill) plus `sale_payments` (each payment line). A bill moves through **Draft → Unpaid → Partially paid → Paid**.
- **Draft:** the vet's charge sheet, created the first time the sheet is opened for a visit and prefilled with the service fee (`SERVICE_FEES` in `config.php`, edit to the clinic's real fees). Medicines come from the product catalog and carry a `product_id`.
- **Done** turns the draft into **Unpaid** and sends it to *Ready for billing*.
- The front desk can edit an Unpaid bill; the bill is flagged **changed by front desk**, the change is logged, and the vet is told.

### Billing Statement, not an official receipt (Update 14)
The printed page is now titled **BILLING STATEMENT** and ends with **"This is not an official receipt."** (the statement of account has the same line). The header is the clinic name as text (no logo, as the client said). The consultation line is always called **Check-up Fee** (`FEE_NAMES`). Buttons and links that said *Receipt* now say *Billing statement*. The page file is still `receipt.php`.

### Taking payment (staff only)
- One or more **payment lines** per payment (split payments):
  - **Cash:** amount received and **change** are shown.
  - **GCash:** reference number.
  - **Card:** last 4 digits and approval code.
  - **Check:** bank, check number and check date. It is **Pending clearing** until marked **Cleared** or **Bounced** on Billing → Checks. A bounced check puts the amount back on the balance, alerts staff, the owner and admin, and is logged.
- The customer's **older unpaid bills** are listed with checkboxes, so one payment can settle them too; money is applied **oldest bill first**. A payment larger than the balance is refused.
- A receipt is printed per payment (grouped by `pay_group`) or per bill; it shows what is still owed. Receipts and statements **print across the full page** at a comfortable size (Update 13).
- A bill can be **Transferred**: a check-up bill added to a confinement or surgery bill is closed as Transferred (logged) and does not count as owed or as revenue (section 12).

### Unpaid balances
- A customer may owe money (partial payment or none). **Service is never blocked.**
- Shown as a red **Owes ₱X** badge on the client list and profile, in the QR verification popup, on the billing screen, on the vet's patient card (information only) and as a **banner in the customer portal**.
- Staff: **Billing → Balances** lists who owes how much, the oldest bill and **ageing** (0–30, 31–60, over 60 days), filterable and exportable to CSV; a **printable statement** per customer with a shortcut to take payment.
- Admin reports show **outstanding** and the ageing as well.

---

## 10. Stock (removed in Update 18)

Stock counting and restocking were **removed in Update 18** because they are not in the thesis paper and the clinic does not need them yet. The product list stays (name and price) so vets can add medicines and items to a charge sheet and the front desk can bill them, but nothing is counted, deducted, restocked or flagged as low. There is no Stock page, no low-stock card or alert, and the product pickers show only the name and price.

If inventory is wanted later it can be added back as a separate piece (quantity per branch, restock and adjust, a history, and low-stock alerts).

---

## 11. Records

- **Pending vs Completed:** a finished visit (Done pressed) whose findings are not typed yet is a **Pending record**; no placeholder rows are created. It becomes **Completed** when the vet saves the record. Pending visits show on the vet's card, the Pending tab of General Records and the dashboards.
- **Visit date:** records always show the **visit date** (the day of the visit), with the date the record was typed small and secondary (`recorded_at`, `recorded_by`). A visit's record cannot be given another date.
- **General Records:** one shared list for all vets of both branches, searchable by owner, pet or phone, with filters by type, vet, dates and Pending/Completed, and a **per-pet timeline** with the owner's balance. The secretary sees the same list **read-only**.
- **Edit:** every vet can edit any record (`VET_CAN_EDIT_RECORDS = true` in `config.php`; set it to `false` to switch editing off everywhere). Each edit is logged in `record_edits` (who, when, what changed) and the record shows **Edited by …**; the original author is told when someone else edits.
- **Check-up record (Update 14):** the fields the vets look at in one glance, typed as text with no extra clicking: **Chief Complaint**, History / Other Details, **Tests / Diagnostics Done**, **Results**, Clinical Findings, **Diagnosis**, **Prescription**, **Follow-up Date** and **Purpose of Follow-up**. The *Purpose* can also be typed at Done and becomes the reason of the follow-up registration (*"Follow-up: recheck wound"*). Older records keep their Details and Findings, which still show.
- **Vaccination visit with several items (Update 14):** a new vaccination record is a list of lines (*Type* Vaccine / Deworming / Tick and flea / Other, the name, and its own *Next schedule*) with **+ Add another**. One row is saved per line, all with the same visit date, so each item keeps its own due date. Editing a saved record edits one line. The owner's "next due / overdue" status uses the latest dose of each item.
- **Outcome (Update 14):** confinement and surgery records have an **Outcome** (*Survived* or *Died*). **Discharge** asks for it (required); if the pet died the owner gets a gentle message instead of "can go home" and no follow-up is booked. Surgery's outcome is chosen in the surgery record.
- **Back to charge sheet:** the record form of a visit has a *Back to charge sheet* button.
- The **Next Step** of a check-up is decided at **Done**; the Check-Up Record just repeats it (greyed out) and the follow-up day is not booked twice. Visits finished before Update 13 keep the old behaviour (Next Step on the record opens the matching form).
- Confinement records can be edited any time (daily notes, treatment); admission, discharge and status are set by the confinement itself.

---

## 12. Confinement, surgery and referrals (Update 13)

**Why:** records are written at the end of the day, so a pet that needs to stay or to be operated on could not be admitted or scheduled in time. The decision is now separate from the write-up.

### What happens next? (at Done)
Shown after a **check-up** (goes home / confine now / surgery) and after a **surgery** (goes home / confine now). Vaccinations go straight home. The choice is checked **before** anything changes, so a mistake leaves the visit open.
- **Goes home:** optional **follow-up check-up** day (a first-come-first-served registration; a closed day moves to the next open day; no duplicate).
- **Confine now:** the pet is admitted at once (see below). The exam room and vet are freed as usual.
- **Surgery:** *Start now* (only at Cainta, only if the Surgery Room and a vet are free; the surgeon list shows the **deciding vet first**, then other free on-duty Cainta vets) or *Another day or time* (the usual smart slot picker, Cainta only). Any free on-duty Cainta vet may operate.
- **The check-up bill:** *Pay it now* (goes to the front desk as usual) or *Add it to the confinement/surgery bill* (one payment at the end). In the second case the check-up bill is closed as **Transferred** (logged) and its total becomes one line on the new bill. The same choice applies at Cainta and Taytay.
- The check-up stays a **Pending record** with its Next Step already filled in.

### Confinement
- **Running charge sheet:** a Draft bill with a first line *Confinement (per day)* × days at `CONFINEMENT_DAILY_RATE` (placeholder ₱800). The vet adds medicines and other charges while the pet stays.
- **Days:** counted by **calendar day**; the admission day counts, so admitted Monday 4 PM and discharged Tuesday 10 AM is 2 days and a same-day discharge is 1 day. The vet or front desk can **overwrite the number of days** (or return to automatic); every change is logged.
- **No deposit:** everything is paid at **discharge**. **Discharge** (vet) closes the bill (it becomes *Unpaid* under Ready for billing, the owner is told, an optional follow-up check-up is booked). The daily notes can be written or edited any time on the Confinement record.
- **Confined page** (staff and vet): who is staying, days, running total, tags; the queue board and dashboards show the count. Pet owners see a banner on My Pets and Appointments.
- A pet that is staying never blocks the queue: cages are **not counted** by the system.

### Surgery
- One **Surgery Room** (`SURGERY_ROOMS`): one surgery at a time. A surgery uses the surgery room, **not** an exam room, so surgeries and check-ups do not block each other. The board shows the room as free or in use.
- A surgery is a normal visit with its own charge sheet and **Done** (then: goes home or confine now). Its appointment is created at once for *Start now* (already checked in, vet and room assigned) or booked for the chosen time.
- Surgery cannot be booked at Taytay, and a confinement is never booked in advance (the form no longer offers it).

### Referral for X-ray and other tests (Update 14)
Taytay is a wellness branch, so X-ray, ultrasound and laboratory tests are done at Cainta. At Done a Taytay vet can choose **Refer to Cainta for tests**: pick what the pet is referred for (`REFERRAL_REASONS`), the date at Cainta (today by default) and an optional note. The Taytay check-up bill is paid at Taytay as usual. The pet is put on the **Cainta check-up list for that day** (first come, first served, tagged *Referred from Taytay*), the owner is told where to go, and the Cainta front desk and vets are notified. The referral is written on the Taytay visit (`referral_reason`) and prefills the *Tests* field of the record.

### Taytay referrals
Taytay has no confinement or surgery, so a Taytay vet *refers* the patient to **Cainta**: the confinement or surgery is created at Cainta when the Taytay vet decides (days count from then) and carries a **Referred from Taytay** tag; Cainta's front desk and vets are notified and the owner is told to go to Cainta with the address. For a confinement the front desk marks **Mark arrived** (until then it cannot be discharged); a referred surgery is checked in with the QR as usual. Taytay staff see their referred patients on the Confined page.

---

## 13. Admin modules

### Reports & Analytics
Admin → **Reports**. Filter by date range and branch. KPIs: appointments booked (online vs. clinic), completed visits, cancellations, bills, **money collected** (cash, GCash, card and cleared checks only; checks not yet cleared are shown separately and not counted) and **outstanding ** with ageing. Charts: appointments per day, by service, by veterinarian, cancelled by and reasons, **money collected per day**, **collected by payment method** (from `sale_payments`) and a branch comparison. Every chart has tooltips and a **View table** switch; **Download CSV** exports the daily numbers.

### Page Management (CMS)
Edits the customer site's public pages: banner title, text and picture, the promo strip, items on sale (price, old price, picture, show/hide, order), the **Services heading and intro**, the About text and the **footer note** (Update 16). Stored in `cms_content` and `cms_items`; every change is logged.

### Audit Log
One table of actions with who, role, type and details; filters for who, type, date range and text. Check changes, payment changes, record edits and emergency moves are included.

---

## 14. Security notes

- Passwords are hashed with PHP `password_hash`; all database queries are prepared statements; output is HTML-escaped.
- Two-step sign-in code, limited attempts, expiring codes, session regeneration on login, a separate session cookie per app.
- Role checks on every API request: billing and balances are staff-only, records can be written only by vets, customers only see their own pets, appointments and balance.
- Payments are validated on the server (methods, amounts, check details, no overpayment); a double press of **Done** does nothing twice (idempotent), and queue operations run under a per-branch lock.
- Photos and pet documents are validated on the server; CMS pictures must be small JPEGs.
- **Idle sign-out (Update 17, customer app only since Update 18):** in the **customer app**, after `IDLE_LOGOUT_MINUTES` (30) without a click, key press or touch the owner is signed out; the server also refuses a session idle that long, and background polling from an idle tab does not keep it alive. **Staff, vet and admin are never signed out for being idle** (their `IDLE_LOGOUT_MINUTES` is 0), because the front desk and the vets keep the queue and charge sheets open all day.
- Admin actions, homepage edits, bill changes, payments and record edits are written to the audit log.

---

## 15. Data model (main tables)

| Table | Purpose |
|---|---|
| `accounts` | All logins: role, username, email, branch, status, email-verified flag, photo. (`can_operate` and `specialty` still exist as unused columns from earlier updates) |
| `clients`, `pets` | Owner and pet records |
| `appointments` | Date, time, service, vet, branch, status, source, QR token, check-in time, room, group token, **`is_queue`, `queue_no`, `severity`, `priority`, `priority_reason`, `called_at`, `done_at`, `done_by`, `record_done`**, late/reminder flags, cancel time/reason/by, reschedule count (`concern` is unused); **Update 13:** `next_step`, `followup_date`, `from_appt_id`, `referred_from` |
| `vet_duty`, `vet_duty_default` | Daily duty settings and the weekly pattern |
| *Update 14 columns* | `vaccinations.item_type`; `checkups.chief_complaint, tests, test_results, diagnosis, prescription, followup_purpose`; `confinements.outcome`, `surgeries.outcome`; `appointments.followup_purpose, referral_reason` |
| `vaccinations`, `checkups`, `confinements`, `surgeries` | Service records, now with `appt_id`, `recorded_at`, `recorded_by`, `edited_by`, `edited_at`. **Confinements also keep** `branch`, `vet`, `from_appt_id`, `admitted_at`, `discharged_at`, `daily_rate`, `days_override`, `sale_id` (the running bill), `rate_item_id`, `referred_from`, `arrived_at` |
| `record_edits` | Edit history of records |
| `message_outbox` | Every email / SMS sent to an owner (channel, recipient, kind, text, status, error) |
| `sales`, `sale_items` | Bills (`status`, `paid`, `appt_id`, `prepared_by`, `ready_at`, `desk_changed`, **`service`, `transferred_to`**) and their items (`product_id`). A running confinement bill is a **Draft** sale until discharge |
| `sale_payments` | Payment lines: method, amount, cash received, reference, bank, check number/date/status, `pay_group`, taken by |
| `products` | Catalog: name, price, active (the list vets and the front desk bill from) |
| `verifications`, `password_resets` | Sign-in codes and reset links |
| `activity_log` | The audit log |
| `notifications` | Per-account notifications |
| `pet_documents` | Birth certificate, vaccination card and other uploads |
| `cms_content`, `cms_items` | Public homepage text and promos |

---

## 16. Configuration (`config.php`)

`DB_*` database login · **`IDLE_LOGOUT_MINUTES`** (customer app: 30; staff, vet and admin: 0 = never signed out for being idle)  · **`ONLINE_PAY_METHODS`** (in `billlib.php`; payment methods counted as *online* on Sales and the Daily sheet, `['GCash']` by default)  · `MAIL_FROM`, `DEV_SHOW_CODE` · `SITE_URLS` · `BRANCHES` · `SERVICES` · `REQUESTABLE` (what owners can book online) · `ROOMS`, `SERVICE_MINUTES`, hours and buffers (section 6) · **`QUEUE_SERVICES`** (services that are first come, first served) · **`SEVERITY_MINUTES`** · **`QUEUE_LAST_ARRIVAL`** · **`SERVICE_FEES`** (set in the staff **and** vet apps) · **`VET_CAN_EDIT_RECORDS`** · **`MAIN_BRANCH`**, **`CONFINEMENT_DAILY_RATE`**, **`SURGERY_ROOMS`** (all four apps' `config.php`) · Update 14: **`MIN_VETS_ON_DUTY`**, **`REFERRAL_REASONS`**, **`SMS_ENABLED`**, **`SMS_PROVIDER`**, **`SMS_API_KEY`**, **`SMS_SENDER`**, **`OWNER_MESSAGE_CHANNELS`**, **`CLINIC_MESSAGE_CONTACT`** (all four apps) · cancel rules (section 8). In `api.php` (staff and vet): `STAFF_CAN_EDIT_RECORDS = false`.

---

## 16a. Look-and-feel switches (Update 15)

All of Update 15 is **additive and removable**. Three constants at the end of each `config.php` control it, and the code falls back to the previous look when a switch is off:

| Constant | Staff | Vet | Admin | Customer | What it does |
|---|---|---|---|---|---|
| `UI_UPGRADE` | true | true | true | true | Master switch: loads `ui14.css` and `ui14.js` (pet avatars, status colours, KPI icons and trends, calendar dots, pet timeline, login polish, two extra report charts). |
| `UI_DARK_MODE` | true | true | true | true | Moon / sun button in the top bar; the choice is remembered in the browser. Needs `UI_UPGRADE`. |
| `UI_NOW_SERVING` | true | false | false | false | Staff only: a **Now serving** card on the dashboard and a small collapsible panel on the other staff pages (see section 21). Needs `UI_UPGRADE`. |

**To remove a piece completely:** set its switch to `false`, then (optionally) delete the files named in section 21. Nothing in the database changed for Update 15, so nothing has to be undone there.

---

## 17. Limitations and assumptions

- The clinic treats **dogs and cats**; the pet form still lists other species.
- Email uses PHP `mail()`; a real SMTP service is needed for production. SMS is built but off until a service is chosen (section 8). No online payment gateway (GCash and card payments are recorded by the secretary, not processed).
- Each vet works at one branch. Timed services have a fixed length.
- Timed automations (late alerts, expiry, reminders) run when someone's browser polls; if no page is open nothing runs until the next visit.
- Waiting-time estimates are rough ranges based on the three severity lengths.
- Vaccinations join the same queue as check-ups (Update 20). The clinic gives the owner a **date only** for a repeat vaccine, so the next-due dates stay as reminders. If the clinic later wants a separate vaccination line, that would be a separate change.
- Moving a severe case to another room while patients are in rooms is not built; it is an open question for the client.
- Online registration has no CAPTCHA or rate limiting; pet documents are stored in the database.
- **Secretary's day off:** the secretary is off on Thursdays. The system does not yet let anyone else take payment that day; the client should say who covers (another front-desk account, or vets). Open question.
- **Open questions for the client** (placeholders in `config.php`): the real **daily confinement rate** and how days are counted (now calendar days, admission day counts, same-day discharge = 1 day), whether a **deposit** is taken, and how many **surgery rooms** there are (now one). A "Pay now" check-up bill moved to a Cainta bill keeps its stock deduction at the branch where it was made.
- **This update was verified with syntax checks, logic tests of the queue planner, duty roster, day counting and the surgery-room rules (52 checks in total: the earlier queue and duty-roster tests, 13 for Update 13 and 14 for Update 14: 15-minute vaccinations, 9 to 5 hours, per-branch minimum vets and the owner message wording) and mock renders of the new screens, the billing statement and the daily sheet; it has not yet been run end to end against a real MySQL database and browsers.** Test with the demo accounts first.

---

## 18. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| "Access denied for user 'root'" | Put the MySQL password in `DB_PASS` in that app's `config.php` |
| Login does nothing or goes to `/undefined` | Output before the reply (a BOM or blank line in `config.php`). Save as UTF-8 **without** BOM |
| Verification code never arrives | Email is not configured. Keep `DEV_SHOW_CODE = true` for testing |
| Camera will not start | Use `localhost` or HTTPS and allow the camera, or upload the QR picture |
| No notification sound | Click anywhere on the page once; browsers block sound until then |
| Old pages after an update | Hard refresh (Ctrl+F5) |
| Pages or buttons fail after updating to Update 12 | The database was not upgraded: import `upgrade_from_previous.sql` (or recreate with `schema.sql`) |
| A patient is never called | Check that a vet is **on duty** (Duty roster), that a room is free, and that the earlier patients were marked **Done** |
| "The queue is busy for a moment" | Another check-in was running at the same moment; try again |
| A check is still counted as owed | It stays "Pending clearing" until marked Cleared on Billing → Checks |
| Vets cannot edit records | `VET_CAN_EDIT_RECORDS` is `false` in `config.php` |

---

## 19. Demo accounts (for testing)

Import `demo_accounts.sql`. Password for every account: **`Demo@1234`** (the sign-in code is shown on screen while `DEV_SHOW_CODE` is true).

| App | Branch | Username | Name | Notes |
|---|---|---|---|---|
| Admin | - | `admin.demo` | Demo Admin | Accounts, Audit Log, Reports, Sales, Products, Page Management |
| Staff | Cainta | `staff.cainta` | Ana Reyes | Front desk |
| Staff | Taytay | `staff.taytay` | Ben Lim | Front desk |
| Vet | Cainta | `dr.gian` | Dr. Gian Santos | Weekly pattern Mon, Tue, Thu, Sat |
| Vet | Cainta | `dr.mae` | Dr. Mae Villanueva | Mon, Wed, Fri |
| Vet | Cainta | `dr.paolo` | Dr. Paolo Cruz | Tue, Wed, Fri, Sat |
| Vet | Cainta | `dr.lea` | Dr. Lea Navarro | Mon, Thu, Fri, Sat |
| Vet | Taytay | `dr.ken` | Dr. Ken Ramos | Every day (no pattern) |
| Vet | Taytay | `dr.ana` | Dr. Ana Lopez | Every day (no pattern) |
| Pet owner | - | `maria.santos` | Maria Santos | Pets Bruno (details incomplete) and Mochi |
| Pet owner | - | `juan.delacruz` | Juan Dela Cruz | Pet Kiko; **owes ₱800** from an old bill |

The import also sets Gian, Mae, Ken and Ana on duty for today so the queue works on any weekday, adds products (name and price) and today's appointments: check-ups for Bruno (Cainta) and Kiko (Taytay) and Mochi's vaccination (a day registration, no time).

Quick tests: (1) scan Bruno's QR as `staff.cainta` and see the queue number; (2) check in more patients and move one up as an **Emergency**; (3) as `dr.gian` open **My Patients**, add Amoxicillin to the charge sheet, **Show customer**, **Done**; (4) as staff open **Billing → Ready for billing**, take a split payment (Cash + GCash) or a Check; (5) see Juan's **Owes ₱800** badge, the Balances list and his portal banner; (6) change today's roster and watch only on-duty vets get patients; (7) write a pending record and edit it as another vet; (8) leave Mochi's vaccination unarrived for 10 and 30 minutes. The same list is in `DEMO_ACCOUNTS.md`.

---

## 20. Change log

| # | Update |
|---|---|
| 1 | First staff dashboard and client management (started in Node, moved to PHP/MySQL as the school requires); staff accounts instead of one shared login |
| 2 | Redesigned to match the Figma (sidebar layout, clinic logo, green palette); sizes scale with the screen |
| 3 | All staff screens: pets, appointments, records (vaccination, check-up, confinement, surgery), sales and receipts |
| 4 | Fresh `greenland_vet` database; sign-in by branch and username with an emailed 6-digit code; Admin app (accounts, reset, disable); Customer app |
| 5 | Check-up flow: next step, confinement/surgery popup, automatic follow-up booking, billing with products, printable receipt |
| 6 | Searchable client picker, 10-per-page lists, date limits, notification bell with sound, profiles with photos |
| 7 | Appointment approval and clickable appointments, customer username login, client portal accounts created by staff |
| 8 | Admin activity log, editing of profiles and pets, products page; customers edit their profile and pet photos; online booking limited to vaccination and check-up |
| 9 | **Smart scheduling**, **QR check-in**, staff and vet separated again, system documentation |
| 10 | **Online customer registration** with email confirmation, add-a-pet with partial details, booking for a new pet, reminder to complete pet details at check-in, "Unverified" tag in Admin |
| 11 | Smart vet and room scheduling, specializations and routing, surgery scheduling after a check-up, QR verification popup and working QR upload, pet documents, notifications for every role, cancel and reschedule rules, late alert and auto-cancel, booking buffers, multi-pet booking, audit log, Page Management, Reports & Analytics, demo accounts |
| 12 | **Queue and operations redesign.** Check-ups are first come, first served with QR queue numbers, per-branch locking, emergency move-up with a logged reason and severity-based waiting estimates; patients are called only when an **on-duty vet and a room** are free and are released on **Done**. **Duty roster** (daily and weekly pattern) replaces specializations and surgery routing (removed everywhere). **Vet tablet:** My Patients, charge sheet with running total, Show customer, large Done with confirmation. **Billing:** bills from charge sheets, split payments (Cash, GCash, Card, Check with clearing), receipts, desk edits logged. **Unpaid balances** with badges, ageing, statements and CSV; never blocks service. **Stock per branch** with automatic deduction, alerts and history. **Records:** Pending vs Completed, visit dates, General Records for all vets (staff read-only), edit with history, reminders. Customer portal (day registration, queue position, balance banner), admin (products with stock per branch, dashboard alerts, reports of money collected and outstanding), demo data. No AI features. |
| 13 | **Confinement, surgery and referrals.** A **"What happens next?"** step at Done (goes home with optional follow-up / confine now / surgery now or on another day) replaces the end-of-day popups; the record repeats the decision. **Confinement** starts immediately with a running bill (daily rate × calendar days, editable and logged), a **Confined patients** page for vets and front desk, owner banner, and **Discharge** that closes the bill (paid at discharge). A separate **Surgery Room** (one surgery at a time, any free on-duty Cainta vet, deciding vet offered first). **Taytay referrals** to Cainta with a "Referred from Taytay" tag and a Mark arrived step; the check-up bill can be paid now or added to the Cainta bill (closed as Transferred, logged). Confinement is no longer bookable and surgery only at Cainta. **Also:** text and headings toned down on every screen of all four apps (customer bill popup, KPI numbers, tablet buttons, dialogs), and receipts and statements now **print across the full page** at a larger size. Config: `MAIN_BRANCH`, `CONFINEMENT_DAILY_RATE`, `SURGERY_ROOMS`. Database: run `upgrade_from_previous.sql` (new columns on `appointments`, `confinements`, `sales`). |
| 14 | **Client interview changes.** Vaccinations last 15 minutes (booked times every 15 minutes) and hours are 9:00 AM to 5:00 PM; Taytay's minimum is 1 vet (`MIN_VETS_ON_DUTY`); the consultation line is **Check-up Fee**. **Records:** a fuller check-up record (chief complaint, tests, results, diagnosis, prescription, follow-up date and purpose), vaccination visits with several items each with its own next schedule, **survived / died** outcome on confinement (asked at Discharge) and surgery. **Referral** of Taytay patients to Cainta for X-ray, ultrasound and lab tests, decided at Done. **Printing:** the receipt becomes a **Billing Statement** with "This is not an official receipt", plus a printable **Daily Sales Sheet**. A **Back** link on every inner page and a *Back to charge sheet* button on the record form. **Messages:** reminders, late and lapsed schedules go out by email in the clinic's wording and an SMS layer is ready (off until a service is chosen); everything is logged in `message_outbox`. Run `upgrade_from_previous.sql` (new columns and table). |
| 15 | **Look-and-feel upgrade.** Staff dashboard calendar: **today ringed** and **one coloured dot per service** (green vaccination, blue check-up, purple confinement, orange surgery) with a legend. **Pet avatars** (photo, or a coloured circle with the first letter and a dog / cat / paw mark) on the queue board, vet cards, bills, confined list, client and pet pages and search results. **One set of status colours** in all four apps (waiting amber, in a room teal, done green, confined purple, emergency red, referred blue) as a dot on badges and a coloured left edge on queue rows, vet cards and confined cards, with a legend on the queue board. **KPI cards** with an icon on staff and vet dashboards, plus two new staff cards, *Patients today* and *Collected today*, each with an up / down comparison with the same weekday last week and a 7-day line. **Now serving** (staff): a dashboard card with each room (queue number, pet, owner, vet, time in room) and the next five in line with estimated waits, plus a small collapsible panel on every other staff page that highlights "#5 Rex: go to Room 2" when someone's turn comes (optional chime, off by default). **Pet timeline** with syringe, stethoscope, bed and scalpel icons on a vertical line (Timeline / Table switch). **Dark mode** for staff and vet. **Admin reports:** two more charts (*Busiest days of the week*, *Vaccinations coming due in the next 14 days*) next to the existing eight. **Login polish:** gradient, paw pattern, dog and cat drawing, softer card. Small fix: the dashboard cards were underlined links. No database change. Config: `UI_UPGRADE`, `UI_DARK_MODE`, `UI_NOW_SERVING`. |
| 16 | **Bigger text, website, dark mode, online sales (Update 16).** Text and spacing are about 10% larger in all four apps (base size now scales gently with the screen, about 15 to 18 px). The staff dashboard no longer shows **Ready for billing** or **Customers owe** (privacy); the Billing page keeps them. **Sales** and the **Daily sheet** now show money **collected online (GCash)** separately from money **collected in the clinic**. **Dark mode** now also works in the customer and admin apps. The **customer app has a real website** as its front page (hero, services, how it works, promos, About, branches with map links, footer) and a new **split login page**; Page Management gained *Services heading*, *Services intro* and *Footer note*. No database change. |
| 17 | **Pet Shop, owner prescriptions, auto sign-out (Update 17).** The Pet Shop and Orders part of this update was **removed in Update 18**. Owners now see the **Prescription** on check-up records. **30-minute idle sign-out** (customer app only since Update 18). **Show / hide password** on every password box. Login page: one **Back to website** button at the top left and a larger card. The website shows **Open now / Closed now** from the clinic hours. |
| 18 | **Shop and stock removed, idle sign-out for owners only (Update 18).** The **Pet Shop**, **My Orders**, the staff **Orders** page, the shop settings in Page Management and the shop fields on Products were removed, together with the whole **inventory** part: the **Stock** page, restocking and adjusting, stock history, low-stock alerts and dashboard cards, stock deduction when a vet presses Done, and the quantity and alert-level fields on Products. Products keep only a name, a price and available / hidden, and billing works as before without counting. The staff dashboard's last card is now **Records to finish** instead of Low stock. The **idle sign-out** now applies to the **customer app only**; staff, vet and admin are not signed out for being idle. The `orders`, `order_items`, `order_log`, `product_stock` and `stock_log` tables and the extra `products` and `sale_items` columns are no longer created by `schema.sql` or `upgrade_from_previous.sql`; a database that already has them keeps them harmlessly (they are not used). |
| 19 | **Money moved to Sales, fluid sizes, tablet and phone (Update 19).** The staff dashboard shows **no money** (the *Collected today* card and the *Billing* shortcut are gone, and the dashboard API no longer sends money numbers). The **Sales** page was rebuilt (periods, branch filter, collected / online / in clinic / billed / **unpaid balances**, per-day chart, payment methods, unpaid balances panel, sales history) and the **admin app has a matching read-only Sales page**. The informal word for unpaid balances was removed from every label (the pages say **Unpaid balances**). **Text size** is now a calm fluid scale (about 14 px on small screens up to 16 px on a full-HD monitor; larger only on very big or 4K screens), the page content is capped on very wide screens, and a **login layout bug** (the welcome panel squeezed to a thin strip on large screens) was fixed. All four apps now **adapt to tablets and phones**: below about 1080 px the menu becomes a slide-out drawer (button in the top bar), grids stack, tables scroll sideways on phones, forms and buttons get larger touch targets on touch screens, and the login page shows the form first. No database change. |
| 20 | **Vaccinations join the queue (Update 20, with a follow-up the same day).** A check-up and a vaccination for the same pet on the same day are allowed and are one visit (one queue number); surgery's auto-cancel is now **60 minutes** (`LATE_CANCEL_MINUTES`); customers still cannot book surgery or confinement online (only the staff and vets arrange them). **Vaccinations join the queue.** Vaccinations are now **first come, first served** like check-ups: the owner registers for a **day** (no booked time), is scanned at the front desk, gets a queue number and waits in the **same single line** (strict order of arrival; only an Emergency can move up). The estimate treats a vaccination as **15 minutes** instead of about an hour, and the check-in screen skips the severity question for it. **Cancel / change:** the owner can cancel or move to another open day until arrival. **If the owner never comes** the registration expires at closing time (5:00 PM) and the owner is sent a *"You missed your vaccination day"* message to register for another open day. The late alert (10 min) and auto-cancel (60 min) now apply to **surgery only**. Vaccine next-due dates and reminders are unchanged (date only). It is one switch: `QUEUE_SERVICES` in `config.php` (remove `'Vaccination'` to bring booked times back). `upgrade_from_previous.sql` converts upcoming booked vaccinations to day registrations; the demo data and `DEMO_ACCOUNTS.md` follow. Tests: 38 checks for this update. |

---

## 21. Update 15: what was added, and how to remove each piece

| Piece | Files | Switch off | Remove completely |
|---|---|---|---|
| Everything visual (avatars, status colours, KPI icons / trends, calendar dots, timeline, login polish, 2 extra charts) | `ui14.css`, `ui14.js` in each app | `UI_UPGRADE = false` | Delete those two files and the `UI_*` lines in `config.php`. `app.js` keeps small helpers that return nothing when `ui14.js` is missing. |
| Dark mode (all four apps) | `ui14-dark.css` | `UI_DARK_MODE = false` | Delete `ui14-dark.css`. |
| Customer website and split login (Update 16) | `greenland-customer/index.php`, `pub.php`, the website part at the end of `style.css`, `BRAND_*` lines and `AUTH_LAYOUT` in `config.php` | Restore the previous `index.php` / `config.php` values | The Page Management fields stay useful for the Services and Contact pages. |
| Idle sign-out (Update 17) | end of `app.js`, `authlib.php`, `IDLE_LOGOUT_MINUTES` in each `config.php` | Customer app 30; staff, vet and admin 0 (off). Set the customer value to 0 to turn it off everywhere | Nothing to delete. |
| Online / in-clinic sales split (Update 16) | `ONLINE_PAY_METHODS` in `billlib.php`, `sales.php`, `daily.php`, `api.php` | Set `ONLINE_PAY_METHODS = []` (online shows 0) | Remove the two stat cards. |
| Now serving (card + panel) | part of `ui14.js` / `ui14.css`; slot in `greenland-staff/index.php` | `UI_NOW_SERVING = false` | Nothing to delete; the switch hides it. |
| Extra data for the cards | `api.php` routes `appointments/mix`, `nowserving`, the `trend` part of `dash`; `species` added to queue and bill queries | Not needed (harmless when unused) | Leave in place. |

**Notes.**
- **Pet avatars use the species only in lists** (no photos), so pages stay fast. The photo shows on the pet's own page and timeline when one was uploaded.
- **Now serving is for staff only** (it shows owner names, so there is no public screen; the clinic has no TV). It refreshes every 15 seconds. The corner panel remembers whether it was open; it opens by itself for about 12 seconds when a new patient is called. The chime works only after you press *Sound off / on* once (browser rule) and is off by default. The panel is not shown on the Queue page, which already has the full board.
- **Trend cards** compare today with the same weekday last week; they show nothing if the database is older and lacks the needed columns.
- The report charts that already existed (daily appointments, by service, by vet, cancellations and reasons, money per day, payment methods, branch table) were kept; Update 15 added two.
- **Not tested** on a real MySQL server or in real browsers: the checks were PHP lint, script checks, the logic tests, and mock-data renders in Chromium (light and dark).

- **Update 16 notes.** *Online* means the methods listed in `ONLINE_PAY_METHODS` (GCash). The Sales "today" cards ignore the date picker and cover both branches (as before). **Owes** amounts still appear on the staff Billing and Clients pages and in client search (only the dashboard cards were removed); tell me if those should be hidden too. *Now serving* shows the owner's name next to the pet; a pet-name-only option can be added. The customer website was checked with mock renders in light and dark, not on a live server.
